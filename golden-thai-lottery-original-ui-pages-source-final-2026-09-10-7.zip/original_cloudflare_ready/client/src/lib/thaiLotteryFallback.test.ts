import { describe, expect, it } from "vitest";
import { FALLBACK_THAI_DRAW_2026_09_16, withThaiLotteryFallback } from "./thaiLotteryFallback";

describe("September 16 Thai lottery fallback", () => {
  it("contains every 4th and 5th prize number", () => {
    expect(FALLBACK_THAI_DRAW_2026_09_16.fourthPrize).toHaveLength(50);
    expect(FALLBACK_THAI_DRAW_2026_09_16.fifthPrize).toHaveLength(100);
  });

  it("replaces an incomplete result with the verified complete draw", () => {
    const draw = withThaiLotteryFallback({
      drawDate: "2026-09-16",
      firstPrize: "730640",
      fourthPrize: [],
      fifthPrize: null,
      source: "database",
    });

    expect(draw.fourthPrize).toHaveLength(50);
    expect(draw.fifthPrize).toHaveLength(100);
    expect(draw.firstPrize).toBe("730640");
    expect(draw.lastTwoDigits).toBe("64");
  });
});
