export type ThaiLotteryDraw = {
  id: number;
  drawDate: string;
  firstPrize: string;
  nearFirstPrize: string[];
  firstThreeDigits: string[];
  lastThreeDigits: string[];
  lastTwoDigits: string;
  secondPrize: string[];
  thirdPrize: string[];
  fourthPrize: string[];
  fifthPrize: string[];
};

export const FALLBACK_THAI_DRAW_2026_09_16: ThaiLotteryDraw = {
  id: 20260916,
  drawDate: "2026-09-16T00:00:00.000Z",
  firstPrize: "730640",
  nearFirstPrize: ["730639", "730641"],
  firstThreeDigits: ["060", "521"],
  lastThreeDigits: ["266", "041"],
  lastTwoDigits: "64",
  secondPrize: ["624884", "279762", "971641", "047801", "272404"],
  thirdPrize: ["727907", "009956", "170127", "314626", "810768", "945207", "389202", "043192", "383963", "532193"],
  fourthPrize: [
    "496192", "116896", "305498", "806175", "945595", "026416", "686280", "314812", "836570", "863204",
    "619908", "997528", "369432", "317305", "731184", "736281", "499284", "011269", "083625", "849062",
    "960055", "602647", "073134", "056075", "183278", "379276", "989427", "238182", "996779", "161593",
    "107564", "335550", "907080", "199464", "652629", "188294", "490849", "225368", "754154", "716047",
    "998848", "590990", "715042", "068732", "761793", "447358", "359099", "587516", "697921", "182133",
  ],
  fifthPrize: [
    "817591", "887425", "490783", "432927", "298384", "432597", "265848", "766375", "369167", "796518",
    "962037", "180381", "721670", "017356", "875108", "543883", "646789", "705684", "399048", "409868",
    "482303", "675564", "439007", "796601", "850833", "909580", "114836", "423853", "505062", "253810",
    "720849", "455376", "409856", "065186", "725730", "415475", "346405", "637646", "449650", "626938",
    "186375", "655867", "941080", "834409", "343872", "208711", "978824", "610545", "840117", "462973",
    "528188", "825874", "631211", "280097", "737516", "302425", "626919", "717854", "335849", "314684",
    "593001", "596643", "909007", "646309", "741336", "333912", "883233", "866319", "015005", "208385",
    "188483", "055829", "973869", "365660", "839642", "267948", "123069", "804785", "731010", "863144",
    "180691", "372657", "195753", "419087", "315409", "294241", "708131", "942510", "673232", "247173",
    "242012", "186551", "303346", "477420", "068583", "778031", "667737", "212572", "958869", "351353",
  ],
};

export function isCompleteThaiLotteryDraw(draw: any): draw is ThaiLotteryDraw {
  return !!draw && /^\d{6}$/.test(draw.firstPrize ?? "") &&
    /^\d{2}$/.test(draw.lastTwoDigits ?? "") &&
    Array.isArray(draw.firstThreeDigits) && draw.firstThreeDigits.length >= 2 &&
    Array.isArray(draw.lastThreeDigits) && draw.lastThreeDigits.length >= 2;
}

export function withThaiLotteryFallback(draw: any): ThaiLotteryDraw {
  return isCompleteThaiLotteryDraw(draw) ? draw : FALLBACK_THAI_DRAW_2026_09_16;
}

export async function fetchLatestThaiLottery(): Promise<ThaiLotteryDraw> {
  const response = await fetch("/api/lottery/latest", { cache: "no-store" });
  if (!response.ok) throw new Error(`Lottery API ${response.status}`);
  const draw = await response.json();
  if (!isCompleteThaiLotteryDraw(draw)) throw new Error("Incomplete lottery result");
  return draw;
}
