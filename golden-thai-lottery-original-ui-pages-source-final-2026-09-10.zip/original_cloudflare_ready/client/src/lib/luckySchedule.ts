export const MYANMAR_UTC_OFFSET_MS = 6.5 * 60 * 60 * 1000;

/** Returns a UTC-backed Date whose UTC parts represent Myanmar local time. */
export function getMyanmarDate(now: Date = new Date()): Date {
  const shifted = new Date(now.getTime() + MYANMAR_UTC_OFFSET_MS);
  return new Date(Date.UTC(
    shifted.getUTCFullYear(),
    shifted.getUTCMonth(),
    shifted.getUTCDate(),
    shifted.getUTCHours(),
    shifted.getUTCMinutes(),
    shifted.getUTCSeconds(),
  ));
}

export function isMyanmarMarketDay(myanmarDate: Date): boolean {
  const day = myanmarDate.getUTCDay();
  return day !== 0 && day !== 6;
}

/** -1 means no Lucky 2D is available yet or the market is closed. */
export function getLucky2DSessionIndex(myanmarDate: Date): number {
  if (!isMyanmarMarketDay(myanmarDate)) return -1;
  const minutes = myanmarDate.getUTCHours() * 60 + myanmarDate.getUTCMinutes();
  if (minutes >= 15 * 60 + 30) return 1;
  if (minutes >= 10 * 60 + 30) return 0;
  return -1;
}

export function getLucky2DPeriod(myanmarDate: Date): string {
  const dateKey = `${myanmarDate.getUTCFullYear()}-${myanmarDate.getUTCMonth()}-${myanmarDate.getUTCDate()}`;
  const session = getLucky2DSessionIndex(myanmarDate);
  return `${dateKey}-${session < 0 ? "closed" : `s${session}`}`;
}

function getLuckyDateKey(myanmarDate: Date): string {
  return `${myanmarDate.getUTCFullYear()}-${myanmarDate.getUTCMonth()}-${myanmarDate.getUTCDate()}`;
}

/**
 * The latest Lucky 2D content remains current until a following 10:30 or
 * 15:30 weekday session. This prevents a badge from returning at midnight.
 */
export function getCurrentLucky2DContentPeriod(myanmarDate: Date): string {
  const activeSession = getLucky2DSessionIndex(myanmarDate);
  if (activeSession >= 0) return `${getLuckyDateKey(myanmarDate)}-s${activeSession}`;

  const previousMarketDay = new Date(Date.UTC(
    myanmarDate.getUTCFullYear(),
    myanmarDate.getUTCMonth(),
    myanmarDate.getUTCDate(),
  ));
  do {
    previousMarketDay.setUTCDate(previousMarketDay.getUTCDate() - 1);
  } while (!isMyanmarMarketDay(previousMarketDay));

  return `${getLuckyDateKey(previousMarketDay)}-s1`;
}

const FIXED_3D_DRAW_DAYS = [5, 15, 20];

export function getLucky3DDrawDays(myanmarDate: Date): number[] {
  const lastDay = new Date(Date.UTC(
    myanmarDate.getUTCFullYear(),
    myanmarDate.getUTCMonth() + 1,
    0,
  )).getUTCDate();
  return [...FIXED_3D_DRAW_DAYS, lastDay];
}

/** Keeps the same 3D period number until the next scheduled date. */
export function getCurrentLucky3DDrawDate(myanmarDate: Date): Date {
  const drawDays = getLucky3DDrawDays(myanmarDate);
  const day = myanmarDate.getUTCDate();
  for (let index = drawDays.length - 1; index >= 0; index--) {
    if (day >= drawDays[index]) {
      return new Date(Date.UTC(myanmarDate.getUTCFullYear(), myanmarDate.getUTCMonth(), drawDays[index]));
    }
  }

  const previousMonth = new Date(Date.UTC(myanmarDate.getUTCFullYear(), myanmarDate.getUTCMonth() - 1, 1));
  const previousMonthLastDay = new Date(Date.UTC(
    previousMonth.getUTCFullYear(),
    previousMonth.getUTCMonth() + 1,
    0,
  )).getUTCDate();
  return new Date(Date.UTC(previousMonth.getUTCFullYear(), previousMonth.getUTCMonth(), previousMonthLastDay));
}

export function getNextLucky3DDrawDay(myanmarDate: Date): Date {
  const day = myanmarDate.getUTCDate();
  for (const drawDay of getLucky3DDrawDays(myanmarDate)) {
    if (drawDay > day) {
      return new Date(Date.UTC(myanmarDate.getUTCFullYear(), myanmarDate.getUTCMonth(), drawDay));
    }
  }
  return new Date(Date.UTC(myanmarDate.getUTCFullYear(), myanmarDate.getUTCMonth() + 1, FIXED_3D_DRAW_DAYS[0]));
}

export function getLucky3DPeriodSeed(myanmarDate: Date): number {
  const period = getCurrentLucky3DDrawDate(myanmarDate);
  return period.getUTCFullYear() * 10000 + (period.getUTCMonth() + 1) * 100 + period.getUTCDate();
}

/**
 * One key for the content currently available to a user. It changes at each
 * weekday Lucky 2D session and at each scheduled 3D date-lock update.
 */
export function getLuckyContentPeriod(myanmarDate: Date): string {
  const threeDPeriod = getCurrentLucky3DDrawDate(myanmarDate);
  const threeDKey = `${threeDPeriod.getUTCFullYear()}-${threeDPeriod.getUTCMonth()}-${threeDPeriod.getUTCDate()}`;
  return `3d-${threeDKey}|2d-${getCurrentLucky2DContentPeriod(myanmarDate)}`;
}
