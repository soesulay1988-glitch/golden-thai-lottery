import { describe, expect, it } from "vitest";
import {
  getCurrentLucky3DDrawDate,
  getCurrentLucky2DContentPeriod,
  getLuckyContentPeriod,
  getLucky2DSessionIndex,
  getMyanmarDate,
  getNextLucky3DDrawDay,
  isMyanmarMarketDay,
} from "./luckySchedule";

describe("Lucky Number 2D schedule", () => {
  it("opens only at 10:30 and 15:30 Myanmar time on weekdays", () => {
    expect(getLucky2DSessionIndex(getMyanmarDate(new Date("2026-09-07T03:59:00Z")))).toBe(-1);
    expect(getLucky2DSessionIndex(getMyanmarDate(new Date("2026-09-07T04:00:00Z")))).toBe(0);
    expect(getLucky2DSessionIndex(getMyanmarDate(new Date("2026-09-07T09:00:00Z")))).toBe(1);
  });

  it("keeps Lucky 2D closed on Saturday and Sunday", () => {
    const saturday = getMyanmarDate(new Date("2026-09-05T04:00:00Z"));
    const sunday = getMyanmarDate(new Date("2026-09-06T04:00:00Z"));
    expect(isMyanmarMarketDay(saturday)).toBe(false);
    expect(isMyanmarMarketDay(sunday)).toBe(false);
    expect(getLucky2DSessionIndex(saturday)).toBe(-1);
    expect(getLucky2DSessionIndex(sunday)).toBe(-1);
  });
});

describe("Lucky Number 3D date lock", () => {
  const atMyanmarDate = (day: number) => new Date(Date.UTC(2026, 8, day, 12));

  it("changes only on the 5th, 15th, 20th, and final day of the month", () => {
    expect(getCurrentLucky3DDrawDate(atMyanmarDate(4)).toISOString()).toBe("2026-08-31T00:00:00.000Z");
    expect(getCurrentLucky3DDrawDate(atMyanmarDate(5)).toISOString()).toBe("2026-09-05T00:00:00.000Z");
    expect(getCurrentLucky3DDrawDate(atMyanmarDate(14)).toISOString()).toBe("2026-09-05T00:00:00.000Z");
    expect(getCurrentLucky3DDrawDate(atMyanmarDate(15)).toISOString()).toBe("2026-09-15T00:00:00.000Z");
    expect(getCurrentLucky3DDrawDate(atMyanmarDate(20)).toISOString()).toBe("2026-09-20T00:00:00.000Z");
    expect(getCurrentLucky3DDrawDate(atMyanmarDate(30)).toISOString()).toBe("2026-09-30T00:00:00.000Z");
  });

  it("returns the next scheduled draw date after the current period", () => {
    expect(getNextLucky3DDrawDay(atMyanmarDate(5)).toISOString()).toBe("2026-09-15T00:00:00.000Z");
    expect(getNextLucky3DDrawDay(atMyanmarDate(20)).toISOString()).toBe("2026-09-30T00:00:00.000Z");
  });
});

describe("Lucky Number content period", () => {
  const atMyanmarTime = (day: number, hour: number, minute = 0) => new Date(Date.UTC(2026, 8, day, hour, minute));

  it("changes when a weekday 2D session begins", () => {
    const beforeMorning = getLuckyContentPeriod(atMyanmarTime(4, 10, 29));
    const morning = getLuckyContentPeriod(atMyanmarTime(4, 10, 30));
    const evening = getLuckyContentPeriod(atMyanmarTime(4, 15, 30));

    expect(beforeMorning).not.toBe(morning);
    expect(morning).not.toBe(evening);
  });

  it("changes on a 3D update date even when 2D is closed", () => {
    expect(getLuckyContentPeriod(atMyanmarTime(4, 12))).not.toBe(getLuckyContentPeriod(atMyanmarTime(5, 12)));
  });

  it("does not create a new badge at midnight or on a 2D weekend", () => {
    expect(getCurrentLucky2DContentPeriod(atMyanmarTime(4, 23, 59)))
      .toBe(getCurrentLucky2DContentPeriod(atMyanmarTime(5, 0, 1)));
    expect(getCurrentLucky2DContentPeriod(atMyanmarTime(5, 12)))
      .toBe(getCurrentLucky2DContentPeriod(atMyanmarTime(4, 16)));
  });
});
