import { useState, useRef, useEffect, useCallback } from "react";
import { createPortal } from "react-dom";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, Camera, X, CheckCircle2, XCircle, Trophy, Volume2, ChevronDown, Calendar, ImageUp, Search, Clock } from "lucide-react";
import { toast } from "sonner";

// Thai lottery ticket has TWO types of codes:
// 1. Data Matrix 2D (square QR-like) — contains: YY-RR-PP-NNNNNN
//    e.g. "69-15-09-842054" → lottery number is "842054"
//
// 2. 1D Barcode (linear) — contains serial/batch data
//    e.g. "2629316668882806-2603" — this is NOT the lottery number!
//
// The 6-digit lottery number is printed LARGE on the ticket (e.g. 842054).
// The Data Matrix 2D encodes it as YY-RR-PP-NNNNNN.
// The 1D barcode does NOT contain the lottery number.
//
// We only accept Data Matrix format (YY-RR-PP-NNNNNN) or exact 6-digit input.
// We reject 1D barcode serial numbers to prevent wrong extraction.
function extractTicketNumber(rawText: string): string {
  const text = rawText.trim();

  // 1. If exactly 6 digits, return directly
  if (/^\d{6}$/.test(text)) return text;

  // 2. Try standard Data Matrix format: YY-RR-PP-NNNNNN
  //    This is the PRIMARY format used by Thai Government Lottery Data Matrix 2D
  const dmMatch = text.match(/^(\d{2})-(\d{1,2})-(\d{1,2})-(\d{6})$/);
  if (dmMatch) return dmMatch[4];

  // 3. Try Data Matrix with alphanumeric prefix: e.g. "GLO69-15-09-842054"
  const dmMatch2 = text.match(/[A-Za-z]*(\d{2})-(\d{1,2})-(\d{1,2})-(\d{6})/);
  if (dmMatch2) return dmMatch2[4];

  // 4. Try Data Matrix without dashes: 10-12 digits total
  const bareDigits = text.replace(/\D/g, "");
  if (bareDigits.length >= 10 && bareDigits.length <= 12) {
    const yearPrefix = parseInt(bareDigits.substring(0, 2));
    if (yearPrefix >= 60 && yearPrefix <= 70) {
      return bareDigits.slice(-6);
    }
  }

  // 5. If exactly 6 digits after removing non-digits, return as-is
  if (bareDigits.length === 6) return bareDigits;

  // 6. If we have a long barcode (serial number) — DO NOT extract from it
  //    1D barcodes contain serial/batch data, NOT the lottery number
  if (bareDigits.length > 12) {
    return "";
  }

  // 7. Try to find a 6-digit group in the text
  const sixDigitMatch = text.match(/\d{6}/);
  if (sixDigitMatch) return sixDigitMatch[0];

  // 8. Last resort: return empty
  return "";
}

export default function Lottery() {
  const { t, lang } = useLang();
  const [, navigate] = useLocation();
  const [ticket, setTicket] = useState("");
  const [scanning, setScanning] = useState(false);
  const [isCheckShaking, setIsCheckShaking] = useState(false);
  const [result, setResult] = useState<null | { matches: any[] | null; draw: any; ticket: string }>(null);
  const [showWin, setShowWin] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [showDatePicker, setShowDatePicker] = useState(false);
  const datePickerBtnRef = useRef<HTMLButtonElement>(null);
  const scannerRef = useRef<any>(null);
  const [dropdownRect, setDropdownRect] = useState<DOMRect | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const openDatePicker = useCallback(() => {
    if (datePickerBtnRef.current) {
      setDropdownRect(datePickerBtnRef.current.getBoundingClientRect());
    }
    setShowDatePicker(true);
  }, []);

  const closeDatePicker = useCallback(() => {
    setShowDatePicker(false);
    setDropdownRect(null);
  }, []);

  useEffect(() => {
    if (!showDatePicker) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest("[data-date-picker]")) closeDatePicker();
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [showDatePicker, closeDatePicker]);

  const scanDivRef = useRef<HTMLDivElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const { data: latestDraw } = trpc.thaiLottery.getLatest.useQuery();
  const { data: drawDates } = trpc.thaiLottery.listDrawDates.useQuery();
  const { data: selectedDrawData } = trpc.thaiLottery.getByDate.useQuery(
    { drawDate: selectedDate },
    { enabled: !!selectedDate }
  );

  const displayDraw = selectedDate ? selectedDrawData : latestDraw;

  const checkMutation = trpc.thaiLottery.checkTicket.useMutation({
    onSuccess: (data) => {
      setResult(data);
      if (data.matches && data.matches.length > 0) {
        setShowWin(true);
        playWinSound();
      }
    },
    onError: (e) => toast.error(e.message),
    onSettled: () => { setTicket(""); },
  });

  function playWinSound() {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioCtxRef.current = ctx;
      const notes = [523, 659, 784, 1047, 784, 1047, 1319];
      let t = ctx.currentTime;
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.frequency.value = freq;
        osc.type = "sine";
        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
        osc.start(t); osc.stop(t + 0.4);
        t += i < 4 ? 0.15 : 0.2;
      });
      setTimeout(() => {
        try {
          const utt = new SpeechSynthesisUtterance("ဂုဏ်ယူပါတယ်");
          utt.lang = "my-MM";
          utt.rate = 0.85;
          utt.pitch = 1.1;
          window.speechSynthesis.speak(utt);
        } catch {}
      }, 1200);
    } catch {}
  }

  // ─── BarcodeDetector-based scanner ───────────────────────────────────
  let barcodeDetectorVideo: HTMLVideoElement | null = null;
  let barcodeDetectorStream: MediaStream | null = null;
  let barcodeDetectorAnimFrame: number | null = null;

  async function startQR() {
    setScanning(true);
    
    // Try BarcodeDetector API first (native, supports Data Matrix)
    const hasBarcodeDetector = 'BarcodeDetector' in window;
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } } });
      
      if (hasBarcodeDetector) {
        // Use native BarcodeDetector - supports QR, Data Matrix, all formats
        barcodeDetectorStream = stream;
        const qrDiv = document.getElementById("qr-reader");
        if (qrDiv) {
          qrDiv.innerHTML = "";
          qrDiv.style.minHeight = "300px";
          
          const video = document.createElement("video");
          video.setAttribute("playsinline", "true");
          video.setAttribute("muted", "true");
          video.style.width = "100%";
          video.style.height = "100%";
          video.style.objectFit = "cover";
          video.style.borderRadius = "12px";
          qrDiv.appendChild(video);
          
          video.srcObject = stream;
          await video.play();
          barcodeDetectorVideo = video;
          
          const detector = new (window as any).BarcodeDetector({ formats: ['qr_code', 'data_matrix'] });
          let lastScanned = '';
          
          const scanFrame = async () => {
            if (!barcodeDetectorVideo || !video.srcObject) return;
            try {
              const results = await detector.detect(video);
              if (results && results.length > 0) {
                for (const result of results) {
                  const rawText = result.rawValue;
                  if (rawText && rawText !== lastScanned) {
                    lastScanned = rawText;
                    console.log("RAW BARCODE SCAN:", rawText, "format:", result.format);
                    toast.info(lang === "mm" ? `RAW: ${rawText} (${result.format})` : `Raw scan: ${rawText} (${result.format})`, { duration: 5000 });
                    
                    const ticketNum = extractTicketNumber(rawText);
                    if (ticketNum.length === 6 && /^\d{6}$/.test(ticketNum)) {
                      setTicket(ticketNum);
                      stopBarcodeDetector();
                      toast.success(lang === "mm" ? `QR ဖတ်ပြီးပါပြီ - ${ticketNum}` : lang === "th" ? `สแกน QR แล้ว: ${ticketNum}` : `QR scanned: ${ticketNum}`, { duration: 6000 });
                      setTimeout(() => {
                        checkMutation.mutate({ ticket: ticketNum, drawDate: selectedDate || undefined });
                      }, 300);
                      return;
                    } else {
                      toast.error(lang === "mm" ? `QR ကုဒ်မှ ၆ လုံး ဂဏန်း မရပါ\nRAW: ${rawText}` : lang === "th" ? `ไม่พบหมายเลขสลาก 6 หลัก\nRaw: ${rawText}` : `Could not find 6-digit ticket number\nRaw: ${rawText}`, { duration: 8000 });
                    }
                  }
                }
              }
            } catch {}
            barcodeDetectorAnimFrame = requestAnimationFrame(scanFrame);
          };
          
          barcodeDetectorAnimFrame = requestAnimationFrame(scanFrame);
        }
      } else {
        // Fallback to html5-qrcode for browsers without BarcodeDetector
        stream.getTracks().forEach(t => t.stop());
        startHtml5QrScanner();
      }
    } catch (e: any) {
      console.error("Camera permission denied:", e);
      toast.error(lang === "mm" ? 'Camera မရပါ - ပုံမှ QR ဖတ်ရန် "ပုံမှ" ခလုတ်ကို နှိပ်ပါ' : lang === "th" ? 'ไม่สามารถเข้าถึงกล้องได้ - ใช้ปุ่ม "จากรูปภาพ"' : 'Camera denied - use "From Image" button');
      setScanning(false);
    }
  }

  async function startHtml5QrScanner() {
    setTimeout(async () => {
      if (!scanDivRef.current) { setScanning(false); return; }
      try {
        if (scannerRef.current) {
          try { await scannerRef.current.stop(); } catch {}
          try { scannerRef.current.clear(); } catch {}
          scannerRef.current = null;
        }
        const qrDiv = document.getElementById("qr-reader");
        if (qrDiv) { qrDiv.innerHTML = ""; qrDiv.style.minHeight = "250px"; }
        const { Html5Qrcode } = await import("html5-qrcode");
        const scanner = new Html5Qrcode("qr-reader", { verbose: false });
        scannerRef.current = scanner;

        const onScan = (rawText: string) => {
          console.log("RAW QR SCAN:", rawText);
          toast.info(lang === "mm" ? `RAW: ${rawText}` : `Raw scan: ${rawText}`, { duration: 5000 });
          
          const ticketNum = extractTicketNumber(rawText);
          if (ticketNum.length === 6 && /^\d{6}$/.test(ticketNum)) {
            setTicket(ticketNum);
            stopQR();
            toast.success(lang === "mm" ? `QR ဖတ်ပြီးပါပြီ - ${ticketNum}` : lang === "th" ? `สแกน QR แล้ว: ${ticketNum}` : `QR scanned: ${ticketNum}`, { duration: 6000 });
            setTimeout(() => {
              checkMutation.mutate({ ticket: ticketNum, drawDate: selectedDate || undefined });
            }, 300);
          } else {
            toast.error(lang === "mm" ? `QR ကုဒ်မှ ၆ လုံး ဂဏန်း မရပါ\nRAW: ${rawText}` : lang === "th" ? `ไม่พบหมายเลขสลาก 6 หลัก\nRaw: ${rawText}` : `Could not find 6-digit ticket number\nRaw: ${rawText}`, { duration: 8000 });
          }
        };

        try {
          const devices = await Html5Qrcode.getCameras();
          const backCamera = devices.find(d => d.label.toLowerCase().includes("back") || d.label.toLowerCase().includes("environment") || d.label.toLowerCase().includes("rear"));
          if (backCamera) {
            await scanner.start(backCamera.id, { fps: 10, qrbox: { width: 250, height: 250 } }, onScan, () => {});
          } else {
            await scanner.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } }, onScan, () => {});
          }
        } catch {
          await scanner.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } }, onScan, () => {});
        }
      } catch (e: any) {
        console.error("QR Scanner start error:", e);
        toast.error(lang === "mm" ? "QR Scanner စတင်မရပါ" : "QR Scanner failed");
        setScanning(false);
      }
    }, 500);
  }

  function stopBarcodeDetector() {
    if (barcodeDetectorAnimFrame) {
      cancelAnimationFrame(barcodeDetectorAnimFrame);
      barcodeDetectorAnimFrame = null;
    }
    if (barcodeDetectorVideo) {
      barcodeDetectorVideo.srcObject = null;
      barcodeDetectorVideo = null;
    }
    if (barcodeDetectorStream) {
      barcodeDetectorStream.getTracks().forEach(t => t.stop());
      barcodeDetectorStream = null;
    }
    const qrDiv = document.getElementById("qr-reader");
    if (qrDiv) qrDiv.innerHTML = "";
    setScanning(false);
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    toast.loading(lang === "mm" ? "ပုံမှ QR ဖတ်နေပါသည်..." : "Reading QR from image...");
    try {
      const { Html5Qrcode } = await import("html5-qrcode");
      const qrDiv = document.getElementById("qr-reader-file");
      if (qrDiv) qrDiv.innerHTML = "";
      const scanner = new Html5Qrcode("qr-reader-file", { verbose: false }); // Detect all formats
      const r = await scanner.scanFile(file, true);
      try { scanner.clear(); } catch {}
      const digits = extractTicketNumber(r);
      if (digits.length === 6 && /^\d{6}$/.test(digits)) {
        setTicket(digits);
        toast.dismiss();
        toast.success(lang === "mm" ? `QR ပုံမှ နံပါတ်ဖတ်ပြီးပါပြီ - ${digits}` : lang === "th" ? `อ่านหมายเลขสลากจากรูปภาพแล้ว: ${digits}` : `Ticket number read: ${digits}`);
        // Auto-check immediately
        setTimeout(() => {
          checkMutation.mutate({ ticket: digits, drawDate: selectedDate || undefined });
        }, 300);
      } else { toast.dismiss(); toast.error(lang === "mm" ? "QR ကုဒ်မှ နံပါတ် ၆ လုံး မရပါ" : lang === "th" ? "ไม่พบหมายเลขสลาก 6 หลัก" : "Could not find 6-digit ticket number"); }
    } catch { toast.dismiss(); toast.error(lang === "mm" ? "QR ကုဒ်ဖတ်မရပါ" : lang === "th" ? "ไม่สามารถอ่าน QR code ได้" : "Could not read QR code"); }
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  async function stopQR() {
    stopBarcodeDetector();
    if (scannerRef.current) { try { await scannerRef.current.stop(); } catch {} try { scannerRef.current.clear(); } catch {} scannerRef.current = null; }
    const qrDiv = document.getElementById("qr-reader");
    if (qrDiv) qrDiv.innerHTML = "";
    setScanning(false);
  }

  useEffect(() => () => { stopQR(); }, []);

  function handleCheck() {
    // Give immediate physical feedback every time the user taps Check.
    setIsCheckShaking(true);
    window.setTimeout(() => setIsCheckShaking(false), 520);
    if (ticket.length !== 6) {
      toast.error(lang === "mm" ? "နံပါတ် ၆ လုံး ထည့်ပါ" : lang === "th" ? "กรุณาใส่หมายเลข 6 หลัก" : "Please enter 6 digits");
      return;
    }
    checkMutation.mutate({ ticket, drawDate: selectedDate || undefined });
  }

  const prizeLabel = (key: string) => {
    const map: Record<string, { mm: string; en: string; th: string }> = {
      "1st": { mm: "ပထမဆု", en: "1ST PRIZE", th: "รางวัลที่ 1" },
      "near1st": { mm: "ပထမဆုနှင့်နီးသောဆု", en: "NEAR 1ST", th: "ใกล้เคียงรางวัลที่ 1" },
      "first3": { mm: "ရှေ့ ၃ လုံး", en: "FIRST 3", th: "เลขหน้า 3 ตัว" },
      "last3": { mm: "နောက် ၃ လုံး", en: "LAST 3", th: "เลขท้าย 3 ตัว" },
      "last2": { mm: "နောက် ၂ လုံး", en: "LAST 2 DIGITS", th: "เลขท้าย 2 ตัว" },
      "2nd": { mm: "ဒုတိယဆု", en: "2ND PRIZE", th: "รางวัลที่ 2" },
      "3rd": { mm: "တတိယဆု", en: "3RD PRIZE", th: "รางวัลที่ 3" },
      "4th": { mm: "စတုတ္ထဆု", en: "4TH PRIZE", th: "รางวัลที่ 4" },
      "5th": { mm: "ပဉ္စမဆု", en: "5TH PRIZE", th: "รางวัลที่ 5" },
    };
    return map[key]?.[lang] ?? key;
  };

  const prizeAmount = (key: string) => {
    const map: Record<string, string> = {
      "1st": "6,000,000", "near1st": "100,000", "first3": "4,000", "last3": "4,000",
      "last2": "2,000", "2nd": "200,000", "3rd": "80,000", "4th": "40,000", "5th": "20,000",
    };
    return map[key] ?? "0";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF8E1] to-[#f5f5f5]">
      {/* ─── Yellow Header ─────────────────────────────────────────────── */}
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto px-4 py-2">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/")} className="text-[#333] btn-press shrink-0">
              <ArrowLeft size={20} />
            </button>
            <h1 className="font-display text-base font-bold text-[#333] flex-1">
              {t("navLottery")}
            </h1>
            <button
              onClick={() => navigate("/lottery/history")}
              className="bg-white/80 text-[#333] text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 btn-press shrink-0"
            >
              <Clock size={13} />
              {t("navHistory")}
            </button>
          </div>
          {displayDraw && (
            <p className="text-xs text-[#555] font-myanmar text-right mt-1">
              {new Date(displayDraw.drawDate).toLocaleDateString(lang === "mm" ? "my-MM" : "en-US", { day: "numeric", month: "numeric", year: "numeric" })}
            </p>
          )}
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-3 py-3 space-y-3">

        {/* ─── Draw Date Picker ────────────────────────────────────────── */}
        {drawDates && drawDates.length > 0 && (
          <div className="bg-gradient-to-br from-[#FFD700] via-[#FFC107] to-[#FFB300] rounded-xl p-3 shadow-lg animate-fade-in-up border border-[#FFB300]/30" data-date-picker>
            <button
              ref={datePickerBtnRef}
              onClick={() => showDatePicker ? closeDatePicker() : openDatePicker()}
              className="w-full flex items-center justify-between px-4 py-2.5 bg-white/20 backdrop-blur-sm rounded-xl text-sm font-myanmar text-[#333] hover:bg-white/30 transition-colors btn-press border border-white/30"
            >
              <span className={selectedDate ? "text-[#333] font-semibold" : "text-[#555]/80"}>
                {selectedDate
                  ? new Date(selectedDate).toLocaleDateString(lang === "mm" ? "my-MM" : lang === "th" ? "th-TH" : "en-US", { day: "numeric", month: "long", year: "numeric" })
                  : t("latestDraw")}
              </span>
              <ChevronDown size={14} className={`text-[#333] transition-transform ${showDatePicker ? "rotate-180" : ""}`} />
            </button>
          </div>
        )}

        {/* ─── Ticket Checker ──────────────────────────────────────────── */}
        <div className="bg-gradient-to-br from-[#FFD700] via-[#FFC107] to-[#FFB300] rounded-xl p-4 shadow-lg animate-fade-in-up border border-[#FFB300]/30">
          <p className="text-xs text-[#555] font-semibold font-myanmar mb-3 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#333]"></span>
            {t("enterTicket")}
          </p>
          <input
            type="tel"
            inputMode="numeric"
            maxLength={6}
            value={ticket}
            onChange={(e) => setTicket(e.target.value.replace(/\D/g, "").slice(0, 6))}
            placeholder="000000"
            className="w-full bg-white/90 border-2 border-[#333]/10 rounded-xl px-4 py-3 text-center prize-number text-3xl text-[#333] placeholder:text-[#333]/20 focus:outline-none focus:border-[#333]/40 focus:ring-2 focus:ring-[#333]/10 transition-all tracking-[0.4em] shadow-inner"
          />
          <div className="flex gap-2 mt-3">
            <button
              onClick={handleCheck}
              disabled={checkMutation.isPending}
              className={`flex-1 bg-[#333] text-[#FFD700] font-bold py-3 rounded-xl text-sm font-myanmar disabled:opacity-40 transition-all btn-press shadow-md ${isCheckShaking ? "animate-check-shake" : ""}`}
            >
              {checkMutation.isPending ? t("loading") : t("checkBtn")}
            </button>
            <button
              onClick={scanning ? stopQR : startQR}
              className="bg-white/30 backdrop-blur-sm px-4 py-3 rounded-xl flex items-center gap-2 text-[#333] text-sm font-myanmar btn-press border border-white/40 shadow-sm"
            >
              {scanning ? <X size={16} /> : <Camera size={16} />}
              {scanning ? t("stopScan") : t("scanQR")}
            </button>
            {/* QR Code visual icon — quick scan shortcut */}
            <button
              onClick={scanning ? stopQR : startQR}
              className="bg-white/30 backdrop-blur-sm px-4 py-3 rounded-xl flex items-center justify-center btn-press border border-white/40 shadow-sm"
              title={lang === "mm" ? "QR ကုဒ် စကင်ဖတ်ရန်" : "Scan QR Code"}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#333" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="7" height="7" />
                <rect x="14" y="3" width="7" height="7" />
                <rect x="3" y="14" width="7" height="7" />
                <line x1="14" y1="14" x2="14.01" y2="14" />
                <line x1="17" y1="14" x2="21" y2="14" />
                <line x1="14" y1="17" x2="14" y2="21" />
                <line x1="17" y1="17" x2="21" y2="21" />
              </svg>
            </button>
            <input ref={fileInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileUpload} />
          </div>
        </div>

        {/* QR Scanner */}
        {scanning && (
          <div className="bg-gradient-to-b from-[#FFF8E1] to-white rounded-xl overflow-hidden animate-scale-in border border-[#FFD700]/30 shadow-md">
            <div id="qr-reader" ref={scanDivRef} className="w-full" />
            <p className="text-center text-xs text-[#555] font-myanmar font-semibold py-2">
              {t("scanQR")}
            </p>
          </div>
        )}
        <div id="qr-reader-file" style={{ display: "none" }} />

        {/* Win overlay */}
        {showWin && result?.matches && (
          <div className="bg-white rounded-xl p-5 border-2 border-[#FFD700] shadow-lg animate-scale-in">
            <div className="flex items-center gap-3 mb-3">
              <Trophy size={28} className="text-[#FFD700]" />
              <div>
                <p className="font-display text-lg font-bold text-[#FFD700]">{t("congratulations")}</p>
                <p className="text-xs text-muted-foreground font-myanmar">{t("youWon")}</p>
              </div>
              <button onClick={() => setShowWin(false)} className="ml-auto text-muted-foreground"><X size={16} /></button>
            </div>
            {result.matches.map((m, i) => (
              <div key={i} className="bg-[#FFD700]/10 rounded-xl px-3 py-2 mb-2">
                <p className="text-sm font-bold text-[#FFD700] font-myanmar">{prizeLabel(m.prize)}</p>
                <p className="text-xs text-muted-foreground">{m.amount} {t("baht")}</p>
              </div>
            ))}
            <button onClick={playWinSound} className="flex items-center gap-1 text-xs text-muted-foreground mt-1 font-myanmar">
              <Volume2 size={12} /> {t("tryAgain")}
            </button>
          </div>
        )}

        {/* No win — screenshot-style sad result card with the checked number */}
        {result && !result.matches && (
          <div className="bg-white rounded-xl p-4 border-2 border-red-200 shadow-sm animate-scale-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full border-2 border-red-300 flex items-center justify-center shrink-0">
                <XCircle size={26} className="text-red-400" />
              </div>
              <div>
                <p className="font-display text-lg font-bold text-red-500 font-myanmar">
                  {t("noWin")}
                </p>
                <p className="text-xs text-muted-foreground font-myanmar">
                  {t("noWin")}
                </p>
              </div>
            </div>
            <div className="mt-3 rounded-xl bg-red-50 border border-red-100 px-4 py-3 flex items-center justify-between gap-3">
              <span className="text-xs text-red-400 font-myanmar">
                {t("checkTicket")}
              </span>
              <span className="prize-number text-2xl font-black text-red-500 tracking-[0.12em]">{result.ticket}</span>
            </div>
            <p className="mt-2 text-center text-xs text-muted-foreground font-myanmar">
              {t("noWin")}
            </p>
          </div>
        )}

        {/* ─── Full Prize Breakdown (Red Cards) ────────────────────────── */}
        {displayDraw && (
          <div className="space-y-3 animate-fade-in-up" style={{ animationDelay: "120ms" }}>

            {/* 1st Prize — Big Red Card with Individual Digits */}
            <div className="bg-[#E8443A] rounded-xl p-5 shadow-lg">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("firstPrize")}</span>
                <span className="text-[11px] text-yellow-300 font-myanmar">฿{prizeAmount("1st")}</span>
              </div>
              <div className="flex justify-center gap-2">
                {(displayDraw.firstPrize ?? "------").split("").map((digit: string, i: number) => (
                  <div key={i} className="w-11 h-11 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <span className="prize-number text-2xl font-black text-[#333]">{digit}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Near 1st */}
            {(displayDraw.nearFirstPrize as string[] | null)?.length ? (
              <div className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-4 bg-white rounded" />
                    <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("nearFirst")}</span>
                  </div>
                  <span className="text-[11px] text-yellow-300 font-myanmar">฿{prizeAmount("near1st")}</span>
                </div>
                <div className="flex flex-wrap gap-2 justify-center">
                  {(displayDraw.nearFirstPrize as string[]).map((n: string) => (
                    <span key={n} className="prize-number text-xl font-black text-[#333] bg-white px-4 py-1.5 rounded-lg shadow-sm">{n}</span>
                  ))}
                </div>
              </div>
            ) : null}

            {/* Last 2 Digits */}
            <div className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-1 h-4 bg-white rounded" />
                  <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("last2Digits")}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-green-300 font-myanmar">฿{prizeAmount("last2")}</span>
                  <span className="prize-number text-2xl font-black text-green-300">{displayDraw.lastTwoDigits ?? "--"}</span>
                </div>
              </div>
            </div>

            {/* First 3 */}
            {(displayDraw.firstThreeDigits as string[] | null)?.length ? (
              <div className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-4 bg-white rounded" />
                    <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("first3Digits")}</span>
                  </div>
                  <span className="text-[11px] text-purple-300 font-myanmar">฿{prizeAmount("first3")}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(displayDraw.firstThreeDigits as string[]).map((n: string) => (
                    <span key={n} className="prize-number text-base font-black text-[#333] bg-white px-3 py-1.5 rounded-lg shadow-sm">{n}</span>
                  ))}
                </div>
              </div>
            ) : null}

            {/* Last 3 */}
            {(displayDraw.lastThreeDigits as string[] | null)?.length ? (
              <div className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-4 bg-white rounded" />
                    <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("last3Digits")}</span>
                  </div>
                  <span className="text-[11px] text-blue-300 font-myanmar">฿{prizeAmount("last3")}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(displayDraw.lastThreeDigits as string[]).map((n: string) => (
                    <span key={n} className="prize-number text-base font-black text-[#333] bg-white px-3 py-1.5 rounded-lg shadow-sm">{n}</span>
                  ))}
                </div>
              </div>
            ) : null}

            {/* 2nd Prize */}
            {(displayDraw.secondPrize as string[] | null)?.length ? (
              <div className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-4 bg-white rounded" />
                    <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("secondPrize")}</span>
                  </div>
                  <span className="text-[11px] text-sky-300 font-myanmar">฿{prizeAmount("2nd")}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(displayDraw.secondPrize as string[]).map((n: string) => (
                    <span key={n} className="prize-number text-sm font-black text-[#333] bg-white px-3 py-1 rounded-lg shadow-sm">{n}</span>
                  ))}
                </div>
              </div>
            ) : null}

            {/* 3rd Prize */}
            {(displayDraw.thirdPrize as string[] | null)?.length ? (
              <div className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-4 bg-white rounded" />
                    <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("thirdPrize")}</span>
                  </div>
                  <span className="text-[11px] text-blue-300 font-myanmar">฿{prizeAmount("3rd")}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(displayDraw.thirdPrize as string[]).map((n: string) => (
                    <span key={n} className="prize-number text-sm font-black text-[#333] bg-white px-3 py-1 rounded-lg shadow-sm">{n}</span>
                  ))}
                </div>
              </div>
            ) : null}

            {/* 4th Prize */}
            {(displayDraw.fourthPrize as string[] | null)?.length ? (
              <div className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-4 bg-white rounded" />
                    <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("fourthPrize")}</span>
                  </div>
                  <span className="text-[11px] text-indigo-300 font-myanmar">฿{prizeAmount("4th")}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(displayDraw.fourthPrize as string[]).map((n: string) => (
                    <span key={n} className="prize-number text-sm font-black text-[#333] bg-white px-3 py-1 rounded-lg shadow-sm">{n}</span>
                  ))}
                </div>
              </div>
            ) : null}

            {/* 5th Prize */}
            {(displayDraw.fifthPrize as string[] | null)?.length ? (
              <div className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-4 bg-white rounded" />
                    <span className="text-xs font-bold text-white font-myanmar tracking-wider">{t("fifthPrize")}</span>
                  </div>
                  <span className="text-[11px] text-purple-300 font-myanmar">฿{prizeAmount("5th")}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(displayDraw.fifthPrize as string[]).map((n: string) => (
                    <span key={n} className="prize-number text-sm font-black text-[#333] bg-white px-3 py-1 rounded-lg shadow-sm">{n}</span>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
        )}
      </div>

      {/* Date picker portal */}
      {drawDates && drawDates.length > 0 && (
        <DatePickerPortal
          show={showDatePicker}
          rect={dropdownRect}
          drawDates={drawDates}
          selectedDate={selectedDate}
          lang={lang}
          onSelect={(date) => { setSelectedDate(date); setResult(null); }}
          onClose={closeDatePicker}
        />
      )}
    </div>
  );
}

// ─── Fixed Date Picker Dropdown Portal ──────────────────────────────────────
function DatePickerPortal({
  show, rect, drawDates, selectedDate, lang,
  onSelect, onClose,
}: {
  show: boolean;
  rect: DOMRect | null;
  drawDates: any[];
  selectedDate: string;
  lang: string;
  onSelect: (date: string) => void;
  onClose: () => void;
}) {
  if (!show || !rect) return null;
  const top = rect.bottom + window.scrollY + 4;
  const left = rect.left + window.scrollX;
  const width = rect.width;
  return createPortal(
    <div
      data-date-picker
      style={{ position: "absolute", top, left, width, zIndex: 9999 }}
      className="bg-white border border-gray-200 rounded-xl shadow-2xl max-h-64 overflow-y-auto"
    >
      <button
        onClick={() => { onSelect(""); onClose(); }}
        className={`w-full text-left px-4 py-2.5 text-sm font-myanmar hover:bg-gray-50 transition-colors border-b border-gray-100
          ${!selectedDate ? "text-[#FFD700] bg-yellow-50 font-semibold" : "text-[#333]"}`}
      >
        {lang === "mm" ? "နောက်ဆုံးဆွဲချက် (ပုံမှန်)" : lang === "th" ? "งวดล่าสุด (ค่าเริ่มต้น)" : "Latest Draw (default)"}
      </button>
      {drawDates.map((d: any) => {
        const dateStr = new Date(d.drawDate).toISOString().slice(0, 10);
        const isSelected = selectedDate === dateStr;
        return (
          <button
            key={d.id}
            onClick={() => { onSelect(dateStr); onClose(); }}
            className={`w-full text-left px-4 py-2.5 text-sm font-myanmar hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-0
              ${isSelected ? "text-[#FFD700] bg-yellow-50 font-semibold" : "text-[#333]"}`}
          >
            <span>{new Date(d.drawDate).toLocaleDateString(lang === "mm" ? "my-MM" : lang === "th" ? "th-TH" : "en-US", { day: "numeric", month: "long", year: "numeric" })}</span>
            {d.firstPrize && <span className="ml-2 text-xs text-amber-500/70 prize-number">{d.firstPrize}</span>}
          </button>
        );
      })}
    </div>,
    document.body
  );
}
