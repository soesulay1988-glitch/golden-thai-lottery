import { ChangeEvent, useRef, useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, ImagePlus, LoaderCircle, Maximize2, RefreshCw, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];

function label(lang: "mm" | "en" | "th", value: { mm: string; en: string; th: string }) {
  return lang === "mm" ? value.mm : lang === "th" ? value.th : value.en;
}

export default function ThreeDAnalysis() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const imageQuery = trpc.threeDImage.get.useQuery(undefined, { staleTime: 30_000 });
  const upload = trpc.threeDImage.upload.useMutation({
    onSuccess: () => {
      imageQuery.refetch();
      toast(label(lang, { mm: "ပုံတင်ပြီးပါပြီ", th: "อัปโหลดรูปแล้ว", en: "Image uploaded" }));
    },
    onError: (error) => toast(error.message || label(lang, { mm: "ပုံတင်မရသေးပါ", th: "ยังอัปโหลดรูปไม่ได้", en: "Unable to upload image" })),
  });
  const clear = trpc.threeDImage.clear.useMutation({
    onSuccess: () => {
      setIsViewerOpen(false);
      imageQuery.refetch();
      toast(label(lang, { mm: "ပုံဖယ်ရှားပြီးပါပြီ", th: "ลบรูปแล้ว", en: "Image removed" }));
    },
    onError: (error) => toast(error.message || label(lang, { mm: "ပုံဖယ်ရှားမရသေးပါ", th: "ยังลบรูปไม่ได้", en: "Unable to remove image" })),
  });

  const handleImageSelect = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
      toast(label(lang, { mm: "JPG၊ PNG သို့မဟုတ် WEBP ပုံသာတင်နိုင်သည်", th: "อัปโหลดได้เฉพาะ JPG, PNG หรือ WEBP", en: "Only JPG, PNG, or WEBP images are allowed" }));
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      toast(label(lang, { mm: "ပုံအရွယ်အစား 3 MB အောက်သာတင်နိုင်သည်", th: "รูปต้องมีขนาดไม่เกิน 3 MB", en: "Image must be 3 MB or smaller" }));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") upload.mutate({ dataUrl: reader.result });
    };
    reader.onerror = () => toast(label(lang, { mm: "ပုံဖတ်မရသေးပါ", th: "ยังอ่านรูปไม่ได้", en: "Unable to read image" }));
    reader.readAsDataURL(file);
  };

  const text = {
    title: label(lang, { mm: "3D အထောက်အထားပုံ", th: "รูปหลักฐาน 3D", en: "3D Evidence Image" }),
    subtitle: label(lang, { mm: "Golden Thai တင်ထားသောပုံကိုကြည့်ရန်", th: "ดูรูปที่ Golden Thai โพสต์", en: "View the image posted by Golden Thai" }),
    emptyTitle: label(lang, { mm: "ပုံမတင်ရသေးပါ", th: "ยังไม่มีรูปที่โพสต์", en: "No image posted yet" }),
    emptyBody: label(lang, { mm: "ပုံအသစ်တင်ပြီးပါက ဤနေရာတွင်အလိုအလျောက်ပေါ်လာပါမည်", th: "รูปใหม่จะปรากฏที่นี่เมื่อโพสต์แล้ว", en: "A new image will appear here after it is posted." }),
  };
  const hasImage = Boolean(imageQuery.data?.image?.imageUrl);
  const isBusy = upload.isPending || clear.isPending;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF8E1] to-[#f7f7f7] pb-24">
      <header className="page-header bg-[#FFD700] shadow-sm">
        <div className="mx-auto flex max-w-[480px] items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/")} className="rounded-xl p-1.5 text-[#3b3200] hover:bg-white/35 btn-press" aria-label="Back"><ArrowLeft size={21} /></button>
          <div className="min-w-0 flex-1"><h1 className="font-myanmar-display text-[17px] font-black leading-tight text-[#312a00]">{text.title}</h1><p className="mt-0.5 font-myanmar text-[10px] text-[#5d5100]">{text.subtitle}</p></div>
          <ImagePlus size={20} className="text-[#926500]" />
        </div>
      </header>

      <main className="mx-auto max-w-[480px] space-y-3 px-3 pt-3">
        {imageQuery.data?.canManage && <section className="rounded-2xl border border-amber-300 bg-white p-3 shadow-sm">
          <p className="font-myanmar text-[11px] font-black text-amber-800">{label(lang, { mm: "Admin ပုံတင်ရန်", th: "สำหรับแอดมิน: อัปโหลดรูป", en: "Admin: upload image" })}</p>
          <p className="mt-1 font-myanmar text-[10px] leading-4 text-slate-600">{label(lang, { mm: "JPG၊ PNG သို့မဟုတ် WEBP ပုံကိုတင်ပါ။ ပုံအသစ်တင်လျှင်အဟောင်းနေရာတွင်အစားထိုးပြမည်။", th: "อัปโหลด JPG, PNG หรือ WEBP รูปใหม่จะแทนที่รูปเดิม", en: "Upload a JPG, PNG, or WEBP image. A new image replaces the displayed one." })}</p>
          <input ref={inputRef} onChange={handleImageSelect} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" />
          <div className="mt-3 flex gap-2">
            <button disabled={isBusy} onClick={() => inputRef.current?.click()} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-3 py-2.5 font-myanmar text-[11px] font-black text-white shadow-sm disabled:opacity-60 btn-press">{upload.isPending ? <LoaderCircle size={15} className="animate-spin" /> : <ImagePlus size={15} />}{hasImage ? label(lang, { mm: "ပုံပြောင်းရန်", th: "เปลี่ยนรูป", en: "Replace image" }) : label(lang, { mm: "ပုံတင်ရန်", th: "อัปโหลดรูป", en: "Upload image" })}</button>
            {hasImage && <button disabled={isBusy} onClick={() => clear.mutate()} className="flex items-center justify-center rounded-xl border border-red-200 bg-red-50 px-3 text-red-600 disabled:opacity-60 btn-press" aria-label="Remove image"><Trash2 size={16} /></button>}
          </div>
        </section>}

        <section className="overflow-hidden rounded-2xl border-2 border-amber-300 bg-white shadow-md">
          <div className="flex items-center justify-between border-b border-amber-100 bg-[#fff8df] px-3 py-2.5"><p className="font-myanmar text-[12px] font-black text-amber-900">{label(lang, { mm: "3D အထောက်အထားပုံ", th: "รูปหลักฐาน 3D", en: "3D evidence image" })}</p><button onClick={() => imageQuery.refetch()} disabled={imageQuery.isFetching} className="rounded-lg bg-white p-1.5 text-amber-700 shadow-sm ring-1 ring-amber-200 disabled:opacity-60 btn-press" aria-label="Refresh image"><RefreshCw size={14} className={imageQuery.isFetching ? "animate-spin" : ""} /></button></div>
          {imageQuery.isLoading ? <div className="flex min-h-64 items-center justify-center"><LoaderCircle className="animate-spin text-amber-500" size={26} /></div> : hasImage ? <button onClick={() => setIsViewerOpen(true)} className="group relative block w-full bg-slate-100 text-left"><img src={imageQuery.data?.image?.imageUrl} alt={text.title} className="block max-h-[70vh] w-full object-contain" /><span className="absolute bottom-3 right-3 flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1.5 font-myanmar text-[10px] font-bold text-white shadow-sm"><Maximize2 size={13} />{label(lang, { mm: "ကြီးကြည့်ရန်", th: "ดูขนาดใหญ่", en: "View larger" })}</span></button> : <div className="flex min-h-64 flex-col items-center justify-center px-6 text-center"><ImagePlus size={34} className="text-amber-300" /><p className="mt-3 font-myanmar text-[14px] font-black text-slate-700">{text.emptyTitle}</p><p className="mt-1 font-myanmar text-[11px] leading-5 text-slate-500">{text.emptyBody}</p></div>}
        </section>
      </main>

      {isViewerOpen && hasImage && <div className="fixed inset-0 z-[500] flex items-center justify-center bg-black/95 p-3" onClick={() => setIsViewerOpen(false)}><button onClick={() => setIsViewerOpen(false)} className="absolute right-4 top-4 rounded-full bg-white/15 p-2 text-white btn-press" aria-label="Close full screen image"><X size={22} /></button><img src={imageQuery.data?.image?.imageUrl} alt={text.title} className="max-h-full max-w-full rounded-lg object-contain" onClick={(event) => event.stopPropagation()} /></div>}
    </div>
  );
}
