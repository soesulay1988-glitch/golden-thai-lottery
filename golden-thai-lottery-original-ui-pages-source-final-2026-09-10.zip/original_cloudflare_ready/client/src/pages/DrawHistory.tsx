import { useState, useMemo } from "react";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowLeft, ChevronDown, ChevronUp, Trophy, Calendar, Filter, X, Users } from "lucide-react";

const MONTH_KEYS: Array<{ key: string; mm: string; en: string }> = [
  { key: "jan", mm: "ဇန်နဝါရီ", en: "Jan" },
  { key: "feb", mm: "ဖေဖော်ဝါရီ", en: "Feb" },
  { key: "mar", mm: "မတ်", en: "Mar" },
  { key: "apr", mm: "ဧပြီ", en: "Apr" },
  { key: "may", mm: "မေ", en: "May" },
  { key: "jun", mm: "ဇွန်", en: "Jun" },
  { key: "jul", mm: "ဇူလိုင်", en: "Jul" },
  { key: "aug", mm: "ဩဂုတ်", en: "Aug" },
  { key: "sep", mm: "စက်တင်ဘာ", en: "Sep" },
  { key: "oct", mm: "အောက်တိုဘာ", en: "Oct" },
  { key: "nov", mm: "နိုဝင်ဘာ", en: "Nov" },
  { key: "dec", mm: "ဒီဇင်ဘာ", en: "Dec" },
];

function formatDate(d: any, lang: string): string {
  if (!d) return "";
  const date = d instanceof Date ? d : new Date(d);
  return date.toLocaleDateString(
    lang === "mm" ? "my-MM" : "en-US",
    { day: "numeric", month: "long", year: "numeric" }
  );
}

function toISODate(d: any): string {
  if (!d) return "";
  const date = d instanceof Date ? d : new Date(d);
  return date.toISOString().slice(0, 10);
}

// ─── Admin Stats Card ──────────────────────────────────────────────────────
function AdminStatsCard() {
  const { lang } = useLang();
  const mm = lang === "mm";
  const { data: stats, isLoading } = trpc.adminLuckyBox.getUserStats.useQuery();

  return (
    <div className="bg-gradient-to-r from-[#1a1a2e] to-[#16213e] rounded-xl p-4 shadow-lg border border-[#FFD700]/20">
      <div className="flex items-center gap-2 mb-3">
        <Users size={16} className="text-[#FFD700]" />
        <span className="text-xs font-bold text-[#FFD700] font-myanmar">{mm ? "Admin မှတ်တမ်း" : "Admin Stats"}</span>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white/10 rounded-lg p-3 text-center backdrop-blur-sm">
          <p className="text-2xl font-black prize-number text-white">
            {isLoading ? "..." : (stats?.totalUsers ?? 0).toLocaleString()}
          </p>
          <p className="text-[10px] text-gray-300 font-myanmar mt-1">{mm ? "စုစုပေါင်း User" : "Total Users"}</p>
        </div>
        <div className="bg-white/10 rounded-lg p-3 text-center backdrop-blur-sm">
          <p className="text-2xl font-black prize-number text-[#FFD700]">
            {isLoading ? "..." : (stats?.totalWinners ?? 0).toLocaleString()}
          </p>
          <p className="text-[10px] text-gray-300 font-myanmar mt-1">{mm ? "ပေါက်သူ" : "Winners"}</p>
        </div>
      </div>
    </div>
  );
}

export default function DrawHistory() {
  const { t, lang } = useLang();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [filterMonth, setFilterMonth] = useState<number | null>(null); // 0-11 or null
  const [filterYear, setFilterYear] = useState<number | null>(null);

  const { data: drawDates } = trpc.thaiLottery.listDrawDates.useQuery();

  // Extract unique years from draws
  const availableYears = useMemo(() => {
    if (!drawDates) return [];
    const years = new Set<number>();
    drawDates.forEach((d: any) => {
      const year = new Date(d.drawDate).getFullYear();
      years.add(year);
    });
    return Array.from(years).sort((a, b) => b - a);
  }, [drawDates]);

  // Filter draws
  const filteredDraws = useMemo(() => {
    if (!drawDates) return [];
    return drawDates.filter((draw: any) => {
      const date = new Date(draw.drawDate);
      if (filterMonth !== null && date.getMonth() !== filterMonth) return false;
      if (filterYear !== null && date.getFullYear() !== filterYear) return false;
      return true;
    });
  }, [drawDates, filterMonth, filterYear]);

  // Get the drawDate string for the expanded item
  const selectedDrawDate = useMemo(() => {
    if (!expandedId || !drawDates) return null;
    const draw = drawDates.find((d: any) => d.id === expandedId);
    return draw ? toISODate(draw.drawDate) : null;
  }, [expandedId, drawDates]);

  const { data: selectedDraw } = trpc.thaiLottery.getByDate.useQuery(
    { drawDate: selectedDrawDate || "" },
    { enabled: !!selectedDrawDate }
  );

  // Keep the history detail in exactly the same order as the lottery checker:
  // 1st → Near 1st → First 3 → Last 3 → Last 2 → 2nd → 3rd → 4th → 5th.
  // JSON prize columns are normalized by the server, but this helper also
  // safely handles older rows that may still arrive as serialized JSON.
  const formatPrizeList = (value: unknown): string => {
    if (Array.isArray(value)) return value.map(String).join(", ");
    if (typeof value !== "string" || !value.trim()) return "";
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.map(String).join(", ") : value;
    } catch {
      return value;
    }
  };

  const prizeRows = selectedDraw ? [
    { key: "1st", label: "1ST PRIZE", amount: "฿6,000,000", val: selectedDraw.firstPrize, color: "text-yellow-300" },
    { key: "near1st", label: "NEAR 1ST", amount: "฿100,000", val: formatPrizeList(selectedDraw.nearFirstPrize), color: "text-yellow-300" },
    { key: "last2", label: "LAST 2 DIGITS", amount: "฿2,000", val: selectedDraw.lastTwoDigits, color: "text-green-300" },
    { key: "first3", label: "FIRST 3", amount: "฿4,000", val: formatPrizeList(selectedDraw.firstThreeDigits), color: "text-purple-300" },
    { key: "last3", label: "LAST 3", amount: "฿4,000", val: formatPrizeList(selectedDraw.lastThreeDigits), color: "text-blue-300" },
    { key: "2nd", label: "2ND PRIZE", amount: "฿200,000", val: formatPrizeList(selectedDraw.secondPrize), color: "text-sky-300" },
    { key: "3rd", label: "3RD PRIZE", amount: "฿80,000", val: formatPrizeList(selectedDraw.thirdPrize), color: "text-blue-300" },
    { key: "4th", label: "4TH PRIZE", amount: "฿40,000", val: formatPrizeList(selectedDraw.fourthPrize), color: "text-indigo-300" },
    { key: "5th", label: "5TH PRIZE", amount: "฿20,000", val: formatPrizeList(selectedDraw.fifthPrize), color: "text-purple-300" },
  ].filter((row) => row.val !== null && row.val !== undefined && String(row.val).trim() !== "") : [];

  const hasFilter = filterMonth !== null || filterYear !== null;

  function clearFilter() {
    setFilterMonth(null);
    setFilterYear(null);
  }

  return (
    <div className="min-h-screen bg-[#FFF8E1]">
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/lottery")} className="text-[#333] btn-press"><ArrowLeft size={20} /></button>
          <h1 className="font-display text-base font-bold text-[#333] flex-1">
            {lang === "mm" ? "ဆွဲချက်မှတ်တမ်း" : "Draw History"}
          </h1>
          <span className="text-xs text-[#555] font-myanmar">
            {filteredDraws.length} / {drawDates?.length || 0} {lang === "mm" ? "ရက်စွဲ" : "draws"}
          </span>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 py-4 space-y-3">
        {/* ─── Admin Stats Card ───────────────────────────────────────────── */}
        <AdminStatsCard />

        {/* ─── Filter Bar ─────────────────────────────────────────────────── */}
        <div className="bg-gradient-to-r from-[#FFD700] via-[#FFC107] to-[#FFB300] rounded-xl p-3 shadow-sm border border-[#FFB300]/30">
          <div className="flex items-center gap-2 mb-2">
            <Filter size={14} className="text-[#333]" />
            <span className="text-xs font-bold text-[#333] font-myanmar">{t("filterBy")}</span>
            {hasFilter && (
              <button
                onClick={clearFilter}
                className="ml-auto bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 btn-press"
              >
                <X size={10} />
                {lang === "mm" ? "ဖျက်ရန်" : "Clear"}
              </button>
            )}
          </div>
          <div className="flex gap-2">
            {/* Month Selector */}
            <select
              value={filterMonth !== null ? filterMonth + 1 : ""}
              onChange={(e) => {
                const val = e.target.value;
                setFilterMonth(val === "" ? null : parseInt(val) - 1);
              }}
              className="flex-1 bg-white/90 border border-[#333]/10 rounded-lg px-3 py-2 text-xs font-myanmar text-[#333] focus:outline-none focus:border-[#333]/40 transition-all appearance-none cursor-pointer"
              style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23333' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 8px center" }}
            >
              <option value="">
                {lang === "mm" ? "လ — အားလုံး" : "Month — All"}
              </option>
              {MONTH_KEYS.map((m, i) => (
                <option key={m.key} value={i + 1}>
                  {m[lang as "mm" | "en"]}
                </option>
              ))}
            </select>

            {/* Year Selector */}
            <select
              value={filterYear !== null ? filterYear : ""}
              onChange={(e) => {
                const val = e.target.value;
                setFilterYear(val === "" ? null : parseInt(val));
              }}
              className="flex-1 bg-white/90 border border-[#333]/10 rounded-lg px-3 py-2 text-xs font-myanmar text-[#333] focus:outline-none focus:border-[#333]/40 transition-all appearance-none cursor-pointer"
              style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23333' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 8px center" }}
            >
              <option value="">
                {lang === "mm" ? "နှစ် — အားလုံး" : "Year — All"}
              </option>
              {availableYears.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* ─── Draw List ──────────────────────────────────────────────────── */}
        {filteredDraws.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Calendar size={48} className="mx-auto mb-3 text-amber-300" />
            <p className="font-myanmar text-sm">
              {hasFilter
                ? t("noFilteredDraws")
                : (lang === "mm" ? "မှတ်တမ်းမရှိသေးပါ" : "No history yet")}
            </p>
            {!hasFilter && (
              <p className="text-xs mt-1 text-muted-foreground">
                {lang === "mm" ? "လော့တာဆွဲချက်ရက်တွင် အလိုအလျောက် ပြည့်စုံပါမည်" : "Will populate on draw days"}
              </p>
            )}
          </div>
        )}
        {filteredDraws.map((draw: any) => {
          const isExpanded = expandedId === draw.id;
          const dateStr = formatDate(draw.drawDate, lang);
          return (
            <div key={draw.id} className="glass rounded-2xl overflow-hidden animate-fade-in-up">
              <button
                onClick={() => setExpandedId(isExpanded ? null : draw.id)}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-yellow-50/50 transition-colors"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-100 border border-amber-300 flex items-center justify-center flex-shrink-0">
                  <Calendar size={16} className="text-amber-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-semibold text-[#333] font-myanmar">{dateStr}</p>
                  {draw.firstPrize && (
                    <p className="text-xs text-muted-foreground prize-number">
                      {lang === "mm" ? "ပထမဆု: " : "1st: "}<span className="text-amber-600">{draw.firstPrize}</span>
                    </p>
                  )}
                </div>
                {isExpanded ? <ChevronUp size={16} className="text-amber-600" /> : <ChevronDown size={16} className="text-muted-foreground" />}
              </button>

              {isExpanded && selectedDraw && (
                <div className="px-3 pb-4 pt-3 border-t border-amber-100 animate-fade-in space-y-3">
                  <div className="flex items-center gap-2 px-1 mb-1">
                    <Trophy size={14} className="text-amber-600" />
                    <span className="text-xs text-amber-600 font-semibold uppercase tracking-wider">
                      {lang === "mm" ? "ဆုများ အပြည့်အစုံ" : "Full Prize Breakdown"}
                    </span>
                  </div>
                  {prizeRows.map((row) => {
                    const values = String(row.val ?? "").split(", ").filter(Boolean);
                    return (
                      <div key={row.key} className="bg-[#E8443A] rounded-xl p-4 shadow-lg">
                        <div className="flex items-center justify-between gap-2 mb-3">
                          <div className="flex items-center gap-2 min-w-0">
                            <div className="w-1 h-5 bg-white rounded-full shrink-0" />
                            <span className="text-xs font-bold text-white tracking-wider truncate">{row.label}</span>
                          </div>
                          <span className={`text-[11px] font-semibold shrink-0 ${row.color}`}>{row.amount}</span>
                        </div>

                        {row.key === "1st" ? (
                          <div className="flex justify-center gap-1.5">
                            {String(row.val).split("").map((digit, index) => (
                              <div key={`${row.key}-${index}`} className="w-9 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                                <span className="prize-number text-xl font-black text-[#333]">{digit}</span>
                              </div>
                            ))}
                          </div>
                        ) : row.key === "last2" ? (
                          <div className="flex items-center justify-end gap-2">
                            <span className={`prize-number text-3xl font-black ${row.color}`}>{String(row.val)}</span>
                          </div>
                        ) : (
                          <div className="flex flex-wrap gap-2">
                            {values.map((value, index) => (
                              <span key={`${row.key}-${index}-${value}`} className="prize-number text-sm font-black text-[#333] bg-white px-3 py-1.5 rounded-lg shadow-sm">
                                {value}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {isExpanded && !selectedDraw && (
                <div className="px-4 py-4 border-t border-amber-100">
                  <p className="text-xs text-muted-foreground text-center font-myanmar">
                    {lang === "mm" ? "ဆုအသေးစိတ် ရယူနေသည်..." : "Loading details..."}
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
