import { useState } from "react";
import { useLang } from "@/contexts/LangContext";
import { Play, ChevronLeft, ChevronRight } from "lucide-react";

// Replace with your actual YouTube channel URL
// Format: https://www.youtube.com/@YourChannelName or https://www.youtube.com/channel/UCxxx
const YOUTUBE_CHANNEL_URL = "https://www.youtube.com/@yourchannel";

// YouTube channel API alternative: use a playlist or video IDs
// For embedded player without API key, we use video IDs directly
const FEATURED_VIDEOS = [
  { id: "", title: "Video 1", titleMm: "ဗီဒီယို ၁" },
  // Add your video IDs here when available
];

interface YouTubeChannelProps {
  compact?: boolean;
}

export default function YouTubeChannel({ compact = false }: YouTubeChannelProps) {
  const { lang, t } = useLang();
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);

  // If we have a video selected, show the embed player
  if (activeVideoId) {
    return (
      <div className="space-y-3">
        <button
          onClick={() => setActiveVideoId(null)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ChevronLeft size={16} />
          {lang === "mm" ? "ဗီဒီယိုများ ပြန်ကြည့်မည်" : "Back to videos"}
        </button>
        <div className="relative w-full rounded-2xl overflow-hidden shadow-lg" style={{ paddingBottom: "56.25%" }}>
          <iframe
            src={`https://www.youtube.com/embed/${activeVideoId}?autoplay=1&rel=0&modestbranding=1`}
            className="absolute inset-0 w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            style={{ border: "none" }}
          />
        </div>
      </div>
    );
  }

  // Show channel embed with latest videos
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-foreground font-myanmar">
          {lang === "mm" ? "ဗီဒီယိုများ" : "Videos"}
        </h3>
      </div>

      {/* YouTube channel embedded player — shows latest videos from the channel */}
      <div className="rounded-2xl overflow-hidden shadow-md border border-red-100">
        <div className="w-full" style={{ paddingBottom: "56.25%" }}>
          <iframe
            src={`https://www.youtube.com/embed?listType=user_uploads&list=${YOUTUBE_CHANNEL_URL.replace(/.*@/, "").replace(/\/$/, "")}&autoplay=0&rel=0&modestbranding=1`}
            className="absolute top-0 left-0 w-full h-full"
            style={{ position: "relative", border: "none", width: "100%", height: "100%" }}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>
      </div>

      {/* Direct video player fallback — for when channel embed doesn't work on mobile */}
      <div className="rounded-2xl overflow-hidden shadow-md border border-red-100">
        <div className="w-full" style={{ paddingBottom: "56.25%" }}>
          <iframe
            src={`https://www.youtube.com/embed?listType=search&list=golden+thai+lottery&autoplay=0&rel=0&modestbranding=1`}
            className="absolute top-0 left-0 w-full h-full"
            style={{ position: "relative", border: "none", width: "100%", height: "100%" }}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>
      </div>
    </div>
  );
}
