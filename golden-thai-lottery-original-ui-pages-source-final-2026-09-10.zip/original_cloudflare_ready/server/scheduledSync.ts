/**
 * Scheduled Lottery Auto-Sync
 * ─────────────────────────────────────────────────────────────────────────────
 * This module handles:
 * 1. /api/scheduled/lottery-sync (Heartbeat on 1st & 16th)
 * 2. /api/scheduled/myanmar2d-sync (Heartbeat 2x daily after sessions)
 * 3. /api/scheduled/horoscope-refresh (weekly on Mondays)
 * 4. Heartbeat job registration on server startup
 */

import type { Express } from "express";
import { sendPushNotification } from "./pushNotifications";
import { createHeartbeatJob, listHeartbeatJobs, updateHeartbeatJob, type HeartbeatJobInfo } from "./_core/heartbeat";
import { sdk } from "./_core/sdk";
import {
  upsertThaiLotteryDraw,
  upsertHoroscopeReading,
  getDb,
  rebuildCalendar3dForYear,
  getLatestThaiLotteryDraw,
} from "./db";
import {
  getAllUsers,
  getWeeklyLuckyEnabledUsers,
  hasLuckyNumberBeenSent,
  insertLuckyNumberLog,
  insertUserNotification,
  hasResultNotified,
  insertLotteryResultNotificationLog,
  insertMyanmar2dNotificationLog,
  has2dResultNotified,
  getMyanmar2dAnalysis,
  getUsersWithPushSubscriptions,
  insertMonthlyReset,
  isMonthlyResetDone,
  deleteOldChatMessages,
  deleteOld2DResults,
  getAppSetting,
  setAppSetting,
} from "./db";
import { thaiLotteryDraws, myanmar2dResults } from "../drizzle/schema";
import { eq, sql, and } from "drizzle-orm";
import {
  generateMyanmar2dPrediction,
  getMyanmarPredictionDate,
  makeMyanmarPredictionSettingKey,
} from "./myanmar2dPrediction";

// ─── Thai Lottery HTML Scraper Helpers ───────────────────────────────────────
// Extracts lottery numbers from HTML text using regex patterns
function extractNumbersFromText(html: string, pattern: RegExp, limit = 100): string[] {
  const matches = html.match(pattern);
  if (!matches) return [];
  const nums = matches
    .map(m => m.replace(/\D/g, "").trim())
    .filter(n => n.length >= 6)
    .map(n => n.slice(-6)) // take last 6 digits
    .filter((n, i, arr) => arr.indexOf(n) === i) // unique
    .slice(0, limit);
  return nums;
}

function extractSpecificNumber(html: string, label: string, contextLength = 200): string | null {
  const regex = new RegExp(`${label}[\\s\\S]{0,${contextLength}}(\\d{6})`, "i");
  const match = html.match(regex);
  return match?.[1] ?? null;
}

// ─── Fallback 1: Kapook.com ──────────────────────────────────────────────────
// ─── Kapook.com HTML parser ──────────────────────────────────────────────────
// Parses a kapook.com lottery result page and extracts all prize categories.
type ThaiLotteryResult = {
  drawDate: string;
  firstPrize: string;
  nearFirstPrize: string[];
  firstThreeDigits: string[];
  lastThreeDigits: string[];
  lastTwoDigits: string;
  secondPrize: string[];
  thirdPrize: string[];
  fourthPrize: string[];
  fifthPrize: string[];
};

function parseKapookHtml(html: string): ThaiLotteryResult | null {
  // Helper: extract 6-digit lottery numbers from a section of HTML
  const extract6Digits = (section: string): string[] => {
    const nums = section.match(/\b\d{6}\b/g) || [];
    const seen = new Set<string>();
    return nums.filter(n => {
      if (seen.has(n)) return false;
      if (n.startsWith("2026") || n.startsWith("2569")) return false;
      seen.add(n);
      return true;
    });
  };

  // Split HTML by prize section headers (kapook uses <h4>รางวัลที่ N</h4>)
  const splitPatterns = {
    1: /รางวัลที่\s*1\s*<\/?h\d>/i,
    2: /รางวัลที่\s*2\s*<\/?h\d>/i,
    3: /รางวัลที่\s*3\s*<\/?h\d>/i,
    4: /รางวัลที่\s*4\s*<\/?h\d>/i,
    5: /รางวัลที่\s*5\s*<\/?h\d>/i,
  };
  const prize1Section = html.split(splitPatterns[1]);
  const prize2Section = html.split(splitPatterns[2]);
  const prize3Section = html.split(splitPatterns[3]);
  const prize4Section = html.split(splitPatterns[4]);
  const prize5Section = html.split(splitPatterns[5]);

  // Extract draw date from page (e.g., 16 สิงหาคม 2569)
  let drawDate = new Date().toISOString().slice(0, 10);
  const dateMatch = html.match(/(\d{1,2})\s*(มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม|ม\.ค\.|ก\.พ\.|มี\.ค\.|เม\.ย\.|พ\.ค\.|มิ\.ย\.|ก\.ค\.|ส\.ค\.|ก\.ย\.|ต\.ค\.|พ\.ย\.|ธ\.ค\.)\s*(\d{4})/);
  if (dateMatch) {
    const thaiMonthMap: Record<string, number> = {
      "มกราคม": 1, "กุมภาพันธ์": 2, "มีนาคม": 3, "เมษายน": 4,
      "พฤษภาคม": 5, "มิถุนายน": 6, "กรกฎาคม": 7, "สิงหาคม": 8,
      "กันยายน": 9, "ตุลาคม": 10, "พฤศจิกายน": 11, "ธันวาคม": 12,
      "ม.ค.": 1, "ก.พ.": 2, "มี.ค.": 3, "เม.ย.": 4,
      "พ.ค.": 5, "มิ.ย.": 6, "ก.ค.": 7, "ส.ค.": 8,
      "ก.ย.": 9, "ต.ค.": 10, "พ.ย.": 11, "ธ.ค.": 12,
    };
    const d = parseInt(dateMatch[1], 10);
    const mth = thaiMonthMap[dateMatch[2]] ?? 0;
    const westernYear = parseInt(dateMatch[3], 10) - 543;
    if (mth > 0) {
      drawDate = `${westernYear}-${String(mth).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    }
  }

  // First prize: first <strong>6-digit</strong> after รางวัลที่ 1 header
  let firstPrize = "";
  if (prize1Section.length > 1) {
    const match = prize1Section[1].match(/<strong>(\d{6})<\/strong>/);
    firstPrize = match?.[1] ?? "";
  }

  // Near first prize: read directly from the page section (more accurate than computing)
  const nearFirstPrize: string[] = [];
  const nearMatch = html.match(/รางวัลข้างเคียงรางวัลที่\s*1<\/h4>([\s\S]*?)<\/section>/i);
  if (nearMatch) {
    const nums = Array.from(nearMatch[1].matchAll(/<strong>\s*(\d{6})\s*<\/strong>/g)).map(x => x[1]);
    nearFirstPrize.push(...nums.slice(0, 2));
  }
  // Fallback: compute from first prize if page section not found
  if (nearFirstPrize.length === 0 && firstPrize && firstPrize.length === 6) {
    const num = parseInt(firstPrize, 10);
    nearFirstPrize.push(String(num - 1).padStart(6, "0"), String(num + 1).padStart(6, "0"));
  }

  // 2nd–5th prizes: all 6-digit numbers after each header
  const secondPrize = prize2Section.length > 1 ? extract6Digits(prize2Section[1]).slice(0, 5) : [];
  const thirdPrize = prize3Section.length > 1 ? extract6Digits(prize3Section[1]).slice(0, 10) : [];
  const fourthPrize = prize4Section.length > 1 ? extract6Digits(prize4Section[1]).slice(0, 50) : [];
  const fifthPrize = prize5Section.length > 1 ? extract6Digits(prize5Section[1]).slice(0, 100) : [];

  // Helper: extract <strong> digit values right after a specific <h4> label.
  // Anchoring on the <h4> tag avoids matching the page <meta> description text.
  const extractStrongAfterH4 = (label: string, count: number): string[] => {
    const re = new RegExp(`<h4>${label}<\\/h4>([\\s\\S]*?)(?:<\\/div>|<h4>)`, "i");
    const m = html.match(re);
    if (!m) return [];
    return Array.from(m[1].matchAll(/<strong>\s*(\d+)\s*<\/strong>/g)).map(x => x[1]).slice(0, count);
  };
  const first3Digits = extractStrongAfterH4("เลขหน้า\\s*3\\s*ตัว", 2);
  const last3Digits = extractStrongAfterH4("เลขท้าย\\s*3\\s*ตัว", 2);
  const lastTwo = extractStrongAfterH4("เลขท้าย\\s*2\\s*ตัว", 1)[0] ?? "";

  // Validate: must have at least a first prize or some prizes
  if (!firstPrize && !secondPrize.length && !fourthPrize.length) return null;
  return {
    drawDate,
    firstPrize,
    nearFirstPrize,
    firstThreeDigits: first3Digits,
    lastThreeDigits: last3Digits,
    lastTwoDigits: lastTwo,
    secondPrize,
    thirdPrize,
    fourthPrize,
    fifthPrize,
  };
}

// ─── Fallback 1: Kapook.com ──────────────────────────────────────────────────
async function fetchFromKapook(): Promise<ThaiLotteryResult | null> {
  try {
    // Generate kapook.com URL for the MOST RECENT draw date (1st or 16th).
    // Thai lottery draws happen on the 1st and 16th of each month.
    // Kapook format: DDMMYY (e.g. 010869 for 1 Aug 2569)
    const now = new Date();
    const thNow = new Date(now.getTime() + 7 * 60 * 60 * 1000);
    const day = thNow.getUTCDate();
    const month = thNow.getUTCMonth(); // 0-based
    const year = thNow.getUTCFullYear();
    // Determine the most recent draw date (1st or 16th, today or earlier)
    let drawDay: number, drawMonth: number, drawYear: number;
    if (day >= 16) {
      drawDay = 16; drawMonth = month; drawYear = year;
    } else {
      drawDay = 1; drawMonth = month; drawYear = year;
    }
    const fetchPage = async (d: number, m: number, y: number): Promise<string | null> => {
      const dd = String(d).padStart(2, "0");
      const mm = String(m + 1).padStart(2, "0");
      const yy = String(y - 543);
      const res = await fetch(`https://lottery.kapook.com/check/${dd}${mm}${yy}`, {
        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) return null;
      return res.text();
    };
    const hasFirstPrize = (html: string) =>
      /<h4>รางวัลที่\s*1<\/h4><strong>\d{6}<\/strong>/.test(html);

    // Try the most recent draw date first
    const html = await fetchPage(drawDay, drawMonth, drawYear);
    if (html && hasFirstPrize(html)) {
      return parseKapookHtml(html);
    }
    // Results not yet published for that date (e.g. morning of a draw day) —
    // fall back to the previous draw date.
    let prevDay = 16, prevMonth = drawMonth, prevYear = drawYear;
    if (drawDay === 16) {
      prevDay = 1;
    } else {
      prevDay = 16; prevMonth = drawMonth - 1;
      if (prevMonth < 0) { prevMonth = 11; prevYear -= 1; }
    }
    const prevHtml = await fetchPage(prevDay, prevMonth, prevYear);
    if (prevHtml && hasFirstPrize(prevHtml)) {
      return parseKapookHtml(prevHtml);
    }
    return null;
  } catch (err) {
    console.error("[LotterySync] Kapook fetch error:", err);
    return null;
  }
}

// ─── Fallback 2: Postjung.com ────────────────────────────────────────────────
async function fetchFromPostjung(): Promise<{
  drawDate: string;
  firstPrize: string;
  nearFirstPrize: string[];
  firstThreeDigits: string[];
  lastThreeDigits: string[];
  lastTwoDigits: string;
  secondPrize: string[];
  thirdPrize: string[];
  fourthPrize: string[];
  fifthPrize: string[];
} | null> {
  try {
    const res = await fetch("https://lotto.postjung.com/", {
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return null;
    const html = await res.text();

    // Postjung result cards use a label followed by an xres value. Reading
    // that block avoids accidentally matching numbers from page metadata.
    const extractCardNumbers = (label: string, count: number, digits: number): string[] => {
      const re = new RegExp(`<div class=["']xlabel["']>\\s*${label}\\s*<\\/div>([\\s\\S]*?)(?:<div class=["']xlabel["']>|<\\/div><\\/div>)`, "i");
      const m = html.match(re);
      if (!m) return [];
      // Depending on the prize type, Postjung uses <b> or <span> for the
      // number, sometimes nested inside a <div class="xres"> wrapper.
      const pattern = new RegExp(`<(?:b|span|div)(?:\\s[^>]*)?>\\s*(\\d{${digits}})\\s*<\\/(?:b|span|div)>`, "gi");
      return Array.from(m[1].matchAll(pattern)).map(x => x[1]).slice(0, count);
    };

    const firstPrize = extractCardNumbers("รางวัลที่ 1", 1, 6)[0] ?? "";
    const nearFirstPrize = extractCardNumbers("รางวัลข้างเคียงรางวัลที่ 1", 2, 6);
    const secondPrize = extractCardNumbers("รางวัลที่ 2", 5, 6);
    const thirdPrize = extractCardNumbers("รางวัลที่ 3", 10, 6);
    const fourthPrize = extractCardNumbers("รางวัลที่ 4", 50, 6);
    const fifthPrize = extractCardNumbers("รางวัลที่ 5", 100, 6);
    const first3Digits = extractCardNumbers("เลขหน้า 3 ตัว", 2, 3);
    const last3Digits = extractCardNumbers("เลขท้าย 3 ตัว", 2, 3);
    const lastTwo = extractCardNumbers("เลขท้าย 2 ตัว", 1, 2)[0] ?? "";

    // Some Postjung versions omit the near-first card; compute it only as a fallback.
    if (nearFirstPrize.length === 0 && firstPrize.length === 6) {
      const num = parseInt(firstPrize, 10);
      nearFirstPrize.push(String(num - 1).padStart(6, "0"), String(num + 1).padStart(6, "0"));
    }

    if (!firstPrize && !secondPrize.length && !fourthPrize.length) return null;

    // Postjung includes the actual Thai draw date in the page title/content.
    // Do not use new Date().toISOString() here: on a Thailand draw day it can
    // still be the previous UTC date, which would save the result incorrectly.
    let drawDate = new Date().toISOString().slice(0, 10);
    const dateMatch = html.match(/งวดวันที่\s*(\d{1,2})\s*(มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม)\s*(\d{4})/i);
    if (dateMatch) {
      const monthMap: Record<string, number> = {
        "มกราคม": 1, "กุมภาพันธ์": 2, "มีนาคม": 3, "เมษายน": 4,
        "พฤษภาคม": 5, "มิถุนายน": 6, "กรกฎาคม": 7, "สิงหาคม": 8,
        "กันยายน": 9, "ตุลาคม": 10, "พฤศจิกายน": 11, "ธันวาคม": 12,
      };
      const month = monthMap[dateMatch[2]] ?? 0;
      if (month > 0) {
        drawDate = `${parseInt(dateMatch[3], 10) - 543}-${String(month).padStart(2, "0")}-${String(parseInt(dateMatch[1], 10)).padStart(2, "0")}`;
      }
    }
    return {
      drawDate,
      firstPrize,
      nearFirstPrize,
      firstThreeDigits: first3Digits,
      lastThreeDigits: last3Digits,
      lastTwoDigits: lastTwo,
      secondPrize,
      thirdPrize,
      fourthPrize,
      fifthPrize,
    };
  } catch (err) {
    console.error("[LotterySync] Postjung fetch error:", err);
    return null;
  }
}

// ─── Main Thai Lottery Fetcher (tries all sources) ────────────────────────────
async function fetchOfficialThaiLotteryResult(): Promise<ThaiLotteryResult | null> {
  // Source 1: Official GLO API
  try {
    const res = await fetch("https://www.glo.or.th/api/lottery/getLatestLottery", {
      headers: {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (compatible; GoldenLottery/1.0)",
      },
      signal: AbortSignal.timeout(15000),
    });
    if (res.ok) {
      const json = await res.json() as any;
      const data = json?.response?.data?.prizes;
      if (data && data.first?.number?.[0]) {
        // Normalize the draw date to YYYY-MM-DD. The GLO API may return a
        // Thai-formatted date (e.g. "16 สิงหาคม 2569") or ISO — handle both.
        let drawDate = new Date().toISOString().slice(0, 10);
        const rawDate = String(json.response.data.date || "");
        if (/^\d{4}-\d{2}-\d{2}/.test(rawDate)) {
          drawDate = rawDate.slice(0, 10);
        } else {
          const dm = rawDate.match(/(\d{1,2})\s*(มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม)\s*(\d{4})/);
          if (dm) {
            const mmMap: Record<string, number> = {
              "มกราคม": 1, "กุมภาพันธ์": 2, "มีนาคม": 3, "เมษายน": 4,
              "พฤษภาคม": 5, "มิถุนายน": 6, "กรกฎาคม": 7, "สิงหาคม": 8,
              "กันยายน": 9, "ตุลาคม": 10, "พฤศจิกายน": 11, "ธันวาคม": 12,
            };
            const mth = mmMap[dm[2]] ?? 0;
            if (mth > 0) {
              drawDate = `${parseInt(dm[3], 10) - 543}-${String(mth).padStart(2, "0")}-${String(parseInt(dm[1], 10)).padStart(2, "0")}`;
            }
          }
        }
        console.log("[LotterySync] ✅ Fetched from GLO API");
        return {
          drawDate,
          firstPrize: data.first?.number?.[0] ?? "",
          nearFirstPrize: data.near_first?.number ?? [],
          firstThreeDigits: data.three_front?.number ?? [],
          lastThreeDigits: data.three_last?.number ?? [],
          lastTwoDigits: data.two_last?.number?.[0] ?? "",
          secondPrize: data.second?.number ?? [],
          thirdPrize: data.third?.number ?? [],
          fourthPrize: data.fourth?.number ?? [],
          fifthPrize: data.fifth?.number ?? [],
        };
      }
    }
  } catch (err) {
    console.warn("[LotterySync] GLO API failed:", String(err).slice(0, 80));
  }

  // Source 2: Fallback HTML scraper - kapook.com
  try {
    const result = await fetchFromKapook();
    if (result) {
      console.log("[LotterySync] ✅ Fetched from kapook.com");
      return result;
    }
  } catch (err) {
    console.warn("[LotterySync] Kapook scraper failed:", String(err).slice(0, 80));
  }

  // Source 3: Fallback HTML scraper - postjung.com
  try {
    const result = await fetchFromPostjung();
    if (result) {
      console.log("[LotterySync] ✅ Fetched from postjung.com");
      return result;
    }
  } catch (err) {
    console.warn("[LotterySync] Postjung scraper failed:", String(err).slice(0, 80));
  }

  console.warn("[LotterySync] All sources failed");
  return null;
}

// Format SET index value with comma separators for display
function formatSetIndex(value: string): string {
  const str = value.toString().trim();
  if (!str || str === "--") return str;
  const parts = str.split(".");
  // Add comma to integer part (e.g., "1622" → "1,622")
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return parts.join(".");
}

function getThailandNow(now = new Date()): Date {
  return new Date(now.getTime() + 7 * 60 * 60 * 1000);
}

function isMyanmar2dClosedDay(now = new Date()): boolean {
  const day = getThailandNow(now).getUTCDay();
  return day === 0 || day === 6;
}

function myanmar2dClosedDayMessage(now = new Date()): string {
  return `2D closed on ${getThailandNow(now).getUTCDay() === 6 ? "Saturday" : "Sunday"}`;
}

// ─── Myanmar 2D Auto-Sync ────────────────────────────────────────────────────
// Fetches from https://api.thaistock2d.com/live
// Sessions: 11:00, 12:01, 15:00, 16:30 (provider's Myanmar time UTC+6:30)
// morning session = 11:00 & 12:01 (hour < 13), evening = 15:00 & 16:30
async function fetchAndSaveMyanmar2dResults() {
  if (isMyanmar2dClosedDay()) {
    const message = myanmar2dClosedDayMessage();
    console.log(`[Myanmar2DSync] Skipping — ${message}`);
    return { success: true, saved: 0, skipped: true, message, date: getThailandNow().toISOString().slice(0, 10) };
  }
  try {
    const res = await fetch("https://api.thaistock2d.com/live", {
      headers: {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (compatible; GoldenLottery/1.0)",
      },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) {
      console.warn("[Myanmar2DSync] API returned non-OK:", res.status);
      return { success: false, message: `API status ${res.status}` };
    }
    const json = await res.json() as any;
    const results: Array<{
      time?: string;
      open_time?: string;
      twod?: string;
      set?: string;
      value?: string;
      stock_date?: string;
    }> = json?.result ?? [];

    if (!results.length) {
      console.warn("[Myanmar2DSync] No results in API response");
      return { success: false, message: "No results" };
    }

    const db = await getDb();
    if (!db) return { success: false, message: "No DB" };

    // A live result must belong to today's Thailand market date. This prevents
    // an API response cached from a previous weekday being shown as a new draw.
    const todayThailand = getThailandNow().toISOString().slice(0, 10);

    // Filter to only morning (12:01) and evening (16:30) sessions
    const filteredResults = results.filter((r) => {
      const t = r.open_time || r.time || "";
      return t.startsWith("12:01") || t.startsWith("16:30");
    });

    let saved = 0;
    const savedSessions: Array<"morning" | "evening"> = [];
    let lastDate = "";
    for (const r of filteredResults) {
      // Skip if set/value are empty or "--"
      if (!r.set || r.set === "--" || !r.value || r.value === "--") continue;

      const resultDate = String(r.stock_date || "").slice(0, 10);
      if (!resultDate || resultDate !== todayThailand) {
        console.warn(`[Myanmar2DSync] Skipping stale or undated row: ${resultDate || "missing date"}`);
        continue;
      }
      lastDate = resultDate;

      // Map time to session by exact time match
      const timeField = r.open_time || r.time || "";
      const session: "morning" | "evening" = timeField.startsWith("12:01") ? "morning" : "evening";

      // Use only a real two-digit official result. Never invent "00" when the
      // provider has not published a number yet.
      const twoD = String(r.twod || "").trim();
      if (!/^\d{1,2}$/.test(twoD)) {
        console.warn(`[Myanmar2DSync] Missing verified 2D number for ${session}, skipping row`);
        continue;
      }

      // Safely format set value
      let formattedSet = "";
      try {
        const setStr = String(r.set).trim();
        formattedSet = formatSetIndex(setStr);
      } catch (e) {
        formattedSet = String(r.set);
      }

      const normalizedTwoD = twoD.padStart(2, "0");
      const existingRows = await db.select()
        .from(myanmar2dResults)
        .where(and(
          sql`${myanmar2dResults.resultDate} = ${resultDate}`,
          eq(myanmar2dResults.session, session)
        ))
        .limit(1);

      // The backup schedule may run after the primary job. Keep the verified
      // record unchanged in that case so the notification is not sent twice.
      if (existingRows[0]?.winningNumber === normalizedTwoD) {
        continue;
      }

      // Upsert: remove existing same date+session then insert fresh
      await db.delete(myanmar2dResults).where(
        and(
          sql`${myanmar2dResults.resultDate} = ${resultDate}`,
          eq(myanmar2dResults.session, session)
        )
      );
      await db.insert(myanmar2dResults).values({
        resultDate: new Date(resultDate),
        session,
        winningNumber: normalizedTwoD,
        setNumber: formattedSet,
        valueNumber: r.value,
      });
      saved++;
      savedSessions.push(session);
      console.log(`[Myanmar2DSync] Saved ${session} session: date=${resultDate}, 2D=${twoD}, SET=${formattedSet}`);
    }
    console.log(`[Myanmar2DSync] ✅ Total saved: ${saved}`);
    return { success: true, saved, sessions: savedSessions, date: lastDate || new Date().toISOString().slice(0, 10) };
  } catch (err) {
    console.error("[Myanmar2DSync] Error:", err);
    return { success: false, error: String(err) };
  }
}

// ─── Horoscope Weekly Refresh ─────────────────────────────────────────────────
const BIRTH_DAYS = [
  "sunday", "monday", "tuesday", "wednesday_am",
  "wednesday_pm", "thursday", "friday", "saturday",
] as const;

const HOROSCOPE_TEMPLATES = {
  sunday:       { mm: "ဂဠုန်နေ့ဖွားများ ဤအပတ်တွင် ကံကောင်းသောအချိန်ဖြစ်သည်။ စီးပွားရေးတွင် တိုးတက်မှုများ ရရှိမည်။", en: "Garuda-born Sunday people will experience great fortune this week. Business improvements are on the horizon." },
  monday:       { mm: "ကျားသစ်နေ့ဖွားများ ဤအပတ်တွင် ကျန်းမာရေးကောင်းမွန်မည်။ ချစ်သူများနှင့် ပေါင်းသင်းဆက်ဆံရေး ကောင်းမည်။", en: "Tiger-born Monday people will enjoy good health this week. Relationships will flourish." },
  tuesday:      { mm: "ခြင်္သေ့နေ့ဖွားများ ဤအပတ်တွင် ငွေကြေးဆိုင်ရာ အကျိုးအမြတ်ရမည်။ ရင်းနှီးမြှုပ်နှံမှုများ အောင်မြင်မည်။", en: "Lion-born Tuesday people will gain financial benefits this week. Investments will succeed." },
  wednesday_am: { mm: "ဆင်နေ့ဖွားများ ဤအပတ်တွင် ပညာရေးနှင့် ဆက်သွယ်ရေးတွင် ကောင်းမွန်မည်။", en: "Elephant-born Wednesday AM people will excel in education and communication this week." },
  wednesday_pm: { mm: "ကျားနေ့ဖွားများ ဤအပတ်တွင် ခရီးသွားလာရေး ကောင်းမည်။ ဝင်ငွေတိုးပွားမည်။", en: "Tiger-born Wednesday PM people will have favorable travel and increased income this week." },
  thursday:     { mm: "ကြွက်နေ့ဖွားများ ဤအပတ်တွင် မိသားစုနှင့် ပတ်သက်သောကိစ္စများ ကောင်းမွန်မည်။", en: "Rat-born Thursday people will see improvements in family matters this week." },
  friday:       { mm: "ကြိုးနေ့ဖွားများ ဤအပတ်တွင် အနုပညာနှင့် ဖန်တီးမှုတွင် ထူးချွန်မည်။ ကံကောင်းသောနေ့ဖြစ်သည်။", en: "Guinea Pig-born Friday people will excel in arts and creativity this week. A lucky period awaits." },
  saturday:     { mm: "နဂါးနေ့ဖွားများ ဤအပတ်တွင် အာဏာနှင့် ဩဇာသည် မြင့်တက်မည်။ ခေါင်းဆောင်မှုစွမ်းရည် ပြသနိုင်မည်။", en: "Dragon-born Saturday people will see their authority and influence rise this week. Leadership opportunities await." },
};

const LUCKY_COLORS = ["ရွှေရောင်", "နီရောင်", "စိမ်းရောင်", "ပြာရောင်", "ဖြူရောင်", "ခရမ်းရောင်", "လိမ္မော်ရောင်", "ပန်းရောင်"];
const LUCKY_DIRECTIONS = ["အရှေ့", "အနောက်", "မြောက်", "တောင်", "အရှေ့မြောက်", "အနောက်တောင်", "အရှေ့တောင်", "အနောက်မြောက်"];

function getWeekStart(): string {
  const now = new Date();
  const day = now.getDay();
  const diff = now.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(now.setDate(diff));
  return monday.toISOString().slice(0, 10);
}

async function generateWeeklyHoroscopes() {
  const weekStart = getWeekStart();
  for (let i = 0; i < BIRTH_DAYS.length; i++) {
    const bd = BIRTH_DAYS[i];
    const tmpl = HOROSCOPE_TEMPLATES[bd];
    const colorIdx = (i + new Date().getMonth()) % LUCKY_COLORS.length;
    const dirIdx = (i + new Date().getDate()) % LUCKY_DIRECTIONS.length;
    const nums2d = Array.from({ length: 4 }, (_, j) => String((i * 13 + j * 7 + new Date().getMonth() * 3) % 100).padStart(2, "0"));
    const numsLottery = Array.from({ length: 2 }, (_, j) => String((i * 137 + j * 97 + new Date().getDate() * 13) % 1000000).padStart(6, "0"));

    await upsertHoroscopeReading({
      weekStart: new Date(weekStart),
      birthDay: bd,
      forecastMm: tmpl.mm,
      forecastEn: tmpl.en,
      luckyColor: LUCKY_COLORS[colorIdx],
      luckyDirection: LUCKY_DIRECTIONS[dirIdx],
      auspiciousNumbers: nums2d,
      lotteryNumbers: numsLottery,
    });
  }
  console.log(`[HoroscopeRefresh] Generated horoscopes for week ${weekStart}`);
}

// ─── Manual Sync (called from admin UI or scheduled route) ────────────────────
// Validate prize arrays to prevent corruption from scraper fallbacks
function validatePrizeData(data: { fourthPrize: string[]; fifthPrize: string[]; thirdPrize: string[]; secondPrize: string[] }) {
  const issues: string[] = [];
  if (data.fourthPrize.length !== 50) {
    issues.push(`4th prize has ${data.fourthPrize.length} numbers (expected 50)`);
  }
  if (data.fifthPrize.length !== 100) {
    issues.push(`5th prize has ${data.fifthPrize.length} numbers (expected 100)`);
  }
  if (data.thirdPrize.length !== 10) {
    issues.push(`3rd prize has ${data.thirdPrize.length} numbers (expected 10)`);
  }
  if (data.secondPrize.length !== 5) {
    issues.push(`2nd prize has ${data.secondPrize.length} numbers (expected 5)`);
  }
  return issues;
}

export async function runSync(): Promise<{ success: boolean; drawDate?: string; firstPrize?: string; source?: string; message?: string }> {
  const result = await fetchOfficialThaiLotteryResult();
  if (!result) {
    return { success: false, message: "No data from any source" };
  }
  // Guard: skip saving if the fetched draw is not newer than what we already
  // have. This prevents re-notifying users about the same draw on every sync.
  try {
    const latest = await getLatestThaiLotteryDraw();
    if (latest) {
      const latestDate = new Date(latest.drawDate).toISOString().slice(0, 10);
      const fetchedDate = new Date(result.drawDate).toISOString().slice(0, 10);
      if (fetchedDate <= latestDate && latest.firstPrize === result.firstPrize) {
        console.log(`[LotterySync] Draw ${fetchedDate} already up-to-date (1st: ${latest.firstPrize}), skipping save`);
        return { success: true, drawDate: fetchedDate, firstPrize: result.firstPrize, source: "auto-sync", message: "Already up-to-date" };
      }
    }
  } catch (err) {
    console.warn("[LotterySync] Could not check latest draw:", err);
  }
  // Validate prize counts before upserting
  const validationIssues = validatePrizeData({
    fourthPrize: result.fourthPrize,
    fifthPrize: result.fifthPrize,
    thirdPrize: result.thirdPrize,
    secondPrize: result.secondPrize,
  });

  if (validationIssues.length > 0) {
    console.warn("[LotterySync] Data validation warnings:", validationIssues.join(", "));
    // Only reject if all lower prizes are wrong counts (likely scraper failure)
    const allWrong = validationIssues.length >= 3;
    if (allWrong) {
      return { success: false, message: `Data validation failed: ${validationIssues.join(", ")}` };
    }
  }

  await upsertThaiLotteryDraw({
    drawDate: new Date(result.drawDate),
    firstPrize: result.firstPrize,
    nearFirstPrize: result.nearFirstPrize,
    firstThreeDigits: result.firstThreeDigits,
    lastThreeDigits: result.lastThreeDigits,
    lastTwoDigits: result.lastTwoDigits,
    secondPrize: result.secondPrize,
    thirdPrize: result.thirdPrize,
    fourthPrize: result.fourthPrize,
    fifthPrize: result.fifthPrize,
    isPublished: true,
    source: "auto-sync",
  });

  // Trigger in-app notifications for all users
  try {
    await sendLotteryResultNotifications(result.drawDate, result.firstPrize, result.lastTwoDigits);
  } catch (err) {
    console.warn("[LotterySync] Failed to send in-app notifications:", err);
  }

  // Trigger web push notifications
  try {
    const { broadcastLotteryResult } = await import("./pushNotifications");
    await broadcastLotteryResult(result.drawDate, result.firstPrize, result.lastTwoDigits);
  } catch (err) {
    console.warn("[LotterySync] Failed to send push notifications:", err);
  }

  // Auto-populate 3D calendar data using the chronological draw sequence row
  try {
    const year = new Date(result.drawDate).getFullYear();
    const updated = await rebuildCalendar3dForYear(year);
    console.log(`[LotterySync] 3D Calendar rebuilt for ${year}: ${updated} entries`);
  } catch (err) {
    console.warn("[LotterySync] Failed to update 3D calendar:", err);
  }

  return { success: true, drawDate: result.drawDate, firstPrize: result.firstPrize, source: "auto-sync" };
}

// ─── Register Express Routes ──────────────────────────────────────────────────
export function registerScheduledRoutes(app: Express) {
  // Thai Lottery sync — called only by a project-owned scheduled job on the 1st and 16th
  app.post("/api/scheduled/lottery-sync", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron) {
        return res.status(403).json({ success: false, error: "Scheduled callback only" });
      }
    } catch (err) {
      return res.status(403).json({ success: false, error: "Scheduled callback only" });
    }
    try {
      console.log("[LotterySync] Starting scheduled sync...");
      const result = await runSync();
      res.json(result);
    } catch (err) {
      console.error("[LotterySync] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  const handleDailyAiPrediction = async (req: any, res: any, session: "morning" | "evening") => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron) {
        return res.status(403).json({ success: false, error: "Scheduled callback only" });
      }
    } catch {
      return res.status(403).json({ success: false, error: "Scheduled callback only" });
    }

    try {
      const result = await generateAndStoreDailyAiPrediction(session);
      return res.json(result);
    } catch (err) {
      console.error(`[Ai2DPrediction] ${session} error:`, err);
      return res.status(500).json({ success: false, error: String(err) });
    }
  };

  app.post("/api/scheduled/myanmar2d-ai-prediction-morning", (req, res) =>
    handleDailyAiPrediction(req, res, "morning"),
  );
  app.post("/api/scheduled/myanmar2d-ai-prediction-evening", (req, res) =>
    handleDailyAiPrediction(req, res, "evening"),
  );

  // Horoscope weekly refresh — called every Monday
  app.post("/api/scheduled/horoscope-refresh", async (_req, res) => {
    try {
      await generateWeeklyHoroscopes();
      res.json({ success: true, weekStart: getWeekStart() });
    } catch (err) {
      console.error("[HoroscopeRefresh] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Myanmar 2D sync — called by Heartbeat 2x daily after sessions
  // SMART NOTIFICATION: sends "before result" notification if result not yet fetched,
  // then sends "with number" notification once the result is synced.
  app.post("/api/scheduled/myanmar2d-sync", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron) {
        return res.status(403).json({ success: false, error: "Scheduled callback only" });
      }
    } catch {
      return res.status(403).json({ success: false, error: "Scheduled callback only" });
    }
    try {
      // Skip sync on Saturday (6) and Sunday (0) — 2D is closed on these days
      if (isMyanmar2dClosedDay()) {
        const message = myanmar2dClosedDayMessage();
        console.log(`[Myanmar2D Sync] Skipping — ${message}`);
        return res.json({ success: true, skipped: true, message });
      }

      const result = await fetchAndSaveMyanmar2dResults();
      const resultDate = result.date || new Date().toISOString().slice(0, 10);

      // Notify only sessions changed by this trigger. The backup Heartbeat
      // calls are therefore idempotent and cannot repeat a completed result.
      const sessions: Array<"morning" | "evening"> = result.success && Array.isArray(result.sessions)
        ? result.sessions
        : [];

      if (result.success && (result.saved || 0) > 0 && sessions.length > 0) {
        // === AFTER RESULT: Send notification WITH the actual 2D number ===
        for (const session of sessions) {
          try {
            const allUsers = await getAllUsers();
            let notifSent = 0;
            
            // Get the actual winning number for this session
            const db = await getDb();
            let winningNumber = "";
            if (db) {
              const rows = await db.select()
                .from(myanmar2dResults)
                .where(and(
                  sql`${myanmar2dResults.resultDate} = ${resultDate}`,
                  eq(myanmar2dResults.session, session)
                ))
                .limit(1);
              if (rows[0]) {
                winningNumber = rows[0].winningNumber;
              }
            }

            for (const user of allUsers) {
              // Use "after" suffix to differentiate from "before-result" notifications
              const logKey = `${session}-after`;
              const alreadySent = await has2dResultNotified(user.id, resultDate, logKey as any);
              if (alreadySent) continue;

              const sessionMm = session === "morning" ? "\u1019\u1006\u102D\u102F\u1004\u103A\u101B\u102D\u102F\u1000\u103A\u1014\u1014\u103A\u1014\u102D\u102F\u1004\u103A" : "\u100A\u1004\u103A\u1014\u1014\u103A\u101B\u102D\u102F\u1000\u103A";
              const titleMm = `\uD83C\uDFAF ${sessionMm} 2D \u1021\u1004\u103A \u101B\u1000\u103A\u101E\u102A\u1004\u103A\u1038 \u101B\u102D\u102F\u1000\u103A\u101B\u102E!`;
              const bodyMm = `${resultDate} ${sessionMm} 2D: \u1013\u102E\u1015\u103A\u1013\u1030 ${winningNumber} \u1021\u1004\u103A \u101B\u1000\u103A\u101E\u102A\u1004\u103A\u1038 \u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B!`;

              await insertUserNotification({
                userId: user.id,
                type: "myanmar_2d_result" as any,
                title: titleMm,
                body: bodyMm,
                drawDate: resultDate,
                luckyNumber: winningNumber,
              });

              await insertMyanmar2dNotificationLog({
                userId: user.id,
                resultDate,
                session: logKey as any,
              });

              notifSent++;
            }
            console.log(`[2DNotification-AFTER] ${session} ${resultDate}: ${winningNumber} sent=${notifSent}`);

            const sessionTitle = session === "morning"
              ? `🎯 မနက်ခင်း 2D ထွက်ပါပြီ — ${winningNumber}`
              : `🎯 ညနေခင်း 2D ထွက်ပါပြီ — ${winningNumber}`;
            await sendPushNotification({
              title: sessionTitle,
              body: "Golden Thai 2D ရလဒ်ကို ကြည့်ရန်နှိပ်ပါ",
              url: "/2d",
              icon: "/icons/golden-thai-2d-crown.png",
              badge: "/icons/golden-thai-2d-crown.png",
              requireInteraction: true,
              tag: `myanmar-2d-${resultDate}-${session}`,
              vibrate: [180, 90, 180],
            });
          } catch (err) {
            console.warn(`[2DNotification-AFTER] Failed for ${session}:`, String(err).slice(0, 120));
          }
        }
      }

      // === BEFORE RESULT: Send notification WITHOUT number if result not yet synced ===
      // Only for morning session, and only if no result was saved yet
      if (result.success && sessions.length === 0 && resultDate === new Date().toISOString().slice(0, 10)) {
        const myanmarNow = new Date();
        const myanmarHour = new Date(myanmarNow.getTime() + 6.5 * 60 * 60 * 1000).getUTCHours();
        
        // Before-result notifications: morning (before 12:00 MYT) and evening (before 16:30 MYT)
        if (myanmarHour >= 5 && myanmarHour < 11) {
          // Morning: result not yet available (before 12:01 TH session)
          try {
            const allUsers = await getAllUsers();
            let notifSent = 0;
            for (const user of allUsers) {
              const alreadySent = await has2dResultNotified(user.id, resultDate, "morning-before" as any);
              if (alreadySent) continue;

              const titleMm = `\uD83C\uDFAF \u1019\u1006\u102D\u102F\u1004\u103A\u101B\u102D\u102F\u1000\u103A\u1014\u1014\u103A\u1014\u102D\u102F\u1004\u103A 2D \u101B\u102D\u102F\u1000\u103A\u101B\u102E \u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B\u1014\u1031\u102C\u103A\u1005\u102D`;
              const bodyMm = `${resultDate} \u1019\u1006\u102D\u102F\u1004\u103A\u101B\u102D\u102F\u1000\u103A 2D \u1021\u1004\u103A \u101B\u1000\u103A\u101E\u102A\u1004\u103A\u1038 \u1019\u103E\u1004\u103A \u1019\u103E\u1019\u103D\u1014\u103A\u1038 \u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B! App \u1000\u1031\u102C\u1004\u103A\u1038\u101B\u1014\u103A \u1013\u103B\u102C\u1014\u103A\u1038 \u1015\u103D\u1011\u103A\u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B`; 

              await insertUserNotification({
                userId: user.id,
                type: "myanmar_2d_result" as any,
                title: titleMm,
                body: bodyMm,
                drawDate: resultDate,
              });

              await insertMyanmar2dNotificationLog({
                userId: user.id,
                resultDate,
                session: "morning-before" as any,
              });

              notifSent++;
            }
            console.log(`[2DNotification-BEFORE] morning ${resultDate}: sent=${notifSent}`);
          } catch (err) {
            console.warn(`[2DNotification-BEFORE] Failed for morning:`, String(err).slice(0, 120));
          }
        } else if (myanmarHour >= 9 && myanmarHour < 15) {
          // Evening: result not yet available (before 16:30 TH session)
          try {
            const allUsers = await getAllUsers();
            let notifSent = 0;
            for (const user of allUsers) {
              const alreadySent = await has2dResultNotified(user.id, resultDate, "evening-before" as any);
              if (alreadySent) continue;

              const titleMm = `\uD83C\uDFAF \u100A\u1004\u103A\u1014\u1014\u103A\u101B\u102D\u102F\u1000\u103A 2D \u101B\u102D\u102F\u1000\u103A\u101B\u102E \u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B\u1014\u1031\u102C\u103A\u1005\u102D`;
              const bodyMm = `${resultDate} \u100A\u1004\u103A\u1014\u1014\u103A 2D \u1021\u1004\u103A \u101B\u1000\u103A\u101E\u102A\u1004\u103A\u1038 \u1019\u103E\u1004\u103A \u1019\u103E\u1019\u103D\u1014\u103A\u1038 \u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B! App \u1000\u1031\u102C\u1004\u103A\u1038\u101B\u1014\u103A \u1013\u103B\u102C\u1014\u103A\u1038 \u1015\u103D\u1011\u103A\u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B`;

              await insertUserNotification({
                userId: user.id,
                type: "myanmar_2d_result" as any,
                title: titleMm,
                body: bodyMm,
                drawDate: resultDate,
              });

              await insertMyanmar2dNotificationLog({
                userId: user.id,
                resultDate,
                session: "evening-before" as any,
              });

              notifSent++;
            }
            console.log(`[2DNotification-BEFORE] evening ${resultDate}: sent=${notifSent}`);
          } catch (err) {
            console.warn(`[2DNotification-BEFORE] Failed for evening:`, String(err).slice(0, 120));
          }
        }
      }

      res.json(result);
    } catch (err) {
      console.error("[Myanmar2DSync] Route error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  app.post("/api/scheduled/myanmar2d-sync-manual", async (req, res) => {
    const secret = req.headers["x-admin-secret"];
    if (secret !== process.env.JWT_SECRET) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    if (isMyanmar2dClosedDay()) {
      return res.status(409).json({ success: false, message: myanmar2dClosedDayMessage() });
    }
    try {
      const result = await fetchAndSaveMyanmar2dResults();
      res.json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Manual trigger endpoint (admin use)
  app.post("/api/scheduled/lottery-sync-manual", async (req, res) => {
    const secret = req.headers["x-admin-secret"];
    if (secret !== process.env.JWT_SECRET) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    try {
      const result = await runSync();
      res.json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // ─── Lucky Box Reminder Notifications (4x daily) ───────────────────────────
  // Slot 1: 03:30 UTC = 10:00 Myanmar time
  // Slot 2: 05:30 UTC = 12:00 Myanmar time
  // Slot 3: 08:30 UTC = 15:00 Myanmar time
  // Slot 4: 14:30 UTC = 21:00 Myanmar time
  app.post("/api/scheduled/lucky-box-reminder-1", async (_req, res) => {
    try {
      const result = await sendLuckyBoxReminder(1);
      res.json(result);
    } catch (err) {
      console.error("[LuckyBoxReminder1] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  app.post("/api/scheduled/lucky-box-reminder-2", async (_req, res) => {
    try {
      const result = await sendLuckyBoxReminder(2);
      res.json(result);
    } catch (err) {
      console.error("[LuckyBoxReminder2] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  app.post("/api/scheduled/lucky-box-reminder-3", async (_req, res) => {
    try {
      const result = await sendLuckyBoxReminder(3);
      res.json(result);
    } catch (err) {
      console.error("[LuckyBoxReminder3] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  app.post("/api/scheduled/lucky-box-reminder-4", async (_req, res) => {
    try {
      const result = await sendLuckyBoxReminder(4);
      res.json(result);
    } catch (err) {
      console.error("[LuckyBoxReminder4] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Monthly Reset — runs on 1st of each month
  app.post("/api/scheduled/lucky-box-monthly-reset", async (_req, res) => {
    try {
      const now = new Date();
      const myanmarNow = new Date(now.getTime() + 6.5 * 60 * 60 * 1000);
      const year = myanmarNow.getFullYear();
      const month = myanmarNow.getMonth() + 1;

      const alreadyDone = await isMonthlyResetDone(year, month);
      if (alreadyDone) {
        return res.json({ success: true, message: "Already reset" });
      }

      await insertMonthlyReset(year, month);
      res.json({ success: true, message: "Monthly reset completed" });
    } catch (err) {
      console.error("[LuckyBoxMonthlyReset] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Lucky Number — 7 days before draw
  app.post("/api/scheduled/lucky-number-7d", async (_req, res) => {
    try {
      const result = await sendLuckyNumberNotifications("lucky_number_7d");
      res.json(result);
    } catch (err) {
      console.error("[LuckyNumber7d] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Lucky Number — draw morning
  app.post("/api/scheduled/lucky-number-draw-day", async (_req, res) => {
    try {
      const result = await sendLuckyNumberNotifications("lucky_number_draw_day");
      res.json(result);
    } catch (err) {
      console.error("[LuckyNumberDrawDay] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Thai Lottery 3D Lucky Number — 9:00 AM MYT on draw days (1st and 16th)
  app.post("/api/scheduled/thai-3d-morning", async (_req, res) => {
    try {
      const result = await sendThai3DMorningNotification();
      res.json(result);
    } catch (err) {
      console.error("[Thai3DMorning] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // ─── Pre-Session 2D Lucky Number Prediction (4 sessions) ─────────────────
  // 9:00 AM, 11:30 AM, 2:00 PM, 4:00 PM Myanmar time
  app.post("/api/scheduled/lucky-2d-session1", async (_req, res) => {
    try {
      const result = await sendLucky2DPrediction("session1");
      res.json(result);
    } catch (err) {
      console.error("[Lucky2D-9am] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  app.post("/api/scheduled/lucky-2d-session2", async (_req, res) => {
    try {
      const result = await sendLucky2DPrediction("session2");
      res.json(result);
    } catch (err) {
      console.error("[Lucky2D-1130am] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  app.post("/api/scheduled/lucky-2d-session3", async (_req, res) => {
    try {
      const result = await sendLucky2DPrediction("session3");
      res.json(result);
    } catch (err) {
      console.error("[Lucky2D-2pm] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  app.post("/api/scheduled/lucky-2d-session4", async (_req, res) => {
    try {
      const result = await sendLucky2DPrediction("session4");
      res.json(result);
    } catch (err) {
      console.error("[Lucky2D-4pm] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Hot Number Alert — runs 20 min before each session
  app.post("/api/scheduled/hot-number-morning", async (_req, res) => {
    try {
      const result = await sendHotNumberAlert("morning");
      res.json(result);
    } catch (err) {
      console.error("[HotNumberMorning] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  app.post("/api/scheduled/hot-number-evening", async (_req, res) => {
    try {
      const result = await sendHotNumberAlert("evening");
      res.json(result);
    } catch (err) {
      console.error("[HotNumberEvening] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Weekly 3D Lucky Number — runs every Sunday at 09:00 Myanmar time
  app.post("/api/scheduled/weekly-3d-lucky", async (_req, res) => {
    try {
      const now = new Date();
      const myanmarNow = new Date(now.getTime() + 6.5 * 60 * 60 * 1000);
      const drawDate = myanmarNow.toISOString().slice(0, 10);
      const result = await sendLuckyNumberNotifications("weekly_3d");

      // Also send web push notification to all subscribers
      const pushResult = await sendPushNotification({
        title: "🍀 ကံကောင်းဂဏန်း ပို့ပေးပါပြီ!",
        body: "တနင်္ဂနွေ ၃ဒီ ကံကောင်းဂဏန်းကို ကြည့်ရန် App ကိုဖွင့်ပါ",
        url: "/",
        icon: "/favicon.ico",
        badge: "/favicon.ico",
      });

      res.json({ ...result, drawDate, push: pushResult });
    } catch (err) {
      console.error("[Weekly3DLucky] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });

  // Daily Cleanup — retain 2D history for 60 days; chat records keep their separate 7-day policy
  app.post("/api/scheduled/daily-cleanup", async (_req, res) => {
    try {
      const deletedChat = await deleteOldChatMessages(7);
      const deletedResults = await deleteOld2DResults(60);
      console.log(`[DailyCleanup] Deleted ${deletedChat} chat messages, ${deletedResults} 2D results`);
      res.json({ success: true, deletedChat, deletedResults });
    } catch (err) {
      console.error("[DailyCleanup] Error:", err);
      res.status(500).json({ success: false, error: String(err) });
    }
  });
}


// ─── Lucky Number Notification Logic ─────────────────────────────────────────
function generateUnique3DNumber(userId: number, drawDate: string, type: string): string {
  const seed = userId * 31 + drawDate.split("-").reduce((a: number, b: string) => a + parseInt(b, 10), 0) + type.length;
  const digits: number[] = [];
  let s = Math.abs(seed);
  while (digits.length < 3) {
    const d = s % 10;
    if (!digits.includes(d)) digits.push(d);
    s = Math.floor(s / 7) + (s % 3) * 13 + 1;
    if (s === 0) s = userId + 1;
  }
  return digits.join("");
}

async function sendLuckyNumberNotifications(type: "lucky_number_7d" | "lucky_number_draw_day" | "weekly_3d") {
  const db = await getDb();
  if (!db) return { success: false, message: "No DB" };

  const now = new Date();
  const thNow = new Date(now.getTime() + 7 * 60 * 60 * 1000);
  const thYear = thNow.getUTCFullYear();
  const thMonth = thNow.getUTCMonth();
  const thDay = thNow.getUTCDate();

  let drawDate: string;
  if (type === "lucky_number_7d") {
    const d1 = new Date(Date.UTC(thYear, thMonth, 1));
    const d16 = new Date(Date.UTC(thYear, thMonth, 16));
    const nextMonth1 = new Date(Date.UTC(thYear, thMonth + 1, 1));
    const nextMonth16 = new Date(Date.UTC(thYear, thMonth + 1, 16));
    const today = new Date(Date.UTC(thYear, thMonth, thDay));
    const candidates = [d1, d16, nextMonth1, nextMonth16].filter(d => {
      const diff = Math.round((d.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return diff >= 6 && diff <= 8;
    });
    if (candidates.length === 0) return { success: true, skipped: "no draw in 7-day window", type };
    drawDate = candidates[0].toISOString().slice(0, 10);
  } else if (type === "weekly_3d") {
    // Weekly uses today's date — no draw-day gating
    drawDate = new Date(Date.UTC(thYear, thMonth, thDay)).toISOString().slice(0, 10);
  } else {
    // lucky_number_draw_day: only on 1st and 16th
    if (thDay !== 1 && thDay !== 16) return { success: true, skipped: "not a draw day", type };
    drawDate = new Date(Date.UTC(thYear, thMonth, thDay)).toISOString().slice(0, 10);
  }

  const allUsers = type === "weekly_3d" ? await getWeeklyLuckyEnabledUsers() : await getAllUsers();
  let sent = 0;
  let skipped = 0;

  for (const user of allUsers) {
    const alreadySent = await hasLuckyNumberBeenSent(user.id, drawDate, type);
    if (alreadySent) { skipped++; continue; }

    const luckyNum = generateUnique3DNumber(user.id, drawDate, type);
    const isWeekly = type === "weekly_3d";
    const is7d = type === "lucky_number_7d";
    let titleMm: string;
    let bodyMm: string;
    if (isWeekly) {
      titleMm = "🍀 \u1000\u1036\u1000\u1031\u102C\u1004\u103A\u1038 \u101B\u1015\u103A\u1000\u1036 \u101C\u1031\u102C\u1000 \u1014\u101A\u102E\u1019\u1004\u103A \u1000\u1036\u101C\u102F\u1004\u103A\u1038 \u1043\u1014\u103A \u1021\u1031\u102C\u1004\u103A \u1001\u101A\u103A\u1015\u1031\u102C\u1004\u103A!";
      bodyMm = `\u1014\u101A\u102E\u1019\u1004\u103A \u1000\u1036\u101C\u102F\u1004\u103A\u1038 \u1000\u1036\u1000\u1031\u102C\u1004\u103A\u1038 \u1021\u1031\u102C\u1004\u103A \u1014\u101A\u102E \u1014\u103E\u1010\u103A — 🎯 ${luckyNum} — \u1014\u102E\u1001\u1036\u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B\u1005\u1031! \u1000\u1036\u1000\u1031\u102C\u1004\u103A\u1038 \u1019\u1015\u103A\u1038 \u1014\u1019\u1000\u103A\u1014\u1031\u1037 \u1014\u1019\u1000\u103A\u1014\u1031\u1037 \u1014\u1019\u1000\u103A\u1014\u1031\u1037 \u101E\u1031\u102C\u1000\u103A \u1014\u103E\u1010\u103A\u1019\u1004\u103A\u1038 \u1000\u1036\u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B\u1005\u1031!`;
    } else {
      titleMm = is7d
        ? "\uD83C\uDFB0 \u101B\u1000\u103A\u1016\u103C\u1015\u103A \u1041 \u101B\u1000\u103A\u101E\u102AC \u1000\u103B\u1014\u103A\u1010\u1031\u102B\u101E\u100A\u103A!"
        : "\uD83C\uDF1F \u101A\u1014\u1031\u1037 \u101B\u1000\u103A\u1006\u103C\u1032\u1001\u103B\u1000\u103A\u1014\u1031\u1037 \u1019\u1014\u1000\u103A\u1015\u102D\u102F\u1004\u103A\u1038!";
      bodyMm = is7d
        ? `${drawDate} \u101B\u1000\u103A\u1006\u103C\u1032\u1001\u103B\u1000\u103A\u1021\u1010\u103C\u1000\u103A \u101E\u1004\u103A\u1038\u101E\u100A\u103A Lucky 3D \u2014 \uD83C\uDFAF ${luckyNum} \u2014 \u1000\u1036\u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B\u1005\u1031!`
        : `\u101A\u1014\u1031\u1037 ${drawDate} \u101B\u1000\u103A\u1006\u103C\u1032\u1001\u103B\u1000\u103A\u1014\u1031\u1037 \u1019\u1014\u1000\u103A\u1015\u102D\u102F\u1004\u103A\u1038! Lucky 3D \u2014 \uD83C\uDFAF ${luckyNum} \u2014 \u1000\u1036\u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B\u1005\u1031!`;
    }

    await insertUserNotification({
      userId: user.id,
      type,
      title: titleMm,
      body: bodyMm,
      luckyNumber: luckyNum,
      drawDate,
    });

    await insertLuckyNumberLog({
      userId: user.id,
      drawDate,
      type,
      luckyNumber: luckyNum,
    });

    sent++;
  }

  console.log(`[LuckyNumber] type=${type} drawDate=${drawDate} sent=${sent} skipped=${skipped}`);
  return { success: true, type, drawDate, sent, skipped };
}

// ─── Thai Lottery 3D Morning Notification (9:00 AM MYT on 1st and 16th) ───────
async function sendThai3DMorningNotification() {
  const now = new Date();
  const myanmarNow = new Date(now.getTime() + 6.5 * 60 * 60 * 1000);
  const myanmarHour = myanmarNow.getUTCHours();

  // Gate: only between 8:30-9:30 MYT
  if (myanmarHour < 8 || myanmarHour >= 10) {
    return { success: true, skipped: "not 9:00 AM MYT time window" };
  }

  const myanmarDate = myanmarNow.toISOString().slice(0, 10);
  const myanmarDay = myanmarNow.getUTCDate();

  // Only on draw days (1st and 16th)
  if (myanmarDay !== 1 && myanmarDay !== 16) {
    return { success: true, skipped: "not a draw day (1st/16th)" };
  }

  const allUsers = await getAllUsers();
  let sent = 0;
  let skipped = 0;

  for (const user of allUsers) {
    const alreadySent = await hasLuckyNumberBeenSent(user.id, myanmarDate, "thai_3d_morning");
    if (alreadySent) { skipped++; continue; }

    const luckyNum = generateUnique3DNumber(user.id, myanmarDate, "thai_3d_morning");

    // Notification with grandfather figure on both sides
    const titleMm = `👴 မက် မက် လုင် ပွန် လည် သောက်သူ မစေ ၃ ကောင် ကာတိုင်း ကံလုင်း နိုင်န် မျင်း 👴`;
    const bodyMm = `👴 ${luckyNum} 👴 — မစေ လုင် မက် ရစျင်း သောက် မစေရှု ကံလုင်း မက် ကာတိုင်းပြီး သင်း နှတ် ကံကောင်းပါစေ!`;

    await insertUserNotification({
      userId: user.id,
      type: "lucky_number_draw_day" as any,
      title: titleMm,
      body: bodyMm,
      luckyNumber: luckyNum,
      drawDate: myanmarDate,
    });

    await insertLuckyNumberLog({
      userId: user.id,
      drawDate: myanmarDate,
      type: "thai_3d_morning",
      luckyNumber: luckyNum,
    });

    sent++;
  }

  console.log(`[Thai3DMorning] date=${myanmarDate} sent=${sent} skipped=${skipped}`);

  // Send web push notification with grandfather figure
  try {
    await sendPushNotification({
      title: "👴 မက် မက် လုင် ပွန် လည် သောက် သင်းသည် လုင် ပွန် 3D 👴",
      body: "မက် လုင် လည် သောက် မက် သင်းသည် 3D ကံလုင်း App ကျန်ပိုင် ကောင်းပါ ပြီးပြီး ရိုက်ပြီးပြီး သောက် နှတ် ကံကောင်းပါ!",
      url: "/lucky",
      icon: "/favicon.ico",
      badge: "/favicon.ico",
    });
  } catch {
    // Push may fail if no subscribers
  }

  return { success: true, date: myanmarDate, sent, skipped };
}


// ─── Lottery Result Push Notification ─────────────────────────────────────────
// Idempotency: lottery_result_notification_log prevents duplicate sends

async function sendLotteryResultNotifications(drawDate: string, firstPrize: string, lastTwoDigits: string) {
  try {
    const allUsers = await getAllUsers();
    let sent = 0;
    let skipped = 0;

    for (const user of allUsers) {
      const alreadySent = await hasResultNotified(user.id, drawDate);
      if (alreadySent) { skipped++; continue; }

      const titleMm = `\uD83C\uDF89 ${drawDate} \u101B\u1000\u103A\u1006\u103C\u1032\u1001\u103B\u1000\u103A \u101E\u1004\u103A\u1038\u101E\u100A\u103A \u101B\u1000\u103A\u101E\u102AC \u1019\u1014\u1000\u103A\u1015\u102D\u102F\u1004\u103A\u1038 \u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B!`;
      const titleEn = `\uD83C\uDF89 Thai Lottery Results for ${drawDate} are now available!`;
      const bodyMm = `\u101B\u1000\u103A\u101E\u102AC \u101B\u1000\u103A\u1006\u103C\u1032\u1001\u103B\u1000\u103A \u1005\u1015\u102F\u1004\u103A\u1038 ${firstPrize} | \u1014\u1031\u101E\u1031\u102C\u103A \u1014\u1031\u101E\u1031\u102C\u103A \u1014\u1031\u101E\u1031\u102C\u103A \u1014\u1031\u101E\u1031\u102C\u103A \u1014\u1031\u101E\u1031\u102C\u103A \u1014\u1031\u101E\u1031\u102C\u103A \u1014\u1031\u101E\u1031\u102C\u103A ${lastTwoDigits} \u1019\u1000\u103A\u1001\u103B\u103E\u1004\u103A\u1038 \u101E\u1014\u103A\u1015\u103C\u102E\u1038\u1015\u103C\u102E\u1038\u1019\u1014\u1000\u103A\u1019\u1014\u103A\u1001\u103D\u1014\u103A\u1038 \u1000\u1031\u102C\u1004\u103A\u1038\u1015\u102B!`;
      const bodyEn = `1st Prize: ${firstPrize} | Last 2 Digits: ${lastTwoDigits} — Check your tickets now!`;

      await insertUserNotification({
        userId: user.id,
        type: "lottery_result",
        title: titleMm,
        body: bodyMm,
        drawDate,
      });

      await insertLotteryResultNotificationLog({
        userId: user.id,
        drawDate,
      });

      sent++;
    }

    console.log(`[LotteryResultNotif] drawDate=${drawDate} sent=${sent} skipped=${skipped}`);
  } catch (err) {
    console.error("[LotteryResultNotif] Error sending notifications:", err);
  }
}

// ─── Heartbeat Job Registration ───────────────────────────────────────────────
// ─── Lucky 2D Prediction (Pre-Session) ─────────────────────────────────────
// Sends 3 unique 2D numbers to all users before each session (4 sessions/day)
// Session 1: 9:00 MYT, Session 2: 11:30 MYT, Session 3: 14:00 MYT, Session 4: 16:00 MYT
async function sendLucky2DPrediction(session: "session1" | "session2" | "session3" | "session4") {
  if (isMyanmar2dClosedDay()) {
    return { success: true, skipped: myanmar2dClosedDayMessage() };
  }
  const db = await getDb();
  if (!db) return { success: false, message: "No DB" };

  const now = new Date();
  const myanmarNow = new Date(now.getTime() + 6.5 * 60 * 60 * 1000);
  const myanmarDate = myanmarNow.toISOString().slice(0, 10);
  const myanmarHour = myanmarNow.getUTCHours();

  // Gate: check time windows for each session
  // Session 1: 8:30-9:30 MYT, Session 2: 11:00-12:00 MYT
  // Session 3: 13:30-14:30 MYT, Session 4: 15:30-16:30 MYT
  if (session === "session1" && (myanmarHour < 8 || myanmarHour >= 10)) {
    return { success: true, skipped: "not session1 prediction time" };
  }
  if (session === "session2" && (myanmarHour < 11 || myanmarHour >= 13)) {
    return { success: true, skipped: "not session2 prediction time" };
  }
  if (session === "session3" && (myanmarHour < 13 || myanmarHour >= 15)) {
    return { success: true, skipped: "not session3 prediction time" };
  }
  if (session === "session4" && (myanmarHour < 15 || myanmarHour >= 17)) {
    return { success: true, skipped: "not session4 prediction time" };
  }

  // Session labels — 2 morning + 2 evening
  const sessionInfo: Record<string, { label: string; timeLabel: string; numLabel: string }> = {
    session1: { label: "၉:၀၀ နံနက်", timeLabel: "၉:၀၀", numLabel: "session1" },
    session2: { label: "၁၁:၃၀ နံနက်", timeLabel: "၁၁:၃၀", numLabel: "session2" },
    session3: { label: "၂:၀၀ ညနေ", timeLabel: "၂:၀၀", numLabel: "session3" },
    session4: { label: "၄:၀၀ ညနေ", timeLabel: "၄:၀၀", numLabel: "session4" },
  };
  const info = sessionInfo[session];

  const allUsers = await getAllUsers();
  let sent = 0;

  for (const user of allUsers) {
    const alreadySent = await has2dResultNotified(user.id, myanmarDate, session);
    if (alreadySent) continue;

    // Generate 3 unique 2D numbers based on user seed + date + session
    const baseSeed = user.id * 31 + myanmarDate.split("-").reduce((a: number, b: string) => a + parseInt(b, 10), 0) + session.length;
    const luckyNums: string[] = [];
    const usedNums = new Set<string>();
    for (let i = 0; i < 3; i++) {
      let s = Math.abs(baseSeed + i * 7 + user.id);
      const d1 = s % 10;
      const d2 = Math.floor(s / 10) % 10;
      let num = `${d1}${d2}`;
      let attempts = 0;
      while (usedNums.has(num) && attempts < 50) {
        s = Math.abs(s * 7 + attempts + 1);
        num = `${s % 10}${Math.floor(s / 10) % 10}`;
        attempts++;
      }
      luckyNums.push(num);
      usedNums.add(num);
    }
    const luckyNumStr = luckyNums.join(", ");

    const titleMm = `🔔 ${info.label} 2D ခန့်မှန်းဂဏန်း`;
    const bodyMm = `${info.label} 2D ခန့်မှန်းဂဏန်း: ${luckyNumStr} — ပေါက်မပေါက် ကံစမ်းကြည့်ပါ 🍀`;

    await insertUserNotification({
      userId: user.id,
      type: "myanmar_2d_result",
      title: titleMm,
      body: bodyMm,
      luckyNumber: luckyNums[0],
      drawDate: myanmarDate,
    });

    await insertMyanmar2dNotificationLog({
      userId: user.id,
      resultDate: myanmarDate,
      session: session,
    });

    sent++;
  }

  console.log(`[Lucky2D] session=${session} date=${myanmarDate} sent=${sent}`);

  // Send push notification with loud sound — show 3 numbers in body
  const isMorning = session === "session1" || session === "session2";
  const timeGroup = isMorning ? "မနက်ပိုင်း" : "ညနေပိုင်း";
  const pushTitle = `🔔 ${info.label} 2D ခန့်မှန်းဂဏန်း`;
  const pushBody = `${info.label} 2D ခန့်မှန်းဂဏန်း ၃ လုံး ပို့ပေးပါပြီ! App ကိုဖွင့်၍ ကြည့်ပါ 🍀`;

  try {
    await sendPushNotification({
      title: pushTitle,
      body: pushBody,
      url: "/lucky",
      icon: "/favicon.ico",
      badge: "/favicon.ico",
      requireInteraction: true,
      tag: "lucky-2d",
      vibrate: [300, 100, 300, 100, 300],
    });
  } catch {
    // Push may fail if no subscribers
  }

  return { success: true, session, date: myanmarDate, sent };
}

// ─── Hot Number Alert (Pre-Session) ─────────────────────────────────────────
// Sends top hot numbers to users 15 min before each session
async function sendHotNumberAlert(session: "morning" | "evening") {
  if (isMyanmar2dClosedDay()) {
    return { success: true, skipped: myanmar2dClosedDayMessage() };
  }
  const analysis = await getMyanmar2dAnalysis();
  if (!analysis || analysis.hotNumbers.length === 0) {
    return { success: true, skipped: "no analysis data" };
  }

  const topHot = analysis.hotNumbers.slice(0, 4).map((h: { number: string; count: number }) => h.number).join(", ");

  const allUsers = await getAllUsers();
  let sent = 0;
  const now = new Date();
  const myanmarNow = new Date(now.getTime() + 6.5 * 60 * 60 * 1000);
  const myanmarDate = myanmarNow.toISOString().slice(0, 10);

  for (const user of allUsers) {
    // Use the same log table but with a special date suffix to avoid conflict with actual results
    const logDate = `${myanmarDate}-hot-${session}`;
    const alreadySent = await has2dResultNotified(user.id, myanmarDate, session);
    if (alreadySent) continue;

    const sessionLabel = session === "morning" ? "မနက်ပိုင်း" : "ညနေပိုင်း";
    const titleMm = `🔥 အနီကပ်ဂဏန်း ${sessionLabel}`;
    const bodyMm = `${sessionLabel} 2D အနီကပ်ဂဏန်းများ: ${topHot} — မထွက်ခင် ကြည့်ပါ! 🍀`;

    await insertUserNotification({
      userId: user.id,
      type: "hot_number_alert",
      title: titleMm,
      body: bodyMm,
      luckyNumber: analysis.hotNumbers[0]?.number ?? "00",
      drawDate: myanmarDate,
    });

    sent++;
  }

  console.log(`[HotNumber] session=${session} date=${myanmarDate} sent=${sent}`);

  // Send push notification
  try {
    await sendPushNotification({
      title: `🔥 အနီကပ်ဂဏန်း ${session === "morning" ? "မနက်ပိုင်း" : "ညနေပိုင်း"}`,
      body: `မထွက်ခင် အနီကပ်ဂဏန်းများ: ${topHot} — ကြည့်ရန် App ကိုဖွင့်ပါ!`,
      url: "/2d",
      icon: "/favicon.ico",
      badge: "/favicon.ico",
    });
  } catch {
    // Push may fail if no subscribers
  }

  return { success: true, session, hotNumbers: analysis.hotNumbers.slice(0, 4), sent };
}

// ─── Lucky Box Reminder Notifications (4x daily) ───────────────────────────
async function sendLuckyBoxReminder(slot: number) {
  const titles: Record<number, string> = {
    1: "🎁 မနက် ၁၀ နာရီ ကံစမ်းရန်!",
    2: "🎁 နေ့လည် ၁၂ နာရီ ကံစမ်းရန်!",
    3: "🎁 ညနေ ၃ နာရီ ကံစမ်းရန်!",
    4: "🎁 ည ၉ နာရီ ကံစမ်းရန်!",
  };
  const bodies: Record<number, string> = {
    1: "🎁 Lucky Box ဖွင့်ချိန်! မနက် ၁၀ နာရီ — ဆုပေါက်နိုင်တယ်! 🍀",
    2: "🎁 Lucky Box ဖွင့်ချိန်! နေ့လည် ၁၂ နာရီ — ကံထူးကြည့်ပါ! 🎉",
    3: "🎁 Lucky Box ဖွင့်ချိန်! ညနေ ၃ နာရီ — ဆုပေါက်နိုင်တယ်! 🎊",
    4: "🎁 Lucky Box ဖွင့်ချိန်! ည ၉ နာရီ — ဒီနေ့ နောက်ဆုံး! 🎁",
  };

  const title = titles[slot] || "🎁 Lucky Box!",
    body = bodies[slot] || "Lucky Box ဖွင့်ချိန်! ";

  try {
    await sendPushNotification({
      title,
      body,
      url: "/lucky-box",
      icon: "/favicon.ico",
      badge: "/favicon.ico",
    });
  } catch {
    // Push may fail if no subscribers
  }

  console.log(`[LuckyBoxReminder] slot=${slot} title=${title}`);
  return { success: true, slot };
}

async function generateAndStoreDailyAiPrediction(session: "morning" | "evening") {
  if (isMyanmar2dClosedDay()) {
    return { success: true, skipped: myanmar2dClosedDayMessage() };
  }

  const predictionDate = getMyanmarPredictionDate();
  const key = makeMyanmarPredictionSettingKey(predictionDate, session);
  const existing = await getAppSetting(key);
  if (existing) {
    return { success: true, date: predictionDate, session, skipped: "already-generated" };
  }

  const prediction = await generateMyanmar2dPrediction("mm");
  await setAppSetting(key, JSON.stringify(prediction));
  console.log(`[Ai2DPrediction] generated date=${predictionDate} session=${session}`);
  return { success: true, date: predictionDate, session };
}

export async function registerHeartbeatJobs() {
  if (process.env.NODE_ENV !== "production") {
    console.log("[Heartbeat] Job registration skipped outside production");
    return;
  }
  try {
    const existingJobs = new Map<string, HeartbeatJobInfo>();
    try {
      const existing = await listHeartbeatJobs("");
      if (existing && Array.isArray(existing.jobs)) {
        existing.jobs.forEach((job) => existingJobs.set(job.name, job));
      }
    } catch {
      console.log("[Heartbeat] Could not list existing jobs, attempting registration anyway");
    }

    // Thai lottery results are announced around 15:00–16:30 Thailand time
    // (UTC+7) on the 1st and 16th of each month. We schedule MULTIPLE sync
    // attempts across that window so the numbers appear in the app as soon
    // as they are published. The sync endpoint is idempotent — it skips
    // saving when the draw is already up-to-date, so repeated calls are safe.
    // Cron times below are in UTC: 08:30 UTC = 15:30 TH, 09:00 = 16:00 TH,
    // 09:30 = 16:30 TH, 10:00 = 17:00 TH, 10:30 = 17:30 TH.
    const thaiSyncTimes = [
      { cronMin: "30", cronHour: "8", label: "15:30" },
      { cronMin: "0", cronHour: "9", label: "16:00" },
      { cronMin: "30", cronHour: "9", label: "16:30" },
      { cronMin: "0", cronHour: "10", label: "17:00" },
      { cronMin: "30", cronHour: "10", label: "17:30" },
    ];
    const thaiSyncJobs = thaiSyncTimes.flatMap((t) => ([
      {
        name: `thai-lottery-sync-1st-${t.cronHour}${t.cronMin}`,
        cron: `0 ${t.cronMin} ${t.cronHour} 1 * *`,
        path: "/api/scheduled/lottery-sync",
        method: "POST" as const,
        description: `Auto-sync Thai Lottery on the 1st at ${t.label} TH time`,
      },
      {
        name: `thai-lottery-sync-16th-${t.cronHour}${t.cronMin}`,
        cron: `0 ${t.cronMin} ${t.cronHour} 16 * *`,
        path: "/api/scheduled/lottery-sync",
        method: "POST" as const,
        description: `Auto-sync Thai Lottery on the 16th at ${t.label} TH time`,
      },
    ]));
    const jobs = [
      ...thaiSyncJobs,
      {
        // Extra safety net: poll every 5 minutes from 15:00–17:55 Thailand
        // time on both draw days. Once new numbers appear, runSync saves them;
        // before that, it safely keeps the previous draw.
        name: "thai-lottery-sync-draw-window",
        cron: "0 */5 8-10 1,16 * *",
        path: "/api/scheduled/lottery-sync",
        method: "POST" as const,
        description: "Poll Thai Lottery results every 5 minutes during the 1st/16th draw window",
      },
      {
        name: "horoscope-weekly-refresh",
        cron: "0 0 0 * * 1",
        path: "/api/scheduled/horoscope-refresh",
        method: "POST" as const,
        description: "Refresh weekly horoscope readings every Monday",
      },
      {
        name: "myanmar2d-sync-morning",
        // 05:35 UTC = 12:05 Myanmar time (after 12:01 session is published)
        cron: "0 35 5 * * 1-5",
        path: "/api/scheduled/myanmar2d-sync",
        method: "POST" as const,
        description: "Sync Myanmar 2D morning session result (after 12:01 Myanmar time)",
      },
      {
        name: "myanmar2d-sync-morning-backup",
        // 05:45 UTC = 12:15 Myanmar time (backup if first attempt fails)
        cron: "0 45 5 * * 1-5",
        path: "/api/scheduled/myanmar2d-sync",
        method: "POST" as const,
        description: "Backup sync Myanmar 2D morning session (12:15 Myanmar time)",
      },
      {
        name: "myanmar2d-sync-evening",
        // 10:05 UTC = 16:35 Myanmar time (after 16:30 session is published)
        cron: "0 5 10 * * 1-5",
        path: "/api/scheduled/myanmar2d-sync",
        method: "POST" as const,
        description: "Sync Myanmar 2D evening session result (after 16:30 Myanmar time)",
      },
      {
        name: "myanmar2d-sync-evening-backup",
        // 10:15 UTC = 16:45 Myanmar time (backup if first attempt fails)
        cron: "0 15 10 * * 1-5",
        path: "/api/scheduled/myanmar2d-sync",
        method: "POST" as const,
        description: "Backup sync Myanmar 2D evening session (16:45 Myanmar time)",
      },
      {
        name: "myanmar2d-ai-prediction-morning",
        // 04:00 UTC = 10:30 Myanmar time
        cron: "0 0 4 * * 1-5",
        path: "/api/scheduled/myanmar2d-ai-prediction-morning",
        method: "POST" as const,
        description: "Generate and save morning AI 2D candidates at 10:30 Myanmar time",
      },
      {
        name: "myanmar2d-ai-prediction-evening",
        // 09:00 UTC = 15:30 Myanmar time
        cron: "0 0 9 * * 1-5",
        path: "/api/scheduled/myanmar2d-ai-prediction-evening",
        method: "POST" as const,
        description: "Generate and save evening AI 2D candidates at 15:30 Myanmar time",
      },
      {
        name: "thai-3d-morning",
        // Run at 02:30 UTC = 9:00 Myanmar time on draw days (1st and 16th)
        cron: "0 30 2 1,16 * *",
        path: "/api/scheduled/thai-3d-morning",
        method: "POST" as const,
        description: "Send Lucky 3D number at 9:00 AM on Thai lottery draw days (1st and 16th)",
      },
      // REMOVED: lucky-number-7d and lucky-number-draw-day — 3D now sent only at 9:00 AM on draw days
      // Old jobs: lucky-number-7d (daily at 9AM TH) + lucky-number-draw-day (8AM on draw days)
      // ─── 2D Lucky Numbers: 2 morning + 2 evening per day ──────────────
      {
        name: "lucky-2d-session1",
        // 02:30 UTC = 9:00 Myanmar time (morning session 1)
        cron: "0 30 2 * * 1-5",
        path: "/api/scheduled/lucky-2d-session1",
        method: "POST" as const,
        description: "Send Lucky 2D prediction for 9:00 AM morning session",
      },
      {
        name: "lucky-2d-session2",
        // 05:00 UTC = 11:30 Myanmar time (morning session 2)
        cron: "0 0 5 * * 1-5",
        path: "/api/scheduled/lucky-2d-session2",
        method: "POST" as const,
        description: "Send Lucky 2D prediction for 11:30 AM morning session",
      },
      {
        name: "lucky-2d-session3",
        // 07:30 UTC = 14:00 Myanmar time (evening session 1)
        cron: "0 30 7 * * 1-5",
        path: "/api/scheduled/lucky-2d-session3",
        method: "POST" as const,
        description: "Send Lucky 2D prediction for 2:00 PM evening session",
      },
      {
        name: "lucky-2d-session4",
        // 09:30 UTC = 16:00 Myanmar time (evening session 2)
        cron: "0 30 9 * * 1-5",
        path: "/api/scheduled/lucky-2d-session4",
        method: "POST" as const,
        description: "Send Lucky 2D prediction for 4:00 PM evening session",
      },
      {
        name: "hot-number-morning",
        // 04:15 UTC = 10:45 Myanmar time (15 min before 11:00 AM session)
        cron: "0 45 4 * * 1-5",
        path: "/api/scheduled/hot-number-morning",
        method: "POST" as const,
        description: "Send hot number alert for morning session (10:45 MYT)",
      },
      {
        name: "hot-number-evening",
        // 09:45 UTC = 16:15 Myanmar time (15 min before 16:30 session)
        cron: "0 45 9 * * 1-5",
        path: "/api/scheduled/hot-number-evening",
        method: "POST" as const,
        description: "Send hot number alert for evening session (16:15 MYT)",
      },
      {
        name: "lucky-box-reminder-1",
        cron: "0 30 3 * * *",
        path: "/api/scheduled/lucky-box-reminder-1",
        method: "POST" as const,
        description: "Lucky Box reminder 1 (10:00 Myanmar time)",
      },
      {
        name: "lucky-box-reminder-2",
        cron: "0 30 5 * * *",
        path: "/api/scheduled/lucky-box-reminder-2",
        method: "POST" as const,
        description: "Lucky Box reminder 2 (12:00 Myanmar time)",
      },
      {
        name: "lucky-box-reminder-3",
        cron: "0 30 8 * * *",
        path: "/api/scheduled/lucky-box-reminder-3",
        method: "POST" as const,
        description: "Lucky Box reminder 3 (15:00 Myanmar time)",
      },
      {
        name: "lucky-box-reminder-4",
        cron: "0 30 14 * * *",
        path: "/api/scheduled/lucky-box-reminder-4",
        method: "POST" as const,
        description: "Lucky Box reminder 4 (21:00 Myanmar time)",
      },
      {
        name: "lucky-box-monthly-reset",
        cron: "0 0 0 1 * *",
        path: "/api/scheduled/lucky-box-monthly-reset",
        method: "POST" as const,
        description: "Monthly Lucky Box reset on 1st of each month",
      },
      {
        name: "daily-cleanup",
        cron: "0 0 1 * * *",
        path: "/api/scheduled/daily-cleanup",
        method: "POST" as const,
        description: "Daily cleanup: delete chat messages and 2D results older than 7 days (07:00 Myanmar time)",
      },
    ];

    for (const job of jobs) {
      const existing = existingJobs.get(job.name);
      if (!existing) {
        const result = await createHeartbeatJob(job, "");
        console.log(`[Heartbeat] ✅ Registered job "${job.name}" → taskUid: ${result.taskUid}`);
      } else {
        const requiresUpdate = existing.cronExpression !== job.cron || existing.callbackPath !== job.path || existing.callbackMethod !== job.method;
        if (requiresUpdate) {
          await updateHeartbeatJob(existing.taskUid, {
            cron: job.cron,
            path: job.path,
            method: job.method,
            description: job.description,
            enable: true,
          }, "");
          console.log(`[Heartbeat] ✅ Updated job "${job.name}" to ${job.cron}`);
        } else {
          console.log(`[Heartbeat] ℹ️  Job "${job.name}" already matches schedule`);
        }
      }
    }
  } catch (err) {
    console.warn("[Heartbeat] Job registration skipped:", String(err).slice(0, 120));
  }
}
