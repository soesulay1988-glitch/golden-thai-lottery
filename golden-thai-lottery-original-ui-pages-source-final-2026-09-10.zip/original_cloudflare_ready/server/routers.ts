import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { ENV } from "./_core/env";
import { TRPCError } from "@trpc/server";
import { invokeLLM } from "./_core/llm";
import { buildCalendar3DAiSource, makeCalendar3DAiCacheKey } from "./calendar3dAi";
import { storagePut } from "./storage";
import {
  getLatestThaiLotteryDraw,
  getThaiLotteryDrawByDate,
  listThaiLotteryDrawDates,
  getLatestMyanmar2dResults,
  getMyanmar2dHistory,
  getMyanmar2dAnalysis,
  getLatestHoroscope,
  getWeeklyHoroscope,
  upsertThaiLotteryDraw,
  insertMyanmar2dResult,
  upsertHoroscopeReading,
  getCalendar3dData,
  getAllCalendar3dYears,
  rebuildCalendar3dForYear,
  getTwoDChatMessages,
  insertTwoDChatMessage,
  deleteTwoDChatMessage,
} from "./db";
import {
  getSavedTicketsByUser,
  addSavedTicket,
  deleteSavedTicket,
  updateSavedTicketResult,
} from "./db";
import {
  getUserNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  getUnreadNotificationCount,
  savePushSubscription,
  removePushSubscription,
  getPushSubscriptionsByUserId,
  getUserByOpenId,
  upsertUser,
  getWeeklyLuckyPreference,
  setWeeklyLuckyPreference,
} from "./db";
import { broadcastLotteryResult } from "./pushNotifications";
import {
  getMahabokeReading,
  saveMahabokeReading,
} from "./db";
import {
  countTodayOpenings,
  countLuckyBoxOpeningsBySlot,
  countMonthWins,
  insertLuckyBoxOpening,
  getLuckyBoxOpenings,
  getGuestLuckyBoxWinnerHistory,
  getMonthlyPrizePool,
  upsertMonthlyPrizePool,
  isMonthlyResetDone,
  insertMonthlyReset,
  getMonthlyWinners,
  getMonthlyLuckyBoxCoinsSpent,
  getAllLuckyBoxWinners,
  countTodayOpeningsByDevice,
  countLuckyBoxOpeningsByDeviceAndSlot,
  countMonthWinsByDevice,
  getGuestLuckyBoxStats,
  getRecentGuestOpenings,
  saveQrToken,
  claimPrizeByReferenceId,
  checkDuplicateClaim,
  getWinnerDetailsByRefId,
  getAppSetting,
  setAppSetting,
  countAllUsers,
  deleteLuckyBoxWinnerById,
  deleteAllLuckyBoxWinnerRecords,
  setLuckyBoxWinnerPaidStatus,
} from "./db";
import { z } from "zod";
import {
  generateMyanmar2dPrediction,
  getMyanmarPredictionDate,
  makeMyanmarPredictionSettingKey,
  parseMyanmar2dPrediction,
} from "./myanmar2dPrediction";
import {
  DEFAULT_LUCKY_BOX_WIN_CHANCE,
  canAwardLuckyBoxCoins,
  isLuckyBoxWinner,
  normalizeLuckyBoxWinChance,
} from "./luckyBoxLogic";
import { getLuckyBoxSlotState } from "./luckyBoxSlots";

const OWNER_ADMIN_EMAIL = "soesulay1988@gmail.com";
const OWNER_CHAT_DISPLAY_NAME = "Golden Thai";
const LEGACY_OWNER_CHAT_NAMES = new Set(["Soe Thu Aung"]);
const IN_APP_BROADCAST_SETTING_KEY = "in_app_broadcast_v1";
const THREE_D_IMAGE_SETTING_KEY = "three_d_evidence_image_v1";
const MAX_THREE_D_IMAGE_BYTES = 3 * 1024 * 1024;

type ThreeDEvidenceImage = {
  imageUrl: string;
  updatedAt: string;
};

type InAppBroadcast = {
  id: string;
  title: string;
  message: string;
  publishedAt: string;
};

function requireLuckyBoxOwner(user: { role: string; email?: string | null }) {
  if (user.role !== "admin" || user.email?.toLowerCase() !== OWNER_ADMIN_EMAIL) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Lucky Box owner-admin only" });
  }
}

function isGoldenThaiOwner(user: { role: string; email?: string | null } | null) {
  return user?.role === "admin" && user.email?.toLowerCase() === OWNER_ADMIN_EMAIL;
}

function requireGoldenThaiOwner(user: { role: string; email?: string | null }) {
  if (!isGoldenThaiOwner(user)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Golden Thai owner-admin only" });
  }
}

function parseThreeDEvidenceImage(raw: string | null): ThreeDEvidenceImage | null {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Partial<ThreeDEvidenceImage>;
    return typeof value.imageUrl === "string" && value.imageUrl.startsWith("/manus-storage/") && typeof value.updatedAt === "string"
      ? { imageUrl: value.imageUrl, updatedAt: value.updatedAt }
      : null;
  } catch {
    return null;
  }
}

export function parseThreeDEvidenceImageDataUrl(dataUrl: string): { bytes: Buffer; mimeType: "image/jpeg" | "image/png" | "image/webp"; extension: "jpg" | "png" | "webp" } {
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(dataUrl);
  if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "Use a JPG, PNG, or WEBP image" });
  const bytes = Buffer.from(match[2], "base64");
  if (!bytes.length || bytes.length > MAX_THREE_D_IMAGE_BYTES) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Image must be 3 MB or smaller" });
  }
  const mimeType = match[1] as "image/jpeg" | "image/png" | "image/webp";
  return {
    bytes,
    mimeType,
    extension: mimeType === "image/jpeg" ? "jpg" : mimeType === "image/png" ? "png" : "webp",
  };
}

export function parseModelJsonObject(rawContent: unknown): Record<string, unknown> {
  const content = Array.isArray(rawContent)
    ? rawContent
      .filter((part): part is { type: "text"; text: string } => (
        typeof part === "object" && part !== null && "type" in part && "text" in part
        && part.type === "text" && typeof part.text === "string"
      ))
      .map((part) => part.text)
      .join("\n")
    : rawContent;

  if (typeof content !== "string" || !content.trim()) {
    throw new Error("No text response from AI");
  }

  const cleanContent = content.trim().replace(/^```json\s*/i, "").replace(/```\s*$/, "").trim();
  const objectStart = cleanContent.indexOf("{");
  const objectEnd = cleanContent.lastIndexOf("}");
  if (objectStart < 0 || objectEnd <= objectStart) {
    throw new Error("AI response does not contain a JSON object");
  }

  const parsed = JSON.parse(cleanContent.slice(objectStart, objectEnd + 1));
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw new Error("AI response JSON is not an object");
  }
  return parsed as Record<string, unknown>;
}

async function getCurrentInAppBroadcast(): Promise<InAppBroadcast | null> {
  const raw = await getAppSetting(IN_APP_BROADCAST_SETTING_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as Partial<InAppBroadcast>;
    if (!parsed.id || !parsed.title || !parsed.message || !parsed.publishedAt) return null;
    return {
      id: String(parsed.id),
      title: String(parsed.title),
      message: String(parsed.message),
      publishedAt: String(parsed.publishedAt),
    };
  } catch {
    return null;
  }
}

// ─── Helpers ────────────────────────────────────────────────────────────────

// Get a random prize amount from the configured prize tiers
async function getRandomPrizeAmount(maximumAffordableCoins = Number.POSITIVE_INFINITY): Promise<number | null> {
  const value = await getAppSetting('lucky_box_prize_tiers');
  const defaultTiers = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
  let tiers: number[];
  try {
    tiers = value ? JSON.parse(value) : defaultTiers;
  } catch {
    tiers = defaultTiers;
  }
  const affordableTiers = tiers.filter((tier) => tier > 0 && tier <= maximumAffordableCoins);
  if (affordableTiers.length === 0) return null;
  // Get configurable weights from app settings
  const weightsValue = await getAppSetting('lucky_box_prize_tier_weights');
  const defaultWeights: Record<number, number> = {
    50: 25, 100: 20, 200: 15, 300: 12, 400: 9, 500: 7, 600: 4, 700: 3, 800: 2, 900: 2, 1000: 1,
  };
  let weights: Record<number, number>;
  try {
    weights = weightsValue ? JSON.parse(weightsValue) : defaultWeights;
  } catch {
    weights = defaultWeights;
  }
  const tierWeights = affordableTiers.map((tier) => Math.max(0, weights[tier] ?? 0));
  const totalWeight = tierWeights.reduce((a, b) => a + b, 0);
  if (totalWeight <= 0) return null;
  let rand = Math.random() * totalWeight;
  for (let i = 0; i < affordableTiers.length; i++) {
    rand -= tierWeights[i];
    if (rand <= 0) return affordableTiers[i];
  }
  return affordableTiers[0];
}

async function getLuckyBoxWinChance(): Promise<number> {
  const value = await getAppSetting("lucky_box_win_chance");
  return normalizeLuckyBoxWinChance(value ?? DEFAULT_LUCKY_BOX_WIN_CHANCE);
}

async function isLuckyBoxTestMode(): Promise<boolean> {
  return (await getAppSetting("lucky_box_test_mode")) === "true";
}

async function getLuckyBoxMonthlyBudget(year: number, month: number) {
  const [pool, spentCoins] = await Promise.all([
    getMonthlyPrizePool(year, month),
    getMonthlyLuckyBoxCoinsSpent(year, month),
  ]);
  const budgetCoins = pool?.totalPrizePool ?? 0;
  return {
    adRevenue: pool?.adRevenue ?? 0,
    allocationPercentage: pool?.prizePercentage ?? 0,
    budgetCoins,
    spentCoins,
    remainingCoins: Math.max(0, budgetCoins - spentCoins),
    isConfigured: Boolean(pool),
  };
}

async function determineLuckyBoxPrize(year: number, month: number) {
  const budget = await getLuckyBoxMonthlyBudget(year, month);
  if (!isLuckyBoxWinner(await getLuckyBoxWinChance())) {
    return { isWinner: false, prizeAmount: 0 };
  }
  const prizeAmount = await getRandomPrizeAmount(budget.remainingCoins);
  if (!prizeAmount || !canAwardLuckyBoxCoins(budget.budgetCoins, budget.spentCoins, prizeAmount)) {
    return { isWinner: false, prizeAmount: 0 };
  }
  return { isWinner: true, prizeAmount };
}

function getWeekStart(): string {
  const now = new Date();
  const day = now.getDay();
  const diff = now.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(now.setDate(diff));
  return monday.toISOString().slice(0, 10);
}

function checkTicketAgainstDraw(
  ticket: string,
  draw: Awaited<ReturnType<typeof getLatestThaiLotteryDraw>>
) {
  if (!draw) return null;
  const t = ticket.trim();
  const matches: { prize: string; prizeEn: string; prizeMm: string; amount: string }[] = [];

  // 1st Prize
  if (draw.firstPrize === t) {
    matches.push({ prize: "1st", prizeEn: "1st Prize", prizeMm: "ပထမဆု", amount: "6,000,000" });
  }
  // Near 1st Prize
  if (draw.nearFirstPrize?.includes(t)) {
    matches.push({ prize: "near1st", prizeEn: "Near 1st Prize", prizeMm: "ပထမဆုနှင့်နီးသောဆု", amount: "100,000" });
  }
  // First 3 digits
  if (draw.firstThreeDigits?.includes(t.slice(0, 3))) {
    matches.push({ prize: "first3", prizeEn: "First 3 Digits", prizeMm: "ရှေ့ ၃ လုံး", amount: "4,000" });
  }
  // Last 3 digits
  if (draw.lastThreeDigits?.includes(t.slice(-3))) {
    matches.push({ prize: "last3", prizeEn: "Last 3 Digits", prizeMm: "နောက် ၃ လုံး", amount: "4,000" });
  }
  // Last 2 digits
  if (draw.lastTwoDigits === t.slice(-2)) {
    matches.push({ prize: "last2", prizeEn: "Last 2 Digits", prizeMm: "နောက် ၂ လုံး", amount: "2,000" });
  }
  // 2nd Prize
  if (draw.secondPrize?.includes(t)) {
    matches.push({ prize: "2nd", prizeEn: "2nd Prize", prizeMm: "ဒုတိယဆု", amount: "200,000" });
  }
  // 3rd Prize
  if (draw.thirdPrize?.includes(t)) {
    matches.push({ prize: "3rd", prizeEn: "3rd Prize", prizeMm: "တတိယဆု", amount: "80,000" });
  }
  // 4th Prize
  if (draw.fourthPrize?.includes(t)) {
    matches.push({ prize: "4th", prizeEn: "4th Prize", prizeMm: "စတုတ္ထဆု", amount: "40,000" });
  }
  // 5th Prize
  if (draw.fifthPrize?.includes(t)) {
    matches.push({ prize: "5th", prizeEn: "5th Prize", prizeMm: "ပဉ္စမဆု", amount: "20,000" });
  }
  return matches.length > 0 ? matches : null;
}

// ─── Router ─────────────────────────────────────────────────────────────────
type Calendar3DAiReading = {
  targetDate: string;
  maps: Array<{
    index: number;
    estimate: string;
    summaryMm: string;
    summaryEn: string;
    summaryTh: string;
    visualEvidence: Array<{
      source: "sameRow" | "recentSameRow" | "currentYear";
      points: Array<{ row: string; year: number; value: string }>;
    }>;
  }>;
};

const calendar3dAiCache = new Map<string, { expiresAt: number; reading: Calendar3DAiReading }>();

function createVerifiedCalendar3DReading(
  source: NonNullable<ReturnType<typeof buildCalendar3DAiSource>>,
): Calendar3DAiReading {
  return {
    targetDate: source.targetDate,
    maps: source.visualMaps.map((map) => ({
      index: map.index,
      estimate: map.candidate,
      summaryMm: `စာရွက် ${map.index} ရှိ အရောင်လိုင်း ၃ မျိုးသည် Golden Thai သမိုင်းဇယားမှရွေးထားသောကွက်များကိုသာချိတ်ပြထားသည်။`,
      summaryEn: `The three colored paths on sheet ${map.index} connect only selected cells from the Golden Thai history grid.`,
      summaryTh: `เส้นสีทั้ง 3 บนแผ่น ${map.index} เชื่อมเฉพาะช่องที่เลือกจากตารางประวัติ Golden Thai เท่านั้น`,
      visualEvidence: map.visualEvidence,
    })),
  };
}

async function getCalendar3DAiReading(): Promise<Calendar3DAiReading | null> {
  const verifiedRows = await getCalendar3dData(2026);
  const currentYearRows = verifiedRows.reduce<Record<string, string>>((result, row) => {
    if (/^\d{1,2}$/.test(String(row.row)) && /^\d{3}$/.test(String(row.value))) {
      result[String(row.row).padStart(2, "0")] = String(row.value);
    }
    return result;
  }, {});
  const source = buildCalendar3DAiSource(new Date(), currentYearRows);
  if (!source) return null;

  const cacheKey = makeCalendar3DAiCacheKey(source);
  const cached = calendar3dAiCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.reading;
  const reading = createVerifiedCalendar3DReading(source);
  calendar3dAiCache.set(cacheKey, { reading, expiresAt: Date.now() + 6 * 60 * 60 * 1000 });
  return reading;
}

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  inAppBroadcast: router({
    current: publicProcedure.query(async () => getCurrentInAppBroadcast()),
  }),

  // ─── Thai Lottery ────────────────────────────────────────────────────────
  thaiLottery: router({
    getLatest: publicProcedure.query(async () => {
      return getLatestThaiLotteryDraw();
    }),

    getByDate: publicProcedure
      .input(z.object({ drawDate: z.string() }))
      .query(async ({ input }) => {
        return getThaiLotteryDrawByDate(input.drawDate);
      }),

    listDrawDates: publicProcedure.query(async () => {
      return listThaiLotteryDrawDates();
    }),

    checkTicket: publicProcedure
      .input(z.object({ ticket: z.string().length(6), drawDate: z.string().optional() }))
      .mutation(async ({ input }) => {
        const draw = input.drawDate
          ? await getThaiLotteryDrawByDate(input.drawDate)
          : await getLatestThaiLotteryDraw();
        if (!draw) throw new TRPCError({ code: "NOT_FOUND", message: "No draw data found" });
        const matches = checkTicketAgainstDraw(input.ticket, draw);
        return { matches, draw, ticket: input.ticket };
      }),
  }),

  // ─── Calendar 3D ─────────────────────────────────────────────────────────
  calendar3d: router({
    getYear: publicProcedure
      .input(z.object({ year: z.number() }))
      .query(async ({ input }) => {
        const data = await getCalendar3dData(input.year);
        // Convert to matrix format: Record<row_number, value>
        const matrix: Record<string, string> = {};
        for (const row of data) {
          matrix[String(row.row).padStart(2, "0")] = row.value;
        }
        return matrix;
      }),

    getAllYears: publicProcedure.query(async () => {
      return getAllCalendar3dYears();
    }),

    getAiAnalysis: publicProcedure.query(async () => {
      return getCalendar3DAiReading();
    }),

    rebuildYear: protectedProcedure
      .input(z.object({ year: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') throw new TRPCError({ code: 'FORBIDDEN' });
        const count = await rebuildCalendar3dForYear(input.year);
        return { success: true, year: input.year, entries: count };
      }),
  }),

  threeDImage: router({
    get: publicProcedure.query(async ({ ctx }) => ({
      image: parseThreeDEvidenceImage(await getAppSetting(THREE_D_IMAGE_SETTING_KEY)),
      canManage: isGoldenThaiOwner(ctx.user),
    })),

    upload: protectedProcedure
      .input(z.object({ dataUrl: z.string().min(32).max(4_200_000) }))
      .mutation(async ({ ctx, input }) => {
        requireGoldenThaiOwner(ctx.user);
        const image = parseThreeDEvidenceImageDataUrl(input.dataUrl);
        const stored = await storagePut(`golden-thai/3d-evidence/current.${image.extension}`, image.bytes, image.mimeType);
        const record: ThreeDEvidenceImage = { imageUrl: stored.url, updatedAt: new Date().toISOString() };
        await setAppSetting(THREE_D_IMAGE_SETTING_KEY, JSON.stringify(record));
        return { image: record };
      }),

    clear: protectedProcedure.mutation(async ({ ctx }) => {
      requireGoldenThaiOwner(ctx.user);
      await setAppSetting(THREE_D_IMAGE_SETTING_KEY, "");
      return { success: true };
    }),
  }),

  // ─── Myanmar 2D ──────────────────────────────────────────────────────────
  myanmar2d: router({
    getLatest: publicProcedure.query(async () => {
      return getLatestMyanmar2dResults();
    }),

    getHistory: publicProcedure
      .input(z.object({ page: z.number().min(1).default(1), pageSize: z.number().min(1).max(120).default(20) }))
      .query(async ({ input }) => {
        return getMyanmar2dHistory(input.page, input.pageSize);
      }),

    getAnalysis: publicProcedure.query(async () => {
      return getMyanmar2dAnalysis();
    }),

    // Chat messages
    getChatMessages: publicProcedure.query(async () => {
      const messages = await getTwoDChatMessages(50);
      return messages.map((message) => (
        LEGACY_OWNER_CHAT_NAMES.has(message.userName)
          ? { ...message, userName: OWNER_CHAT_DISPLAY_NAME }
          : message
      ));
    }),

    sendChatMessage: publicProcedure
      .input(z.object({ message: z.string().min(1).max(500), userName: z.string().max(64).optional() }))
      .mutation(async ({ ctx, input }) => {
        // Server-side content filter: block phone numbers, URLs, and profanity
        const phoneRegex = /\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3,4}[-.\s]?\d{4}\b/;
        const mmPhoneRegex = /(?:^|\s)(?:09|0\s?9)\d{7,9}(?:\s|$)/;
        const urlRegex = /(?:https?:\/\/|www\.)[^\s]+/;
        const dotComRegex = /\.[a-z]{2,}(\/|\s|$)/;

        if (phoneRegex.test(input.message) || mmPhoneRegex.test(input.message) || urlRegex.test(input.message) || dotComRegex.test(input.message)) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'Phone numbers and links are not allowed in chat' });
        }

        // Server-side profanity filter
        const PROFANITY_WORDS = [
          "လီး", "စပတ်", "ငါလိုးမ", "လူလိမ်", "ခွေးသား",
          "လိုး", "ပိုး", "ဆု", "မင်္ဇား", "မင်္ဇ", "ခွေး",
          "ကြိတ်", "စုပ်", "ဝတ်မတ်", "ဝတ်မတ်ရုတ်",
          "ကုတင်ပေါ်", "ညဉ့်သုတ်", "စောက်ပြတ်", "စောက်ကုတ်",
          "မိကျောင်း", "ခရုရမ်း", "ရမ်းချင်း", "ရမ်းကား",
          "ဒေါင်းရမ်း", "နွားရမ်း", "စိန်ရမ်း", "ဘဲစုပ်",
          "ကပ်ရံ", "ရန်ရှာ", "ရန်မုန်း", "စိန်ခေါ်",
          "စောက်ဖြတ်", "မိတ်ဆွေစီး", "အိမ်မိတ်", "အိမ်မိတ်ဆွေ",
          "လီုး", "စပတ်", "ခွေးသာ", "လူးလိမ်",
          "မိလိုး", "မိလိုးမ", "ငါလိုး", "လိုးတယ်",
          "dog", "fuck", "shit", "asshole", "bitch",
          "bastard", "damn", "hell", "crap", "dick",
          "penis", "pussy", "slut", "whore", "cunt",
          "motherfucker", "son of a bitch", "fucking",
        ];
        const lowerMsg = input.message.toLowerCase();
        if (PROFANITY_WORDS.some(word => lowerMsg.includes(word.toLowerCase()))) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့' });
        }

        const isLoggedin = !!ctx.user;
        const userId = isLoggedin ? (ctx.user?.id ?? null) : null;
        // Use user name if logged in, otherwise use provided name or generate one
        let userName: string;
        if (isLoggedin && ctx.user) {
          userName = ctx.user.email?.toLowerCase() === OWNER_ADMIN_EMAIL
            ? OWNER_CHAT_DISPLAY_NAME
            : (ctx.user.name || ctx.user.email?.split("@")[0] || "Anonymous");
        } else {
          userName = input.userName || `အလျာသား${Math.floor(Math.random() * 9000 + 1000)}`;
        }
        await insertTwoDChatMessage({
          userId: userId,
          userName: userName.slice(0, 64),
          message: input.message.slice(0, 500),
        });
        return { success: true };
      }),

    deleteChatMessage: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED" });
        // Only admin or the message owner can delete
        await deleteTwoDChatMessage(input.id);
        return { success: true };
      }),

    // Live fetch — fetches SET/VAL/2D directly from API for real-time market tracking
    getLive: publicProcedure.query(async () => {
      try {
        const res = await fetch("https://api.thaistock2d.com/live", {
          headers: {
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (compatible; GoldenLottery/1.0)",
          },
          signal: AbortSignal.timeout(10000),
        });
        if (!res.ok) {
          return { success: false, message: `API status ${res.status}` };
        }
        const json = await res.json() as any;
        const results: Array<{
          time?: string;
          open_time?: string;
          twod?: string;
          set?: string;
          value?: string;
          stock_date?: string;
        }> = json?.result ?? [];

        // Extract the live real-time data from the API
        const liveData = json?.live || null;

        if (!results.length && !liveData) {
          return { success: false, message: "No results" };
        }

        // Match sessions by exact time: 12:01 = morning, 16:30 = evening
        const liveResults = results
          .filter((r) => {
            const t = r.open_time || r.time || "";
            return t.startsWith("12:01") || t.startsWith("16:30");
          })
          .map((r) => {
            const timeField = r.open_time || r.time || "";
            const session: "morning" | "evening" = timeField.startsWith("12:01") ? "morning" : "evening";
            const setStr = r.set?.toString().trim() || "--";
            const valStr = r.value || "--";
            const twoD = r.twod || "--";
            // Format SET with comma (e.g. 1622.41 → 1,622.41)
            const parts = setStr.split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            const formattedSet = parts.join(".");

            return {
              time: timeField,
              session,
              set: formattedSet,
              value: valStr,
              twod: twoD,
              rawSet: setStr,
              stockDate: r.stock_date || "",
            };
          });

        // Build live real-time object from the 'live' field
        let live: { set: string; value: string; twod: string; time: string } | null = null;
        if (liveData) {
          live = {
            set: liveData.set || "--",
            value: liveData.value || "--",
            twod: liveData.twod || "--",
            time: liveData.time || "",
          };
        }

        return { success: true, results: liveResults, live };
      } catch (err) {
        return { success: false, message: String(err) };
      }
    }),
  }),

  // ─── Horoscope (existing, kept for backward compatibility) ─────────────────
  horoscope: router({
    getLatest: publicProcedure.query(async () => {
      return getLatestHoroscope();
    }),

    getByWeek: publicProcedure
      .input(z.object({ weekStart: z.string() }))
      .query(async ({ input }) => {
        return getWeeklyHoroscope(input.weekStart);
      }),

    getPersonalized: publicProcedure
      .input(z.object({
        birthDay: z.number().min(1).max(31),
        birthMonth: z.number().min(1).max(12),
        birthYear: z.number().min(1900).max(2030),
        language: z.enum(["mm", "en", "th"]).default("mm"),
      }))
      .mutation(async ({ input }) => {
        const { birthDay, birthMonth, birthYear, language } = input;
        const birthDate = new Date(birthYear, birthMonth - 1, birthDay);
        const dayOfWeek = birthDate.getDay();
        const myanmarDays = ["တနင်္ဂနွေ", "တနင်္လာ", "အင်္ဂါ", "ဗုဒ္ဓဟူး (မနက်)", "ကြာသပတေး", "သောကြာ", "စနေ"];
        const englishDays = ["Sunday", "Monday", "Tuesday", "Wednesday (AM)", "Thursday", "Friday", "Saturday"];
        const myanmarBirthDay = myanmarDays[dayOfWeek];
        const englishBirthDay = englishDays[dayOfWeek];

        const today = new Date();
        const age = today.getFullYear() - birthYear - (
          today.getMonth() < birthMonth - 1 || (today.getMonth() === birthMonth - 1 && today.getDate() < birthDay) ? 1 : 0
        );

        const systemPrompt = `You are a master Myanmar astrologer and numerologist specializing in traditional Burmese horoscope reading (မြန်မာ့ဗေဒင်). 
You combine Myanmar weekday astrology (ကြိုးနေ့), numerology, and traditional Burmese fortune-telling.

Given a person's birth date, you must:
1. Identify their Myanmar birth weekday and its ruling planet
2. Provide their personality traits based on Myanmar astrology
3. Give current week's fortune reading (love, career, health, finance)
4. Suggest lucky numbers for 2D lottery and Thai lottery
5. Give lucky color, lucky direction, lucky day this week
6. Provide a special message/advice for this week

Always respond in valid JSON. Be mystical, encouraging, and culturally authentic to Myanmar traditions.`;

        const userPrompt = language === "mm"
          ? `မွေးနေ့: ${birthDay}/${birthMonth}/${birthYear} (${myanmarBirthDay}နေ့ဖွား) | အသက်: ${age} နှစ်

ဤပုဂ္ဂိုလ်အတွက် မြန်မာ့ဗေဒင်ဟောကိန်း ပေးပါ။ JSON format ဖြင့်သာ ဖြေပါ။`
          : `Birth date: ${birthDay}/${birthMonth}/${birthYear} (Born on ${englishBirthDay}) | Age: ${age}

Please provide a Myanmar astrology horoscope reading. Respond in JSON format only.`;

        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "horoscope_reading",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  birthWeekday: { type: "string" },
                  birthWeekdayEn: { type: "string" },
                  rulingPlanet: { type: "string" },
                  rulingPlanetEn: { type: "string" },
                  personalityMm: { type: "string" },
                  personalityEn: { type: "string" },
                  weeklyFortune: {
                    type: "object",
                    properties: {
                      loveMm: { type: "string" },
                      loveEn: { type: "string" },
                      careerMm: { type: "string" },
                      careerEn: { type: "string" },
                      healthMm: { type: "string" },
                      healthEn: { type: "string" },
                      financeMm: { type: "string" },
                      financeEn: { type: "string" },
                    },
                    required: ["loveMm","loveEn","careerMm","careerEn","healthMm","healthEn","financeMm","financeEn"],
                    additionalProperties: false,
                  },
                  lucky2dNumbers: { type: "array", items: { type: "string" } },
                  luckyLotteryNumbers: { type: "array", items: { type: "string" } },
                  luckyColor: { type: "string" },
                  luckyColorMm: { type: "string" },
                  luckyDirection: { type: "string" },
                  luckyDirectionMm: { type: "string" },
                  luckyDay: { type: "string" },
                  luckyDayMm: { type: "string" },
                  overallFortune: { type: "number" },
                  weeklyMessageMm: { type: "string" },
                  weeklyMessageEn: { type: "string" },
                },
                required: [
                  "birthWeekday","birthWeekdayEn","rulingPlanet","rulingPlanetEn",
                  "personalityMm","personalityEn","weeklyFortune",
                  "lucky2dNumbers","luckyLotteryNumbers",
                  "luckyColor","luckyColorMm","luckyDirection","luckyDirectionMm",
                  "luckyDay","luckyDayMm","overallFortune","weeklyMessageMm","weeklyMessageEn"
                ],
                additionalProperties: false,
              },
            },
          },
        });

        const content = response.choices[0]?.message?.content as string | undefined;
        if (!content) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No response from AI" });
        try {
          return JSON.parse(content);
        } catch {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to parse AI response" });
        }
      }),
  }),

  // ─── Mahaboke (မဟာဘုတ်) Weekly Horoscope ──────────────────────────────────
  // Per-user weekly horoscope: same answer for entire week, only changes when new week starts
  mahaboke: router({
    getWeekly: publicProcedure
      .input(z.object({
        birthDay: z.number().min(1).max(31),
        birthMonth: z.number().min(1).max(12),
        birthYear: z.number().min(1900).max(2030),
        weekday: z.enum(["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]).optional(),
        deviceId: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { birthDay, birthMonth, birthYear, weekday, deviceId } = input;
        // Use userId from auth if available, otherwise use guest (0) — caching works for all
        const userId = ctx.user?.id ?? 0;
        // If weekday is provided directly, use it; otherwise calculate from date
        let dayOfWeek: number;
        if (weekday) {
          const weekdayMap: Record<string, number> = {
            sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6
          };
          dayOfWeek = weekdayMap[weekday] ?? 0;
        } else {
          const birthDate = new Date(birthYear, birthMonth - 1, birthDay);
          dayOfWeek = birthDate.getDay();
        }

        // Myanmar astrology birth day mapping
        const MYANMAR_BIRTH_DAYS = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"] as const;
        // Wednesday PM (after noon) = rahu in Myanmar astrology
        const MYANMAR_BIRTH_NAMES_MM = [
          { mm: "တနင်္ဂနွေ (ဂဠုန်)", en: "Sunday (Garuda)" },
          { mm: "တနင်္လာ (ကျားသစ်)", en: "Monday (Tiger)" },
          { mm: "အင်္ဂါ (ခြင်္သေ့)", en: "Tuesday (Lion)" },
          { mm: "ဗုဒ္ဓဟူး (ဆင်)", en: "Wednesday (Elephant)" },
          { mm: "ကြာသပတေး (ကြွက်)", en: "Thursday (Rat)" },
          { mm: "သောကြာ (ကြိုး)", en: "Friday (Guinea Pig)" },
          { mm: "စနေ (နဂါး)", en: "Saturday (Dragon)" },
        ];
        const MAHABOKE_RULING = [
          { mm: "နေ (Sun)", en: "Sun" },
          { mm: "လ (Moon)", en: "Moon" },
          { mm: "အင်္ဂါ (Mars)", en: "Mars" },
          { mm: "ဗုဒ္ဓဟူး (Mercury)", en: "Mercury" },
          { mm: "ကြာသပတေး (Jupiter)", en: "Jupiter" },
          { mm: "သောကြာ (Venus)", en: "Venus" },
          { mm: "စနေ (Saturn)", en: "Saturn" },
        ];

        // Rahu is for Wednesday born after noon (but we simplify to Wednesday for now)
        const birthDayKey = MYANMAR_BIRTH_DAYS[dayOfWeek] || "sunday";
        const birthName = MYANMAR_BIRTH_NAMES_MM[dayOfWeek];
        const rulingPlanet = MAHABOKE_RULING[dayOfWeek];

        const weekStart = getWeekStart();

        // Check if we already have a cached reading for this user + birthDay + birthMonth + birthYear + current week
        const cached = await getMahabokeReading(userId, deviceId || null, birthDayKey, birthDay, birthMonth, birthYear, weekStart);
        if (cached) {
          // Return cached result — same answer for the entire week
          return {
            ...cached,
            birthDayNameMm: birthName.mm,
            birthDayNameEn: birthName.en,
            rulingPlanetMm: rulingPlanet.mm,
            rulingPlanetEn: rulingPlanet.en,
            isCached: true,
          };
        }

        // Calculate age
        const today = new Date();
        const age = today.getFullYear() - birthYear - (
          today.getMonth() < birthMonth - 1 || (today.getMonth() === birthMonth - 1 && today.getDate() < birthDay) ? 1 : 0
        );

        // Generate new horoscope via LLM
        const systemPrompt = `You are a master Myanmar Mahaboke astrologer (မဟာဘုတ် ဗေဒင်ဆရာ) with over 30 years of experience in traditional Burmese astrology.
You combine knowledge of the 8 planetary rulers (ဂြိုဟ် ၈ စင်း), Mahaboke system, and Myanmar cultural wisdom.

Write in the style of a respected Myanmar horoscope master - warm, wise, mystical yet practical.
Use Myanmar proverbs and wisdom where appropriate.

The person was born on: ${birthName.mm} (${birthName.en})
Ruling planet: ${rulingPlanet.mm} (${rulingPlanet.en})
Birth date: ${birthDay}/${birthMonth}/${birthYear}
Myanmar Year: ${birthYear + 544} ခုနှစ်
Age: ${age}
Current week starts: ${weekStart}

Provide a concise weekly horoscope reading (တစ်ပတ်စာ ဟောကိန်း) covering all listed aspects of life.
Each reading should be one or two clear sentences so the full JSON answer remains complete.
Reference their birth day planetary influence in the reading.
Be encouraging but honest. Give practical advice alongside mystical insights.
Include specific lucky numbers, colors, and directions based on their birth day.

Always respond in valid JSON only.`;

        const userPrompt = `ဤပုဂ္ဂိုလ်၏ တစ်ပတ်စာ ဟောကိန်း ပေးပါ။ JSON format ဖြင့်သာ ဖြေပါ။ Field တစ်ခုစီကို စာကြောင်း ၁-၂ ကြောင်းဖြင့်တိုတောင်းရှင်းလင်းစွာရေးပါ။ Thai translation fields (personalityTh, loveTh, careerTh, healthTh, financeTh, familyTh, educationTh, travelTh, spiritualTh, luckyColorTh, luckyDirectionTh, luckyDayTh, weeklyMessageTh) လည်း ထည့်ပေးပါ။`;

        // A complete local reading keeps the page useful if an upstream model
        // returns incomplete or non-JSON content. It is also used to fill any
        // optional field a model leaves blank.
        const fallbackReading = {
          personalityMm: `${birthName.mm}ဖွား၏ ${rulingPlanet.mm} အင်အားကြောင့် စိတ်တည်ငြိမ်စွာစဉ်းစားနိုင်ပြီး ယခုအပတ်တွင် အရေးကြီးကိစ္စများကိုအစီအစဉ်တကျလုပ်ဆောင်သင့်ပါသည်။`,
          personalityEn: `Born on ${birthName.en}, you can use the steady influence of ${rulingPlanet.en} to plan important work with care this week.`,
          personalityTh: `ผู้ที่เกิด${birthName.en} ควรใช้พลังของ${rulingPlanet.en} วางแผนเรื่องสำคัญอย่างรอบคอบในสัปดาห์นี้`,
          loveMm: `စကားပြောရာတွင် နူးညံ့စွာနားထောင်ပေးလျှင် ချစ်ခင်ရသူနှင့်နားလည်မှု ပိုကောင်းလာနိုင်ပါသည်။`,
          loveEn: `Listen gently and speak clearly to strengthen understanding with loved ones.`,
          loveTh: `รับฟังและสื่อสารอย่างอ่อนโยนเพื่อเพิ่มความเข้าใจกับคนที่คุณรัก`,
          careerMm: `လုပ်ငန်းတာဝန်များကို ဦးစားပေးစီမံပြီး အလျင်စလိုဆုံးဖြတ်မှုထက် စစ်ဆေးပြီးမှဆောင်ရွက်ပါ။`,
          careerEn: `Prioritize work carefully and verify details before making fast decisions.`,
          careerTh: `จัดลำดับงานและตรวจสอบรายละเอียดก่อนตัดสินใจอย่างเร่งรีบ`,
          healthMm: `အနားယူချိန်နှင့်ရေသောက်ချိန်ကိုမှန်ကန်စွာထားကာ မပင်ပန်းအောင်နေ့စဉ်လှုပ်ရှားမှုကိုညှိနှိုင်းပါ။`,
          healthEn: `Balance rest, hydration, and daily activity so you do not overextend yourself.`,
          healthTh: `ดูแลการพักผ่อน ดื่มน้ำ และกิจกรรมประจำวันให้สมดุล`,
          financeMm: `အသုံးစရိတ်ကိုစာရင်းမှတ်ပြီး လိုအပ်ချက်အလိုက်သာသုံးစွဲခြင်းက အဆင်ပြေစေပါမည်။`,
          financeEn: `Track spending and focus on essentials for steadier finances.`,
          financeTh: `บันทึกรายจ่ายและเน้นสิ่งจำเป็นเพื่อการเงินที่มั่นคง`,
          familyMm: `မိသားစုနှင့်စကားဝိုင်းတိုတိုလေးများပြုလုပ်ခြင်းက နွေးထွေးမှုနှင့်ယုံကြည်မှုကိုတိုးစေပါမည်။`,
          familyEn: `Short, thoughtful conversations can bring more warmth to family relationships.`,
          familyTh: `การพูดคุยสั้น ๆ อย่างใส่ใจช่วยเพิ่มความอบอุ่นในครอบครัว`,
          educationMm: `အသစ်လေ့လာစရာများကိုအပိုင်းငယ်များခွဲ၍ထပ်မံလေ့ကျင့်ပါ။`,
          educationEn: `Break new learning into small parts and practise consistently.`,
          educationTh: `แบ่งการเรียนรู้ใหม่เป็นส่วนเล็ก ๆ และฝึกอย่างสม่ำเสมอ`,
          travelMm: `ခရီးသွားရန်ရှိလျှင်အချိန်ဇယားနှင့်လိုအပ်သောပစ္စည်းများကိုကြိုတင်စစ်ဆေးပါ။`,
          travelEn: `If travelling, check your schedule and essential items ahead of time.`,
          travelTh: `หากเดินทางควรตรวจสอบกำหนดการและสิ่งจำเป็นล่วงหน้า`,
          spiritualMm: `မိမိစိတ်ကိုငြိမ်းချမ်းစေရန်ကောင်းမှုတစ်ခုလုပ်ပြီး ကျေးဇူးတင်စိတ်ဖြင့်နေ့စတင်ပါ။`,
          spiritualEn: `Begin the day with gratitude and one small act of kindness.`,
          spiritualTh: `เริ่มวันด้วยความกตัญญูและทำความดีเล็ก ๆ หนึ่งอย่าง`,
          luckyColor: "Gold",
          luckyColorMm: "ရွှေရောင်",
          luckyColorTh: "สีทอง",
          luckyDirection: "East",
          luckyDirectionMm: "အရှေ့ဘက်",
          luckyDirectionTh: "ทิศตะวันออก",
          luckyDay: "Wednesday",
          luckyDayMm: "ဗုဒ္ဓဟူးနေ့",
          luckyDayTh: "วันพุธ",
          lucky2dNumbers: ["17", "28", "64"],
          luckyLotteryNumbers: ["172864", "641728"],
          overallFortune: 3,
          weeklyMessageMm: `${birthName.mm}ဖွားအတွက် ယခုအပတ်သည် စနစ်တကျလုပ်ဆောင်ခြင်းနှင့်စိတ်ရှည်ခြင်းက အခွင့်အလမ်းကောင်းများကိုဖွင့်ပေးမည့်ကာလဖြစ်ပါသည်။`,
          weeklyMessageEn: `For those born on ${birthName.en}, patience and orderly progress can open useful opportunities this week.`,
          weeklyMessageTh: `ผู้ที่เกิด${birthName.en} จะพบโอกาสที่ดีขึ้นเมื่อทำสิ่งต่าง ๆ อย่างเป็นระบบและอดทนในสัปดาห์นี้`,
        };

        let reading: typeof fallbackReading;
        try {
          const response = await invokeLLM({
            model: "gemini-3-flash-preview",
            maxTokens: 8000,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "mahaboke_weekly_reading",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  personalityMm: { type: "string", description: "Personal traits and birth day influence in Myanmar (2-3 sentences)" },
                  personalityEn: { type: "string", description: "Personal traits and birth day influence in English (2-3 sentences)" },
                  personalityTh: { type: "string", description: "Personal traits and birth day influence in Thai (2-3 sentences)" },
                  loveMm: { type: "string", description: "Love and relationship forecast in Myanmar (2-3 sentences, specific advice)" },
                  loveEn: { type: "string", description: "Love and relationship forecast in English (2-3 sentences)" },
                  loveTh: { type: "string", description: "Love and relationship forecast in Thai (2-3 sentences)" },
                  careerMm: { type: "string", description: "Career and work forecast in Myanmar (2-3 sentences, specific advice)" },
                  careerEn: { type: "string", description: "Career and work forecast in English (2-3 sentences)" },
                  careerTh: { type: "string", description: "Career and work forecast in Thai (2-3 sentences)" },
                  healthMm: { type: "string", description: "Health and wellness forecast in Myanmar (2-3 sentences)" },
                  healthEn: { type: "string", description: "Health and wellness forecast in English (2-3 sentences)" },
                  healthTh: { type: "string", description: "Health and wellness forecast in Thai (2-3 sentences)" },
                  financeMm: { type: "string", description: "Finance and wealth forecast in Myanmar (2-3 sentences)" },
                  financeEn: { type: "string", description: "Finance and wealth forecast in English (2-3 sentences)" },
                  financeTh: { type: "string", description: "Finance and wealth forecast in Thai (2-3 sentences)" },
                  familyMm: { type: "string", description: "Family and relationships with relatives in Myanmar (2-3 sentences)" },
                  familyEn: { type: "string", description: "Family and relationships with relatives in English (2-3 sentences)" },
                  familyTh: { type: "string", description: "Family and relationships with relatives in Thai (2-3 sentences)" },
                  educationMm: { type: "string", description: "Education and learning forecast in Myanmar (2-3 sentences)" },
                  educationEn: { type: "string", description: "Education and learning forecast in English (2-3 sentences)" },
                  educationTh: { type: "string", description: "Education and learning forecast in Thai (2-3 sentences)" },
                  travelMm: { type: "string", description: "Travel and journey forecast in Myanmar (2-3 sentences)" },
                  travelEn: { type: "string", description: "Travel and journey forecast in English (2-3 sentences)" },
                  travelTh: { type: "string", description: "Travel and journey forecast in Thai (2-3 sentences)" },
                  spiritualMm: { type: "string", description: "Spiritual and merit-making advice in Myanmar (2-3 sentences)" },
                  spiritualEn: { type: "string", description: "Spiritual and merit-making advice in English (2-3 sentences)" },
                  spiritualTh: { type: "string", description: "Spiritual and merit-making advice in Thai (2-3 sentences)" },
                  luckyColor: { type: "string", description: "Lucky color in English" },
                  luckyColorMm: { type: "string", description: "Lucky color in Myanmar" },
                  luckyColorTh: { type: "string", description: "Lucky color in Thai" },
                  luckyDirection: { type: "string", description: "Lucky direction in English" },
                  luckyDirectionMm: { type: "string", description: "Lucky direction in Myanmar" },
                  luckyDirectionTh: { type: "string", description: "Lucky direction in Thai" },
                  luckyDay: { type: "string", description: "Lucky day in English" },
                  luckyDayMm: { type: "string", description: "Lucky day in Myanmar" },
                  luckyDayTh: { type: "string", description: "Lucky day in Thai" },
                  lucky2dNumbers: { type: "array", items: { type: "string" }, description: "3-5 lucky 2-digit numbers for 2D lottery" },
                  luckyLotteryNumbers: { type: "array", items: { type: "string" }, description: "2-3 lucky 6-digit lottery numbers" },
                  overallFortune: { type: "integer", minimum: 1, maximum: 5, description: "Overall fortune rating 1-5 stars" },
                  weeklyMessageMm: { type: "string", description: "Special weekly master advice with Myanmar proverb in Myanmar" },
                  weeklyMessageEn: { type: "string", description: "Special weekly master advice in English" },
                  weeklyMessageTh: { type: "string", description: "Special weekly master advice in Thai" },
                },
                required: [
                  "personalityMm","personalityEn",
                  "personalityTh",
                  "loveMm","loveEn","careerMm","careerEn","healthMm","healthEn","financeMm","financeEn",
                  "loveTh","careerTh","healthTh","financeTh",
                  "familyMm","familyEn","educationMm","educationEn","travelMm","travelEn","spiritualMm","spiritualEn",
                  "familyTh","educationTh","travelTh","spiritualTh",
                  "luckyColor","luckyColorMm","luckyDirection","luckyDirectionMm",
                  "luckyColorTh","luckyDirectionTh",
                  "luckyDay","luckyDayMm",
                  "luckyDayTh",
                  "lucky2dNumbers","luckyLotteryNumbers",
                  "overallFortune","weeklyMessageMm","weeklyMessageEn","weeklyMessageTh"
                ],
                additionalProperties: false,
              },
            },
          },
          });

          const parsed = parseModelJsonObject(response.choices[0]?.message?.content) as Partial<typeof fallbackReading>;

          reading = {
            ...fallbackReading,
            ...parsed,
            lucky2dNumbers: Array.isArray(parsed.lucky2dNumbers)
              ? parsed.lucky2dNumbers.filter((value): value is string => typeof value === "string").slice(0, 5)
              : fallbackReading.lucky2dNumbers,
            luckyLotteryNumbers: Array.isArray(parsed.luckyLotteryNumbers)
              ? parsed.luckyLotteryNumbers.filter((value): value is string => typeof value === "string").slice(0, 3)
              : fallbackReading.luckyLotteryNumbers,
            overallFortune: Number.isInteger(parsed.overallFortune) && parsed.overallFortune! >= 1 && parsed.overallFortune! <= 5
              ? parsed.overallFortune!
              : fallbackReading.overallFortune,
          };
        } catch (error) {
          console.warn("[Mahaboke] AI response unavailable or invalid; using local reading", error);
          reading = fallbackReading;
        }

        // Save to database for weekly caching (all users including guests).
        // Same birth day + same week = same result, no matter how many times they ask.
        await saveMahabokeReading({
          userId: userId > 0 ? userId : 0,
          deviceId: userId > 0 ? null : (deviceId || null),
          weekStart,
          birthDay: birthDayKey,
          birthDayOfMonth: birthDay,
          birthMonth,
          birthYear,
          personalityMm: reading.personalityMm,
          personalityEn: reading.personalityEn,
          personalityTh: reading.personalityTh,
          rulingPlanet: rulingPlanet.mm,
          rulingPlanetEn: rulingPlanet.en,
          loveMm: reading.loveMm,
          loveEn: reading.loveEn,
          loveTh: reading.loveTh,
          careerMm: reading.careerMm,
          careerEn: reading.careerEn,
          careerTh: reading.careerTh,
          healthMm: reading.healthMm,
          healthEn: reading.healthEn,
          healthTh: reading.healthTh,
          financeMm: reading.financeMm,
          financeEn: reading.financeEn,
          financeTh: reading.financeTh,
          familyMm: reading.familyMm || null,
          familyEn: reading.familyEn || null,
          familyTh: reading.familyTh || null,
          educationMm: reading.educationMm || null,
          educationEn: reading.educationEn || null,
          educationTh: reading.educationTh || null,
          travelMm: reading.travelMm || null,
          travelEn: reading.travelEn || null,
          travelTh: reading.travelTh || null,
          spiritualMm: reading.spiritualMm || null,
          spiritualEn: reading.spiritualEn || null,
          spiritualTh: reading.spiritualTh || null,
          luckyColor: reading.luckyColor,
          luckyColorMm: reading.luckyColorMm,
          luckyColorTh: reading.luckyColorTh,
          luckyDirection: reading.luckyDirection,
          luckyDirectionMm: reading.luckyDirectionMm,
          luckyDirectionTh: reading.luckyDirectionTh,
          luckyDay: reading.luckyDay,
          luckyDayMm: reading.luckyDayMm,
          luckyDayTh: reading.luckyDayTh,
          lucky2dNumbers: reading.lucky2dNumbers,
          luckyLotteryNumbers: reading.luckyLotteryNumbers,
          overallFortune: reading.overallFortune,
          weeklyMessageMm: reading.weeklyMessageMm,
          weeklyMessageEn: reading.weeklyMessageEn,
          weeklyMessageTh: reading.weeklyMessageTh,
        });

        return {
          ...reading,
          birthDayNameMm: birthName.mm,
          birthDayNameEn: birthName.en,
          rulingPlanetMm: rulingPlanet.mm,
          rulingPlanetEn: rulingPlanet.en,
          isCached: false,
        };
      }),
  }),

  // ─── AI Dream Interpreter ────────────────────────────────────────────────
  dream: router({
    interpret: publicProcedure
      .input(
        z.object({
          dreamText: z.string().min(5).max(2000),
          language: z.enum(["mm", "en", "th"]).default("mm"),
        })
      )
      .mutation(async ({ input }) => {
        const systemPrompt = `You are a mystical Myanmar dream interpreter and numerologist. 
You specialize in Burmese traditional dream interpretation (အိမ်မက်ဟောကိန်း) combined with 
astrological lucky number prediction for Thai lottery (6-digit) and Myanmar 2D (2-digit).

When given a dream description, you must:
1. Interpret the dream's spiritual meaning in Myanmar cultural context
2. Identify symbolic elements and their traditional meanings
3. Generate lucky 2D numbers (2-digit, 00-99) based on dream symbols
4. Generate lucky lottery numbers (6-digit combinations) based on dream energy
5. Provide lucky colors and directions for the week
6. Give an overall fortune rating (1-5 stars)

Always respond in valid JSON matching the exact schema provided.
Be mystical, encouraging, and culturally authentic to Myanmar traditions.`;

        const userPrompt = input.language === "mm"
          ? `အိမ်မက်: "${input.dreamText}"

ဤအိမ်မက်ကို မြန်မာ့ရိုးရာဓလေ့ထုံးတမ်းအရ ဟောကိန်းပေးပါ။ JSON format ဖြင့်သာ ဖြေပါ။`
          : `Dream: "${input.dreamText}"

Please interpret this dream using Myanmar traditional dream reading. Respond in JSON format only.`;

        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "dream_interpretation",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  interpretationMm: { type: "string", description: "Dream interpretation in Myanmar language" },
                  interpretationEn: { type: "string", description: "Dream interpretation in English" },
                  symbols: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        symbol: { type: "string" },
                        meaningMm: { type: "string" },
                        meaningEn: { type: "string" },
                      },
                      required: ["symbol", "meaningMm", "meaningEn"],
                      additionalProperties: false,
                    },
                  },
                  lucky2dNumbers: {
                    type: "array",
                    items: { type: "string" },
                    description: "3-5 lucky 2-digit numbers (00-99)",
                  },
                  luckyLotteryNumbers: {
                    type: "array",
                    items: { type: "string" },
                    description: "2-3 lucky 6-digit lottery number suggestions",
                  },
                  luckyColor: { type: "string", description: "Lucky color in English" },
                  luckyColorMm: { type: "string", description: "Lucky color in Myanmar" },
                  luckyDirection: { type: "string", description: "Lucky direction in English" },
                  luckyDirectionMm: { type: "string", description: "Lucky direction in Myanmar" },
                  overallFortune: { type: "number", description: "Overall fortune rating 1-5" },
                  fortuneMessageMm: { type: "string", description: "Encouraging fortune message in Myanmar" },
                  fortuneMessageEn: { type: "string", description: "Encouraging fortune message in English" },
                },
                required: [
                  "interpretationMm",
                  "interpretationEn",
                  "symbols",
                  "lucky2dNumbers",
                  "luckyLotteryNumbers",
                  "luckyColor",
                  "luckyColorMm",
                  "luckyDirection",
                  "luckyDirectionMm",
                  "overallFortune",
                  "fortuneMessageMm",
                  "fortuneMessageEn",
                ],
                additionalProperties: false,
              },
            },
          },
        });

        const content = response.choices[0]?.message?.content as string | undefined;
        if (!content) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No response from AI" });
        try {
          return JSON.parse(content) as {
            interpretationMm: string;
            interpretationEn: string;
            symbols: { symbol: string; meaningMm: string; meaningEn: string }[];
            lucky2dNumbers: string[];
            luckyLotteryNumbers: string[];
            luckyColor: string;
            luckyColorMm: string;
            luckyDirection: string;
            luckyDirectionMm: string;
            overallFortune: number;
            fortuneMessageMm: string;
            fortuneMessageEn: string;
          };
        } catch {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to parse AI response" });
        }
      }),
  }),

  // ─── Admin ───────────────────────────────────────────────────────────────
  admin: router({
    syncLotteryData: protectedProcedure.mutation(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
      }
      const { runSync } = await import("./scheduledSync");
      const result = await runSync();
      return result;
    }),
    broadcastLotteryResult: protectedProcedure
      .input(z.object({
        drawDate: z.string(),
        firstPrize: z.string(),
        lastTwoDigits: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
        }
        const result = await broadcastLotteryResult(input.drawDate, input.firstPrize, input.lastTwoDigits);
        return result;
      }),
  }),

  // ─── Saved Tickets ───────────────────────────────────────────────────────
  savedTickets: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const userId = ctx.user!.id;
      return getSavedTicketsByUser(userId);
    }),

    add: protectedProcedure
      .input(z.object({
        ticketNumber: z.string().length(6),
        drawDate: z.string(),
        note: z.string().max(128).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const userId = ctx.user!.id;
        await addSavedTicket({
          userId,
          ticketNumber: input.ticketNumber,
          drawDate: input.drawDate,
          note: input.note ?? null,
          isChecked: false,
          prizeResult: null,
        });
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const userId = ctx.user!.id;
        await deleteSavedTicket(input.id, userId);
        return { success: true };
      }),

    checkAll: protectedProcedure.mutation(async ({ ctx }) => {
      const userId = ctx.user!.id;
      const tickets = await getSavedTicketsByUser(userId);
      const unchecked = tickets.filter((t) => !t.isChecked);
      let checkedCount = 0;
      for (const ticket of unchecked) {
        const drawDateStr = typeof ticket.drawDate === "string"
          ? ticket.drawDate
          : String(ticket.drawDate);
        const draw = await getThaiLotteryDrawByDate(drawDateStr);
        if (!draw) continue;
        const matches = checkTicketAgainstDraw(ticket.ticketNumber, draw);
        await updateSavedTicketResult(ticket.id, userId, matches);
        checkedCount++;
      }
      return { checkedCount };
    }),
  }),

  // ─── AI Lucky Number Generator ───────────────────────────────────────────
  lucky: router({
    generate: publicProcedure
      .input(z.object({
        birthDay: z.number().min(1).max(31),
        birthMonth: z.number().min(1).max(12),
        birthYear: z.number().min(1900).max(2030),
        language: z.enum(["mm", "en", "th"]).default("mm"),
      }))
      .mutation(async ({ input }) => {
        const { birthDay, birthMonth, birthYear, language } = input;
        const today = new Date();
        const todayStr = `${today.getDate()}/${today.getMonth() + 1}/${today.getFullYear()}`;
        const birthDate = new Date(birthYear, birthMonth - 1, birthDay);
        const dayOfWeek = birthDate.getDay();
        const myanmarDays = ["တနင်္ဂနွေ", "တနင်္လာ", "အင်္ဂါ", "ဗုဒ္ဓဟူး", "ကြာသပတေး", "သောကြာ", "စနေ"];
        const birthWeekday = myanmarDays[dayOfWeek];

        const systemPrompt = `You are a master Myanmar numerologist and lottery expert. 
You specialize in generating lucky numbers based on birth dates using Myanmar traditional numerology (ကံဂဏန်းတွက်နည်း).
You combine birth date numerology, Myanmar weekday energy, and current date vibrations to generate the most auspicious numbers.
Always respond in valid JSON only.`;

        const userPrompt = language === "mm"
          ? `မွေးနေ့: ${birthDay}/${birthMonth}/${birthYear} (${birthWeekday}နေ့ဖွား)
ယနေ့ရက်: ${todayStr}

ဤပုဂ္ဂိုလ်အတွက် ယနေ့ကံကောင်းစေမဲ့ဂဏန်းများ ထုတ်ပေးပါ။
- ထိုင်းထီ ၆ လုံးဂဏန်း ၃ ခု
- မြန်မာ ၂ ဒီ ဂဏန်း ၅ ခု
- ကံကောင်းရောင် နှင့် ကံကောင်းသောနေ့
JSON format ဖြင့်သာ ဖြေပါ။`
          : `Birth date: ${birthDay}/${birthMonth}/${birthYear} (Born on ${birthWeekday} day)
Today: ${todayStr}

Generate lucky numbers for this person based on Myanmar numerology.
- 3 Thai lottery 6-digit numbers
- 5 Myanmar 2D 2-digit numbers
- Lucky color and lucky day
Respond in JSON format only.`;

        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "lucky_numbers",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  luckyLotteryNumbers: { type: "array", items: { type: "string" }, description: "3 lucky 6-digit Thai lottery numbers" },
                  lucky2dNumbers: { type: "array", items: { type: "string" }, description: "5 lucky 2-digit Myanmar 2D numbers" },
                  luckyColor: { type: "string" },
                  luckyColorMm: { type: "string" },
                  luckyDay: { type: "string" },
                  luckyDayMm: { type: "string" },
                  reasoningMm: { type: "string", description: "Brief explanation in Myanmar why these numbers are lucky" },
                  reasoningEn: { type: "string", description: "Brief explanation in English why these numbers are lucky" },
                  overallLuck: { type: "number", description: "Overall luck score 1-5" },
                },
                required: ["luckyLotteryNumbers","lucky2dNumbers","luckyColor","luckyColorMm","luckyDay","luckyDayMm","reasoningMm","reasoningEn","overallLuck"],
                additionalProperties: false,
              },
            },
          },
        });

        const content = response.choices[0]?.message?.content as string | undefined;
        if (!content) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No AI response" });
        try {
          return JSON.parse(content) as {
            luckyLotteryNumbers: string[];
            lucky2dNumbers: string[];
            luckyColor: string;
            luckyColorMm: string;
            luckyDay: string;
            luckyDayMm: string;
            reasoningMm: string;
            reasoningEn: string;
            overallLuck: number;
          };
        } catch {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to parse AI response" });
        }
      }),
  }),

  // ─── Myanmar 2D AI Prediction ────────────────────────────────────────────
  prediction: router({
    myanmar2d: publicProcedure
      .input(z.object({ language: z.enum(["mm", "en", "th"]).default("mm") }))
      .mutation(async ({ input }) => {
        return generateMyanmar2dPrediction(input.language);
      }),
    getDailyMyanmar2d: publicProcedure.query(async () => {
      const predictionDate = getMyanmarPredictionDate();
      const [morningRaw, eveningRaw] = await Promise.all([
        getAppSetting(makeMyanmarPredictionSettingKey(predictionDate, "morning")),
        getAppSetting(makeMyanmarPredictionSettingKey(predictionDate, "evening")),
      ]);
      const parseStored = (raw: string | null) => {
        if (!raw) return null;
        try { return parseMyanmar2dPrediction(JSON.parse(raw)); } catch { return null; }
      };
      const morning = parseStored(morningRaw);
      const evening = parseStored(eveningRaw);
      if (!morning && !evening) return null;
      return {
        morningPredictions: morning?.morningPredictions ?? [],
        eveningPredictions: evening?.eveningPredictions ?? [],
        hotNumbers: evening?.hotNumbers ?? morning?.hotNumbers ?? [],
        coldNumbers: evening?.coldNumbers ?? morning?.coldNumbers ?? [],
        analysisMm: evening?.analysisMm ?? morning?.analysisMm ?? "",
        analysisEn: evening?.analysisEn ?? morning?.analysisEn ?? "",
        confidenceLevel: evening?.confidenceLevel ?? morning?.confidenceLevel ?? 1,
        disclaimer: evening?.disclaimer ?? morning?.disclaimer ?? "ဟောဂဏန်းသည် ဖျော်ဖြေရေးအတွက်သာဖြစ်ပြီး အာမခံရလဒ်မဟုတ်ပါ။",
      };
    }),
  }),
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserNotifications(ctx.user.id);
    }),
    unreadCount: protectedProcedure.query(async ({ ctx }) => {
      return getUnreadNotificationCount(ctx.user.id);
    }),
    markRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await markNotificationRead(input.id, ctx.user.id);
        return { success: true };
      }),
    markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
      await markAllNotificationsRead(ctx.user.id);
      return { success: true };
    }),
  }),
  // ─── Push Subscriptions ───────────────────────────────────────────────────
  push: router({
    getPublicKey: publicProcedure.query(() => {
      return { publicKey: ENV.vapidPublicKey };
    }),
    subscribe: publicProcedure
      .input(z.object({
        endpoint: z.string().min(1),
        p256dh: z.string().min(1),
        auth: z.string().min(1),
        visitorId: z.string().min(16).max(96),
      }))
      .mutation(async ({ input, ctx }) => {
        let userId = ctx.user?.id;
        if (!userId) {
          const guestOpenId = `push-device-${input.visitorId}`;
          await upsertUser({
            openId: guestOpenId,
            name: "Golden Thai subscriber",
            loginMethod: "web-push",
          });
          const guestUser = await getUserByOpenId(guestOpenId);
          if (!guestUser) {
            throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Unable to save this device notification subscription" });
          }
          userId = guestUser.id;
        }
        await savePushSubscription({
          userId,
          endpoint: input.endpoint,
          p256dh: input.p256dh,
          auth: input.auth,
        });
        return { success: true };
      }),
    unsubscribe: protectedProcedure
      .input(z.object({ endpoint: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        await removePushSubscription(ctx.user.id, input.endpoint);
        return { success: true };
      }),
    getSubscriptions: protectedProcedure.query(async ({ ctx }) => {
      return getPushSubscriptionsByUserId(ctx.user.id);
    }),
  }),
  // ─── Weekly Lucky Number Preferences ─────────────────────────────────────
  weeklyLucky: router({
    getPreference: protectedProcedure.query(async ({ ctx }) => {
      const enabled = await getWeeklyLuckyPreference(ctx.user.id);
      return { enabled };
    }),
    setPreference: protectedProcedure
      .input(z.object({ enabled: z.boolean() }))
      .mutation(async ({ input, ctx }) => {
        await setWeeklyLuckyPreference(ctx.user.id, input.enabled);
        return { success: true, enabled: input.enabled };
      }),
  }),
  // ─── Lucky Box ────────────────────────────────────────────────────────────
  luckyBox: router({
    // Get stats: works for both logged-in and guest users
    getStats: publicProcedure.query(async ({ ctx }) => {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      const day = now.getDate();
      const prizePool = await getMonthlyPrizePool(year, month);

      if (ctx.user) {
        // Logged-in user — use userId
        const todayOpenings = await countTodayOpenings(ctx.user.id, year, month, day);
        const monthWins = await countMonthWins(ctx.user.id, year, month);
        return {
          todayOpenings,
          maxDailyOpenings: 4,
          monthWins,
          maxMonthlyWins: 1,
          prizePool: prizePool ? {
            adRevenue: prizePool.adRevenue,
            prizePercentage: prizePool.prizePercentage,
            totalPrizePool: prizePool.totalPrizePool,
          } : null,
          hasWonThisMonth: monthWins > 0,
        };
      }

      // Guest user — return default stats (frontend will handle device-based tracking)
      return {
        todayOpenings: 0,
        maxDailyOpenings: 4,
        monthWins: 0,
        maxMonthlyWins: 1,
        prizePool: prizePool ? {
          adRevenue: prizePool.adRevenue,
          prizePercentage: prizePool.prizePercentage,
          totalPrizePool: prizePool.totalPrizePool,
        } : null,
        hasWonThisMonth: false,
      };
    }),

    // Get guest stats by device ID
    getGuestStats: publicProcedure
      .input(z.object({
        guestDeviceId: z.string().min(1).max(64),
      }))
      .query(async ({ input }) => {
        const now = new Date();
        const year = now.getFullYear();
        const month = now.getMonth() + 1;
        const day = now.getDate();
        const prizePool = await getMonthlyPrizePool(year, month);
        const guestStats = await getGuestLuckyBoxStats(input.guestDeviceId, year, month, day);

        return {
          todayOpenings: guestStats.todayOpenings,
          maxDailyOpenings: 4,
          monthWins: 0,
          maxMonthlyWins: 1,
          prizePool: prizePool ? {
            adRevenue: prizePool.adRevenue,
            prizePercentage: prizePool.prizePercentage,
            totalPrizePool: prizePool.totalPrizePool,
          } : null,
          hasWonThisMonth: guestStats.hasWonThisMonth,
        };
      }),

    // Get current time slot info (which slots are active)
    getTimeSlots: publicProcedure
      .input(z.object({ guestDeviceId: z.string().min(1).max(64).optional() }).optional())
      .query(async ({ ctx, input }) => {
        const state = getLuckyBoxSlotState();
        const testMode = await isLuckyBoxTestMode();
        const todayOpenings = ctx.user
          ? await countTodayOpenings(ctx.user.id, state.year, state.month, state.day)
          : input?.guestDeviceId
            ? await countTodayOpeningsByDevice(input.guestDeviceId, state.year, state.month, state.day)
            : 0;
        const hasOpenedCurrentSlot = !testMode && state.slotKey
          ? ctx.user
            ? (await countLuckyBoxOpeningsBySlot(ctx.user.id, state.slotKey)) > 0
            : input?.guestDeviceId
              ? (await countLuckyBoxOpeningsByDeviceAndSlot(input.guestDeviceId, state.slotKey)) > 0
              : false
          : false;

        return {
          activeSlot: testMode
            ? { id: 0, label: "စမ်းသပ်ဖွင့်ထားသည်", labelEn: "Test mode open" }
            : state.activeSlot ? { id: state.activeSlot.id, label: state.activeSlot.label, labelEn: state.activeSlot.labelEn } : null,
          nextSlot: { id: state.nextSlot.id, label: state.nextSlot.label, labelEn: state.nextSlot.labelEn },
          secondsUntilNext: state.secondsUntilNext,
          hasOpenedCurrentSlot,
          testMode,
          dailyOpeningsRemaining: Math.max(0, 4 - todayOpenings),
          canOpen: testMode ? todayOpenings < 4 : Boolean(state.activeSlot) && !hasOpenedCurrentSlot,
        };
      }),

    // Open the lucky box — works for both logged-in and guest users
    openBox: publicProcedure
      .input(z.object({
        guestDeviceId: z.string().min(1).max(64),
      }))
      .mutation(async ({ ctx, input }) => {
        // Check if Lucky Box is disabled by admin
        const boxEnabled = await getAppSetting('lucky_box_enabled');
        if (boxEnabled === 'false') {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Lucky Box is currently disabled by admin. ပြန်ဖွင့်ချိန်မှာ ထပ်ကြိုင်းပါ။",
          });
        }

        const [slotState, testMode] = [getLuckyBoxSlotState(), await isLuckyBoxTestMode()];
        if (!testMode && (!slotState.activeSlot || !slotState.slotKey)) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: `Lucky Box is closed. Next opening: ${slotState.nextSlot.label}`,
          });
        }
        const { year, month, day } = slotState;
        const slotKey = testMode
          ? `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}-test`
          : slotState.slotKey!;

        if (ctx.user) {
          // === AUTHENTICATED USER ===
          if (!testMode && await countLuckyBoxOpeningsBySlot(ctx.user.id, slotKey)) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "This Lucky Box opening has already been used. Please wait for the next slot." });
          }
          const todayOpenings = await countTodayOpenings(ctx.user.id, year, month, day);
          const monthWins = await countMonthWins(ctx.user.id, year, month);
          if (todayOpenings >= 4) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "Today opening limit reached" });
          }
          if (!testMode && monthWins >= 1) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "Monthly winner limit reached" });
          }

          // Generate reference ID
          const referenceId = `LB${year}${String(month).padStart(2, "0")}${String(day).padStart(2, "0")}-${ctx.user.id}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

          const { isWinner, prizeAmount } = await determineLuckyBoxPrize(year, month);
          // Generate one-time QR token for winner
          const qrToken = isWinner ? crypto.randomUUID().replace(/-/g, '') : null;

          await insertLuckyBoxOpening({
            userId: ctx.user.id,
            slotKey,
            year,
            month,
            isWinner,
            prizeAmount,
            referenceId,
            qrToken,
          });

          return {
            isWinner,
            prizeAmount,
            referenceId,
            qrToken,
            todayOpenings: todayOpenings + 1,
            hasWonThisMonth: monthWins + (isWinner ? 1 : 0) >= 1,
            monthWins: monthWins + (isWinner ? 1 : 0),
          };
        }

        // === GUEST USER (no auth) ===
        // Check 1: Daily limit via device ID
        if (!testMode && await countLuckyBoxOpeningsByDeviceAndSlot(input.guestDeviceId, slotKey)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "This Lucky Box opening has already been used. Please wait for the next slot." });
        }
        const todayOpenings = await countTodayOpeningsByDevice(input.guestDeviceId, year, month, day);
        const monthWins = await countMonthWinsByDevice(input.guestDeviceId, year, month);
        if (todayOpenings >= 4) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Today opening limit reached" });
        }
        if (!testMode && monthWins >= 1) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Monthly winner limit reached" });
        }

        // Generate reference ID (device-based)
        const deviceHash = input.guestDeviceId.substring(0, 8);
        const referenceId = `LB${year}${String(month).padStart(2, "0")}${String(day).padStart(2, "0")}-G-${deviceHash}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

        const { isWinner, prizeAmount } = await determineLuckyBoxPrize(year, month);
        // Generate one-time QR token for winner
        const qrToken = isWinner ? crypto.randomUUID().replace(/-/g, '') : null;

        // Insert opening record (userId=0 for guests, guestDeviceId tracks the device)
        await insertLuckyBoxOpening({
          userId: 0, // Guest
          guestDeviceId: input.guestDeviceId,
          slotKey,
          year,
          month,
          isWinner,
          prizeAmount,
          referenceId,
          qrToken,
        });

        return {
          isWinner,
          prizeAmount,
          referenceId,
          qrToken,
          todayOpenings: todayOpenings + 1,
          hasWonThisMonth: monthWins + (isWinner ? 1 : 0) >= 1,
          monthWins: monthWins + (isWinner ? 1 : 0),
        };
      }),

    // Claim prize by reference ID + phone number
    claimPrize: publicProcedure
      .input(z.object({
        referenceId: z.string().min(1),
        phone: z.string().min(6).max(20),
      }))
      .mutation(async ({ input }) => {
        // Check if this phone already claimed a prize
        const alreadyUsed = await checkDuplicateClaim(input.phone);
        if (alreadyUsed) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "This phone number has already claimed a prize",
          });
        }

        const result = await claimPrizeByReferenceId(input.referenceId, input.phone);
        if (!result) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Invalid reference ID",
          });
        }
        if (result.alreadyClaimed) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "This prize has already been claimed",
          });
        }

        return { success: true, message: "Prize claimed successfully. Admin will contact you via Telegram." };
      }),

    // Get winner details (for admin to verify)
    getWinnerDetails: publicProcedure
      .input(z.object({
        referenceId: z.string().min(1),
      }))
      .query(async ({ input }) => {
        return await getWinnerDetailsByRefId(input.referenceId);
      }),

    // A signed-in user can only read their own opening records. Because admin
    // deletion removes the same record from lucky_box_openings, it disappears
    // from this history automatically on the next refresh.
    getHistory: protectedProcedure.query(async ({ ctx }) => {
      return await getLuckyBoxOpenings(ctx.user.id, 30);
    }),

    // A guest can read only winner records bound to its own locally generated
    // device ID. Admin deletion removes the same record and it vanishes on the
    // next client refresh.
    getGuestWinnerHistory: publicProcedure
      .input(z.object({ guestDeviceId: z.string().min(12).max(64) }))
      .query(async ({ input }) => {
        return await getGuestLuckyBoxWinnerHistory(input.guestDeviceId, 30);
      }),

    // Get monthly prize pool
    getPrizePool: publicProcedure.query(async () => {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      const prizePool = await getMonthlyPrizePool(year, month);
      return prizePool ? {
        adRevenue: prizePool.adRevenue,
        prizePercentage: prizePool.prizePercentage,
        totalPrizePool: prizePool.totalPrizePool,
      } : null;
    }),
  }),
  // ─── Lucky Box Winners (Public) ────────────────────────────────────────────
  luckyBoxWinners: router({
    // Public: Get all past Lucky Box winners
    getWinners: publicProcedure.query(async () => {
      const winners = await getAllLuckyBoxWinners();
      return winners.map((w: any) => ({
        id: w.id,
        displayName: w.userName || w.userEmail?.split("@")[0] || "Unknown",
        openedAt: w.openedAt,
        referenceId: w.referenceId,
        year: w.year,
        month: w.month,
      }));
    }),
  }),

  // ─── Admin Lucky Box ─────────────────────────────────────────────────────
  adminLuckyBox: router({
    // Set monthly prize pool
    setPrizePool: protectedProcedure
      .input(z.object({
        adRevenue: z.number().min(0),
        prizePercentage: z.number().min(1).max(100),
      }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        const now = new Date();
        const year = now.getFullYear();
        const month = now.getMonth() + 1;
        const totalPrizePool = Math.floor((input.adRevenue * input.prizePercentage) / 100);

        await upsertMonthlyPrizePool({
          year,
          month,
          adRevenue: input.adRevenue,
          prizePercentage: input.prizePercentage,
          totalPrizePool,
        });

        return { success: true, totalPrizePool };
      }),

    // Get monthly winners
    getMonthlyWinners: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      return getMonthlyWinners(year, month);
    }),

    // Get Lucky Box enabled status
    getLuckyBoxStatus: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      const value = await getAppSetting('lucky_box_enabled');
      return { enabled: value !== 'false' };
    }),

    // Toggle Lucky Box on/off (admin only)
    toggleLuckyBox: protectedProcedure
      .input(z.object({
        enabled: z.boolean(),
      }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        await setAppSetting('lucky_box_enabled', String(input.enabled));
        return { success: true, enabled: input.enabled };
      }),

    // Get prize tiers (admin)
    getPrizeTiers: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      const value = await getAppSetting('lucky_box_prize_tiers');
      const defaultTiers = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
      let tiers: number[];
      try {
        tiers = value ? JSON.parse(value) : defaultTiers;
      } catch {
        tiers = defaultTiers;
      }
      return { tiers };
    }),

    // Set prize tiers (admin only)
    setPrizeTiers: protectedProcedure
      .input(z.object({
        tiers: z.array(z.number().int().min(50).max(9999999)),
      }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        await setAppSetting('lucky_box_prize_tiers', JSON.stringify(input.tiers));
        return { success: true, tiers: input.tiers };
      }),

    // Get prize tier weights (admin)
    getPrizeTierWeights: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      const value = await getAppSetting('lucky_box_prize_tier_weights');
      const defaultWeights: Record<number, number> = {
        50: 25, 100: 20, 200: 15, 300: 12, 400: 9, 500: 7, 600: 4, 700: 3, 800: 2, 900: 2, 1000: 1,
      };
      let weights: Record<number, number>;
      try {
        weights = value ? JSON.parse(value) : defaultWeights;
      } catch {
        weights = defaultWeights;
      }
      return { weights };
    }),

    // Set prize tier weights (admin only)
    setPrizeTierWeights: protectedProcedure
      .input(z.object({
        weights: z.record(z.string(), z.number().min(0).max(100)),
      }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        const weights: Record<number, number> = {};
        for (const [key, value] of Object.entries(input.weights)) {
          weights[parseInt(key)] = value;
        }
        const tierSetting = await getAppSetting('lucky_box_prize_tiers');
        const defaultTiers = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
        let activeTiers: number[];
        try {
          activeTiers = tierSetting ? JSON.parse(tierSetting) : defaultTiers;
        } catch {
          activeTiers = defaultTiers;
        }
        const totalPercentage = activeTiers.reduce((total, tier) => total + (weights[tier] ?? 0), 0);
        if (Math.abs(totalPercentage - 100) > 0.001) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'Coin tier percentages must total 100%' });
        }
        await setAppSetting('lucky_box_prize_tier_weights', JSON.stringify(weights));
        return { success: true, weights, totalPercentage };
      }),

    // Get prize tiers (public — for display on Lucky Box page)
    getPublicPrizeTiers: publicProcedure.query(async () => {
      const value = await getAppSetting('lucky_box_prize_tiers');
      const defaultTiers = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
      let tiers: number[];
      try {
        tiers = value ? JSON.parse(value) : defaultTiers;
      } catch {
        tiers = defaultTiers;
      }
      return { tiers };
    }),

    // Get time slots (admin)
    getTimeSlotsAdmin: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      const value = await getAppSetting('lucky_box_time_slots');
      const defaultSlots = [
        { hour: 9, minute: 0, labelMm: "မနက် ၉:၀၀", labelEn: "9:00 AM" },
        { hour: 13, minute: 0, labelMm: "နေ့လည် ၁:၀၀", labelEn: "1:00 PM" },
        { hour: 16, minute: 0, labelMm: "ညနေ ၄:၀၀", labelEn: "4:00 PM" },
        { hour: 20, minute: 0, labelMm: "ည ၈:၀၀", labelEn: "8:00 PM" },
      ];
      let slots: Array<{ hour: number; minute: number; labelMm: string; labelEn: string }>;
      try {
        slots = value ? JSON.parse(value) : defaultSlots;
      } catch {
        slots = defaultSlots;
      }
      return { slots };
    }),

    // Set time slots (admin only)
    setTimeSlots: protectedProcedure
      .input(z.object({
        slots: z.array(z.object({
          hour: z.number().int().min(0).max(23),
          minute: z.number().int().min(0).max(59),
          labelMm: z.string(),
          labelEn: z.string(),
        })),
      }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        await setAppSetting('lucky_box_time_slots', JSON.stringify(input.slots));
        return { success: true, slots: input.slots };
      }),

    // Legacy: Get prize amount setting (returns highest tier for backward compat)
    getPrizeAmount: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      const value = await getAppSetting('lucky_box_prize_tiers');
      const defaultTiers = [100, 200, 300, 400, 500, 800, 1000];
      let tiers: number[];
      try {
        tiers = value ? JSON.parse(value) : defaultTiers;
      } catch {
        tiers = defaultTiers;
      }
      return { amount: Math.max(...tiers) };
    }),

    // Legacy: Set prize amount (maps to max tier for backward compat)
    setPrizeAmount: protectedProcedure
      .input(z.object({
        amount: z.number().int().min(100).max(9999999),
      }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        // Keep existing tiers, just ensure max tier >= amount
        const current = await getAppSetting('lucky_box_prize_tiers');
        const defaultTiers = [100, 200, 300, 400, 500, 800, 1000];
        let tiers: number[];
        try {
          tiers = current ? JSON.parse(current) : defaultTiers;
        } catch {
          tiers = defaultTiers;
        }
        const maxCurrent = Math.max(...tiers);
        if (input.amount > maxCurrent) {
          tiers.push(input.amount);
        }
        await setAppSetting('lucky_box_prize_tiers', JSON.stringify(tiers));
        return { success: true, amount: input.amount };
      }),

    // Get all winners with full details for admin (claim status, phone, device ID, user info)
    getAllWinners: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      return await getAllLuckyBoxWinners();
    }),

    // Get winner details by reference ID for admin verification
    getWinnerByRefId: protectedProcedure
      .input(z.object({
        referenceId: z.string().min(1),
      }))
      .query(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        return await getWinnerDetailsByRefId(input.referenceId);
      }),

    getWinChance: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      return { percentage: await getLuckyBoxWinChance() };
    }),

    setWinChance: protectedProcedure
      .input(z.object({ percentage: z.number().min(0).max(100) }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        const percentage = normalizeLuckyBoxWinChance(input.percentage);
        await setAppSetting('lucky_box_win_chance', String(percentage));
        return { success: true, percentage };
      }),

    getMonthlyBudget: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      const now = new Date();
      return getLuckyBoxMonthlyBudget(now.getFullYear(), now.getMonth() + 1);
    }),

    setMonthlyBudget: protectedProcedure
      .input(z.object({
        budgetCoins: z.number().int().min(0),
      }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        const now = new Date();
        await upsertMonthlyPrizePool({
          year: now.getFullYear(),
          month: now.getMonth() + 1,
          adRevenue: 0,
          prizePercentage: 0,
          totalPrizePool: input.budgetCoins,
        });
        return { success: true, budgetCoins: input.budgetCoins };
      }),

    deleteWinner: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        return { success: await deleteLuckyBoxWinnerById(input.id) };
      }),

    setWinnerPaidStatus: protectedProcedure
      .input(z.object({ id: z.number().int().positive(), paid: z.boolean() }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        const success = await setLuckyBoxWinnerPaidStatus(input.id, input.paid);
        if (!success) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Lucky Box winner record not found" });
        }
        return { success: true, paid: input.paid };
      }),

    deleteAllWinners: protectedProcedure.mutation(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      return { success: true, deletedCount: await deleteAllLuckyBoxWinnerRecords() };
    }),

    getBroadcastStatus: protectedProcedure.query(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      return { current: await getCurrentInAppBroadcast() };
    }),

    sendBroadcast: protectedProcedure
      .input(z.object({
        title: z.string().trim().min(1).max(80),
        message: z.string().trim().min(1).max(300),
      }))
      .mutation(async ({ ctx, input }) => {
        requireLuckyBoxOwner(ctx.user);
        const broadcast: InAppBroadcast = {
          id: crypto.randomUUID(),
          title: input.title,
          message: input.message,
          publishedAt: new Date().toISOString(),
        };
        await setAppSetting(IN_APP_BROADCAST_SETTING_KEY, JSON.stringify(broadcast));
        return { published: true, broadcast };
      }),

    // Get total user count (public — no login required)
    getUserStats: publicProcedure.query(async () => {
      const totalUsers = await countAllUsers();
      const totalWinners = (await getAllLuckyBoxWinners()).length;
      return { totalUsers, totalWinners };
    }),

    // Trigger monthly reset
    monthlyReset: protectedProcedure.mutation(async ({ ctx }) => {
      requireLuckyBoxOwner(ctx.user);
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;

      const alreadyDone = await isMonthlyResetDone(year, month);
      if (alreadyDone) {
        return { success: true, message: "Already reset for this month" };
      }

      await insertMonthlyReset(year, month);
      return { success: true, message: "Monthly reset completed" };
    }),
  }),
});

export type AppRouter = typeof appRouter;
