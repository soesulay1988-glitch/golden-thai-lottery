/**
 * Web Push Notification Module
 * Handles sending push notifications to browser subscriptions
 */

import webpush from "web-push";
import { ENV } from "./_core/env";
import { getAllPushSubscriptions, removePushSubscription } from "./db";

// Initialize VAPID keys on module load
function initVapidKeys() {
  if (ENV.vapidPublicKey && ENV.vapidPrivateKey) {
    webpush.setVapidDetails(
      "mailto:admin@goldenthai.manus.space",
      ENV.vapidPublicKey,
      ENV.vapidPrivateKey
    );
    return true;
  }
  return false;
}

// Ensure keys are initialized (lazy init)
let vapidInitialized = false;
function ensureVapid() {
  if (!vapidInitialized) {
    vapidInitialized = initVapidKeys();
  }
  return vapidInitialized;
}

export type PushPayload = {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  url?: string;
  requireInteraction?: boolean;
  tag?: string;
  silent?: boolean;
  vibrate?: number[];
};

export async function getPushDeliveryStatus(): Promise<{ vapidConfigured: boolean; subscriberCount: number }> {
  const vapidConfigured = ensureVapid();
  const subscriptions = await getAllPushSubscriptions();
  return { vapidConfigured, subscriberCount: subscriptions.length };
}

/**
 * Send a push notification to all registered subscriptions
 * Returns count of successful sends
 */
export async function sendPushNotification(payload: PushPayload): Promise<{ sent: number; failed: number; dead: number }> {
  if (!ensureVapid()) {
    console.warn("[PushNotification] VAPID keys not configured, skipping push");
    return { sent: 0, failed: 0, dead: 0 };
  }

  const subscriptions = await getAllPushSubscriptions();
  if (subscriptions.length === 0) {
    return { sent: 0, failed: 0, dead: 0 };
  }

  let sent = 0;
  let failed = 0;
  let dead = 0;

  for (const sub of subscriptions) {
    try {
      // Merge NotificationOptions for browser display
      const notificationData: Record<string, unknown> = { ...payload };
      // Web push options for sound/vibration
      const pushOptions: Record<string, unknown> = {};
      if (payload.vibrate) pushOptions.vibrate = payload.vibrate;
      if (payload.tag) pushOptions.tag = payload.tag;
      if (payload.requireInteraction !== undefined) pushOptions.requireInteraction = payload.requireInteraction;
      if (payload.silent !== undefined) pushOptions.silent = payload.silent;
      // Send as data payload — client-side SW handles the notification display
      const dataPayload = {
        ...notificationData,
        _options: Object.keys(pushOptions).length > 0 ? pushOptions : undefined,
      };
      await webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: {
            p256dh: sub.p256dh,
            auth: sub.auth,
          },
        },
        JSON.stringify(dataPayload)
      );
      sent++;
    } catch (err: any) {
      if (err?.statusCode === 410) {
        // Subscription expired — remove it
        console.log(`[PushNotification] Subscription expired for user ${sub.userId}, removing`);
        await removePushSubscription(sub.userId, sub.endpoint);
        dead++;
      } else {
        failed++;
        console.warn(`[PushNotification] Failed for user ${sub.userId}: ${err?.message || String(err)}`);
      }
    }
  }

  console.log(`[PushNotification] Sent=${sent} Failed=${failed} Dead=${dead}`);
  return { sent, failed, dead };
}

/**
 * Broadcast lottery result notification via web push
 */
export async function broadcastLotteryResult(drawDate: string, firstPrize: string, lastTwoDigits: string) {
  const payload: PushPayload = {
    title: `🎉 ${drawDate} ထီဆွဲချက် ရလဒ်များ ထွက်ပြီးပါပြီ!`,
    body: `ပထမဆု: ${firstPrize} | နောက် ၂ လုံး: ${lastTwoDigits}`,
    url: "/lottery",
    icon: "/favicon.ico",
    badge: "/favicon.ico",
  };

  return sendPushNotification(payload);
}
