import { describe, expect, it } from "vitest";
import { appRouter, parseThreeDEvidenceImageDataUrl } from "./routers";
import type { TrpcContext } from "./_core/context";

function createNonOwnerContext(): TrpcContext {
  return {
    user: {
      id: 42,
      openId: "non-owner",
      email: "member@example.com",
      name: "Member",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("3D evidence image upload validation", () => {
  it("accepts a supported image data URL", () => {
    const result = parseThreeDEvidenceImageDataUrl("data:image/png;base64,aGVsbG8=");
    expect(result.mimeType).toBe("image/png");
    expect(result.extension).toBe("png");
    expect(result.bytes.toString()).toBe("hello");
  });

  it("rejects unsupported image types", () => {
    expect(() => parseThreeDEvidenceImageDataUrl("data:image/gif;base64,aGVsbG8=")).toThrow("Use a JPG, PNG, or WEBP image");
  });

  it("rejects a non-owner admin before image storage is called", async () => {
    const caller = appRouter.createCaller(createNonOwnerContext());
    await expect(caller.threeDImage.upload({ dataUrl: "data:image/png;base64,aGVsbG8gd29ybGQgdGVzdCBpbWFnZSBmaWxlIQ==" })).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });
});
