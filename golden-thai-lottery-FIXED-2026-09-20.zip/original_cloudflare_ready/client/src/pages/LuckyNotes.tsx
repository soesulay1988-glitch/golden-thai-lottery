import { FormEvent, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, CalendarDays, NotebookPen, Pencil, Plus, Save, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { useLang } from "@/contexts/LangContext";

const STORAGE_KEY = "golden_thai_lucky_notes_v1";
const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;

type LuckyNote = {
  id: string;
  numbers: string;
  note: string;
  noteDate: string;
  createdAt: number;
  updatedAt: number;
  expiresAt: number;
};

function readNotes(now = Date.now()): LuckyNote[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]") as LuckyNote[];
    const active = Array.isArray(parsed) ? parsed.filter((item) => item && typeof item.id === "string" && Number(item.expiresAt) > now) : [];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(active));
    return active.sort((a, b) => b.updatedAt - a.updatedAt);
  } catch {
    return [];
  }
}

function writeNotes(notes: LuckyNote[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

function makeId() {
  return globalThis.crypto?.randomUUID?.() ?? `note-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export default function LuckyNotes() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const mm = lang === "mm";
  const [notes, setNotes] = useState<LuckyNote[]>(() => readNotes());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [numbers, setNumbers] = useState("");
  const [note, setNote] = useState("");
  const [noteDate, setNoteDate] = useState(() => new Date().toISOString().slice(0, 10));
  const editing = useMemo(() => notes.find((item) => item.id === editingId), [editingId, notes]);

  const resetForm = () => {
    setEditingId(null);
    setNumbers("");
    setNote("");
    setNoteDate(new Date().toISOString().slice(0, 10));
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const cleanNumbers = numbers.trim();
    const cleanNote = note.trim();
    if (!cleanNumbers && !cleanNote) {
      toast(mm ? "စာသား သို့မဟုတ် ဂဏန်း ထည့်ပါ" : "Enter a note or number");
      return;
    }
    const now = Date.now();
    const next = editing
      ? notes.map((item) => item.id === editing.id ? { ...item, numbers: cleanNumbers, note: cleanNote, noteDate, updatedAt: now } : item)
      : [{ id: makeId(), numbers: cleanNumbers, note: cleanNote, noteDate, createdAt: now, updatedAt: now, expiresAt: now + ONE_YEAR_MS }, ...notes];
    writeNotes(next);
    setNotes(next.sort((a, b) => b.updatedAt - a.updatedAt));
    toast(mm ? "မှတ်တမ်းသိမ်းပြီးပါပြီ" : "Note saved");
    resetForm();
  };

  const startEdit = (item: LuckyNote) => {
    setEditingId(item.id);
    setNumbers(item.numbers);
    setNote(item.note);
    setNoteDate(item.noteDate);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const remove = (id: string) => {
    if (!window.confirm(mm ? "ဒီမှတ်တမ်းကို ဖျက်မလား?" : "Delete this note?")) return;
    const next = notes.filter((item) => item.id !== id);
    writeNotes(next);
    setNotes(next);
    if (editingId === id) resetForm();
    toast(mm ? "မှတ်တမ်းဖျက်ပြီးပါပြီ" : "Note deleted");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF8E1] to-[#f7f7f7] pb-24">
      <header className="page-header bg-[#FFD700] shadow-sm">
        <div className="mx-auto flex max-w-[480px] items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/")} className="rounded-xl p-1.5 text-[#3b3200] hover:bg-white/35 btn-press" aria-label="Back"><ArrowLeft size={21} /></button>
          <div className="min-w-0 flex-1"><h1 className="font-myanmar-display text-[17px] font-black text-[#312a00]">{mm ? "ကံထူးမှတ်တမ်း" : "Lucky Notes"}</h1><p className="font-myanmar text-[10px] text-[#5d5100]">{mm ? "ဖုန်းထဲတွင် ၁ နှစ်သိမ်းထားမည်" : "Stored on this phone for one year"}</p></div>
          <NotebookPen size={20} className="text-[#795d00]" />
        </div>
      </header>

      <main className="mx-auto max-w-[480px] space-y-3 px-3 pt-3">
        <form onSubmit={submit} className="rounded-2xl border border-violet-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between"><h2 className="font-myanmar text-sm font-black text-violet-800">{editing ? (mm ? "မှတ်တမ်းပြင်ရန်" : "Edit note") : (mm ? "မှတ်တမ်းအသစ်" : "New note")}</h2>{editing && <button type="button" onClick={resetForm} className="rounded-full bg-slate-100 p-1.5 text-slate-500"><X size={15} /></button>}</div>
          <label className="mt-3 block font-myanmar text-[11px] font-bold text-slate-600">{mm ? "ဂဏန်းများ" : "Numbers"}<input value={numbers} onChange={(event) => setNumbers(event.target.value)} inputMode="numeric" maxLength={100} placeholder={mm ? "ဥပမာ 12, 24, 58" : "Example: 12, 24, 58"} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-lg font-black tracking-wider outline-none focus:border-violet-400" /></label>
          <label className="mt-3 block font-myanmar text-[11px] font-bold text-slate-600">{mm ? "မှတ်ချက်စာသား" : "Note"}<textarea value={note} onChange={(event) => setNote(event.target.value)} maxLength={1000} rows={4} placeholder={mm ? "မှတ်သားလိုသော အကြောင်းအရာရေးပါ" : "Write something to remember"} className="mt-1 w-full resize-none rounded-xl border border-slate-200 px-3 py-2.5 font-myanmar text-sm leading-6 outline-none focus:border-violet-400" /></label>
          <label className="mt-3 block font-myanmar text-[11px] font-bold text-slate-600">{mm ? "ရက်စွဲ" : "Date"}<input value={noteDate} onChange={(event) => setNoteDate(event.target.value)} type="date" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:border-violet-400" /></label>
          <button type="submit" className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-violet-600 px-4 py-3 font-myanmar text-sm font-black text-white shadow-sm btn-press">{editing ? <Save size={17} /> : <Plus size={17} />}{editing ? (mm ? "ပြင်ဆင်ပြီး သိမ်းရန်" : "Save changes") : (mm ? "မှတ်တမ်းသိမ်းရန်" : "Save note")}</button>
        </form>

        <section className="space-y-2">
          <div className="flex items-center justify-between px-1"><h2 className="font-myanmar text-sm font-black text-slate-700">{mm ? "သိမ်းထားသောမှတ်တမ်းများ" : "Saved notes"}</h2><span className="rounded-full bg-violet-100 px-2 py-1 text-[10px] font-bold text-violet-700">{notes.length}</span></div>
          {!notes.length && <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-5 py-12 text-center"><NotebookPen className="mx-auto text-slate-300" size={34} /><p className="mt-3 font-myanmar text-sm font-bold text-slate-500">{mm ? "မှတ်တမ်းမရှိသေးပါ" : "No notes yet"}</p></div>}
          {notes.map((item) => <article key={item.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3"><div className="min-w-0 flex-1">{item.numbers && <p className="break-words text-2xl font-black tracking-widest text-violet-700">{item.numbers}</p>}{item.note && <p className="mt-2 whitespace-pre-wrap break-words font-myanmar text-sm leading-6 text-slate-700">{item.note}</p>}<p className="mt-3 flex items-center gap-1 font-myanmar text-[10px] text-slate-400"><CalendarDays size={12} />{item.noteDate} · {mm ? "၁ နှစ်အတွင်း အလိုအလျောက်ဖျက်မည်" : "Expires after one year"}</p></div><div className="flex gap-1"><button onClick={() => startEdit(item)} className="rounded-lg bg-violet-50 p-2 text-violet-600 btn-press" aria-label="Edit"><Pencil size={15} /></button><button onClick={() => remove(item.id)} className="rounded-lg bg-red-50 p-2 text-red-600 btn-press" aria-label="Delete"><Trash2 size={15} /></button></div></div>
          </article>)}
        </section>
      </main>
    </div>
  );
}
