import { useState, useRef, useEffect, useCallback } from "react";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, Volume2, VolumeX, Star, Sparkles, Calendar, Crown, Clock } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getMyanmarYearInfo } from "@/lib/myanmarCalendar";

// Generate or retrieve stable device ID for guest users
function getDeviceId(): string {
  try {
    let id = localStorage.getItem("mahaboke_device_id");
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem("mahaboke_device_id", id);
    }
    return id;
  } catch {
    return "unknown";
  }
}

const MONTHS_MM = ["ဇန်နဝါရီ","ဖေဖော်ဝါရီ","မတ်","ဧပြီ","မေ","ဇွန်","ဇူလိုင်","သြဂုတ်","စက်တင်ဘာ","အောက်တိုဘာ","နိုဝင်ဘာ","ဒီဇင်ဘာ"];
const MONTHS_EN = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const MONTHS_TH = ["มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม"];

// Myanmar calendar months (traditional names)
const MYANMAR_MONTHS = [
  "တန်ခူးလ", "ကဆုန်လ", "နယုန်လ", "ဝါဆိုလ",
  "ဝါခေါင်လ", "တော်သလင်းလ", "သီတင်းကျွတ်လ", "တန်ဆောင်မုန်းလ",
  "နတ်တော်လ", "ပြာသိုလ", "တပို့တွဲလ", "တပေါင်းလ"
];
const MYANMAR_MONTHS_EN = [
  "Tagu", "Kason", "Nayon", "Waso",
  "Wagaung", "Tawthalin", "Thadingyut", "Tazaungmon",
  "Nadaw", "Pyatho", "Tabodwe", "Tabaung"
];

const WEEKDAY_ICONS: Record<string, string> = {
  "ဂဠုန်": "🦅", "Garuda": "🦅", "ครุฑ": "🦅",
  "ကျားသစ်": "🐯", "Tiger": "🐯", "เสือ": "🐯",
  "ခြင်္သေ့": "🦁", "Lion": "🦁", "สิงโต": "🦁",
  "ဆင်": "🐘", "Elephant": "🐘", "ช้าง": "🐘",
  "ကြွက်": "🐀", "Rat": "🐀", "หนู": "🐀",
  "ကြိုး": "🐹", "Guinea Pig": "🐹", "หนูตะเภา": "🐹",
  "နဂါး": "🐉", "Dragon": "🐉", "มังกร": "🐉",
};

// Weekday names for each language
const WEEKDAYS_MM = ["တနင်္ဂနွေ", "တနင်္လာ", "အင်္ဂါ", "ဗုဒ္ဓဟူး", "ကြာသပတေး", "သောကြာ", "စနေ"];
const WEEKDAYS_EN = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const WEEKDAYS_TH = ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"];

function getWeekdayName(day: number, month: number, year: number, lang: string): string {
  const d = new Date(year, month - 1, day);
  const wd = d.getDay();
  if (lang === "mm") return WEEKDAYS_MM[wd];
  if (lang === "th") return WEEKDAYS_TH[wd];
  return WEEKDAYS_EN[wd];
}

function getIcon(name: string) {
  for (const key of Object.keys(WEEKDAY_ICONS)) {
    if (name?.includes(key)) return WEEKDAY_ICONS[key];
  }
  return "⭐";
}

function getWeekLabel(): string {
  const now = new Date();
  const day = now.getDay();
  const diff = now.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(now.setDate(diff));
  const nextSunday = new Date(monday);
  nextSunday.setDate(monday.getDate() + 6);
  const mmMonths = ["ဇန်","ဖေ","မတ်","ဧပြီ","မေ","ဇွန်","ဇူလိုင်","သြဂုတ်","စက်","အောက်","နိုဝင်","ဒီဇင်"];
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const thMonths = ["ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค."];
  const m1 = monday.getMonth();
  const m2 = nextSunday.getMonth();
  if (m1 === m2) {
    return `${mmMonths[m1]} ${monday.getDate()} - ${nextSunday.getDate()}, ${monday.getFullYear()}`;
  }
  return `${mmMonths[m1]} ${monday.getDate()} - ${months[m2]} ${nextSunday.getDate()}`;
}

export default function Mahaboke() {
  const { lang, t } = useLang();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [speaking, setSpeaking] = useState(false);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);
  const speechRunRef = useRef(0);
  const [isUpdating, setIsUpdating] = useState(false);

  // Birth date state
  const today = new Date();
  const [birthDay, setBirthDay] = useState<number>(1);
  const [birthMonth, setBirthMonth] = useState<number>(1);
  const [birthYear, setBirthYear] = useState<number>(1990);

  const [result, setResult] = useState<any>(null);
  const requestKeyRef = useRef<string>("");

  const mahabokeMutation = trpc.mahaboke.getWeekly.useMutation({
    onSuccess: (data) => {
      // Only update if this response matches the latest request
      const currentKey = `${birthDay}-${birthMonth}-${birthYear}`;
      if (requestKeyRef.current === currentKey) {
        setResult(data);
        setIsUpdating(false);
      }
    },
    onError: (e) => {
      const currentKey = `${birthDay}-${birthMonth}-${birthYear}`;
      if (requestKeyRef.current === currentKey) {
        toast.error(t("loading") + " — " + e.message);
        setIsUpdating(false);
      }
    },
  });

  // Days in selected month
  const daysInMonth = new Date(birthYear, birthMonth, 0).getDate();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const years = Array.from({ length: today.getFullYear() - 1900 + 1 }, (_, i) => today.getFullYear() - i);

  // Gregorian year list (for dropdown) — use AD years internally
  const gregorianYears = Array.from({ length: 100 }, (_, i) => today.getFullYear() - i);

  // Day name in Myanmar
  const DAYS_MM = ["", "၁", "၂", "၃", "၄", "၅", "၆", "၇", "၈", "၉", "၁၀",
    "၁၁", "၁၂", "၁၃", "၁၄", "၁၅", "၁၆", "၁၇", "၁၈", "၁၉", "၂၀",
    "၂၁", "၂၂", "၂၃", "၂၄", "၂၅", "၂၆", "၂၇", "၂၈", "၂၉", "၃၀", "၃၁"];

  // Debounced fetch when date changes
  const fetchReading = useCallback(() => {
    if (birthDay > daysInMonth) return;
    const key = `${birthDay}-${birthMonth}-${birthYear}`;
    requestKeyRef.current = key;
    setIsUpdating(true);
    mahabokeMutation.mutate({ birthDay, birthMonth, birthYear, deviceId: getDeviceId() });
  }, [birthDay, birthMonth, birthYear, daysInMonth]);

  function speakResult() {
    if (!result) return;
    if (!("speechSynthesis" in window)) {
      toast.error(lang === "mm" ? "ဤဖုန်းတွင်အသံဖွင့်နားထောင်စနစ်မရရှိပါ" : lang === "th" ? "โทรศัพท์นี้ไม่รองรับการอ่านออกเสียง" : "Speech playback is not available on this device");
      return;
    }
    if (speaking) {
      speechRunRef.current += 1;
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }

    const reading = lang === "mm"
      ? {
        locale: "my-MM",
        noVoiceMessage: "ဤဖုန်းတွင် မြန်မာအသံ (Myanmar voice) မရှိသေးပါ။ ဖုန်း၏ Text-to-Speech settings တွင် Myanmar ကိုထည့်သွင်းပြီးမှ ပြန်နားထောင်ပါ။",
        sections: [
          `${result.birthDayNameMm} ဖွားအတွက် မဟာဘုတ် ဟောကိန်းကို ဖတ်ပြပါမည်။`,
          `ကိုယ်ရည်ကိုယ်သွေး။ ${result.personalityMm}`,
          `အချစ်ရေး။ ${result.loveMm}`,
          `အလုပ်ကိစ္စ။ ${result.careerMm}`,
          `ကျန်းမာရေး။ ${result.healthMm}`,
          `ငွေကြေး။ ${result.financeMm}`,
          result.familyMm ? `မိသားစု။ ${result.familyMm}` : "",
          result.educationMm ? `ပညာရေး။ ${result.educationMm}` : "",
          result.travelMm ? `ခရီးသွားခြင်း။ ${result.travelMm}` : "",
          result.spiritualMm ? `ဝိညာဉ်ရေး။ ${result.spiritualMm}` : "",
          `ကံကောင်းအရောင်။ ${result.luckyColorMm}`,
          `ကံကောင်းရာအရပ်။ ${result.luckyDirectionMm}`,
          `ကံကောင်းနေ့။ ${result.luckyDayMm}`,
          result.lucky2dNumbers?.length ? `ကံကောင်း 2D ဂဏန်း။ ${result.lucky2dNumbers.join(", ")}` : "",
          result.luckyLotteryNumbers?.length ? `ကံကောင်းထီဂဏန်း။ ${result.luckyLotteryNumbers.join(", ")}` : "",
          `တစ်ပတ်စာအကြံပြုချက်။ ${result.weeklyMessageMm}`,
        ],
      }
      : lang === "th"
        ? {
          locale: "th-TH",
          noVoiceMessage: "โทรศัพท์นี้ยังไม่มีเสียงภาษาไทย โปรดเพิ่ม Thai ในการตั้งค่า Text-to-Speech แล้วลองใหม่",
          sections: [
            `คำทำนายมหาบุรุษสำหรับผู้ที่เกิด ${result.birthDayNameEn}`,
            result.personalityTh ? `ลักษณะนิสัย ${result.personalityTh}` : "",
            result.loveTh ? `ความรัก ${result.loveTh}` : "",
            result.careerTh ? `การงาน ${result.careerTh}` : "",
            result.healthTh ? `สุขภาพ ${result.healthTh}` : "",
            result.financeTh ? `การเงิน ${result.financeTh}` : "",
            result.familyTh ? `ครอบครัว ${result.familyTh}` : "",
            result.educationTh ? `การศึกษา ${result.educationTh}` : "",
            result.travelTh ? `การเดินทาง ${result.travelTh}` : "",
            result.spiritualTh ? `จิตวิญญาณ ${result.spiritualTh}` : "",
            result.luckyColorTh ? `สีนำโชค ${result.luckyColorTh}` : "",
            result.luckyDirectionTh ? `ทิศนำโชค ${result.luckyDirectionTh}` : "",
            result.luckyDayTh ? `วันนำโชค ${result.luckyDayTh}` : "",
            result.lucky2dNumbers?.length ? `เลข 2D นำโชค ${result.lucky2dNumbers.join(", ")}` : "",
            result.luckyLotteryNumbers?.length ? `เลขสลากนำโชค ${result.luckyLotteryNumbers.join(", ")}` : "",
            result.weeklyMessageTh ? `คำแนะนำประจำสัปดาห์ ${result.weeklyMessageTh}` : "",
          ],
        }
        : {
          locale: "en-US",
          noVoiceMessage: "This device does not have an English speech voice available.",
          sections: [
            `Mahaboke reading for someone born on ${result.birthDayNameEn}.`,
            `Personality. ${result.personalityEn}`,
            `Love. ${result.loveEn}`,
            `Career. ${result.careerEn}`,
            `Health. ${result.healthEn}`,
            `Finance. ${result.financeEn}`,
            result.familyEn ? `Family. ${result.familyEn}` : "",
            result.educationEn ? `Education. ${result.educationEn}` : "",
            result.travelEn ? `Travel. ${result.travelEn}` : "",
            result.spiritualEn ? `Spiritual. ${result.spiritualEn}` : "",
            `Lucky color. ${result.luckyColor}`,
            `Lucky direction. ${result.luckyDirection}`,
            `Lucky day. ${result.luckyDay}`,
            result.lucky2dNumbers?.length ? `Lucky 2D numbers. ${result.lucky2dNumbers.join(", ")}` : "",
            result.luckyLotteryNumbers?.length ? `Lucky lottery numbers. ${result.luckyLotteryNumbers.join(", ")}` : "",
            `Weekly guidance. ${result.weeklyMessageEn}`,
          ],
        };

    const languageCode = reading.locale.split("-")[0].toLowerCase();
    const voices = window.speechSynthesis.getVoices();
    const matchingVoice = voices.find((voice) => voice.lang.toLowerCase() === reading.locale.toLowerCase())
      ?? voices.find((voice) => voice.lang.toLowerCase().startsWith(`${languageCode}-`))
      ?? (lang === "mm" ? voices.find((voice) => /myanmar|burmese/i.test(voice.name)) : undefined);

    // Do not let a random English voice misread Myanmar or Thai answers.
    if (!matchingVoice) {
      toast.error(reading.noVoiceMessage, { duration: 7000 });
      return;
    }

    const sections = reading.sections.filter((section) => typeof section === "string" && section.trim());
    if (!sections.length) return;

    window.speechSynthesis.cancel();
    const currentRun = speechRunRef.current + 1;
    speechRunRef.current = currentRun;

    const speakNextSection = (index: number) => {
      if (speechRunRef.current !== currentRun) return;
      if (index >= sections.length) {
        setSpeaking(false);
        return;
      }

      const utt = new SpeechSynthesisUtterance(sections[index]);
      utt.lang = matchingVoice.lang;
      utt.voice = matchingVoice;
      utt.rate = 0.9;
      utt.onend = () => speakNextSection(index + 1);
      utt.onerror = () => {
        if (speechRunRef.current === currentRun) setSpeaking(false);
      };
      synthRef.current = utt;
      window.speechSynthesis.speak(utt);
    };

    setSpeaking(true);
    speakNextSection(0);
  }

  const selectClass = "bg-white border border-gray-200 rounded-xl px-3 py-2.5 text-sm font-myanmar text-[#333] focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-200 transition-all appearance-none cursor-pointer";

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/")} className="text-[#333] btn-press"><ArrowLeft size={20} /></button>
          <div className="flex-1">
            <h1 className="font-display text-base font-bold text-[#333] font-myanmar">
              {t("navMahaboke")} {t("horoscope")}
            </h1>
            <p className="text-[10px] text-amber-700/70 font-myanmar flex items-center gap-1">
              <Clock size={10} />
              {getWeekLabel()}
            </p>
          </div>
          <div className="flex items-center gap-1 text-amber-600/60">
            <Crown size={14} />
          </div>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 py-4 space-y-4">

        {/* Weekly badge */}
        <div className="bg-gradient-to-r from-amber-500 to-amber-400 rounded-xl px-4 py-2.5 flex items-center gap-2 shadow-sm animate-fade-in-up">
          <Sparkles size={16} className="text-white" />
          <p className="text-sm font-bold text-white font-myanmar">
            {t("horoTitle")}
          </p>
          <span className="ml-auto text-[10px] text-white/80 font-myanmar">
            {t("monday")} ~ {t("sunday")}
          </span>
        </div>

        {/* Birth date input card */}
        <div className="bg-white rounded-xl p-4 shadow-sm animate-fade-in-up">
          <div className="flex items-center gap-2 mb-3">
            <Calendar size={16} className="text-amber-600" />
            <p className="text-sm font-bold text-amber-600 font-myanmar">
              {t("birthDay")} {t("enterTicket").replace("လက်မှတ်နံပါတ် ၆ လုံး ထည့်ပါ", "").replace("Enter 6-digit ticket number", "").replace("ใส่หมายเลขสลาก 6 หลัก", "")}
            </p>
          </div>
          <p className="text-xs text-muted-foreground font-myanmar mb-4">
            {t("selectBirthDay")}
          </p>

          {/* Day / Month / Year selectors */}
          {/* Myanmar Year Display */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl px-3 py-2.5 mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-base">🏛️</span>
              <div>
                <p className="text-[10px] text-amber-600/70 font-myanmar">
                  {t("year")}
                </p>
                <p className="text-sm font-bold text-amber-700 font-myanmar">
                  AD {birthYear} / မြန်မာ {birthYear - 638}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-amber-600/70 font-myanmar">
                {t("horoscope")}
              </p>
              <p className="text-sm font-bold text-amber-700 font-myanmar">
                {lang === "mm" ? getMyanmarYearInfo(birthYear).cycleMm : getMyanmarYearInfo(birthYear).cycle}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 mb-4">
            {/* Day */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-amber-600/70 font-myanmar">
                {lang === "mm" ? "ရက်" : lang === "th" ? "วัน" : "Day"}
              </label>
              <select
                value={birthDay}
                onChange={e => setBirthDay(Number(e.target.value))}
                className={selectClass}
              >
                {days.map(d => (
                  <option key={d} value={d}>
                    {getWeekdayName(d, birthMonth, birthYear, lang)}
                  </option>
                ))}
              </select>
            </div>
            {/* Month — Myanmar month names */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-amber-600/70 font-myanmar">
                {lang === "mm" ? "လ" : lang === "th" ? "เดือน" : "Month"}
              </label>
              <select
                value={birthMonth}
                onChange={e => setBirthMonth(Number(e.target.value))}
                className={selectClass}
              >
                {months.map(m => (
                  <option key={m} value={m}>
                    {lang === "mm" ? `${MYANMAR_MONTHS[m - 1]} / ${MONTHS_EN[m - 1]}` : lang === "th" ? `${MONTHS_TH[m - 1]} / ${MONTHS_EN[m - 1]}` : `${MONTHS_EN[m - 1]} / ${MYANMAR_MONTHS[m - 1]}`}
                  </option>
                ))}
              </select>
            </div>
            {/* Year — shows both AD and Myanmar year */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-amber-600/70 font-myanmar">
                {lang === "mm" ? "ခုနှစ်" : lang === "th" ? "ปี" : "Year"}
              </label>
              <select
                value={birthYear}
                onChange={e => setBirthYear(Number(e.target.value))}
                className={selectClass}
              >
                {gregorianYears.map(y => (
                  <option key={y} value={y}>
                    {lang === "mm" ? `AD ${y} / မြန်မာ ${y - 638}` : lang === "th" ? `ค.ศ. ${y}` : `${y}`}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {isUpdating && (
            <div className="flex items-center justify-center gap-2 py-2 text-amber-600">
              <span className="animate-spin">✨</span>
              <span className="text-sm font-myanmar">{t("loading")}</span>
            </div>
          )}

          {/* View Mahaboke button */}
          <button
            onClick={fetchReading}
            disabled={isUpdating}
            className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-3 px-4 rounded-xl shadow-md transition-all btn-press disabled:opacity-50 disabled:cursor-not-allowed font-myanmar flex items-center justify-center gap-2"
          >
            <Crown size={18} />
            {lang === "mm" ? "မဟာဘုတ် ကြည့်ရန်" : lang === "th" ? "ดูมหาบุตร" : "View Mahaboke"}
          </button>

        </div>

        {/* Result */}
        {result && (
          <div className="space-y-3 animate-fade-in-up">

            {/* Cache indicator */}
            {result.isCached && (
              <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-2.5 flex items-center gap-2">
                <Clock size={14} className="text-blue-500" />
                <p className="text-xs text-blue-700 font-myanmar">
                  {t("horoTitle")} — {t("updated")}
                </p>
              </div>
            )}

            {/* Header card */}
            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{getIcon(lang === "mm" ? result.birthDayNameMm : result.birthDayNameEn)}</span>
                  <div>
                    <p className="text-base font-bold text-amber-600 font-myanmar">
                      {lang === "mm" ? result.birthDayNameMm : lang === "th" ? result.birthDayNameEn.replace("Sunday", "วันอาทิตย์").replace("Monday", "วันจันทร์").replace("Tuesday", "วันอังคาร").replace("Wednesday", "วันพุธ").replace("Thursday", "วันพฤหัสบดี").replace("Friday", "วันศุกร์").replace("Saturday", "วันเสาร์") : result.birthDayNameEn}
                      {lang === "mm" ? "ဖွား" : lang === "th" ? " เกิด" : " Born"}
                    </p>
                    {/* Myanmar Year Badge */}
                    <p className="text-[10px] text-amber-600 font-myanmar mt-0.5">
                      {lang === "mm" ? `AD ${birthYear} / မြန်မာ ${birthYear - 638} · ${getMyanmarYearInfo(birthYear).cycleMm}` : lang === "th" ? `ค.ศ. ${birthYear} · ${getMyanmarYearInfo(birthYear).cycle}` : `${getMyanmarYearInfo(birthYear).cycle} · AD ${birthYear} / Myanmar ${birthYear - 638}`}
                    </p>
                    <p className="text-xs text-muted-foreground font-myanmar">
                      {lang === "mm" ? result.rulingPlanetMm : lang === "th" ? result.rulingPlanetEn.replace("Sun", "พระอาทิตย์").replace("Moon", "พระจันทร์").replace("Mars", "พระอังคาร").replace("Mercury", "พระพุธ").replace("Jupiter", "พระพฤหัสบดี").replace("Venus", "พระศุกร์").replace("Saturn", "พระเสาร์") : result.rulingPlanetEn}
                    </p>
                    <div className="flex mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} size={12} className={i < (result.overallFortune ?? 3) ? "text-yellow-400" : "text-muted-foreground/30"} fill="currentColor" />
                      ))}
                    </div>
                  </div>
                </div>
                <button
                  onClick={speakResult}
                  className={`p-2 rounded-xl transition-all btn-press ${speaking ? "bg-amber-100 text-amber-600" : "bg-white text-amber-600 border border-gray-200"}`}
                >
                  {speaking ? <VolumeX size={18} /> : <Volume2 size={18} />}
                </button>
              </div>
              <p className="text-sm text-foreground/90 font-myanmar leading-relaxed">
                {lang === "mm" ? result.personalityMm : lang === "th" ? (result.personalityTh || result.personalityEn) : result.personalityEn}
              </p>
            </div>

            {/* Weekly fortune */}
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <p className="text-xs text-amber-600/70 font-myanmar font-bold mb-3 uppercase tracking-widest">
                {t("horoTitle")}
              </p>
              <div className="space-y-3">
                {[
                  { icon: "❤️", label: lang === "mm" ? "အချစ်ရေး" : lang === "th" ? "ความรัก" : "Love", text: lang === "mm" ? result.loveMm : lang === "th" ? (result.loveTh || result.loveEn) : result.loveEn },
                  { icon: "💼", label: lang === "mm" ? "အလုပ်ကိစ္စ" : lang === "th" ? "การงาน" : "Career", text: lang === "mm" ? result.careerMm : lang === "th" ? (result.careerTh || result.careerEn) : result.careerEn },
                  { icon: "💚", label: lang === "mm" ? "ကျန်းမာရေး" : lang === "th" ? "สุขภาพ" : "Health", text: lang === "mm" ? result.healthMm : lang === "th" ? (result.healthTh || result.healthEn) : result.healthEn },
                  { icon: "💰", label: lang === "mm" ? "ငွေကြေး" : lang === "th" ? "การเงิน" : "Finance", text: lang === "mm" ? result.financeMm : lang === "th" ? (result.financeTh || result.financeEn) : result.financeEn },
                  { icon: "👨‍👩‍👧", label: lang === "mm" ? "မိသားစု" : lang === "th" ? "ครอบครัว" : "Family", text: lang === "mm" ? (result.familyMm || "") : lang === "th" ? (result.familyTh || result.familyEn || "") : (result.familyEn || "") },
                  { icon: "📚", label: lang === "mm" ? "ပညာရေး" : lang === "th" ? "การศึกษา" : "Education", text: lang === "mm" ? (result.educationMm || "") : lang === "th" ? (result.educationTh || result.educationEn || "") : (result.educationEn || "") },
                  { icon: "✈️", label: lang === "mm" ? "ခရီးသွား" : lang === "th" ? "การเดินทาง" : "Travel", text: lang === "mm" ? (result.travelMm || "") : lang === "th" ? (result.travelTh || result.travelEn || "") : (result.travelEn || "") },
                  { icon: "🙏", label: lang === "mm" ? "ဝိညာဉ်ရေး" : lang === "th" ? "จิตวิญญาณ" : "Spiritual", text: lang === "mm" ? (result.spiritualMm || "") : lang === "th" ? (result.spiritualTh || result.spiritualEn || "") : (result.spiritualEn || "") },
                ].filter(row => row.text).map(row => (
                  <div key={row.label} className="flex gap-3 py-2 border-b border-amber-100 last:border-0">
                    <span className="text-lg mt-0.5">{row.icon}</span>
                    <div>
                      <p className="text-[10px] text-amber-600/70 font-myanmar font-bold mb-0.5">{row.label}</p>
                      <p className="text-sm text-foreground/85 font-myanmar leading-relaxed">{row.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Lucky info */}
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-white rounded-xl p-3 shadow-sm">
                <p className="text-[10px] text-muted-foreground font-myanmar mb-1">{t("luckyColor")}</p>
                <p className="text-sm font-bold text-amber-600 font-myanmar">{lang === "mm" ? result.luckyColorMm : lang === "th" ? (result.luckyColorTh || result.luckyColor) : result.luckyColor}</p>
              </div>
              <div className="bg-white rounded-xl p-3 shadow-sm">
                <p className="text-[10px] text-muted-foreground font-myanmar mb-1">{t("luckyDirection")}</p>
                <p className="text-sm font-bold text-amber-600 font-myanmar">{lang === "mm" ? result.luckyDirectionMm : lang === "th" ? (result.luckyDirectionTh || result.luckyDirection) : result.luckyDirection}</p>
              </div>
              <div className="bg-white rounded-xl p-3 shadow-sm">
                <p className="text-[10px] text-muted-foreground font-myanmar mb-1">{t("luckyDay")}</p>
                <p className="text-sm font-bold text-amber-600 font-myanmar">{lang === "mm" ? result.luckyDayMm : lang === "th" ? (result.luckyDayTh || result.luckyDay) : result.luckyDay}</p>
              </div>
              <div className="bg-white rounded-xl p-3 shadow-sm">
                <p className="text-[10px] text-muted-foreground font-myanmar mb-1">{t("numbers2D")}</p>
                <div className="flex gap-1 flex-wrap">
                  {result.lucky2dNumbers?.slice(0, 3).map((n: string) => (
                    <span key={n} className="prize-number text-sm font-bold text-emerald-400">{n}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Lottery numbers */}
            {result.luckyLotteryNumbers?.length > 0 && (
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
                <p className="text-[10px] text-amber-600/70 font-myanmar mb-2">{t("lotteryNums")}</p>
                <div className="flex flex-wrap gap-2">
                  {result.luckyLotteryNumbers.map((n: string) => (
                    <span key={n} className="prize-number text-base font-bold text-amber-600 bg-amber-50 px-3 py-1.5 rounded-xl border border-gray-200">{n}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Weekly message */}
            <div className="bg-white rounded-xl p-4 shadow-sm border border-purple-500/20 bg-purple-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles size={14} className="text-purple-400" />
                <p className="text-[10px] text-purple-400/80 font-myanmar font-bold uppercase tracking-widest">
                  {t("horoTitle")}
                </p>
              </div>
              <p className="text-sm text-foreground/90 font-myanmar leading-relaxed italic">
                {lang === "mm" ? result.weeklyMessageMm : lang === "th" ? (result.weeklyMessageTh || result.weeklyMessageEn) : result.weeklyMessageEn}
              </p>
            </div>

            {/* Ask again — change birth date to get new reading (but same birth day = same result this week) */}
            <button
              onClick={() => {
                // Clear birth date to force user to re-enter, but keep current result visible until new birth date is entered
                setResult(null);
              }}
              className="w-full bg-white text-amber-600 font-myanmar text-sm py-2.5 rounded-xl btn-press"
            >
              {t("tryAgain")}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
