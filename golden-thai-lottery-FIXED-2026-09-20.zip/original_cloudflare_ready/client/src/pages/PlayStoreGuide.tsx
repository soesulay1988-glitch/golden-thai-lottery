import { useLang } from "@/contexts/LangContext";
import { useLocation } from "wouter";
import {
  CheckCircle, Circle, ExternalLink, Copy, Check, ArrowLeft,
  Shield, Smartphone, Upload, FileText, Image, DollarSign,
  Globe, Package, Settings, ChevronRight
} from "lucide-react";
import { useState } from "react";

const APP_URL = "https://golden-thai-lottery-web.pages.dev/";
const PRIVACY_URL = `${APP_URL}privacy`;

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  return (
    <button
      onClick={copy}
      className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-amber-50 hover:bg-amber-100 border border-amber-200 transition-all btn-press"
    >
      {copied ? (
        <Check size={14} className="text-green-600" />
      ) : (
        <Copy size={14} className="text-amber-600" />
      )}
      <span className="text-xs font-medium text-amber-700">
        {copied ? "ကူးပြီးပြီ" : "Copy"}
      </span>
    </button>
  );
}

function StepCard({ number, icon: Icon, title, children }: {
  number: number; icon: typeof Shield; title: string; children: React.ReactNode;
}) {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-amber-100 overflow-hidden animate-fade-in-up">
      <div className="bg-gradient-to-r from-[#FFD700] to-[#FFB300] px-4 py-3 flex items-center gap-3">
        <span className="w-8 h-8 rounded-full bg-white/90 text-[#8B6914] text-sm font-bold flex items-center justify-center shadow-sm">
          {number}
        </span>
        <Icon size={18} className="text-white" />
        <h2 className="font-bold text-white text-sm">{title}</h2>
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}

export default function PlayStoreGuide() {
  const { lang } = useLang();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-[#FFF8E1] pb-28">
      {/* Header */}
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/profile")} className="text-[#333] btn-press">
            <ArrowLeft size={20} />
          </button>
          <h1 className="font-display text-base font-bold text-[#333] flex-1">
            {lang === "mm" ? "Play Store လမ်းညွှန်" : "Play Store Guide"}
          </h1>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 py-5 space-y-4">
        {/* Intro */}
        <div className="bg-gradient-to-br from-[#FFD700] to-[#FFB300] rounded-2xl p-5 shadow-lg text-center">
          <Package size={36} className="mx-auto mb-2 text-white" />
          <h2 className="text-lg font-bold text-white">
            {lang === "mm" ? "Google Play Store တင်ရန် အဆင့်ဆင့် လမ်းညွှန်" : "Google Play Store Submission Guide"}
          </h2>
          <p className="text-xs text-white/80 mt-1">
            {lang === "mm"
              ? "Golden Thai Lottery & 2D app ကို Play Store မှာ တင်ရန် လိုအပ်သော အဆင့်များ"
              : "Everything you need to publish Golden Thai Lottery & 2D on Google Play Store"}
          </p>
        </div>

        {/* Step 1: App Info */}
        <StepCard number={1} icon={Globe} title={lang === "mm" ? "App URL & နာမည်" : "App Info & URLs"}>
          <div className="space-y-3">
            <div>
              <p className="text-xs text-gray-500 mb-1">App URL</p>
              <div className="flex items-center gap-2 bg-gray-50 rounded-lg p-2.5 font-mono text-xs">
                <span className="text-gray-700 flex-1 break-all">{APP_URL}</span>
                <CopyButton text={APP_URL} />
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1">Privacy Policy URL</p>
              <div className="flex items-center gap-2 bg-gray-50 rounded-lg p-2.5 font-mono text-xs">
                <span className="text-gray-700 flex-1 break-all">{PRIVACY_URL}</span>
                <CopyButton text={PRIVACY_URL} />
              </div>
            </div>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <p className="text-xs text-yellow-800 font-medium">
                {lang === "mm"
                  ? "⚠️ အရေးကြီး — Management UI → Settings → Visibility ကို \"Public\" သို့ ပြောင်းပါ"
                  : "⚠️ Important — Change visibility to \"Public\" in Management UI → Settings"}
              </p>
            </div>
          </div>
        </StepCard>

        {/* Step 2: PWABuilder */}
        <StepCard number={2} icon={Package} title={lang === "mm" ? "APK/AAB ဖန်တီးရန်" : "Generate Android Package"}>
          <ol className="space-y-3 text-sm text-gray-700">
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">1</span>
              <span>
                {lang === "mm" ? "PWABuilder သို့ ဝင်ပါ" : "Go to PWABuilder"}:{" "}
                <a href="https://www.pwabuilder.com/" target="_blank" rel="noopener noreferrer" className="text-amber-600 underline inline-flex items-center gap-1">
                  pwabuilder.com <ExternalLink size={10} />
                </a>
              </span>
            </li>
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">2</span>
              <span>
                {lang === "mm" ? "App URL ထည့်ပြီး \"Start\" နှိပ်ပါ" : "Enter your App URL and click \"Start\""}
              </span>
            </li>
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">3</span>
              <span>
                {lang === "mm" ? "Score 100 ရပြီဆိုရင် \"Package For Stores\" → \"Android\" → .aab download" : "When score reaches 100, click \"Package For Stores\" → \"Android\" → Download .aab"}
              </span>
            </li>
          </ol>
          <div className="mt-3 bg-blue-50 border border-blue-200 rounded-lg p-2.5">
            <p className="text-xs text-blue-800">
              {lang === "mm"
                ? "💡 အကယ်၍ PWABuilder မှ .aab မရရင် Android Studio + Bubblewrap (TWA) method ကို အသုံးပြုပါ"
                : "💡 If PWABuilder doesn't generate .aab, use Android Studio + Bubblewrap (TWA) method instead"}
            </p>
          </div>
        </StepCard>

        {/* Step 3: TWA via Android Studio */}
        <StepCard number={3} icon={Smartphone} title={lang === "mm" ? "Android Studio ဖြင့် AAB ဖန်တီးရန်" : "Generate AAB via Android Studio"}>
          <div className="space-y-2 text-sm text-gray-700">
            <p className="font-medium text-gray-800">
              {lang === "mm" ? "TWA (Trusted Web Activity) method:" : "TWA (Trusted Web Activity) method:"}
            </p>
            <ol className="space-y-2 text-xs">
              <li className="flex gap-2">
                <ChevronRight size={12} className="text-amber-500 shrink-0 mt-0.5" />
                <span>
                  {lang === "mm" ? "Android Studio install လုပ်ပါ" : "Install Android Studio"}
                </span>
              </li>
              <li className="flex gap-2">
                <ChevronRight size={12} className="text-amber-500 shrink-0 mt-0.5" />
                <span>
                  {lang === "mm" ? "Terminal မှာ run လုပ်ပါ:" : "Run in terminal:"}
                </span>
              </li>
            </ol>
            <div className="bg-gray-900 rounded-lg p-3 overflow-x-auto">
              <pre className="text-green-400 text-[11px] whitespace-pre">{`npx @nicolo-ribaudo/bubblewrap@latest init
npx @nicolo-ribaudo/bubblewrap@latest build`}</pre>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {lang === "mm"
                ? "bubblewrap init လုပ်စဥ်မှာ package name ကို com.goldenthailottery.app ထည့်ပါ"
                : "When running bubblewrap init, use package name: com.goldenthailottery.app"}
            </p>
          </div>
        </StepCard>

        {/* Step 4: Asset Links */}
        <StepCard number={4} icon={Shield} title="Digital Asset Links">
          <p className="text-xs text-gray-600 mb-2">
            {lang === "mm"
              ? "TWA အဖြစ် လုပ်ဆောင်ရန် assetlinks.json ကို hosting နှင့် SHA-256 fingerprint ထည့်ရပါမယ်:"
              : "For TWA to work, host assetlinks.json with your SHA-256 fingerprint:"}
          </p>
          <p className="text-[10px] font-mono bg-gray-50 p-2 rounded text-gray-500 break-all">
            {APP_URL}.well-known/assetlinks.json
          </p>
          <div className="mt-2 bg-gray-900 rounded-lg p-3 overflow-x-auto">
            <pre className="text-green-400 text-[10px] whitespace-pre">{`[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "com.goldenthailottery.app",
    "sha256_cert_fingerprints": ["YOUR_SHA256_HERE"]
  }
}]`}</pre>
          </div>
          <p className="text-[10px] text-gray-400 mt-2">
            {lang === "mm"
              ? "SHA-256 ကို Play Console → App signing → Certificate fingerprint မှ ရယူပါ"
              : "Get SHA-256 from Play Console → App signing → Certificate fingerprint"}
          </p>
        </StepCard>

        {/* Step 5: Play Console */}
        <StepCard number={5} icon={Upload} title={lang === "mm" ? "Google Play Console တင်ရန်" : "Submit to Google Play Console"}>
          <ol className="space-y-3 text-xs text-gray-700">
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">1</span>
              <span>
                <a href="https://play.google.com/console/" target="_blank" rel="noopener noreferrer" className="text-amber-600 underline inline-flex items-center gap-1">
                  play.google.com/console <ExternalLink size={10} />
                </a>{" "}
                {lang === "mm" ? "သို့ login ဝင်ပါ" : "— Log in"}
              </span>
            </li>
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">2</span>
              <span>
                <span className="font-medium">Create app</span>
                <br />
                <span className="text-gray-500">
                  {lang === "mm"
                    ? "နာမည်: Golden Thai Lottery & 2D | ဘာသာ: Burmese | အခမဲ့"
                    : "Name: Golden Thai Lottery & 2D | Language: Burmese | Free"}
                </span>
              </span>
            </li>
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">3</span>
              <span>
                <span className="font-medium">{lang === "mm" ? "Store listing ပြည့်စုံအောင် ဖြည့်ပါ" : "Complete Store listing"}</span>
                <br />
                <span className="text-gray-500">
                  {lang === "mm" ? "Short description: ထိုင်းလော့တာရလဒ်များ၊ မြန်မာ ၂ဒီ" : "Short: Thai lottery results, Myanmar 2D"}
                </span>
              </span>
            </li>
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">4</span>
              <span>
                <span className="font-medium">{lang === "mm" ? ".aab file upload လုပ်ပါ" : "Upload .aab file"}</span>
                <br />
                <span className="text-gray-500">Production → Create new release → Upload .aab</span>
              </span>
            </li>
            <li className="flex gap-3">
              <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">5</span>
              <span>
                <span className="font-medium">{lang === "mm" ? "Privacy Policy link ထည့်ပါ" : "Add Privacy Policy"}</span>
                <br />
                <span className="text-gray-500 break-all">{PRIVACY_URL}</span>
              </span>
            </li>
          </ol>
        </StepCard>

        {/* Step 6: Required Graphics */}
        <StepCard number={6} icon={Image} title={lang === "mm" ? "လိုအပ်သော ဓာတ်ပုံများ" : "Required Graphics"}>
          <div className="grid gap-2 text-sm">
            {[
              { en: "App Icon", mm: "App Icon", size: "512 × 512 px" },
              { en: "Feature Graphic", mm: "Feature Graphic", size: "1024 × 500 px" },
              { en: "Phone Screenshots", mm: "Phone Screenshots", size: "1080 × 1920 (min 2)" },
              { en: "Tablet Screenshots (optional)", mm: "Tablet Screenshots (ရွေးချယ်ခွင့်)", size: "1280 × 800" },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between bg-gray-50 rounded-lg p-2.5">
                <span className="text-gray-700 text-xs">{lang === "mm" ? item.mm : item.en}</span>
                <span className="text-[10px] text-gray-400 font-mono">{item.size}</span>
              </div>
            ))}
          </div>
        </StepCard>

        {/* Step 7: Content Rating */}
        <StepCard number={7} icon={FileText} title={lang === "mm" ? "Content Rating & Store Categories" : "Content Rating & Categories"}>
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-2.5">
              <span className="text-gray-700">{lang === "mm" ? "Category" : "Category"}</span>
              <span className="text-gray-800 font-medium">Entertainment</span>
            </div>
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-2.5">
              <span className="text-gray-700">{lang === "mm" ? "Age Rating" : "Age Rating"}</span>
              <span className="text-gray-800 font-medium">12+</span>
            </div>
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-2.5">
              <span className="text-gray-700">{lang === "mm" ? "Price" : "Price"}</span>
              <span className="text-gray-800 font-medium">Free</span>
            </div>
          </div>
        </StepCard>

        {/* Step 8: Fee */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl border border-blue-200 p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign size={16} className="text-blue-600" />
            <h3 className="font-bold text-blue-900 text-sm">
              {lang === "mm" ? "Google Play Developer Account" : "Google Play Developer Account"}
            </h3>
          </div>
          <p className="text-xs text-blue-800">
            {lang === "mm"
              ? "Google Play Console account ဖွင့်ရန် $25 (တစ်ကြိမ်ပေးရသော fee) လိုအပ်ပါတယ်။"
              : "A one-time fee of $25 is required to create a Google Play Developer account."}
          </p>
          <a
            href="https://play.google.com/console"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 mt-2 text-[11px] text-blue-600 underline"
          >
            play.google.com/console <ExternalLink size={10} />
          </a>
        </div>

        {/* Final Checklist */}
        <section className="bg-white rounded-2xl shadow-sm border border-amber-100 overflow-hidden">
          <div className="bg-gradient-to-r from-[#FFD700] to-[#FFB300] px-4 py-3">
            <h2 className="font-bold text-white text-sm">
              {lang === "mm" ? "နောက်ဆုံး စစ်ဆေးရန် စာရင်း" : "Final Checklist"}
            </h2>
          </div>
          <div className="p-4 space-y-1.5">
            {[
              { done: true, my: "PWA Manifest ဖွဲ့စည်းပြီး", en: "PWA Manifest configured" },
              { done: true, my: "Service Worker active", en: "Service Worker active" },
              { done: true, my: "Privacy Policy page live", en: "Privacy Policy page live" },
              { done: true, my: "Phone screenshots ပြင်ဆင်ပြီး", en: "Phone screenshots ready" },
              { done: false, my: "Visibility ကို Public ပြောင်းပြီး", en: "Visibility changed to Public" },
              { done: false, my: "PWABuilder မှ .aab file ရယူပြီး", en: ".aab file generated via PWABuilder" },
              { done: false, my: "assetlinks.json hosted (SHA-256 ထည့်ပြီး)", en: "assetlinks.json hosted (SHA-256 added)" },
              { done: false, my: "Google Play Console store listing ပြည့်စုံ", en: "Google Play Console store listing complete" },
              { done: false, my: ".aab upload လုပ်ပြီး", en: ".aab uploaded" },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 py-1.5">
                {item.done ? (
                  <CheckCircle size={16} className="text-green-500 shrink-0" />
                ) : (
                  <Circle size={16} className="text-gray-300 shrink-0" />
                )}
                <span className={`text-xs ${item.done ? "text-gray-500" : "text-gray-800 font-medium"}`}>
                  {lang === "mm" ? item.my : item.en}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
