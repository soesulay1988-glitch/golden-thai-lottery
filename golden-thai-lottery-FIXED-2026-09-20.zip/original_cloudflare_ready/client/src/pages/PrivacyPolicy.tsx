import { useLang } from "@/contexts/LangContext";
import { useLocation } from "wouter";
import { ArrowLeft, Shield, Download } from "lucide-react";

const APP_URL = "https://golden-thai-lottery-web.pages.dev/";

function HtmlSection({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="mb-5">
      <h2 className="text-base font-bold text-[#333] mb-2">{title}</h2>
      <ul className="list-disc pl-5 space-y-1 text-sm text-[#555]">
        {items.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

export default function PrivacyPolicy() {
  const { lang } = useLang();
  const [, navigate] = useLocation();

  const downloadHtml = () => {
    const html = getHtmlContent(lang);
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "privacy-policy.html";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#FFF8E1]">
      {/* Header */}
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/profile")} className="text-[#333] btn-press">
            <ArrowLeft size={20} />
          </button>
          <h1 className="font-display text-base font-bold text-[#333] flex-1">
            {lang === "mm" ? "ကိုယ်ရေးကိုယ်တာ မူဝါဒ" : "Privacy Policy"}
          </h1>
          <button
            onClick={downloadHtml}
            className="bg-white/80 text-[#333] text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 btn-press"
          >
            <Download size={12} />
            HTML
          </button>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 py-5">
        {/* Title Card */}
        <div className="bg-gradient-to-br from-[#FFD700] to-[#FFB300] rounded-2xl p-5 mb-5 shadow-lg text-center">
          <Shield size={32} className="mx-auto mb-2 text-white" />
          <h2 className="text-lg font-bold text-white">{lang === "mm" ? "ကိုယ်ရေးကိုယ်တာ မူဝါဒ" : "Privacy Policy"}</h2>
          <p className="text-xs text-white/80 mt-1">
            {lang === "mm" ? "နောက်ဆုံး ပြင်ဆင်သည့်ရက်: ဩဂုတ် ၂၀၂၆" : "Last Updated: August 2026"}
          </p>
        </div>

        {/* Content Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-amber-100 p-5">
          {lang === "mm" ? (
            <>
              <p className="text-sm text-[#555] mb-4">
                ရွှေထိုင်းလော့တာ & ၂ဒီ (Golden Thai Lottery & 2D) app ကို အသုံးပြုသောအခါ သင်၏ ကိုယ်ရေးကိုယ်တာ အချက်အလက်များကို မည်သို့ ကိုင်တွယ်ကြောင်း ကျွန်ုပ်တို့ ရှင်းပြပါမည်။
              </p>

              <HtmlSection
                title="၁။ အချက်အလက် စုဆောင်းခြင်း"
                items={[
                  "အကောင့် အချက်အလက် (အမည်၊ email) — Google login သုံးသောအခါ",
                  "ထီလက်မှတ် ဂဏန်းများ — \"My Tickets\" feature သုံးသောအခါ",
                  "Browser push notification subscription — notification ချိတ်ဆက်သောအခါ",
                  "သုံးစွဲမှု အချက်အလက် — page views, feature usage (Google Analytics)",
                  "မွေးနေ့ အချက်အလက် — horoscope နှင့် lucky number feature များအတွက်",
                  "Device information — ဘာသာစကား၊ screen size, browser type",
                ]}
              />

              <HtmlSection
                title="၂။ အချက်အလက် အသုံးပြုခြင်း"
                items={[
                  "ထီဆွဲချက် ရလဒ်များ အော်တို ပြသခြင်းနှင့် အပ်ဒိတ်လုပ်ခြင်း",
                  "ထီဆွဲချက် အသစ် ထွက်သောအခါ push notification ပေးပို့ခြင်း",
                  "My Tickets feature ဖြင့် သင်၏ လက်မှတ်များကို ဆွဲချက် ရလဒ်များနှင့် စစ်ဆေးခြင်း",
                  "AI-powered lucky number generation (3D နှင့် 2D ဂဏန်းများ)",
                  "Weekly horoscope နှင့် ဗေဒင်ဟောကိန်း ပေးပို့ခြင်း",
                  "App အသုံးပြုမှု အတွေ့အကြုံ ပိုမိုကောင်းမွန်စေရန်",
                  "Offline mode အတွက် data caching",
                ]}
              />

              <HtmlSection
                title="၃။ အချက်အလက် မျှဝေခြင်း"
                items={[
                  "သင်၏ ကိုယ်ရေးကိုယ်တာ အချက်အလက်များကို တတိယ ပါတီများသို့ ရောင်းချခြင်း သို့မဟုတ် မျှဝေခြင်း မပြုလုပ်ပါ",
                  "Google Analytics နှင့် analytics services များနှင့်သာ anonymized data မျှဝေပါသည်",
                  "ထိုင်းလော့တာ ရလဒ်များကို တရားဝင် ရင်းမြစ်များမှ ရယူပါသည်",
                  "Myanmar 2D ရလဒ်များကို SET index data မှ ရယူပါသည်",
                ]}
              />

              <HtmlSection
                title="၄။ Data Storage & Security"
                items={[
                  "သင်၏ အချက်အလက်များကို HTTPS encryption ဖြင့် ကာကွယ်ပါသည်",
                  "Database ကို encrypted connection (SSL/TLS) ဖြင့် ဆက်သွယ်ပါသည်",
                  "User passwords ကို မှတ်သားခြင်း မရှိပါ (OAuth only)",
                  "Push notification tokens ကို securely storage တွင် သိမ်းဆည်းပါသည်",
                  "Data backups ကို ပုံမှန် ရယူပါသည်",
                ]}
              />

              <HtmlSection
                title="၅။ ဘေးအန္တရာယ် ဖြည့်စွက်ချက် (Disclaimer)"
                items={[
                  "ဤ app သည် ပျော်ရွှင်မှုနှင့် အချက်အလက် ရည်ရွယ်ချက်အတွက်သာ ဖြစ်ပါသည်",
                  "AI lucky numbers များသည် ဟောကိန်းသက်သက် ဖြစ်ပြီး ဆုပေါက်မည့် အာမခံချက် မရှိပါ",
                  "ထီလက်မှတ် စစ်ဆေးမှု ရလဒ်များသည် တရားဝင် ဆုပေါက်စာရင်းနှင့် ကိုက်ညီရန် ရည်ရွယ်ပါသည်",
                  "အသက် ၁၈ နှစ်အောက် မသုံးစွဲရန် တိုက်တွန်းအပ်ပါသည်",
                ]}
              />

              <HtmlSection
                title="၆။ ကိုယ်ရေးကိုယ်တာ အခွင့်အရေးများ"
                items={[
                  "သင်၏ အချက်အလက်များကို delete လုပ်ရန် တောင်းဆိုနိုင်ပါသည်",
                  "Notification subscription ကို အချိန်မရွေး ဖျက်နိုင်ပါသည်",
                  "My Tickets data ကို app အတွင်းမှ delete လုပ်နိုင်ပါသည်",
                  "App ၏ data collection ကို disable လုပ်ရန် browser settings တွင် ပြောင်းနိုင်ပါသည်",
                ]}
              />

              <HtmlSection
                title="၇။ ဆက်သွယ်ရန်"
                items={[
                  "Privacy Policy နှင့် ပတ်သက်၍ မေးမြန်းလိုပါက ကျွန်ုပ်တို့ထံ ဆက်သွယ်ပါ",
                  "Email: support@goldenthailottery.com",
                  "Website: " + APP_URL,
                ]}
              />

              <div className="border-t border-amber-100 pt-4 mt-4">
                <p className="text-xs text-muted-foreground text-center">
                  နောက်ဆုံး ပြင်ဆင်သည့်ရက်: ဩဂုတ် ၂၀၂၆ | Golden Thai Lottery & 2D
                </p>
              </div>
            </>
          ) : (
            <>
              <p className="text-sm text-[#555] mb-4">
                This Privacy Policy explains how Golden Thai Lottery & 2D ("we", "our", or "the App") collects, uses, and protects your personal information when you use our application.
              </p>

              <HtmlSection
                title="1. Information We Collect"
                items={[
                  "Account information (name, email) — when using Google login",
                  "Lottery ticket numbers — when using \"My Tickets\" feature",
                  "Browser push notification subscriptions — when enabling notifications",
                  "Usage data — page views, feature usage (Google Analytics)",
                  "Birth date information — for horoscope and lucky number features",
                  "Device information — language, screen size, browser type",
                ]}
              />

              <HtmlSection
                title="2. How We Use Your Information"
                items={[
                  "Automatically displaying and updating lottery draw results",
                  "Sending push notifications when new lottery results are available",
                  "Checking your saved tickets against draw results (My Tickets feature)",
                  "AI-powered lucky number generation (3D and 2D numbers)",
                  "Delivering weekly horoscope readings and fortune predictions",
                  "Improving app experience and performance",
                  "Offline mode data caching for uninterrupted access",
                ]}
              />

              <HtmlSection
                title="3. Information Sharing"
                items={[
                  "We do NOT sell or share your personal information with third parties",
                  "We only share anonymized data with analytics services like Google Analytics",
                  "Thai lottery results are fetched from official authorized sources",
                  "Myanmar 2D results are obtained from SET index data",
                ]}
              />

              <HtmlSection
                title="4. Data Storage & Security"
                items={[
                  "Your information is protected with HTTPS encryption",
                  "Database connections use encrypted SSL/TLS connections",
                  "We do NOT store user passwords (OAuth authentication only)",
                  "Push notification tokens are stored securely",
                  "Regular data backups are maintained",
                ]}
              />

              <HtmlSection
                title="5. Disclaimer"
                items={[
                  "This app is for entertainment and informational purposes only",
                  "AI-generated lucky numbers are predictions only — no guarantee of winning",
                  "Ticket checking results are intended to match official winning lists",
                  "Not recommended for users under 18 years of age",
                ]}
              />

              <HtmlSection
                title="6. Your Rights"
                items={[
                  "You may request deletion of your personal data at any time",
                  "You can unsubscribe from notifications at any time",
                  "You can delete your saved ticket data within the app",
                  "You can disable data collection in your browser settings",
                ]}
              />

              <HtmlSection
                title="7. Contact Us"
                items={[
                  "If you have questions about this Privacy Policy, please contact us",
                  "Email: support@goldenthailottery.com",
                  "Website: " + APP_URL,
                ]}
              />

              <div className="border-t border-amber-100 pt-4 mt-4">
                <p className="text-xs text-muted-foreground text-center">
                  Last Updated: August 2026 | Golden Thai Lottery & 2D
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── HTML Export Generator ───────────────────────────────────────────────────
function getHtmlContent(lang: string): string {
  if (lang === "mm") {
    return `<!DOCTYPE html>
<html lang="my">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ကိုယ်ရေးကိုယ်တာ မူဝါဒ — Golden Thai Lottery & 2D</title>
<style>
body{font-family:'Noto Sans Myanmar',sans-serif;max-width:600px;margin:0 auto;padding:20px;background:#FFF8E1;color:#333;line-height:1.7}
h1{text-align:center;color:#B8860B;border-bottom:3px solid #FFD700;padding-bottom:10px}
h2{color:#8B6914;margin-top:24px;font-size:16px}
ul{padding-left:20px}
li{margin-bottom:6px;color:#555}
.header{text-align:center;background:linear-gradient(135deg,#FFD700,#FFB300);color:white;padding:20px;border-radius:12px;margin-bottom:20px}
.footer{text-align:center;color:#999;font-size:12px;margin-top:30px;padding-top:15px;border-top:1px solid #ddd}
.date{text-align:center;font-size:13px;color:#888;margin-bottom:15px}
</style>
</head>
<body>
<div class="header"><h1>ကိုယ်ရေးကိုယ်တာ မူဝါဒ</h1><p>နောက်ဆုံး ပြင်ဆင်သည့်ရက်: ဩဂုတ် ၂၀၂၆</p></div>
<p>ရွှေထိုင်းလော့တာ & ၂ဒီ (Golden Thai Lottery & 2D) app ကို အသုံးပြုသောအခါ သင်၏ ကိုယ်ရေးကိုယ်တာ အချက်အလက်များကို မည်သို့ ကိုင်တွယ်ကြောင်း ကျွန်ုပ်တို့ ရှင်းပြပါမည်။</p>
<h2>၁။ အချက်အလက် စုဆောင်းခြင်း</h2>
<ul>
<li>အကောင့် အချက်အလက် (အမည်၊ email) — Google login သုံးသောအခါ</li>
<li>ထီလက်မှတ် ဂဏန်းများ — "My Tickets" feature သုံးသောအခါ</li>
<li>Browser push notification subscription — notification ချိတ်ဆက်သောအခါ</li>
<li>သုံးစွဲမှု အချက်အလက် — page views, feature usage (Google Analytics)</li>
<li>မွေးနေ့ အချက်အလက် — horoscope နှင့် lucky number feature များအတွက်</li>
<li>Device information — ဘာသာစကား၊ screen size, browser type</li>
</ul>
<h2>၂။ အချက်အလက် အသုံးပြုခြင်း</h2>
<ul>
<li>ထီဆွဲချက် ရလဒ်များ အော်တို ပြသခြင်းနှင့် အပ်ဒိတ်လုပ်ခြင်း</li>
<li>ထီဆွဲချက် အသစ် ထွက်သောအခါ push notification ပေးပို့ခြင်း</li>
<li>My Tickets feature ဖြင့် သင်၏ လက်မှတ်များကို ဆွဲချက် ရလဒ်များနှင့် စစ်ဆေးခြင်း</li>
<li>AI-powered lucky number generation (3D နှင့် 2D ဂဏန်းများ)</li>
<li>Weekly horoscope နှင့် ဗေဒင်ဟောကိန်း ပေးပို့ခြင်း</li>
<li>App အသုံးပြုမှု အတွေ့အကြုံ ပိုမိုကောင်းမွန်စေရန်</li>
</ul>
<h2>၃။ အချက်အလက် မျှဝေခြင်း</h2>
<ul>
<li>သင်၏ ကိုယ်ရေးကိုယ်တာ အချက်အလက်များကို တတိယ ပါတီများသို့ ရောင်းချခြင်း သို့မဟုတ် မျှဝေခြင်း မပြုလုပ်ပါ</li>
<li>Google Analytics နှင့် analytics services များနှင့်သာ anonymized data မျှဝေပါသည်</li>
<li>ထိုင်းလော့တာ ရလဒ်များကို တရားဝင် ရင်းမြစ်များမှ ရယူပါသည်</li>
</ul>
<h2>၄။ Data Storage & Security</h2>
<ul>
<li>သင်၏ အချက်အလက်များကို HTTPS encryption ဖြင့် ကာကွယ်ပါသည်</li>
<li>Database ကို encrypted connection (SSL/TLS) ဖြင့် ဆက်သွယ်ပါသည်</li>
<li>User passwords ကို မှတ်သားခြင်း မရှိပါ (OAuth only)</li>
<li>Push notification tokens ကို securely storage တွင် သိမ်းဆည်းပါသည်</li>
</ul>
<h2>၅။ ဘေးအန္တရာယ် ဖြည့်စွက်ချက် (Disclaimer)</h2>
<ul>
<li>ဤ app သည် ပျော်ရွှင်မှုနှင့် အချက်အလက် ရည်ရွယ်ချက်အတွက်သာ ဖြစ်ပါသည်</li>
<li>AI lucky numbers များသည် ဟောကိန်းသက်သက် ဖြစ်ပြီး ဆုပေါက်မည့် အာမခံချက် မရှိပါ</li>
<li>ထီလက်မှတ် စစ်ဆေးမှု ရလဒ်များသည် တရားဝင် ဆုပေါက်စာရင်းနှင့် ကိုက်ညီရန် ရည်ရွယ်ပါသည်</li>
<li>အသက် ၁၈ နှစ်အောက် မသုံးစွဲရန် တိုက်တွန်းအပ်ပါသည်</li>
</ul>
<h2>၆။ ကိုယ်ရေးကိုယ်တာ အခွင့်အရေးများ</h2>
<ul>
<li>သင်၏ အချက်အလက်များကို delete လုပ်ရန် တောင်းဆိုနိုင်ပါသည်</li>
<li>Notification subscription ကို အချိန်မရွေး ဖျက်နိုင်ပါသည်</li>
<li>My Tickets data ကို app အတွင်းမှ delete လုပ်နိုင်ပါသည်</li>
</ul>
<h2>၇။ ဆက်သွယ်ရန်</h2>
<p>Email: support@goldenthailottery.com</p>
<p>Website: ${APP_URL}</p>
<div class="footer"><p>နောက်ဆုံး ပြင်ဆင်သည့်ရက်: ဩဂုတ် ၂၀၂၆ | Golden Thai Lottery & 2D</p></div>
</body>
</html>`;
  }
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Privacy Policy — Golden Thai Lottery & 2D</title>
<style>
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;padding:20px;background:#FFF8E1;color:#333;line-height:1.7}
h1{text-align:center;color:#B8860B;border-bottom:3px solid #FFD700;padding-bottom:10px}
h2{color:#8B6914;margin-top:24px;font-size:16px}
ul{padding-left:20px}
li{margin-bottom:6px;color:#555}
.header{text-align:center;background:linear-gradient(135deg,#FFD700,#FFB300);color:white;padding:20px;border-radius:12px;margin-bottom:20px}
.footer{text-align:center;color:#999;font-size:12px;margin-top:30px;padding-top:15px;border-top:1px solid #ddd}
.date{text-align:center;font-size:13px;color:#888;margin-bottom:15px}
</style>
</head>
<body>
<div class="header"><h1>Privacy Policy</h1><p>Last Updated: August 2026</p></div>
<p>This Privacy Policy explains how Golden Thai Lottery & 2D ("we", "our", or "the App") collects, uses, and protects your personal information when you use our application.</p>
<h2>1. Information We Collect</h2>
<ul>
<li>Account information (name, email) — when using Google login</li>
<li>Lottery ticket numbers — when using "My Tickets" feature</li>
<li>Browser push notification subscriptions — when enabling notifications</li>
<li>Usage data — page views, feature usage (Google Analytics)</li>
<li>Birth date information — for horoscope and lucky number features</li>
<li>Device information — language, screen size, browser type</li>
</ul>
<h2>2. How We Use Your Information</h2>
<ul>
<li>Automatically displaying and updating lottery draw results</li>
<li>Sending push notifications when new lottery results are available</li>
<li>Checking your saved tickets against draw results (My Tickets feature)</li>
<li>AI-powered lucky number generation (3D and 2D numbers)</li>
<li>Delivering weekly horoscope readings and fortune predictions</li>
<li>Improving app experience and performance</li>
</ul>
<h2>3. Information Sharing</h2>
<ul>
<li>We do NOT sell or share your personal information with third parties</li>
<li>We only share anonymized data with analytics services like Google Analytics</li>
<li>Thai lottery results are fetched from official authorized sources</li>
<li>Myanmar 2D results are obtained from SET index data</li>
</ul>
<h2>4. Data Storage & Security</h2>
<ul>
<li>Your information is protected with HTTPS encryption</li>
<li>Database connections use encrypted SSL/TLS connections</li>
<li>We do NOT store user passwords (OAuth authentication only)</li>
<li>Push notification tokens are stored securely</li>
<li>Regular data backups are maintained</li>
</ul>
<h2>5. Disclaimer</h2>
<ul>
<li>This app is for entertainment and informational purposes only</li>
<li>AI-generated lucky numbers are predictions only — no guarantee of winning</li>
<li>Ticket checking results are intended to match official winning lists</li>
<li>Not recommended for users under 18 years of age</li>
</ul>
<h2>6. Your Rights</h2>
<ul>
<li>You may request deletion of your personal data at any time</li>
<li>You can unsubscribe from notifications at any time</li>
<li>You can delete your saved ticket data within the app</li>
<li>You can disable data collection in your browser settings</li>
</ul>
<h2>7. Contact Us</h2>
<p>Email: support@goldenthailottery.com</p>
<p>Website: ${APP_URL}</p>
<div class="footer"><p>Last Updated: August 2026 | Golden Thai Lottery & 2D</p></div>
</body>
</html>`;
}
