import { useLang } from "@/contexts/LangContext";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Trophy, Crown, Clock, Hash, Calendar } from "lucide-react";
import { Trophy as TrophyIcon } from "lucide-react";

// ─── Confetti / Celebration Sound Effect ─────────────────────────────────
function playWinnerSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const sampleRate = ctx.sampleRate;
    const duration = 1.5;
    const length = Math.ceil(sampleRate * duration);
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    // Celebration chime: ascending arpeggio
    const notes = [523, 659, 784, 1047]; // C5, E5, G5, C6
    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      let sample = 0;
      notes.forEach((freq, idx) => {
        const start = idx * 0.2;
        if (t >= start && t < start + 0.3) {
          const nt = t - start;
          const envelope = Math.exp(-nt * 3);
          sample += Math.sin(2 * Math.PI * freq * nt) * envelope * 0.25;
        }
      });
      data[i] = Math.max(-1, Math.min(1, sample));
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start(0);
  } catch { /* silent fail */ }
}

export default function LuckyBoxWinners() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const mm = lang === "mm";

  const { data: winners, isLoading } = trpc.luckyBoxWinners.getWinners.useQuery();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a0a3e] to-[#0d0520]">
      {/* ─── Header ──────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 bg-gradient-to-r from-[#1a0a3e] to-[#2d1b69] border-b border-purple-700/30 backdrop-blur-sm">
        <div className="max-w-[480px] mx-auto px-3 py-2.5 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="p-1.5 rounded-lg bg-white/10 text-white"
          >
            <ArrowLeft size={18} />
          </button>
          <div className="flex items-center gap-2">
            <TrophyIcon size={18} className="text-[#FFD700]" />
            <h1 className="text-base font-bold text-white font-myanmar-display">
              {mm ? "ကံထူးမှတ်တမ်း" : "Winners Hall"}
            </h1>
          </div>
          <div className="w-8" /> {/* spacer */}
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-3 py-4">
        {/* ─── Header Banner ─────────────────────────────────────────── */}
        <div className="relative rounded-2xl overflow-hidden mb-4">
          <div className="bg-gradient-to-br from-[#FFD700]/20 to-[#FF6B35]/20 border border-[#FFD700]/30 p-5 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Crown size={24} className="text-[#FFD700]" />
              <h2 className="text-xl font-bold text-[#FFD700] font-myanmar-display">
                {mm ? "ကံထူးသူများ" : "Hall of Winners"}
              </h2>
              <Crown size={24} className="text-[#FFD700]" />
            </div>
            <p className="text-[#FFD700]/80 text-sm font-myanmar">
              {mm
                ? "ကံထူးဆုလက်ဆောင် ကံထူးသူများ၏ မှတ်တမ်း"
                : "Lucky Box winners — all past winners"}
            </p>
          </div>
        </div>

        {/* ─── Winners Count ─────────────────────────────────────────── */}
        {!isLoading && winners && (
          <div className="flex items-center justify-between mb-3 px-1">
            <p className="text-white/70 text-sm font-myanmar">
              {mm ? "စုစုပေါင်း" : "Total"}{" "}
              <span className="text-[#FFD700] font-bold">{winners.length}</span>{" "}
              {mm ? "ဦး" : "winners"}
            </p>
          </div>
        )}

        {/* ─── Loading State ─────────────────────────────────────────── */}
        {isLoading && (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="bg-white/5 rounded-xl p-4 animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/10" />
                  <div className="flex-1">
                    <div className="h-4 w-32 bg-white/10 rounded mb-2" />
                    <div className="h-3 w-24 bg-white/5 rounded" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ─── Empty State ───────────────────────────────────────────── */}
        {!isLoading && winners && winners.length === 0 && (
          <div className="text-center py-12">
            <Trophy size={48} className="mx-auto text-white/20 mb-4" />
            <p className="text-white/50 text-base font-myanmar">
              {mm
                ? "မရှိသေးပါ — ပထမဆုံး ကံထူးသူ ဖြစ်ပါစေ!"
                : "No winners yet — be the first to win!"}
            </p>
          </div>
        )}

        {/* ─── Winners List ──────────────────────────────────────────── */}
        {!isLoading && winners && winners.length > 0 && (
          <div className="space-y-2">
            {winners.map((winner, i) => {
              const openedDate = new Date(winner.openedAt);
              const dateStr = `${openedDate.getFullYear()}-${String(openedDate.getMonth() + 1).padStart(2, "0")}-${String(openedDate.getDate()).padStart(2, "0")}`;
              const timeStr = `${String(openedDate.getHours()).padStart(2, "0")}:${String(openedDate.getMinutes()).padStart(2, "0")}`;
              const isRecent = i < 3; // First 3 get gold border

              return (
                <div
                  key={winner.id}
                  className={`relative rounded-xl p-4 transition-all ${
                    isRecent
                      ? "bg-gradient-to-r from-[#FFD700]/15 to-[#FF6B35]/10 border border-[#FFD700]/30"
                      : "bg-white/5 border border-white/10"
                  }`}
                >
                  {/* Rank badge */}
                  <div className="absolute -top-1.5 -left-1.5">
                    {isRecent && (
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shadow-lg ${
                        i === 0 ? "bg-gradient-to-br from-[#FFD700] to-[#FFB300] text-[#1a0a3e]" :
                        i === 1 ? "bg-gradient-to-br from-[#C0C0C0] to-[#A0A0A0] text-[#1a0a3e]" :
                        "bg-gradient-to-br from-[#CD7F32] to-[#8B4513] text-white"
                      }`}>
                        {i + 1}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    {/* Avatar */}
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isRecent
                        ? "bg-gradient-to-br from-[#FFD700]/30 to-[#FF6B35]/30"
                        : "bg-white/10"
                    }`}>
                      <Crown size={16} className={isRecent ? "text-[#FFD700]" : "text-white/50"} />
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-semibold text-sm truncate">
                        {winner.displayName}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <Calendar size={10} className="text-white/40" />
                        <span className="text-white/50 text-xs">
                          {dateStr} {timeStr}
                        </span>
                      </div>
                    </div>

                    {/* Reference ID */}
                    {winner.referenceId && (
                      <div className="flex items-center gap-1 bg-white/5 rounded-lg px-2 py-1">
                        <Hash size={10} className="text-white/30" />
                        <span className="text-white/50 text-[10px] font-mono">
                          {winner.referenceId.slice(0, 8)}...
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ─── Footer CTA ────────────────────────────────────────────── */}
        <div className="text-center mt-6">
          <button
            onClick={() => { playWinnerSound(); navigate("/lucky-box"); }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#FFD700] to-[#FFB300] text-[#1a0a3e] font-bold px-6 py-3 rounded-full shadow-lg shadow-[#FFD700]/20 hover:shadow-[#FFD700]/40 transition-all active:scale-95 font-myanmar"
          >
            <Crown size={16} />
            {mm ? "Lucky Box ဖွင့်ပါ" : "Open Lucky Box"}
          </button>
        </div>


      </div>
    </div>
  );
}
