import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, MessageCircle, Send, User, RefreshCw, AlertTriangle, Sun, Moon, Sparkles, TrendingUp, TrendingDown, BarChart3, Flame, Snowflake, CheckCircle2, Volume2, VolumeX, Bell, BellOff, Clock, Copy, Check, X } from "lucide-react";
import { useState, useEffect, useRef, useCallback } from "react";
import { toast } from "sonner";
import { useLang } from "@/contexts/LangContext";
import { canShowMyanmarMarketBoard, getCurrentDayLiveMarket, getCurrentDayVerifiedMarketResult, getMyanmarMarketSession, getThaiLotteryThreeDigit } from "@/lib/twoDMarket";

// ─── Bell sound for new 2D results ───────────────────────────────────────
let cachedBellBuffer: AudioBuffer | null = null;
async function getBellBuffer(): Promise<AudioBuffer | null> {
  try {
    if (cachedBellBuffer) return cachedBellBuffer;
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const sampleRate = ctx.sampleRate;
    const duration = 1.0;
    const length = Math.ceil(sampleRate * duration);
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    const notes = [
      { freq: 988, start: 0, dur: 0.35 },
      { freq: 1175, start: 0.12, dur: 0.5 },
    ];
    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      let sample = 0;
      for (const note of notes) {
        if (t >= note.start && t < note.start + note.dur) {
          const nt = t - note.start;
          const envelope = Math.exp(-nt * 4.5);
          sample += Math.sin(2 * Math.PI * note.freq * nt) * envelope * 0.25;
        }
      }
      data[i] = Math.max(-1, Math.min(1, sample));
    }
    cachedBellBuffer = buffer;
    return buffer;
  } catch { return null; }
}

function playBellSound() {
  try {
    const AudioCtx = (window.AudioContext || (window as any).webkitAudioContext);
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    if (ctx.state === 'suspended') ctx.resume();
    getBellBuffer().then(buf => {
      if (!buf) return;
      const source = ctx.createBufferSource();
      source.buffer = buf;
      source.connect(ctx.destination);
      source.start(0);
    });
  } catch { /* silent fail */ }
}

function useAudioUnlock() {
  const unlockedRef = useRef(false);
  useEffect(() => {
    const unlock = () => {
      if (!unlockedRef.current) {
        try {
          const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
          if (ctx.state === 'suspended') ctx.resume();
          unlockedRef.current = true;
        } catch { /* ignore */ }
      }
      window.removeEventListener('touchstart', unlock);
      window.removeEventListener('click', unlock);
    };
    window.addEventListener('touchstart', unlock, { once: true });
    window.addEventListener('click', unlock, { once: true });
    return () => {
      window.removeEventListener('touchstart', unlock);
      window.removeEventListener('click', unlock);
    };
  }, []);
}

// ─── Helpers ─────────────────────────────────────────────────────────────
function formatMyanmarTime(date: Date): string {
  return date.toLocaleTimeString("en-US", {
    timeZone: "Asia/Yangon",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function getMyanmarNow(): Date {
  const utc = Date.now();
  return new Date(utc + 6.5 * 60 * 60 * 1000);
}

function getTodayMyanmarStr(): string {
  const mm = getMyanmarNow();
  return mm.toISOString().split("T")[0];
}

// 2D number comes directly from API's twod field (stored as winningNumber)
// Do NOT derive from SET index — the API provides the authoritative 2D value
function get2DFromResult(result: any): string {
  if (!result) return "--";
  return result.winningNumber || "--";
}

// Format number with comma thousands separator
function formatNumber(num: number | string): string {
  const raw = typeof num === "string" ? num.replace(/,/g, "") : String(num);
  const n = parseFloat(raw);
  if (isNaN(n)) return String(num);
  return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ─── Profanity filter: block offensive words ─────────────────────────────
const PROFANITY_WORDS = [
  // Myanmar profanity (explicit swear words)
  "လီး", "စပတ်", "ငါလိုးမ", "လူလိမ်", "ခွေးသား",
  "လိုး", "ပိုး", "ဆု", "မင်္ဇား", "မင်္ဇ", "ခွေး",
  "ကြိတ်", "စုပ်", "ဝတ်မတ်", "ဝတ်မတ်ရုတ်",
  "ကုတင်ပေါ်", "ညဉ့်သုတ်", "စောက်ပြတ်", "စောက်ကုတ်",
  "မိကျောင်း", "ခရုရမ်း", "ရမ်းချင်း", "ရမ်းကား",
  "ဒေါင်းရမ်း", "နွားရမ်း", "စိန်ရမ်း", "ဘဲစုပ်",
  "ကပ်ရံ", "ရန်ရှာ", "ရန်မုန်း", "စိန်ခေါ်",
  "စောက်ဖြတ်", "မိတ်ဆွေစီး", "အိမ်မိတ်", "အိမ်မိတ်ဆွေ",
  // Variations and common misspellings
  "လီုး", "စပတ်", "ခွေးသာ", "လူးလိမ်",
  "မိလိုး", "မိလိုးမ", "ငါလိုး", "လိုးတယ်",
  // English profanity
  "dog", "fuck", "shit", "asshole", "bitch",
  "bastard", "damn", "hell", "crap", "dick",
  "penis", "pussy", "slut", "whore", "cunt",
  "motherfucker", "son of a bitch", "fucking",
];

function containsProfanity(text: string): boolean {
  const lowerText = text.toLowerCase();
  return PROFANITY_WORDS.some(word => lowerText.includes(word.toLowerCase()));
}

// ─── Chat content filter: block phone numbers, URLs, and profanity ────────
function containsBlockedContent(text: string): boolean {
  // Phone number patterns: +65, 09xxxxxxxxx, 09-xxxxxxxx, (09)xxxxxxxx, etc.
  const phoneRegex = /\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3,4}[-.\s]?\d{4}\b/;
  // Myanmar phone: 09xxxxxxxxx (9 digits after 09)
  const mmPhoneRegex = /(?:^|\s)(?:09|0\s?9)\d{7,9}(?:\s|$)/;
  // URL patterns
  const urlRegex = /(?:https?:\/\/|www\.)[^\s]+/;
  const dotComRegex = /\.[a-z]{2,}(\/|\s|$)/;
  // Email patterns
  const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/;

  if (phoneRegex.test(text) || mmPhoneRegex.test(text) || urlRegex.test(text) || dotComRegex.test(text) || emailRegex.test(text)) {
    return true;
  }

  // Profanity check
  if (containsProfanity(text)) {
    return true;
  }

  return false;
}

// ─── Black-and-gold 2D header — verified result experience only ──────────
function LiveHeader({ mm, navigate, showChatBtn, onChatToggle }: {
  mm: boolean;
  navigate: (to: string) => void;
  showChatBtn?: boolean;
  onChatToggle?: () => void;
}) {
  return (
    <header className="sticky top-0 z-50 border-b border-[#f59e0b]/80 bg-[#080808] text-[#fff7e8] shadow-lg shadow-black/30">
      <div className="mx-auto flex max-w-[480px] items-center gap-2.5 px-3 py-2">
        <button onClick={() => navigate("/")} className="text-[#f8c45d] btn-press" aria-label="Back">
          <ArrowLeft size={20} />
        </button>
          <h1 className="flex-1 font-display text-sm font-bold tracking-wide">
          {mm ? "မြန်မာ ၂ဒီ" : "Myanmar 2D"}
        </h1>
        {showChatBtn && (
          <button
            onClick={onChatToggle}
            className="flex items-center gap-1 rounded-full border border-[#f59e0b]/70 bg-[#1a1208] px-2.5 py-1 text-[11px] font-bold text-[#f8c45d] btn-press"
            aria-label="Chat"
          >
            <span className="animate-chat-attention flex items-center gap-1">
              <MessageCircle size={15} />
              <span>Chat</span>
            </span>
          </button>
        )}
      </div>
    </header>
  );
}

// ─── Black-and-gold verified result board ─────────────────────────────────
function LiveCard({ mm, morningResult, eveningResult, todayDisplay, liveMarket }: {
  mm: boolean;
  morningResult: any;
  eveningResult: any;
  todayDisplay: string;
  liveMarket: { set?: string; value?: string; twod?: string; time?: string } | null;
}) {
  const mmNow = getMyanmarNow();
  const isWeekend = mmNow.getUTCDay() === 0 || mmNow.getUTCDay() === 6;
  const marketBoardVisible = canShowMyanmarMarketBoard();
  const rawLiveTwoD = String(liveMarket?.twod || "").trim();
  const liveTwoD = /^\d{1,2}$/.test(rawLiveTwoD) ? rawLiveTwoD.padStart(2, "0") : "--";

  const marketSession = getMyanmarMarketSession();
  const sessionResult = marketSession === "morning" ? morningResult : marketSession === "evening" ? eveningResult : undefined;
  const currentSessionTwoD = String(sessionResult?.winningNumber || "").trim();
  const latestSettledTwoD = String(eveningResult?.winningNumber || morningResult?.winningNumber || "").trim();
  const displayTwoDRaw = /^\d{1,2}$/.test(currentSessionTwoD)
    ? currentSessionTwoD
    : liveTwoD !== "--"
      ? liveTwoD
      : marketBoardVisible && /^\d{1,2}$/.test(latestSettledTwoD)
        ? latestSettledTwoD
        : "--";
  const displayTwoD = displayTwoDRaw === "--" ? "--" : displayTwoDRaw.padStart(2, "0");
  const hasDisplayTwoD = displayTwoD !== "--";
  const showsLiveTwoD = liveTwoD !== "--" && !/^\d{1,2}$/.test(currentSessionTwoD);

  const ResultRow = ({ label, time, number, setNumber, valueNumber, session }: { label: string; time: string; number?: string; setNumber?: string; valueNumber?: string; session: "morning" | "evening" }) => {
    const result = number || "--";
    const isReady = result !== "--";
    const isActiveSession = marketSession === session;
    const isLiveSession = !isReady && isActiveSession && Boolean(liveMarket?.set && liveMarket?.value);
    const hasSettledMarket = marketBoardVisible && Boolean(setNumber && valueNumber && setNumber !== "--" && valueNumber !== "--");
    const displaySet = hasSettledMarket ? setNumber : (isLiveSession ? liveMarket?.set : "--");
    const displayValue = hasSettledMarket ? valueNumber : (isLiveSession ? liveMarket?.value : "--");
    const hasMarketData = displaySet !== "--" && displayValue !== "--";
    return (
      <div className="grid grid-cols-[58px_minmax(0,1fr)_56px] items-center gap-1.5 rounded-lg border border-[#d99a25] bg-[#111111] px-2.5 py-1.5 shadow-[inset_0_0_14px_rgba(245,158,11,0.07)]">
        <div>
          <p className="text-[9px] font-semibold text-[#d6b578] font-myanmar">{label}</p>
          <p className="mt-0.5 text-base font-black tracking-wide text-[#fff2d2]">{time}</p>
        </div>
        <div className="min-w-0 border-x border-[#4f391a] px-2.5">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-[10px] font-black text-[#f2a321]">SET</span>
            <span className={`truncate font-mono text-[15px] font-black ${hasMarketData ? "text-[#39d98a]" : "text-[#8a806e]"}`}>{displaySet}</span>
          </div>
          <div className="mt-0.5 flex items-baseline justify-between gap-2">
            <span className="text-[10px] font-black text-[#f2a321]">VAL</span>
            <span className={`truncate font-mono text-[15px] font-black ${hasMarketData ? "text-[#39d98a]" : "text-[#8a806e]"}`}>{displayValue}</span>
          </div>
        </div>
        <div className="text-center">
          <p className="text-[8px] font-bold uppercase tracking-[0.15em] text-[#d6b578]">2D</p>
          <div className={`mt-0.5 rounded-md border px-1 py-0.5 text-center text-xl font-black prize-number ${isReady ? "border-[#f59e0b] bg-[#2b1a05] text-[#ffad1f]" : "border-[#6b5634] bg-[#18130c] text-[#8a806e]"}`}>
            {result}
          </div>
        </div>
      </div>
    );
  };

  return (
    <section className="mt-2 overflow-hidden rounded-xl border border-[#e2a42c] bg-[#060606] p-2.5 shadow-[0_10px_22px_rgba(0,0,0,0.5)] animate-fade-in-up">
      <div className="flex items-center justify-between border-b border-[#6f4a16] pb-1.5">
        <div>
          <p className="text-[9px] font-bold uppercase tracking-[0.14em] text-[#d6b578]">{mm ? "အတည်ပြု ၂ဒီ ရလဒ်" : "Verified 2D Result"}</p>
          <p className="text-[11px] font-semibold text-[#fff2d2]">{todayDisplay}</p>
        </div>
        {isWeekend && <span className="rounded-full border border-[#7a5b2d] bg-[#20170a] px-2 py-0.5 text-[10px] font-bold text-[#ffd486]">{mm ? "ပိတ်ရက်" : "Closed"}</span>}
      </div>

      <div className="py-1.5 text-center">
        <p className="text-[9px] font-semibold text-[#c9ad78] font-myanmar">{showsLiveTwoD ? (mm ? "တိုက်ရိုက်ပြောင်းလဲနေသော ၂ဒီ" : "Live changing 2D") : (hasDisplayTwoD ? (mm ? "အတည်ပြုပြီး ၂ဒီ ရလဒ်" : "Verified 2D result") : (mm ? "ရလဒ်စောင့်ဆိုင်းနေသည်" : "Result pending"))}</p>
        <div className={`mt-0.5 prize-number text-5xl font-black leading-none ${hasDisplayTwoD ? "text-[#ff9f0a]" : "text-[#80745e]"}`} style={{ textShadow: hasDisplayTwoD ? "0 0 16px rgba(245,158,11,0.35)" : "none" }}>
          {displayTwoD}
        </div>
        <p className="mt-0.5 text-[9px] text-[#bca97d] font-myanmar">{showsLiveTwoD ? (mm ? "စျေးကွက်ဂဏန်းပြောင်းသလို အလိုအလျောက်ပြောင်းပါမည်" : "Updates automatically with the market") : (hasDisplayTwoD ? (mm ? "ယနေ့အတည်ပြုထားသော ရလဒ်" : "Verified result for today") : (isWeekend ? (mm ? "စနေ၊ တနင်္ဂနွေ ပိတ်ရက်" : "Closed on Saturday and Sunday") : (mm ? "စျေးကွက်ဖွင့်ချိန်တွင် ၂လုံးဂဏန်း ပြသပါမည်" : "Shown during market hours")))}</p>
      </div>

      <div className="space-y-1.5">
        <ResultRow label={mm ? "မနက်" : "Morning"} time={mm ? "၁၂:၀၁" : "12:01"} session="morning" number={morningResult?.winningNumber} setNumber={morningResult?.setNumber} valueNumber={morningResult?.valueNumber} />
        <ResultRow label={mm ? "ညနေ" : "Evening"} time={mm ? "၀၄:၃၀" : "4:30"} session="evening" number={eveningResult?.winningNumber} setNumber={eveningResult?.setNumber} valueNumber={eveningResult?.valueNumber} />
      </div>
    </section>
  );
}

// ─── Result schedule — no market/stock values ────────────────────────────
function ResultSchedule({
  mm,
  morningMarket,
  eveningMarket,
}: {
  mm: boolean;
  morningMarket: { set: string; value: string };
  eveningMarket: { set: string; value: string };
}) {
  const rows = [
    { time: mm ? "၁၂:၀၁ PM" : "12:01 PM", market: morningMarket },
    { time: mm ? "၀၄:၃၀ PM" : "4:30 PM", market: eveningMarket },
  ];

  return (
    <section className="mt-2 overflow-hidden rounded-lg border border-[#9c6d20] bg-[#0b0b0b] shadow-lg animate-fade-in-up">
      <div className="flex items-center gap-1.5 border-b border-[#76521a] bg-[#171006] px-2.5 py-1.5">
        <Clock size={12} className="text-[#f8c45d]" />
        <h2 className="text-[11px] font-bold text-[#fff2d2] font-myanmar">{mm ? "၂ဒီ အချိန်ဇယား" : "2D Schedule"}</h2>
      </div>
      <div className="grid grid-cols-[82px_minmax(0,1fr)_minmax(0,1fr)] gap-1 border-b border-[#3c2b10] bg-[#120d06] px-2.5 py-1 text-[9px] font-black uppercase tracking-wide">
        <span className="text-[#d6b578]">{mm ? "အချိန်" : "Time"}</span>
        <span className="text-center text-[#f2a321]">SET</span>
        <span className="text-center text-[#39d98a]">VAL</span>
      </div>
      <div className="divide-y divide-[#3c2b10]">
        {rows.map((row) => (
          <div key={row.time} className="grid grid-cols-[82px_minmax(0,1fr)_minmax(0,1fr)] items-center gap-1 px-2.5 py-1.5">
            <span className="text-xs font-bold text-[#fff2d2] font-myanmar">{row.time}</span>
            <span className={`truncate text-center font-mono text-xs font-black ${row.market.set === "--" ? "text-[#8a806e]" : "text-[#f8c45d]"}`}>{row.market.set}</span>
            <span className={`truncate text-center font-mono text-xs font-black ${row.market.value === "--" ? "text-[#8a806e]" : "text-[#39d98a]"}`}>{row.market.value}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

// ─── Session predictions and verified 3D/week summary ──────────────────────
function HotAndWeekSummary({
  mm,
  history,
  hasTodayResult,
  latest3D,
  prediction,
}: {
  mm: boolean;
  history: any;
  hasTodayResult: boolean;
  latest3D: string;
  prediction: { morningPredictions: string[]; eveningPredictions: string[] } | null;
}) {
  const recentRows = Array.isArray(history?.results) ? history.results : [];
  const predictionNumbers = (values: string[] | undefined) =>
    (values || []).filter((value) => /^\d{2}$/.test(String(value))).slice(0, 3);
  const morningPredictions = predictionNumbers(prediction?.morningPredictions);
  const eveningPredictions = predictionNumbers(prediction?.eveningPredictions);
  const now = getMyanmarNow();
  const monday = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  monday.setUTCDate(monday.getUTCDate() - ((monday.getUTCDay() + 6) % 7));
  const weekdayLabels = mm ? ["တန", "အင်္ဂါ", "ဗုဒ္ဓ", "ကြာ", "သော"] : ["Mon", "Tue", "Wed", "Thu", "Fri"];

  const dateKey = (value: unknown) => {
    const date = new Date(String(value));
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
  };
  const resultByDate = new Map<string, { morning: string; evening: string }>();
  recentRows.forEach((row: any) => {
    if (!hasTodayResult) return;
    if (!/^\d{2}$/.test(String(row.winningNumber || ""))) return;
    const key = dateKey(row.resultDate);
    const existing = resultByDate.get(key) || { morning: "--", evening: "--" };
    const session = String(row.session);
    if (session === "morning" || session === "evening") {
      existing[session] = String(row.winningNumber);
      resultByDate.set(key, existing);
    }
  });

  const weekdayResults = weekdayLabels.map((label, index) => {
    const date = new Date(monday);
    date.setUTCDate(monday.getUTCDate() + index);
    const key = `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
    return { label, ...(resultByDate.get(key) || { morning: "--", evening: "--" }) };
  });
  const HotCard = ({ label, values }: { label: string; values: string[] }) => (
    <div className="relative rounded-2xl border border-[#d98d12] bg-[#101010] px-2.5 pb-2.5 pt-4.5 shadow-[0_8px_18px_rgba(0,0,0,0.36)]">
      <span className="absolute -top-3 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-[#f59e0b] px-3 py-1 text-xs font-black text-[#221607] shadow-lg">{label}</span>
      <div className="grid grid-cols-3 gap-1.5">
        {(values.length ? values : ["--", "--", "--"]).map((value, index) => (
          <div key={`${value}-${index}`} className="rounded-lg border border-[#9f691c] bg-[#080808] py-1.5 text-center font-mono text-xl font-black text-[#ffdca5]">{value}</div>
        ))}
      </div>
    </div>
  );

  return (
    <section className="mt-4 space-y-2.5 animate-fade-in-up">
      <div className="grid grid-cols-2 gap-2.5">
        <HotCard label={mm ? "ဟောဂဏန်း (၁၂:၀၁)" : "Prediction (12:01)"} values={morningPredictions} />
        <HotCard label={mm ? "ဟောဂဏန်း (၀၄:၃၀)" : "Prediction (04:30)"} values={eveningPredictions} />
      </div>

      <div className="grid grid-cols-[78px_minmax(0,1fr)] gap-2.5">
        <div className="rounded-2xl border border-[#d98d12] bg-[#101010] px-2 py-2.5 text-center shadow-[0_8px_18px_rgba(0,0,0,0.36)]">
          <p className="text-[11px] font-bold text-[#f7d9a4]">3D</p>
          <p className="mt-1.5 font-mono text-3xl font-black text-[#ff9f0a]" style={{ textShadow: "0 0 14px rgba(245,158,11,0.32)" }}>{latest3D}</p>
          <p className="mt-1 text-[9px] text-[#a98c59] font-myanmar">{mm ? "နောက်ဆုံးထွက်" : "Latest draw"}</p>
        </div>
        <div className="rounded-2xl border border-[#d98d12] bg-[#101010] px-2 pb-2.5 pt-4.5 shadow-[0_8px_18px_rgba(0,0,0,0.36)]">
          <span className="absolute sr-only">{mm ? "ယခုအပတ် ၂ဒီ" : "Current-week 2D"}</span>
          <div className="-mt-7 mb-2 flex justify-center">
            <span className="rounded-full bg-[#f59e0b] px-3 py-1 text-xs font-black text-[#221607] shadow-lg">{mm ? "ယခုအပတ် ၂ဒီ" : "Current Week 2D"}</span>
          </div>
          <div className="grid grid-cols-5 gap-1">
            {weekdayResults.map((day) => (
              <div key={day.label} className="text-center">
                <p className="mb-0.5 text-[9px] font-semibold text-[#f7d9a4]">{day.label}</p>
                <div className="overflow-hidden rounded-lg border border-[#59451f] bg-[#080808] font-mono text-[11px] font-black leading-none">
                  <div className={`border-b border-[#3c2b10] px-0.5 py-1 ${day.morning === "--" ? "text-[#877453]" : "text-[#7cc4ff]"}`}>{day.morning}</div>
                  <div className={`px-0.5 py-1 ${day.evening === "--" ? "text-[#877453]" : "text-[#ff8f85]"}`}>{day.evening}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function ResultHistory({ mm, results }: { mm: boolean; results: any[] }) {
  const weekdays = mm
    ? ["တနင်္ဂနွေ", "တနင်္လာ", "အင်္ဂါ", "ဗုဒ္ဓဟူး", "ကြာသပတေး", "သောကြာ", "စနေ"]
    : ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const grouped = results.reduce((rows: Record<string, { date: string; morning?: string; evening?: string }>, item: any) => {
    const date = new Date(String(item.resultDate));
    const key = `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
    if (!rows[key]) rows[key] = { date: key };
    rows[key][item.session as "morning" | "evening"] = item.winningNumber;
    return rows;
  }, {});
  const rows = Object.values(grouped)
    .sort((left, right) => right.date.localeCompare(left.date))
    .slice(0, 60);

  return (
    <section className="mt-6 overflow-hidden rounded-3xl border border-[#d98d12] bg-[#101010] shadow-[0_14px_34px_rgba(0,0,0,0.46)] animate-fade-in-up">
      <div className="border-b border-[#704914] bg-[#171006] px-4 py-3">
        <h2 className="font-myanmar text-sm font-black text-[#ffe2ad]">{mm ? "၂ဒီ ထွက်မှတ်တမ်း" : "2D Result History"}</h2>
        <p className="mt-0.5 font-myanmar text-[10px] text-[#b99d70]">{mm ? "နေ့စွဲနှင့် နေ့နာမည်ပါသော နောက်ဆုံး ၆၀ ရက်" : "Latest 60 days with date and weekday"}</p>
      </div>
      {rows.length === 0 ? (
        <p className="px-4 py-8 text-center font-myanmar text-sm text-[#a98c59]">{mm ? "အတည်ပြု ၂ဒီ ထွက်မှတ်တမ်း မရှိသေးပါ" : "No verified 2D result history yet"}</p>
      ) : (
        <div className="divide-y divide-[#3c2b10]">
          {rows.map((row) => {
            const date = new Date(`${row.date}T00:00:00Z`);
            const formattedDate = `${String(date.getUTCDate()).padStart(2, "0")}/${String(date.getUTCMonth() + 1).padStart(2, "0")}/${String(date.getUTCFullYear()).slice(2)}`;
            const weekday = weekdays[date.getUTCDay()];
            return (
              <div key={row.date} className="px-4 py-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-[#ffe2ad]">{formattedDate}</span>
                  <span className="font-myanmar text-[11px] font-semibold text-[#d7a451]">{weekday}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-xl border border-[#58421f] bg-[#090909] px-3 py-2">
                    <p className="font-myanmar text-[10px] text-[#a98c59]">{mm ? "မနက် ၁၂:၀၁" : "12:01 PM"}</p>
                    <p className={`mt-1 font-mono text-xl font-black ${row.morning ? "text-[#ffb42b]" : "text-[#716042]"}`}>{row.morning || "--"}</p>
                  </div>
                  <div className="rounded-xl border border-[#58421f] bg-[#090909] px-3 py-2">
                    <p className="font-myanmar text-[10px] text-[#a98c59]">{mm ? "ညနေ ၀၄:၃၀" : "4:30 PM"}</p>
                    <p className={`mt-1 font-mono text-xl font-black ${row.evening ? "text-[#ffb42b]" : "text-[#716042]"}`}>{row.evening || "--"}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

// ─── Chat Box — INDIGO/PURPLE Theme ──────────────────────────────────────
function ChatSection({ mm, chatMessages, chatRef, chatInput, setChatInput, sendChatMutation, isAuthenticated, currentUser, handleSendChat, guestName }: {
  mm: boolean;
  chatMessages: any[];
  chatRef: React.RefObject<HTMLDivElement | null>;
  chatInput: string;
  setChatInput: (v: string) => void;
  sendChatMutation: any;
  isAuthenticated: boolean;
  currentUser: any;
  handleSendChat: () => void;
  guestName?: string;
}) {
  return (
    <div className="mt-3 bg-gradient-to-br from-[#4A148C] to-[#311B92] rounded-xl shadow-sm animate-fade-in-up overflow-hidden">
      <div className="px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle size={14} className="text-white" />
          <h2 className="text-sm font-bold text-white font-myanmar">
            {mm ? "ဆွေးနွေးခန်း" : "Live Chat"}
          </h2>
        </div>
        <span className="text-[9px] text-white/70 bg-white/20 px-2 py-0.5 rounded-full">
          {chatMessages?.length ?? 0} {mm ? "စာ" : "messages"}
        </span>
      </div>

      {/* Scrolling warning text */}
      <div className="overflow-hidden bg-[#311B92] border-b border-[#1A237E]">
        <div className="flex whitespace-nowrap py-1" style={{ animation: 'marquee 10s linear infinite' }}>
          <span className="text-[10px] text-[#00E5FF] font-myanmar px-4">
            {mm ? "⚠ ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့ — ပရိသတ်အားလုံးအတွက် ကောင်းမွန်စွာ ဆွေးနွေးပါ ⚠" : "⚠ No abusive language — Please be respectful ⚠"}
          </span>
          <span className="text-[10px] text-[#00E5FF] font-myanmar px-4">
            {mm ? "⚠ ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့ — ပရိသတ်အားလုံးအတွက် ကောင်းမွန်စွာ ဆွေးနွေးပါ ⚠" : "⚠ No abusive language — Please be respectful ⚠"}
          </span>
        </div>
      </div>

      {/* Messages area */}
      <div
        ref={chatRef}
        className="h-[280px] overflow-y-auto px-4 py-3 space-y-3 bg-white"
        style={{ maxHeight: 280 }}
      >
        {chatMessages && chatMessages.length === 0 && (
          <p className="text-center text-[11px] text-muted-foreground font-myanmar py-8">
            {mm ? "စကားပြောခန်းမှာ မှတ်ချက်ရေးပါ" : "Be the first to chat"}
          </p>
        )}
        {chatMessages && chatMessages.map((msg) => {
          const initials = (msg.userName || "?").slice(0, 1).toUpperCase();
          const isMe = (isAuthenticated && msg.userId === currentUser?.id) || (!isAuthenticated && guestName && msg.userName === guestName);
          const timeStr = new Date(msg.createdAt).toLocaleTimeString("en-US", {
            timeZone: "Asia/Yangon",
            hour: "2-digit",
            minute: "2-digit",
            hour12: false,
          });
          return (
            <div key={msg.id} className={`flex items-start gap-2.5 ${isMe ? "flex-row-reverse" : ""}`}>
              {/* Avatar */}
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-white text-[11px] font-bold ${
                isMe ? "bg-[#5E35B1]" : "bg-[#4A148C]"
              }`}>
                {initials}
              </div>
              {/* Message bubble */}
              <div className={`max-w-[70%] ${isMe ? "items-end" : ""}`}>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[11px] font-bold text-[#333] font-myanmar">
                    {msg.userName}
                  </span>
                  {isMe && (
                    <span className="text-[9px] text-gray-400">({mm ? "ကျွန်တော်" : "Me"})</span>
                  )}
                </div>
                {/* Chat message — text only, no image/HTML rendering */}
                <div className={`rounded-2xl px-3 py-2 text-[13px] leading-relaxed font-myanmar ${
                  isMe
                    ? "bg-[#5E35B1] text-white rounded-tr-md"
                    : "bg-white border border-gray-200 text-[#333] rounded-tl-md"
                }`}>
                  {msg.message}
                </div>
                <p className="text-[9px] text-muted-foreground mt-0.5 px-1">
                  {timeStr}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Chat input */}
      <div className="bg-gradient-to-br from-[#4A148C] to-[#311B92] px-3 py-2.5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
            <User size={14} className="text-white" />
          </div>
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendChat();
              }
            }}
            placeholder={mm ? "ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့" : "No abusive language please"}
            className="flex-1 bg-white border-0 rounded-full px-4 py-2 text-[13px] focus:outline-none focus:ring-1 focus:ring-[#7B1FA2] font-myanmar placeholder:text-gray-400"
            maxLength={500}
          />
          <button
            onClick={handleSendChat}
            disabled={!chatInput.trim() || sendChatMutation.isPending}
            className="w-9 h-9 rounded-full bg-[#00E5FF] flex items-center justify-center btn-press disabled:opacity-40 flex-shrink-0"
          >
            <Send size={14} className="text-[#1A237E]" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Page ───────────────────────────────────────────────────────────
export default function Myanmar2D() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const mm = lang === "mm";

  // Audio unlock
  useAudioUnlock();

  // ─── Copy state ────────────────────────────────────────────────────
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [showPredictedNumbers, setShowPredictedNumbers] = useState(false);

  const handleCopy = (text: string, idx: number) => {
    copyToClipboard(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 1500);
  };

  // ─── Countdown timer state ─────────────────────────────────────────
  const [countdown, setCountdown] = useState({ h: 0, m: 0, s: 0, label: "" });

  useEffect(() => {
    function calcCountdown() {
      const now = new Date();
      const nowMM = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Yangon" }));
      const h = nowMM.getHours();
      const m = nowMM.getMinutes();
      const s = nowMM.getSeconds();
      const totalSec = h * 3600 + m * 60 + s;

      const morningTarget = 11 * 3600;
      const eveningTarget = 16 * 3600 + 30 * 60;

      let diff = 0;
      let label = "";
      if (totalSec < morningTarget) {
        diff = morningTarget - totalSec;
        label = mm ? "မနက် ၁၁:၀၀ ကျန်ချိန်" : "Until Morning 11:00";
      } else if (totalSec < eveningTarget) {
        diff = eveningTarget - totalSec;
        label = mm ? "ညနေ ၄:၃၀ ကျန်ချိန်" : "Until Evening 4:30";
      } else {
        const nextDay = 24 * 3600 - totalSec + morningTarget;
        diff = nextDay;
        label = mm ? "မနက်ဖြန် မနက် ၁၁:၀၀ ကျန်ချိန်" : "Until Tomorrow 11:00";
      }

      const rh = Math.floor(diff / 3600);
      const rm = Math.floor((diff % 3600) / 60);
      const rs = diff % 60;
      setCountdown({ h: rh, m: rm, s: rs, label });
    }
    calcCountdown();
    const id = setInterval(calcCountdown, 1000);
    return () => clearInterval(id);
  }, [mm]);

  // ─── Session detection (morning vs evening) ───────────────────────
  const getCurrentSession = (): 'morning' | 'evening' => {
    const now = new Date();
    const nowMM = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Yangon" }));
    const h = nowMM.getHours();
    const m = nowMM.getMinutes();
    const totalMin = h * 60 + m;
    // Morning session: before 12:30 PM (12:30 Myanmar time)
    // Evening session: after 12:30 PM
    if (totalMin < 12 * 60 + 30) return 'morning';
    return 'evening';
  };
  const [currentSession, setCurrentSession] = useState<'morning' | 'evening'>(getCurrentSession());
  
  // Update session every minute
  useEffect(() => {
    const id = setInterval(() => {
      setCurrentSession(getCurrentSession());
    }, 60000);
    return () => clearInterval(id);
  }, []);

  // ─── AI Prediction state ──────────────────────────────────────────
  const [prediction, setPrediction] = useState<{
    morningPredictions: string[];
    eveningPredictions: string[];
    hotNumbers: string[];
    coldNumbers: string[];
    analysisMm: string;
    analysisEn: string;
    confidenceLevel: number;
    disclaimer: string;
  } | null>(null);

  // ─── Data fetching ────────────────────────────────────────────────
  const { data: latest } = trpc.myanmar2d.getLatest.useQuery(undefined, { refetchInterval: 15_000, refetchIntervalInBackground: true });
  const { data: history } = trpc.myanmar2d.getHistory.useQuery({ page: 1, pageSize: 120 }, { refetchInterval: 15_000, refetchIntervalInBackground: true });
  const { data: analysis } = trpc.myanmar2d.getAnalysis.useQuery(undefined, { refetchInterval: 60_000, refetchIntervalInBackground: true });
  const { data: liveResponse } = trpc.myanmar2d.getLive.useQuery(undefined, { refetchInterval: 15_000, refetchIntervalInBackground: true });
  const { data: latestThaiLottery } = trpc.thaiLottery.getLatest.useQuery(undefined, { refetchInterval: 300_000, refetchIntervalInBackground: true });
  const { data: dailyPrediction } = trpc.prediction.getDailyMyanmar2d.useQuery(undefined, { refetchInterval: 60_000, refetchIntervalInBackground: true });

  const predictMutation = trpc.prediction.myanmar2d.useMutation({
    onSuccess: (data) => setPrediction(data),
    onError: () => toast.error(mm ? "ကြိုတင်ခန့်မှန်းချက် ရယူ၍မရပါ" : "Failed to get prediction"),
  });

  // ─── Bell sound toggle ────────────────────────────────────────────
  const [bellEnabled, setBellEnabled] = useState(() => {
    try {
      const stored = localStorage.getItem("myanmar2d_bell_enabled");
      return stored === null ? true : stored === "true";
    } catch { return true; }
  });

  useEffect(() => {
    try { localStorage.setItem("myanmar2d_bell_enabled", String(bellEnabled)); } catch {}
  }, [bellEnabled]);

  const handleBellToggle = () => {
    setBellEnabled(prev => {
      if (prev) {
        playBellSound();
        toast.success(mm ? "ခေါင်းလောင်း ဖွင့်ထားပါပြီ" : "Bell sound enabled");
      } else {
        toast.info(mm ? "ခေါင်းလောင်း ပိတ်ထားပါပြီ" : "Bell sound disabled");
      }
      return !prev;
    });
  };

  // Bell on new results — plays on EVERY new result (not just first time)
  const prevResultCount = useRef<number | null>(null);

  useEffect(() => {
    if (latest && latest.length > 0) {
      if (prevResultCount.current === null) {
        prevResultCount.current = latest.length;
        return;
      }
      if (latest.length > prevResultCount.current && bellEnabled) {
        playBellSound();
        toast.success(mm ? "🔔 ရလဒ်အသစ် ထွက်ပါပြီ!" : "🔔 New result available!");
      }
      prevResultCount.current = latest.length;
    }
  }, [latest, mm, bellEnabled]);

  // ─── Chat overlay state ───────────────────────────────────────────
  const [chatOpen, setChatOpen] = useState(() => {
    if (typeof window === "undefined") return false;
    return new URLSearchParams(window.location.search).get("chat") === "1";
  });

  // ─── Auth ─────────────────────────────────────────────────────────
  const { data: currentUser, isLoading: authLoading } = trpc.auth.me.useQuery();
  const isAuthenticated = !!currentUser;

  // ─── Guest name (persisted in localStorage for anonymous chat identity) ──
  const [guestName] = useState(() => {
    try {
      let name = localStorage.getItem("myanmar2d_guest_name");
      if (!name) {
        name = `အလျာသား${Math.floor(Math.random() * 9000 + 1000)}`;
        localStorage.setItem("myanmar2d_guest_name", name);
      }
      return name;
    } catch {
      return `အလျာသား${Math.floor(Math.random() * 9000 + 1000)}`;
    }
  });

  // ─── Chat state ───────────────────────────────────────────────────
  const [chatInput, setChatInput] = useState("");
  const chatRef = useRef<HTMLDivElement>(null);
  const { data: chatMessages, refetch: refetchChat } = trpc.myanmar2d.getChatMessages.useQuery();
  const sendChatMutation = trpc.myanmar2d.sendChatMessage.useMutation({
    onSuccess: () => {
      setChatInput("");
      refetchChat();
      setTimeout(() => {
        if (chatRef.current) {
          chatRef.current.scrollTop = chatRef.current.scrollHeight;
        }
      }, 100);
    },
    onError: () => toast.error(mm ? "စာပို့၍မရပါ" : "Failed to send message"),
  });

  const handleSendChat = () => {
    const msg = chatInput.trim();
    if (!msg) return;

    // Check for blocked content (phone numbers, URLs)
    if (containsBlockedContent(msg)) {
      // Check if it's profanity specifically
      if (containsProfanity(msg)) {
        toast.error(mm ? "ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့" : "No abusive language allowed");
      } else {
        toast.error(mm ? "ဖုန်းနံပါတ်နဲ့ link တွေ ပို့ခွင့်မရှိပါ" : "Phone numbers and links are not allowed");
      }
      return;
    }

    const payload: { message: string; userName?: string } = { message: msg };
    if (!isAuthenticated) {
      payload.userName = guestName;
    }
    sendChatMutation.mutate(payload);
  };

  // ─── Verified result data ───────────────────────────────────────────
  const todayMyanmarStr = getTodayMyanmarStr();
  const liveLatest = latest;

  // Find today's DB results for settled 2D numbers
  const morningResult = liveLatest?.find((x) => {
    const rdStr = String(x.resultDate);
    const d = new Date(rdStr);
    const rDate = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
    return x.session === "morning" && rDate === todayMyanmarStr;
  });
  const eveningResult = liveLatest?.find((x) => {
    const rdStr = String(x.resultDate);
    const d = new Date(rdStr);
    const rDate = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
    return x.session === "evening" && rDate === todayMyanmarStr;
  });

  // Format date for display
  const todayDisplay = (() => {
    const parts = todayMyanmarStr.split("-");
    const year = parts[0];
    const month = parseInt(parts[1], 10);
    const day = parseInt(parts[2], 10);
    return `${day}/${month}/${year.slice(2)}`;
  })();
  const liveMarket = getCurrentDayLiveMarket(liveResponse?.success ? liveResponse.live : null);
  const providerResults = liveResponse?.success ? liveResponse.results : [];
  const providerMorning = getCurrentDayVerifiedMarketResult(providerResults, "morning");
  const providerEvening = getCurrentDayVerifiedMarketResult(providerResults, "evening");
  const displayMorningResult = morningResult || (providerMorning ? {
    winningNumber: providerMorning.twod,
    setNumber: providerMorning.set,
    valueNumber: providerMorning.value,
  } : undefined);
  const displayEveningResult = eveningResult || (providerEvening ? {
    winningNumber: providerEvening.twod,
    setNumber: providerEvening.set,
    valueNumber: providerEvening.value,
  } : undefined);
  const scheduleMarketFor = (session: "morning" | "evening") => {
    const settledResult = session === "morning" ? displayMorningResult : displayEveningResult;
    if (settledResult?.setNumber && settledResult?.valueNumber) {
      return {
        set: String(settledResult.setNumber),
        value: String(settledResult.valueNumber),
      };
    }
    if (getMyanmarMarketSession() === session && liveMarket?.set && liveMarket?.value) {
      return {
        set: liveMarket.set,
        value: liveMarket.value,
      };
    }
    return { set: "--", value: "--" };
  };
  const scheduleMorningMarket = scheduleMarketFor("morning");
  const scheduleEveningMarket = scheduleMarketFor("evening");
  const latest3D = getThaiLotteryThreeDigit(latestThaiLottery?.firstPrize);
  const chatLiveTwoDRaw = String(liveMarket?.twod || "").trim();
  const chatLiveTwoD = /^\d{1,2}$/.test(chatLiveTwoDRaw) ? chatLiveTwoDRaw.padStart(2, "0") : "--";
  const hasChatMarket = Boolean(liveMarket?.set && liveMarket?.value && chatLiveTwoD !== "--");

  return (
    <div className="min-h-screen bg-[#050505]">
      <LiveHeader mm={mm} navigate={navigate} showChatBtn={!chatOpen} onChatToggle={() => setChatOpen(true)} />

      <div className="max-w-[480px] mx-auto px-3 pb-20">

        {/* ─── Chat Overlay ──────────────────────────────────────────── */}
        {chatOpen && (
          <div className="fixed inset-0 z-[100] flex flex-col bg-white">
            {/* Dedicated Chat header */}
            <div className="bg-gradient-to-br from-[#4A148C] to-[#311B92] text-white sticky top-0 z-50">
              <div className="max-w-[480px] mx-auto px-4 py-2 flex items-center gap-3">
                <button onClick={() => setChatOpen(false)} className="text-white btn-press">
                  <ArrowLeft size={20} />
                </button>
                <h1 className="font-display text-base font-bold flex-1">
                  {mm ? "ဆွေးနွေးခန်း" : "Live Chat"}
                </h1>
              </div>
            </div>

            {/* Live 2D market strip — lets users chat while watching current values */}
            <div className="border-b border-[#d99a25]/55 bg-[#120d07] text-[#fff7e8]">
              <div className="mx-auto grid max-w-[480px] grid-cols-[1fr_1fr_auto] items-center gap-2 px-3 py-1.5">
                <div className="min-w-0 border-r border-[#735022] pr-2">
                  <span className="mr-1 text-[10px] font-black text-[#f2a321]">SET</span>
                  <span className={`font-mono text-xs font-black ${hasChatMarket ? "text-[#39d98a]" : "text-[#8a806e]"}`}>{liveMarket?.set || "--"}</span>
                </div>
                <div className="min-w-0">
                  <span className="mr-1 text-[10px] font-black text-[#f2a321]">VAL</span>
                  <span className={`font-mono text-xs font-black ${hasChatMarket ? "text-[#39d98a]" : "text-[#8a806e]"}`}>{liveMarket?.value || "--"}</span>
                </div>
                <div className="flex items-center gap-1.5 rounded-md border border-[#725120] bg-[#1b1208] px-2 py-1">
                  <span className="text-[10px] font-black text-[#f2a321]">2D</span>
                  <span className={`prize-number text-lg font-black leading-none ${hasChatMarket ? "text-[#ffad1f]" : "text-[#8a806e]"}`}>{chatLiveTwoD}</span>
                </div>
              </div>
            </div>

            {/* Scrolling warning text */}
            <div className="max-w-[480px] mx-auto w-full overflow-hidden bg-gradient-to-r from-[#EDE7F6] via-[#E8EAF6] to-[#EDE7F6] border-b border-[#B39DDB]">
              <div className="flex whitespace-nowrap py-1.5" style={{ animation: 'marquee 12s linear infinite' }}>
                <span className="text-[11px] text-[#5E35B1] font-myanmar px-4">
                  {mm ? "⚠ ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့ — ပရိသတ်အားလုံးအတွက် ကောင်းမွန်စွာ ဆွေးနွေးပါ ⚠" : "⚠ No abusive or offensive language — Please be respectful to all users ⚠"}
                </span>
                <span className="text-[11px] text-[#5E35B1] font-myanmar px-4">
                  {mm ? "⚠ ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့ — ပရိသတ်အားလုံးအတွက် ကောင်းမွန်စွာ ဆွေးနွေးပါ ⚠" : "⚠ No abusive or offensive language — Please be respectful to all users ⚠"}
                </span>
                <span className="text-[11px] text-[#5E35B1] font-myanmar px-4">
                  {mm ? "⚠ ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့ — ပရိသတ်အားလုံးအတွက် ကောင်းမွန်စွာ ဆွေးနွေးပါ ⚠" : "⚠ No abusive or offensive language — Please be respectful to all users ⚠"}
                </span>
              </div>
            </div>

            {/* Messages area — full screen */}
            <div
              ref={chatRef}
              className="flex-1 overflow-y-auto px-4 py-3 space-y-3 bg-[#f5f5f5]"
            >
              {chatMessages && chatMessages.length === 0 && (
                <p className="text-center text-[12px] text-muted-foreground font-myanmar py-12">
                  {mm ? "စကားပြောခန်းမှာ မှတ်ချက်ရေးပါ" : "Be the first to chat"}
                </p>
              )}
              {chatMessages && chatMessages.map((msg) => {
                const initials = (msg.userName || "?").slice(0, 1).toUpperCase();
                const isMe = (isAuthenticated && msg.userId === currentUser?.id) || (!isAuthenticated && guestName && msg.userName === guestName);
                const timeStr = new Date(msg.createdAt).toLocaleTimeString("en-US", {
                  timeZone: "Asia/Yangon",
                  hour: "2-digit",
                  minute: "2-digit",
                  hour12: false,
                });
                return (
                  <div key={msg.id} className={`flex items-start gap-2.5 ${isMe ? "flex-row-reverse" : ""}`}>
                    {/* Avatar */}
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 text-white text-[11px] font-bold ${
                      isMe ? "bg-[#5E35B1]" : "bg-[#4A148C]"
                    }`}>
                      {initials}
                    </div>
                    {/* Message bubble */}
                    <div className={`max-w-[75%] ${isMe ? "items-end" : ""}`}>
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="text-[11px] font-bold text-[#333] font-myanmar">
                          {msg.userName}
                        </span>
                        {isMe && (
                          <span className="text-[9px] text-gray-400">({mm ? "ကျွန်တော်" : "Me"})</span>
                        )}
                      </div>
                      {/* Chat message — text only, no image/HTML rendering */}
                      <div className={`rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed font-myanmar ${
                        isMe
                          ? "bg-[#5E35B1] text-white rounded-tr-md"
                          : "bg-white border border-gray-200 text-[#333] rounded-tl-md"
                      }`}>
                        {msg.message}
                      </div>
                      <p className="text-[9px] text-muted-foreground mt-0.5 px-1">
                        {timeStr}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Chat input — fixed at bottom */}
            <div className="bg-gradient-to-br from-[#4A148C] to-[#311B92] px-3 py-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                  <User size={14} className="text-white" />
                </div>
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendChat();
                    }
                  }}
                  placeholder={mm ? "ဆဲဆိုရိုင်းစိုင်းသော စာသားများ မရေးသားပါနဲ့" : "No abusive language please"}
                  className="flex-1 bg-white border-0 rounded-full px-4 py-2.5 text-[13px] focus:outline-none focus:ring-1 focus:ring-[#7B1FA2] font-myanmar placeholder:text-gray-400"
                  maxLength={500}
                />
                <button
                  onClick={handleSendChat}
                  disabled={!chatInput.trim() || sendChatMutation.isPending}
                  className="w-10 h-10 rounded-full bg-[#00E5FF] flex items-center justify-center btn-press disabled:opacity-40 flex-shrink-0"
                >
                  <Send size={16} className="text-[#1A237E]" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ─── Verified black-and-gold 2D result board ───────────────── */}
        <LiveCard
          mm={mm}
          morningResult={displayMorningResult}
          eveningResult={displayEveningResult}
          todayDisplay={todayDisplay}
          liveMarket={liveMarket}
        />

        <ResultSchedule
          mm={mm}
          morningMarket={scheduleMorningMarket}
          eveningMarket={scheduleEveningMarket}
        />

        <HotAndWeekSummary
          mm={mm}
          history={history}
          hasTodayResult={Boolean(displayMorningResult?.winningNumber || displayEveningResult?.winningNumber)}
          latest3D={latest3D}
          prediction={dailyPrediction ?? prediction}
        />

        <button
          onClick={() => {
            setShowPredictedNumbers((value) => !value);
            if (!prediction && !predictMutation.isPending) {
              predictMutation.mutate({ language: lang });
            }
          }}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-[#d99a25] bg-[#151007] px-3 py-2.5 text-sm font-black text-[#f8c45d] shadow-[0_5px_16px_rgba(0,0,0,0.36)] btn-press font-myanmar"
          aria-expanded={showPredictedNumbers}
        >
          <Sparkles size={16} />
          {showPredictedNumbers ? (mm ? "ခန့်မှန်းဂဏန်းကို ဖျောက်ရန်" : "Hide predicted numbers") : (mm ? "ခန့်မှန်းဂဏန်း ကြည့်ရန်" : "View predicted numbers")}
        </button>

        {showPredictedNumbers && (
          <section className="mt-2 rounded-xl border border-[#d99a25] bg-[#0b0b0b] p-3 shadow-[0_8px_20px_rgba(0,0,0,0.4)] animate-fade-in-up">
            <div className="mb-2 flex items-center justify-between border-b border-[#65491d] pb-2">
              <div className="flex items-center gap-1.5">
                <Sparkles size={15} className="text-[#f8c45d]" />
                <p className="text-xs font-black text-[#fff2d2] font-myanmar">{mm ? "ခန့်မှန်းဂဏန်း" : "Predicted numbers"}</p>
              </div>
              <span className="text-[9px] text-[#bca97d] font-myanmar">{mm ? "မှတ်တမ်းအပေါ်မူတည်သည်" : "Based on history"}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-lg border border-[#7a431b] bg-[#17100a] p-2">
                <div className="mb-1.5 flex items-center gap-1">
                  <Flame size={13} className="text-[#ff8a3d]" />
                  <span className="text-[11px] font-bold text-[#ffbd83] font-myanmar">{mm ? "ကြာခဏပေါ်" : "Often appearing"}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {(analysis?.hotNumbers?.length ? analysis.hotNumbers : [{ number: "--", count: 0 }, { number: "--", count: 0 }, { number: "--", count: 0 }]).slice(0, 6).map((item, index) => (
                    <span key={`${item.number}-${index}`} className="rounded-md border border-[#a85d25] bg-[#241408] px-1.5 py-1 font-mono text-sm font-black text-[#ffbd83]">
                      {item.number}
                    </span>
                  ))}
                </div>
              </div>
              <div className="rounded-lg border border-[#285e86] bg-[#09131b] p-2">
                <div className="mb-1.5 flex items-center gap-1">
                  <Snowflake size={13} className="text-[#6bc8ff]" />
                  <span className="text-[11px] font-bold text-[#9bdbff] font-myanmar">{mm ? "ကြာမပေါ်" : "Less appearing"}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {(analysis?.coldNumbers?.length ? analysis.coldNumbers : [{ number: "--", count: 0 }, { number: "--", count: 0 }, { number: "--", count: 0 }]).slice(0, 6).map((item, index) => (
                    <span key={`${item.number}-${index}`} className="rounded-md border border-[#34749f] bg-[#0b1c28] px-1.5 py-1 font-mono text-sm font-black text-[#a6e0ff]">
                      {item.number}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <p className="mt-2 text-[9px] leading-relaxed text-[#a89472] font-myanmar">{mm ? "ဤဂဏန်းများသည် အတည်ပြုထွက်မှတ်တမ်းအပေါ်မူတည်သော အချက်အလက်သာဖြစ်ပြီး ရလဒ်ကိုအာမခံမထားပါ။" : "These are history-based indicators only and do not guarantee a result."}</p>
          </section>
        )}

        <button
          onClick={() => setShowDetails((value) => !value)}
          className="mt-2 w-full rounded-xl border border-[#76521a] bg-[#151007] px-3 py-2 text-xs font-bold text-[#f8c45d] btn-press"
        >
          {showDetails ? (mm ? "အသေးစိတ်ကို ဖျောက်ရန်" : "Hide details") : (mm ? "မှတ်တမ်းနှင့် အသေးစိတ်ကြည့်ရန်" : "View history and details")}
        </button>

        {showDetails && <>
        {/* ─── Countdown Timer ─────────────────────────────────────── */}
        <div className="mt-3 bg-white rounded-xl px-4 py-3 flex items-center justify-between shadow-sm animate-fade-in-up">
          <div className="flex items-center gap-2">
            <Clock size={14} className="text-muted-foreground" />
            <span className="text-[11px] text-muted-foreground font-myanmar">{countdown.label}</span>
          </div>
          <div className="flex items-center gap-1 font-mono font-bold text-foreground text-[15px]">
            <span className="bg-gray-100 rounded-lg px-2 py-1 text-[13px]">{String(countdown.h).padStart(2, "0")}</span>
            <span className="text-muted-foreground">:</span>
            <span className="bg-gray-100 rounded-lg px-2 py-1 text-[13px]">{String(countdown.m).padStart(2, "0")}</span>
            <span className="text-muted-foreground">:</span>
            <span className="bg-gray-100 rounded-lg px-2 py-1 text-[13px]">{String(countdown.s).padStart(2, "0")}</span>
          </div>
        </div>

        {/* ─── Bell Sound Toggle ───────────────────────────────────── */}
        <div className="mt-3 bg-white rounded-xl px-4 py-3 flex items-center justify-between shadow-sm animate-fade-in-up">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${bellEnabled ? 'bg-purple-100' : 'bg-gray-100'}`}>
              {bellEnabled ? <Volume2 size={14} className="text-purple-600" /> : <VolumeX size={14} className="text-gray-400" />}
            </div>
            <div>
              <p className="text-[12px] font-bold text-foreground font-myanmar">{mm ? "ရလဒ် အသိပေးခေါင်းလောင်း" : "Result Alert Bell"}</p>
              <p className="text-[10px] text-muted-foreground font-myanmar">{bellEnabled ? (mm ? "ရလဒ်အသစ် ထွက်ရင် မြည်မည်" : "Chimes when new results arrive") : (mm ? "ခေါင်းလောင်း ပိတ်ထားသည်" : "Bell is muted")}</p>
            </div>
          </div>
          <button
            onClick={handleBellToggle}
            className={`relative w-12 h-7 rounded-full transition-colors duration-300 flex-shrink-0 ${bellEnabled ? 'bg-purple-500' : 'bg-gray-300'}`}
            role="switch"
            aria-checked={bellEnabled}
          >
            <span
              className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow-md transition-transform duration-300 ${bellEnabled ? 'translate-x-5.5' : 'translate-x-0.5'}`}
              style={{ transform: bellEnabled ? 'translateX(22px)' : 'translateX(2px)' }}
            />
          </button>
        </div>

        {/* ─── Hot/Cold Analysis ───────────────────────────────────── */}
        {analysis && (
          <div className="mt-3 bg-white rounded-xl p-4 border border-purple-200 shadow-sm animate-fade-in-up">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                  <BarChart3 size={14} className="text-purple-600" />
                </div>
                <div>
                  <p className="text-[12px] font-bold text-foreground font-myanmar font-myanmar-display">
                    {mm ? "ဂဏန်း ခွဲခြမ်းစိတ်ဖြာချက်" : "Number Analysis"}
                  </p>
                  <p className="text-[10px] text-muted-foreground font-myanmar">
                    {mm ? "ရက် ၃၀ အတွင်း ခွဲခြမ်းစိတ်ဖြာချက်" : "Based on last 30 days"}
                  </p>
                </div>
              </div>
              <span className="text-[9px] text-muted-foreground bg-gray-50 px-2 py-0.5 rounded-full">
                {analysis.totalResults} {mm ? "ရလဒ်" : "results"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-3">
              <div>
                <div className="flex items-center gap-1 mb-1.5">
                  <Flame size={12} className="text-red-500" />
                  <span className="text-[10px] font-bold text-red-600 font-myanmar">{mm ? "ကြာခဏပေါ်" : "Hot Numbers"}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {analysis.hotNumbers.map((item) => (
                    <span key={item.number} className="text-[12px] font-bold text-red-600 bg-red-50 border border-red-200 rounded-lg px-2 py-0.5 flex items-center gap-0.5">
                      {item.number}
                      <span className="text-[8px] text-red-400">×{item.count}</span>
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1 mb-1.5">
                  <Snowflake size={12} className="text-blue-500" />
                  <span className="text-[10px] font-bold text-blue-600 font-myanmar">{mm ? "ကြာမပေါ်" : "Cold Numbers"}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {analysis.coldNumbers.map((item) => (
                    <span key={item.number} className="text-[12px] font-bold text-blue-600 bg-blue-50 border border-blue-200 rounded-lg px-2 py-0.5 flex items-center gap-0.5">
                      {item.number}
                      <span className="text-[8px] text-blue-400">×{item.count}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {analysis.consecutivePairs.length > 0 && (
              <div className="mb-3">
                <div className="flex items-center gap-1 mb-1.5">
                  <TrendingUp size={11} className="text-purple-500" />
                  <span className="text-[10px] font-bold text-purple-600 font-myanmar">{mm ? "တွဲထွက်ဂဏန်း" : "Consecutive Pairs"}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {analysis.consecutivePairs.map((item) => {
                    const [a, b] = item.pair.split("-");
                    return (
                      <span key={item.pair} className="text-[11px] font-bold text-purple-700 bg-purple-50 border border-purple-200 rounded-lg px-2 py-0.5 flex items-center gap-0.5">
                        {a}→{b}
                        <span className="text-[8px] text-purple-400">×{item.count}</span>
                      </span>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="mb-3">
              <div className="flex items-center gap-1 mb-1.5">
                <BarChart3 size={11} className="text-teal-500" />
                <span className="text-[10px] font-bold text-teal-600 font-myanmar">{mm ? "တစ်လုံးဂဏန်း ခွဲခြမ်းစိတ်ဖြာချက်" : "Single Digit Analysis"}</span>
              </div>
              <div className="flex items-end gap-1 h-10">
                {analysis.digitAnalysis.map((item) => {
                  const maxCount = Math.max(...analysis.digitAnalysis.map(d => d.count));
                  const height = maxCount > 0 ? Math.max(4, (item.count / maxCount) * 100) : 4;
                  return (
                    <div key={item.digit} className="flex flex-col items-center flex-1" style={{ animationDelay: `${parseInt(item.digit) * 30}ms` }}>
                      <span className="text-[8px] text-muted-foreground mb-0.5">{item.count}</span>
                      <div
                        className="w-full rounded-t bg-gradient-to-t from-teal-500 to-teal-300 transition-all duration-500"
                        style={{ height: `${height}%`, minHeight: '4px' }}
                      />
                      <span className="text-[8px] font-bold text-teal-600 mt-0.5">{item.digit}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-1 mb-1.5">
                <BarChart3 size={11} className="text-purple-500" />
                <span className="text-[10px] font-bold text-purple-600 font-myanmar">{mm ? "အကြိမ်အရေအတွက်" : "Frequency Chart"}</span>
              </div>
              <div className="space-y-1">
                {analysis.allFrequencies
                  .filter(f => f.count > 0)
                  .sort((a, b) => b.count - a.count)
                  .slice(0, 20)
                  .map((item) => {
                    const maxCount = Math.max(...analysis.allFrequencies.filter(f => f.count > 0).map(f => f.count));
                    const width = maxCount > 0 ? Math.max(8, (item.count / maxCount) * 100) : 8;
                    return (
                      <div key={item.number} className="flex items-center gap-2">
                        <span className="w-6 text-right text-[11px] font-mono font-bold text-[#333]">{item.number}</span>
                        <div className="flex-1 bg-gray-100 rounded-full h-3 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-purple-400 to-purple-600 transition-all duration-500"
                            style={{ width: `${width}%` }}
                          />
                        </div>
                        <span className="w-4 text-[9px] text-muted-foreground text-right">{item.count}</span>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>
        )}

        {/* ─── Prediction Section ──────────────────────────────────── */}
        <div className="mt-3 bg-white rounded-xl p-4 border border-purple-200 shadow-sm animate-fade-in-up">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                <Sparkles size={14} className="text-purple-600" />
              </div>
              <div>
                <p className="text-[12px] font-bold text-foreground font-myanmar">
                  {mm ? "၂ဒီ ခန့်မှန်းဂဏန်း" : "2D Predicted Numbers"}
                </p>
                <p className="text-[10px] text-muted-foreground font-myanmar">
                  {currentSession === 'morning'
                    ? (mm ? "မနက်ပိုင်း session (၁၁:၀၀ AM)" : "Morning session (11:00 AM)")
                    : (mm ? "ညနေပိုင်း session (၄:၃၀ PM)" : "Evening session (4:30 PM)")}
                </p>
              </div>
            </div>
            <button
              onClick={() => predictMutation.mutate({ language: lang })}
              disabled={predictMutation.isPending}
              className="flex items-center gap-1.5 bg-purple-100 border border-purple-300 text-purple-700 text-[11px] font-bold px-3 py-2 rounded-xl btn-press font-myanmar"
            >
              {predictMutation.isPending ? (
                <RefreshCw size={12} className="animate-spin" />
              ) : (
                <Sparkles size={12} />
              )}
              {mm ? "ခန့်မှန်းဂဏန်း ကြည့်ရန်" : "View predicted numbers"}
            </button>
          </div>

          {prediction ? (
            <div className="space-y-3">
              {/* Show ONLY the current session's prediction */}
              <div className="grid grid-cols-1 gap-2">
                {currentSession === 'morning' ? (
                  <div className="bg-[#EDE7F6] border border-purple-200 rounded-xl p-3">
                    <div className="flex items-center gap-1 mb-2">
                      <Sun size={12} className="text-purple-500" />
                      <span className="text-[10px] font-bold text-purple-700 font-myanmar">{mm ? "မနက်ပိုင်း (၁၁:၀၀ AM)" : "Morning Session (11:00 AM)"}</span>
                      <span className="ml-auto text-[9px] bg-purple-500 text-white px-2 py-0.5 rounded-full font-bold">LIVE</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {prediction.morningPredictions.map((n) => (
                        <span key={n} className="prize-number text-xl font-black text-purple-600 bg-white border border-purple-200 rounded-lg px-3 py-1">{n}</span>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#E8EAF6] border border-indigo-200 rounded-xl p-3">
                    <div className="flex items-center gap-1 mb-2">
                      <Moon size={12} className="text-indigo-500" />
                      <span className="text-[10px] font-bold text-indigo-700 font-myanmar">{mm ? "ညနေပိုင်း (၄:၃၀ PM)" : "Evening Session (4:30 PM)"}</span>
                      <span className="ml-auto text-[9px] bg-indigo-500 text-white px-2 py-0.5 rounded-full font-bold">LIVE</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {prediction.eveningPredictions.map((n) => (
                        <span key={n} className="prize-number text-xl font-black text-indigo-600 bg-white border border-indigo-200 rounded-lg px-3 py-1">{n}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <div className="flex items-center gap-1 mb-1">
                    <TrendingUp size={11} className="text-red-500" />
                    <span className="text-[10px] font-bold text-red-600 font-myanmar">{mm ? "ကြာခဏပေါ်" : "Hot"}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {prediction.hotNumbers.map((n) => (
                      <span key={n} className="text-[12px] font-bold text-red-600 bg-red-50 border border-red-200 rounded-lg px-2 py-0.5">{n}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1 mb-1">
                    <TrendingDown size={11} className="text-blue-500" />
                    <span className="text-[10px] font-bold text-blue-600 font-myanmar">{mm ? "ကြာမပေါ်" : "Cold"}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {prediction.coldNumbers.map((n) => (
                      <span key={n} className="text-[12px] font-bold text-blue-600 bg-blue-50 border border-blue-200 rounded-lg px-2 py-0.5">{n}</span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-purple-50 border border-purple-200 rounded-xl p-3">
                <p className="text-[11px] text-foreground font-myanmar leading-relaxed">
                  {mm ? prediction.analysisMm : prediction.analysisEn}
                </p>
              </div>

              <div className="flex items-start gap-1.5">
                <AlertTriangle size={11} className="text-amber-500 mt-0.5 flex-shrink-0" />
                <p className="text-[10px] text-muted-foreground font-myanmar">{prediction.disclaimer}</p>
              </div>
            </div>
          ) : (
            <p className="text-[11px] text-muted-foreground font-myanmar text-center py-2">
              {mm ? "\"ခန့်မှန်းဂဏန်း ကြည့်ရန်\" ကို နှိပ်ပြီး ခန့်မှန်းချက်ကိုကြည့်ပါ" : "Tap \"View predicted numbers\" to see the prediction"}
            </p>
          )}
        </div>

        <ResultHistory mm={mm} results={history?.results || []} />
        </>}
      </div>
    </div>
  );
}

// ─── Copy helper ─────────────────────────────────────────────────────────
async function copyToClipboard(text: string, label?: string) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success(`${label || text} copied!`);
  } catch {
    // fallback
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
    toast.success(`${label || text} copied!`);
  }
}
