import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { useLocation } from "wouter";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Gift, ArrowLeft, Star, X, MessageCircle, Send, Clock, Sparkles, Trophy, Copy, ExternalLink, Bell, Timer, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import confetti from "canvas-confetti";
import QRCode from "qrcode";

// ─── Box Opening Sound Effect ──────────────────────────────────────────────
function playBoxOpenSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const sampleRate = ctx.sampleRate;
    const duration = 1.5;
    const length = Math.ceil(sampleRate * duration);
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    const notes = [
      { freq: 523, start: 0, dur: 0.3 },
      { freq: 659, start: 0.08, dur: 0.3 },
      { freq: 784, start: 0.16, dur: 0.4 },
      { freq: 1047, start: 0.24, dur: 0.5 },
      { freq: 1319, start: 0.35, dur: 0.6 },
    ];
    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      let sample = 0;
      for (const note of notes) {
        if (t >= note.start && t < note.start + note.dur) {
          const decay = Math.exp(-(t - note.start) * 4);
          sample += Math.sin(2 * Math.PI * note.freq * (t - note.start)) * decay * 0.15;
        }
      }
      if (t < 0.6) {
        sample += (Math.random() - 0.5) * 0.03 * Math.exp(-t * 3);
      }
      data[i] = sample;
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start(0);
  } catch { /* silent fail */ }
}

// ─── Winning Sound Effect (Grand Victory Fanfare) ──────────────────────────
function playWinSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const sampleRate = ctx.sampleRate;
    const duration = 4;
    const length = Math.ceil(sampleRate * duration);
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    
    // Multi-layered fanfare: brass, chime, and drum roll
    // Layer 1: Rising brass fanfare (trumpet-like ascending notes)
    const brassNotes = [
      { freq: 523, start: 0, dur: 0.35 },
      { freq: 659, start: 0.12, dur: 0.35 },
      { freq: 784, start: 0.24, dur: 0.35 },
      { freq: 1047, start: 0.36, dur: 0.45 },
      { freq: 1319, start: 0.50, dur: 0.55 },
      { freq: 1568, start: 0.65, dur: 0.70 },
      { freq: 2093, start: 0.85, dur: 1.0 },
      // Victory chord
      { freq: 1047, start: 1.2, dur: 0.6 },
      { freq: 1319, start: 1.2, dur: 0.6 },
      { freq: 1568, start: 1.2, dur: 0.6 },
      { freq: 2093, start: 1.2, dur: 1.8 },
    ];
    
    // Layer 2: Bell/chime sparkle notes
    const chimeNotes = [
      { freq: 2637, start: 0.3, dur: 0.3 },
      { freq: 3136, start: 0.5, dur: 0.25 },
      { freq: 2637, start: 0.7, dur: 0.25 },
      { freq: 3520, start: 0.9, dur: 0.3 },
      { freq: 3136, start: 1.1, dur: 0.25 },
      { freq: 3520, start: 1.4, dur: 0.5 },
    ];
    
    // Layer 3: Drum roll (noise-based)
    const drumRollEnd = 1.0;
    
    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      let sample = 0;
      
      // Brass fanfare
      for (const note of brassNotes) {
        if (t >= note.start && t < note.start + note.dur) {
          const progress = (t - note.start) / note.dur;
          const decay = Math.exp(-progress * 2);
          const attack = Math.min(progress * 8, 1);
          const envelope = attack * decay;
          // Main tone
          sample += Math.sin(2 * Math.PI * note.freq * (t - note.start)) * envelope * 0.08;
          // First harmonic
          sample += Math.sin(2 * Math.PI * note.freq * 2 * (t - note.start)) * envelope * 0.04;
          // Second harmonic (brass character)
          sample += Math.sin(2 * Math.PI * note.freq * 3 * (t - note.start)) * envelope * 0.02;
        }
      }
      
      // Chime sparkle
      for (const note of chimeNotes) {
        if (t >= note.start && t < note.start + note.dur) {
          const progress = (t - note.start) / note.dur;
          const decay = Math.exp(-progress * 3);
          sample += Math.sin(2 * Math.PI * note.freq * (t - note.start)) * decay * 0.04;
        }
      }
      
      // Drum roll (noise with increasing intensity)
      if (t < drumRollEnd) {
        const intensity = (t / drumRollEnd) * 0.06;
        sample += (Math.random() - 0.5) * intensity;
      }
      
      // Sparkle noise trail
      if (t > 0.3 && t < 2.5) {
        sample += (Math.random() - 0.5) * 0.012 * Math.exp(-(t - 0.3) * 1.2);
      }
      
      // Final sustained chord shimmer
      if (t > 1.2 && t < 3.5) {
        const shimmer = Math.sin(2 * Math.PI * 2093 * t) * 0.02 * Math.exp(-(t - 1.2) * 0.5);
        shimmer + Math.sin(2 * Math.PI * 3136 * t) * 0.015 * Math.exp(-(t - 1.2) * 0.6);
        sample += shimmer;
      }
      
      data[i] = Math.max(-1, Math.min(1, sample));
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start(0);
  } catch { /* silent fail */ }
}

// ─── Confetti Celebration ─────────────────────────────────────────────────
let confettiFired = false;
function fireConfetti() {
  if (confettiFired) return;
  confettiFired = true;
  window.setTimeout(() => { confettiFired = false; }, 1500);

  // A short, light celebration lets users see the award screen immediately.
  confetti({
    particleCount: 42,
    spread: 58,
    origin: { x: 0.5, y: 0.22 },
    colors: ["#FFD700", "#FFB300", "#FFFFFF"],
    shapes: ["circle", "square"],
    scalar: 0.55,
    gravity: 0.9,
    ticks: 95,
    startVelocity: 16,
    disableForReducedMotion: true,
  });
}

// ─── Box Opening Animation Component ──────────────────────────────────────
function BoxAnimation({ isOpening, onOpened }: { isOpening: boolean; onOpened: () => void }) {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    if (!isOpening) { setStage(0); return; }
    const t1 = setTimeout(() => setStage(1), 80);
    const t2 = setTimeout(() => setStage(2), 350);
    const t3 = setTimeout(() => { setStage(3); onOpened(); }, 600);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [isOpening, onOpened]);

  return (
    <div className={`relative flex flex-col items-center justify-center py-8 ${stage === 1 ? 'animate-bounce' : ''}`}>
      {stage >= 3 && (
        <div className="absolute inset-0 overflow-hidden">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                backgroundColor: ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'][Math.floor(Math.random() * 5)],
                animation: `sparkle 1s ease-out ${i * 0.05}s forwards`,
                opacity: 0,
              }}
            />
          ))}
        </div>
      )}

      <div className={`relative ${stage >= 2 ? 'scale-110' : 'scale-100'} transition-transform duration-200`}>
        <div className="w-32 h-32 rounded-2xl bg-gradient-to-br from-[#E8443A] to-[#C0392B] shadow-2xl flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-4 bg-[#FFD700]" />
          <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-4 bg-[#FFD700]" />
          {stage < 2 && (
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <div className="w-10 h-6 rounded-full bg-[#FFD700] -rotate-45" />
              <div className="w-10 h-6 rounded-full bg-[#FFD700] rotate-45 -mt-6" />
            </div>
          )}
          <Gift size={40} className="text-white z-10" />
          {stage >= 3 && (
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-[#FFD700]/30 to-[#FFD700]/50 animate-pulse" />
          )}
        </div>
        <div className={`absolute -top-3 left-1/2 -translate-x-1/2 transition-all duration-300 ${stage >= 2 ? '-translate-y-16 rotate-45 opacity-0' : ''}`}>
          <div className="w-36 h-4 rounded-t-lg bg-gradient-to-b from-[#C0392B] to-[#E8443A] shadow-md" />
        </div>
      </div>

      {stage >= 2 && (
        <div className="absolute inset-0 rounded-full bg-[#FFD700]/20 blur-3xl animate-ping" />
      )}
    </div>
  );
}

// ─── Winning Popup — Celebration Style with Confetti ─────────────────────
function WinPopup({ result, onClose }: { result: any; onClose: () => void }) {
  const { lang } = useLang();
  const mm = lang === "mm";
  const [copied, setCopied] = useState(false);
  const [phone, setPhone] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [claimSubmitted, setClaimSubmitted] = useState(false);
  const [claiming, setClaiming] = useState(false);
  const popupRef = useRef<HTMLDivElement>(null);

  const claimMutation = trpc.luckyBox.claimPrize.useMutation({
    onSuccess: () => {
      setClaimSubmitted(true);
      setClaiming(false);
    },
    onError: (error) => {
      setClaiming(false);
      setPhoneError(error.message || (mm ? "အမှားဖြစ်ပါသည်" : "Error occurred"));
    },
  });

  useEffect(() => {
    // Fire confetti when popup appears
    fireConfetti();
    playWinSound();
  }, []);

  const copyRefId = () => {
    navigator.clipboard.writeText(result.referenceId).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleSubmitClaim = () => {
    // Validate phone
    const phoneClean = phone.replace(/[^0-9+]/g, "");
    if (phoneClean.length < 6) {
      setPhoneError(mm ? "ဖုန်းနံပါတ် မှန်ကန်စွာ ရိုက်ထည့်ပါ" : "Enter a valid phone number");
      return;
    }
    setPhoneError("");
    setClaiming(true);
    claimMutation.mutate({
      referenceId: result.referenceId,
      phone: phoneClean,
    });
  };

  // Floating sparkle particles for winner popup
  const sparkles = useMemo(() =>
    Array.from({ length: 40 }, (_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      size: 2 + Math.random() * 5,
      delay: Math.random() * 2,
      duration: 1 + Math.random() * 2,
      color: ['#FFD700', '#FF6B6B', '#FFB300', '#FFF', '#FFC0CB', '#4ECDC4'][Math.floor(Math.random() * 6)],
    })),
    []
  );

  // Generate QR code data with prize info
  const qrData = useMemo(() => {
    const token = result.qrToken || result.referenceId;
    const prize = result.prizeAmount || 0;
    // Encode prize amount + reference ID in QR code for verification
    return JSON.stringify({
      type: "GTL-PRIZE",
      ref: result.referenceId,
      token,
      prize,
      time: result.openedAt || Date.now(),
    });
  }, [result.qrToken, result.referenceId, result.prizeAmount, result.openedAt]);

  // Real QR code SVG generation
  const [qrSvg, setQrSvg] = useState<string>("");
  useEffect(() => {
    QRCode.toString(qrData, {
      type: "svg",
      width: 140,
      margin: 1,
      color: { dark: "#1a1a1a", light: "#FFFFFF" },
      errorCorrectionLevel: "H",
    }).then(svg => setQrSvg(svg)).catch(() => setQrSvg(""));
  }, [qrData]);

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fade-in">
      {/* Full-screen floating sparkle particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {sparkles.map((s) => (
          <div
            key={s.id}
            className="absolute rounded-full"
            style={{
              left: s.left,
              top: s.top,
              width: s.size,
              height: s.size,
              backgroundColor: s.color,
              boxShadow: `0 0 ${s.size * 3}px ${s.color}`,
              animation: `sparkle-float ${s.duration}s ease-in-out ${s.delay}s infinite alternate`,
              opacity: 0,
            }}
          />
        ))}
      </div>

      <div
        ref={popupRef}
        className="relative max-w-sm w-full bg-gradient-to-b from-[#FFF8E1] to-white rounded-2xl shadow-2xl overflow-hidden animate-scale-in max-h-[90vh] overflow-y-auto"
      >
        {/* Celebration header with animated gradient */}
        <div className="bg-gradient-to-r from-[#FFD700] via-[#FFB300] to-[#FFD700] p-5 text-center relative overflow-hidden">
          <div className="absolute inset-0">
            {Array.from({ length: 12 }).map((_, i) => (
              <div
                key={i}
                className="absolute w-1.5 h-1.5 rounded-full bg-white/80"
                style={{
                  left: `${10 + Math.random() * 80}%`,
                  top: `${10 + Math.random() * 80}%`,
                  animation: `sparkle 1.5s ease-in-out ${i * 0.1}s infinite alternate`,
                }}
              />
            ))}
          </div>
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-white/30 border-3 border-white/60 flex items-center justify-center mx-auto mb-2 animate-bounce shadow-lg">
              <Trophy size={32} className="text-white drop-shadow-md" />
            </div>
            <h2 className="text-2xl font-black text-[#333] font-myanmar-display tracking-wide">
              {mm ? "🎉 ကံထူးပါပြီ! 🎉" : "🎉 You're Lucky! 🎉"}
            </h2>
            <p className="text-[#444] font-myanmar text-sm mt-1 font-bold">
              {mm ? "ကံကောင်းဆု ရရှိပါပြီ!" : "A Lucky Gift awaits you!"}
            </p>
          </div>
        </div>

        {/* Content area */}
        <div className="p-4 space-y-3">
          {/* Lucky Stars */}
          <div className="bg-[#FFF8E1] border border-[#FFD700]/30 rounded-xl p-3 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-t from-transparent to-[#FFD700]/5" />
            <p className="text-xs text-[#555] font-myanmar mb-1.5 relative">
              {mm ? "ကံကောင်းကြယ်" : "Lucky Stars"}
            </p>
            <div className="flex items-center justify-center gap-1 mt-1 relative">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  size={24}
                  className="text-[#FFD700] fill-[#FFD700] animate-pulse"
                  style={{ animationDelay: `${i * 0.15}s` }}
                />
              ))}
            </div>
          </div>

          {/* Prize Amount — Prominent Display */}
          <div className="bg-gradient-to-br from-[#FFD700] to-[#FFA000] rounded-xl p-4 text-center shadow-lg">
            <p className="text-xs text-white/80 font-myanmar mb-1">
              {mm ? "🏆 Coins ပမာဏ" : "🏆 Coins Earned"}
            </p>
            <p className="text-3xl font-black text-white drop-shadow-lg tracking-wider" style={{ fontFamily: "'Cinzel', serif" }}>
              {(result.prizeAmount || 0).toLocaleString()} <span className="text-xl">Coins</span>
            </p>
            <p className="text-[10px] text-white/60 font-myanmar mt-1">
              {mm ? "Coins အပြည့်အဝ ပေးအပ်ပါမည်" : "Full coins will be awarded"}
            </p>
          </div>

          {/* Prize Cash Exchange Instructions */}
          <div className="bg-[#FFF3E0] border-2 border-[#FF8F00] rounded-xl p-4 shadow-sm">
            <p className="text-sm text-[#E65100] font-bold font-myanmar mb-2 flex items-center gap-2">
              <span className="text-lg">💰</span>
              {mm ? "Coins ပြောင်းလဲရန် နည်းလမ်း" : "How to Claim Your Coins"}
            </p>
            <ol className="text-xs text-[#333] font-myanmar space-y-1.5 list-decimal list-inside">
              <li>{mm ? "ဤ screen ကို screenshot ရိုက်ပါ" : "Take a screenshot of this screen"}</li>
              <li>{mm ? "ဖုန်းနံပါတ် ထည့်ပါ" : "Enter your phone number"}</li>
              <li>{mm ? "Telegram မှ Admin ကို ဆက်သွယ်ပါ" : "Contact Admin via Telegram"}</li>
              <li>{mm ? "Screenshot နှင့် Reference ID ပို့ပါ" : "Send the screenshot + Reference ID"}</li>
            </ol>
          </div>

          {/* Reference ID */}
          <div className="bg-gray-50 rounded-xl p-3">
            <p className="text-[10px] text-gray-400 font-myanmar mb-1.5">
              {mm ? "Reference ID (ဆုရယူရန် လိုအပ်)" : "Reference ID (Required for claim)"}
            </p>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-sm font-mono font-bold text-[#333] bg-white px-3 py-2 rounded-lg border-2 border-[#FFD700]/40 shadow-sm">
                {result.referenceId}
              </code>
              <button
                onClick={copyRefId}
                className="px-3 py-2 rounded-lg bg-[#FFD700] text-[#333] text-xs font-bold hover:bg-[#FFB300] transition-colors btn-press shadow-sm whitespace-nowrap"
              >
                {copied ? "✓" : "Copy"}
              </button>
            </div>
          </div>

          {/* User ID — for fraud prevention */}
          <div className="bg-gray-50 rounded-xl p-3">
            <p className="text-[10px] text-gray-400 font-myanmar mb-1.5">
              {mm ? "User ID (လိမ်ထုပ်ခြင်း ကာကွယ်ရန်)" : "User ID (Fraud prevention)"}
            </p>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-sm font-mono font-bold text-[#333] bg-white px-3 py-2 rounded-lg border-2 border-[#FFD700]/40 shadow-sm">
                {result.userId || result.guestDeviceId || "N/A"}
              </code>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(result.userId || result.guestDeviceId || "N/A").then(() => {
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  });
                }}
                className="px-3 py-2 rounded-lg bg-[#FFD700] text-[#333] text-xs font-bold hover:bg-[#FFB300] transition-colors btn-press shadow-sm whitespace-nowrap"
              >
                {copied ? "✓" : "Copy"}
              </button>
            </div>
          </div>

          {/* User ID — for fraud prevention */}
          <div className="bg-gray-50 rounded-xl p-3">
            <p className="text-[10px] text-gray-400 font-myanmar mb-1.5">
              {mm ? "User ID (လိမ်ထုပ်ခြင်း ကာကွယ်ရန်)" : "User ID (Fraud prevention)"}
            </p>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-sm font-mono font-bold text-[#333] bg-white px-3 py-2 rounded-lg border-2 border-[#FFD700]/40 shadow-sm">
                {result.userId || result.guestDeviceId || "N/A"}
              </code>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(result.userId || result.guestDeviceId || "N/A").then(() => {
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  });
                }}
                className="px-3 py-2 rounded-lg bg-[#FFD700] text-[#333] text-xs font-bold hover:bg-[#FFB300] transition-colors btn-press shadow-sm whitespace-nowrap"
              >
                {copied ? "✓" : "Copy"}
              </button>
            </div>
          </div>

          {/* QR Code — Scannable, contains prize amount + reference ID */}
          <div className="bg-white border-2 border-[#FFD700] rounded-xl p-4 text-center shadow-sm">
            <p className="text-xs text-[#333] font-bold font-myanmar mb-2">
              {mm ? `QR Code — Coins ${(result.prizeAmount || 0).toLocaleString()}` : `QR Code — ${(result.prizeAmount || 0).toLocaleString()} Coins`}
            </p>
            <div
              className="inline-block bg-white p-2 rounded-lg border border-gray-200"
              dangerouslySetInnerHTML={{ __html: qrSvg || '<div class="text-gray-400 text-xs p-4">Loading QR...</div>' }}
            />
            <p className="text-[9px] text-gray-400 font-myanmar mt-2">
              {mm ? "QR ကို scan လုပ်၍ Admin သို့ ပို့ပါ" : "Admin scans QR to verify prize"}
            </p>
          </div>

          {/* Screenshot Instruction — MOST PROMINENT */}
          <div className="bg-gradient-to-r from-[#FF5252] to-[#D32F2F] rounded-xl p-5 shadow-lg text-center animate-pulse">
            <p className="text-xl text-white font-black font-myanmar mb-1 flex items-center justify-center gap-2">
              <span className="text-2xl">📸</span>
              {mm ? "စခရင်ရှော့ ရိုက်ပို့ပါ!" : "TAKE A SCREENSHOT!"}
            </p>
            <p className="text-sm text-white/90 font-myanmar">
              {mm ? "ဤ screen ကို screenshot ရိုက်ပြီး Telegram မှ Admin ကို ချက်ချင်း ပို့ပါ" : "Screenshot this screen and send to Admin on Telegram immediately"}
            </p>
            <p className="text-[10px] text-white/60 font-myanmar mt-2">
              {mm ? "⚠️ ပထမဆုံးပို့သူသာ Coins ရရှိပါမည် — ထပ်ပို့ခြင်း အသုံးမဝင်ပါ" : "⚠️ Only the first claimant will receive the coins — duplicates rejected"}
            </p>
          </div>

          {/* Phone Number Input */}
          {!claimSubmitted ? (
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
              <p className="text-xs text-[#333] font-bold font-myanmar mb-2">
                {mm ? "ဆုရရှိသူ ဖုန်းနံပါတ်" : "Winner's Phone Number"}
              </p>
              <input
                type="tel"
                value={phone}
                onChange={(e) => { setPhone(e.target.value); setPhoneError(""); }}
                placeholder={mm ? "09xxxxxxxxx" : "09xxxxxxxxx"}
                className="w-full px-4 py-2.5 rounded-lg bg-white border-2 border-[#FFD700]/40 text-[#333] text-base font-myanmar outline-none focus:border-[#FFD700] transition-colors"
                disabled={claiming}
              />
              {phoneError && (
                <p className="text-xs text-[#E8443A] font-myanmar mt-1">{phoneError}</p>
              )}
              <button
                onClick={handleSubmitClaim}
                disabled={claiming}
                className="mt-3 w-full py-3 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#FFB300] text-[#333] font-bold text-sm btn-press shadow-md disabled:opacity-50 transition-all"
              >
                {claiming
                  ? (mm ? "ပို့နေပါသည်..." : "Submitting...")
                  : (mm ? "ဆု တောင်းခံရန်" : "Submit Claim")
                }
              </button>
            </div>
          ) : (
            <div className="bg-green-50 border-2 border-green-300 rounded-xl p-4 text-center">
              <p className="text-base text-green-700 font-bold font-myanmar mb-1">
                ✓ {mm ? "ဆု တောင်းခံပြီးပါပြီ!" : "Claim submitted!"}
              </p>
              <p className="text-xs text-green-600 font-myanmar">
                {mm ? "Admin မှ Telegram မှ ဆက်သွယ်ပါမည်" : "Admin will contact you via Telegram"}
              </p>
            </div>
          )}

          {/* Telegram Contact — PRIMARY action */}
          <div className="bg-[#FFF8E1] border-2 border-[#FFD700] rounded-xl p-4 shadow-md">
            <p className="text-sm text-[#333] font-bold font-myanmar mb-3 text-center">
              {mm ? "🏆 Admin ကို ချက်ချင်း ဆက်သွယ်ပါ" : "🏆 Contact Admin Now"}
            </p>
            <a
              href="https://t.me/Aung007t"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-3 py-3.5 rounded-xl bg-gradient-to-r from-[#0088CC] to-[#0077B5] text-white text-base font-bold btn-press shadow-lg animate-pulse"
              style={{ textDecoration: 'none' }}
            >
              <Send size={18} />
              {mm ? "Telegram မှ ဆက်သွယ်ပါ" : "Contact on Telegram"}
            </a>
            <p className="text-[10px] text-gray-400 font-myanmar text-center mt-2">
              @Aung007t
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Coins Winner Claim Screen ───────────────────────────────────────────
function CoinsWinPopup({ result, onClose, celebrate = true }: { result: any; onClose: () => void; celebrate?: boolean }) {
  const { lang } = useLang();
  const mm = lang === "mm";
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!celebrate) return;
    fireConfetti();
    playWinSound();
  }, [celebrate]);

  const copyReferenceId = async () => {
    try {
      await navigator.clipboard.writeText(result.referenceId);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
      <div className="relative max-h-[90vh] w-full max-w-sm overflow-y-auto rounded-[28px] bg-[#FFFDF5] shadow-2xl animate-scale-in">
        <div className="relative overflow-hidden bg-gradient-to-r from-[#FFD700] via-[#FFCA28] to-[#FFD700] px-5 pb-6 pt-7 text-center">
          <button
            onClick={onClose}
            aria-label={mm ? "ပိတ်ရန်" : "Close"}
            className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-white/35 text-[#4A3400] hover:bg-white/60 btn-press"
          >
            <X size={17} />
          </button>
          <Trophy size={38} className="mx-auto mb-2 text-[#8A5A00]" />
          <h2 className="font-myanmar-display text-2xl font-black text-[#4A3400]">
            {mm ? "ကံကောင်းဆု ရရှိပြီ!" : "You won Coins!"}
          </h2>
        </div>

        <div className="space-y-5 p-5">
          <section className="rounded-2xl border border-[#FFD700]/40 bg-[#FFFDF3] px-4 py-4 text-center shadow-sm">
            <p className="font-myanmar text-base font-semibold text-[#5A4A18]">
              {mm ? "ကံကောင်းကြယ်" : "Lucky stars"}
            </p>
            <div className="mt-2 flex items-center justify-center gap-1.5">
              {Array.from({ length: 5 }).map((_, index) => (
                <Star
                  key={index}
                  size={31}
                  className="fill-[#FFD700] text-[#FFD700]"
                  style={{ filter: "drop-shadow(0 2px 2px rgba(180, 120, 0, 0.16))" }}
                />
              ))}
            </div>
          </section>

          <section className="rounded-2xl bg-gradient-to-br from-[#FFD700] via-[#FFC107] to-[#FFA000] px-4 py-6 text-center shadow-lg shadow-[#FFB300]/25">
            <p className="font-myanmar text-base font-semibold text-white/90">
              {mm ? "🏆 Coins ပမာဏ" : "🏆 Coins reward"}
            </p>
            <p className="mt-2 font-serif text-5xl font-black tracking-wide text-white drop-shadow-sm">
              {(result.prizeAmount || 0).toLocaleString()} <span className="text-3xl">Coins</span>
            </p>
            <p className="mt-2 font-myanmar text-sm text-white/85">
              {mm ? "Coins ဆုလက်ဆောင် ရရှိပါပြီ" : "Your Coins reward is ready"}
            </p>
          </section>

          <section className="rounded-2xl border-[3px] border-[#FFA000] bg-[#FFF9ED] px-4 py-4">
            <h3 className="flex items-center gap-2 font-myanmar text-xl font-black text-[#C85A08]">
              <span className="text-2xl">💰</span>
              {mm ? "Coins ဆုယူရန်" : "How to claim Coins"}
            </h3>
            <p className="mt-3 font-myanmar text-base leading-relaxed text-[#3B3428]">
              {mm
                ? "အောက်က ဆု ID ကို ကူးယူပြီး Telegram မှ Admin ကို ပို့ပါ။ ဆု ID ကို အလိုအလျောက် စစ်ဆေးပြီး Coins ဆုကို အတည်ပြုပေးပါမည်။"
                : "Copy the prize ID below and send it to Admin on Telegram for verification."}
            </p>
          </section>

          <section>
            <p className="mb-2 font-myanmar text-sm font-semibold text-[#665D49]">
              {mm ? "ဆု ID" : "Prize ID"}
            </p>
            <div className="flex items-center gap-3 rounded-xl border-2 border-[#FFE17A] bg-white p-2 shadow-sm">
              <code className="min-w-0 flex-1 break-all px-2 font-mono text-lg font-bold leading-snug text-[#313131]">
                {result.referenceId}
              </code>
              <button
                onClick={copyReferenceId}
                className="shrink-0 rounded-xl bg-[#FFD700] px-4 py-3 text-sm font-black text-[#4A3400] shadow-sm hover:bg-[#FFCA28] btn-press"
              >
                {copied ? (mm ? "ကူးပြီး" : "Copied") : (mm ? "ကူးရန်" : "Copy")}
              </button>
            </div>
          </section>

          <section className={`rounded-2xl border px-4 py-3 text-center ${result.paidAt ? "border-emerald-300 bg-emerald-50" : "border-orange-200 bg-orange-50"}`}>
            <p className={`font-myanmar text-sm font-black ${result.paidAt ? "text-emerald-800" : "text-orange-800"}`}>{result.paidAt ? (mm ? "✓ ဆုကြေးပေးပြီးပါပြီ" : "✓ Prize paid") : (mm ? "ဆုကြေးအတည်ပြုစောင့်နေသည်" : "Prize payment pending")}</p>
            <p className={`mt-1 font-myanmar text-[10px] ${result.paidAt ? "text-emerald-700" : "text-orange-700"}`}>{result.paidAt ? (mm ? `Admin မှ ${new Date(result.paidAt).toLocaleString("my-MM", { dateStyle: "medium", timeStyle: "short" })} တွင်မှတ်သားထားသည်` : `Marked paid on ${new Date(result.paidAt).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}`) : (mm ? "Telegram မှဆက်သွယ်ပြီးနောက် Admin ကပေးချေမှုအခြေအနေကိုပြောင်းပေးပါမည်" : "After you contact Admin on Telegram, payment status will be updated here.")}</p>
          </section>

          <section className="rounded-2xl border border-[#F2D76A] bg-[#FFFCED] px-4 py-4 text-center shadow-sm">
            <h3 className="font-myanmar text-lg font-black text-[#3B3428]">
              {mm ? "သင်ချင်းက ဆက်သွယ်မေးမြန်းပါ" : "Contact us to claim"}
            </h3>
            <a
              href="https://t.me/Aung007t"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#19A9E5] to-[#0088CC] py-3.5 text-lg font-black text-white shadow-lg btn-press"
              style={{ textDecoration: "none" }}
            >
              <Send size={21} />
              Telegram @Aung007t
            </a>
            <p className="mt-2 font-myanmar text-xs text-[#8C8778]">
              {mm ? "နှိပ်လိုက်လျှင် ဆု ID ကို ကူးယူပို့ရန်လွယ်ကူပါမည်" : "Copy the prize ID before contacting Admin."}
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

// ─── Already Won This Month Message ──────────────────────────────────────
function AlreadyWonMessage() {
  const { lang } = useLang();
  const mm = lang === "mm";

  return (
    <div className="bg-gradient-to-b from-green-50 to-white border-2 border-green-200 rounded-2xl p-6 text-center">
      <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-3">
        <Star size={32} className="text-green-600" />
      </div>
      <h3 className="text-lg font-bold text-green-700 font-myanmar-display mb-2">
        {mm ? "ဂုဏ်ယူပါတယ်!" : "Congratulations!"}
      </h3>
      <p className="text-sm text-[#555] font-myanmar leading-relaxed">
        {mm
          ? "ဂုဏ်ယူပါတယ်! ယခုလအတွက် ဆုလက်ဆောင် ရရှိထားပြီးဖြစ်ပါသည်။ နောက်ထပ်လည်း ဆုတွေ ထပ်ပေါက်ပါစေ 🎁🎉"
          : "Congratulations! You've won this month. May more prizes come your way! 🎁🎉"}
      </p>
      <div className="mt-4 flex items-center justify-center gap-2 text-xs text-green-600">
        <Sparkles size={14} />
        <span className="font-myanmar">{mm ? "အိပ်မက် ပြန်မက်ပါ" : "Keep trying!"}</span>
        <Sparkles size={14} />
      </div>
    </div>
  );
}

// ─── Main Lucky Box Page ─────────────────────────────────────────────────
// Generate/restore guest device ID from localStorage
function getGuestDeviceId(): string {
  let deviceId = localStorage.getItem("lucky_box_device_id");
  if (!deviceId) {
    deviceId = `dev-${Date.now()}-${Math.random().toString(36).substring(2, 10)}`;
    localStorage.setItem("lucky_box_device_id", deviceId);
  }
  return deviceId;
}

export default function LuckyBoxPage() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const mm = lang === "mm";
  const guestDeviceId = useMemo(() => getGuestDeviceId(), []);

  const [isOpening, setIsOpening] = useState(false);
  const [lastResult, setLastResult] = useState<any>(null);
  const [showWinPopup, setShowWinPopup] = useState(false);
  const [historyPrize, setHistoryPrize] = useState<any>(null);
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  const [openError, setOpenError] = useState<string | null>(null);

  // If logged in, use auth-based stats; otherwise use guest device stats
  const { data: stats, refetch: refetchStats } = user
    ? trpc.luckyBox.getStats.useQuery(undefined, {})
    : trpc.luckyBox.getGuestStats.useQuery({ guestDeviceId }, {
        refetchInterval: 5000, // Poll every 5s for guest tracking
      });

  const openBoxMutation = trpc.luckyBox.openBox.useMutation({
    onSuccess: (data) => {
      setLastResult(data);
      setOpenError(null);
      if (data.isWinner) {
        setShowWinPopup(true); // Confetti & sound fire from WinPopup mount effect
      }
      refetchStats();
      refetchTimeSlots();
    },
    onError: (error) => {
      setOpenError(error.message || (mm ? "ဖွင့်၍ မရပါ" : "Could not open box"));
    },
  });

  const handleOpenBox = () => {
    if (isOpening || !isSlotActive) {
      if (!isSlotActive) {
        setOpenError(isTestMode
          ? (mm ? "ယနေ့ စမ်းသပ်ဖွင့်ခွင့် 4 ကြိမ်ပြည့်နေပါပြီ" : "Today's four test openings are used")
          : (mm ? "ယခုအချိန်တွင်ဖွင့်၍မရသေးပါ" : "Lucky Box is not open yet"));
      }
      return;
    }

    // Clear lastResult when opening a new box (so previous win display is replaced)
    setLastResult(null);
    setOpenError(null);
    playBoxOpenSound();
    setIsOpening(true);
  };

  const handleBoxOpened = useCallback(() => {
    setIsOpening(false);
    openBoxMutation.mutate({ guestDeviceId });
  }, [openBoxMutation, guestDeviceId]);

  const openingsRemaining = stats ? stats.maxDailyOpenings - stats.todayOpenings : 4;

  // Time slot query — the server is the source of truth for opening/locked status.
  const { data: timeSlots, refetch: refetchTimeSlots } = trpc.luckyBox.getTimeSlots.useQuery({ guestDeviceId }, {
    refetchInterval: 30_000,
  });
  const isSlotActive = Boolean(timeSlots?.canOpen);
  const isTestMode = Boolean(timeSlots?.testMode);
  const currentSlot = timeSlots?.activeSlot ?? null;
  const nextSlot = timeSlots?.nextSlot ?? null;

  // Prize tiers query — show available prize amounts
  const { data: prizeTiers } = trpc.adminLuckyBox.getPublicPrizeTiers.useQuery(undefined, {
    refetchInterval: 5 * 60_000, // Refresh every 5 minutes
  });
  const displayTiers = prizeTiers?.tiers ?? [50, 100, 200, 300, 400, 500, 800, 1000];

  // Countdown to next slot
  const [countdown, setCountdown] = useState(0);
  useEffect(() => {
    if (timeSlots?.secondsUntilNext && timeSlots.secondsUntilNext > 0) {
      setCountdown(timeSlots.secondsUntilNext);
    }
  }, [timeSlots?.secondsUntilNext]);

  useEffect(() => {
    if (countdown <= 0) return;
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          refetchTimeSlots();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [countdown > 0, refetchTimeSlots]);

  const formatCountdown = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF8E1] to-[#f5f5f5]">
      {/* Header */}
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/")} className="p-1.5 rounded-lg bg-white/30 hover:bg-white/50 btn-press">
            <ArrowLeft size={18} className="text-[#333]" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-[#333] font-myanmar-display">
              {mm ? "ကံထူးဆုလက်ဆောင်" : "Lucky Box"}
            </h1>
            <p className="text-xs text-[#555] font-myanmar">
              {mm ? "အပျော်သဘောဆုများ ရယူရန် ဖွင့်ပါ" : "Open daily for fun surprises"}
            </p>
          </div>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 pt-4 pb-24 space-y-4">
        {/* Fun Banner — No Prize Pool Amount Shown */}
        <div className="bg-gradient-to-r from-[#FFD700] to-[#FFB300] rounded-xl p-3.5 shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[11px] text-[#555] font-myanmar">
                {mm ? "ယခုလ ကံကောင်းဆု" : "Monthly Lucky Gifts"}
              </p>
              <p className="text-xl font-black text-[#333]">
                {mm ? "🎁 ကံထူးသူများ" : "Lucky Winners"}
              </p>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={14} className="text-white fill-white" />
                ))}
              </div>
              <p className="text-[10px] text-[#555] font-myanmar mt-1">{mm ? "အပျော်သဘောဆု" : "Fun rewards"}</p>
            </div>
          </div>
        </div>

        {/* Prize Tiers — Available Prizes */}
        <div className="bg-white rounded-xl px-4 py-3 shadow-sm border border-[#FFD700]/20">
          <p className="text-xs text-[#555] font-myanmar mb-2">
            {mm ? "🎁 ရရှိနိုင်သည့် Coins များ" : "🎁 Available Coins"}
          </p>
          <div className="flex flex-wrap gap-1.5">
            {displayTiers.sort((a, b) => a - b).map((amount) => (
              <span
                key={amount}
                className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-gradient-to-r from-[#FFD700]/20 to-[#FFA000]/20 text-[#B8860B] border border-[#FFD700]/30"
              >
                {amount.toLocaleString()} Coins
              </span>
            ))}
          </div>
        </div>

        {/* Openings Counter */}
        <div className="bg-white rounded-xl px-4 py-3 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2">
            <span className="text-xs font-myanmar text-gray-500">
              {mm ? "ယနေ့ ကျန်သေးသည့် အကြိမ်" : "Remaining today"}
            </span>
            <div className="flex gap-1 ml-auto">
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    i <= (stats?.todayOpenings ?? 0)
                      ? "bg-[#E8443A] text-white"
                      : "bg-gray-100 text-gray-400"
                  }`}
                >
                  {i}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Time Slot Display */}
        <div className="bg-gradient-to-r from-[#FFD700]/20 to-[#FFA000]/20 rounded-xl px-4 py-3 shadow-sm border border-[#FFD700]/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-[#555] font-myanmar">
                {mm ? "ဖွင့်ချိန်" : "Opening Time"}
              </p>
              <p className="text-sm font-bold text-[#333] font-myanmar">
                {isTestMode
                  ? (isSlotActive ? (mm ? "စမ်းသပ်ဖွင့်ထားသည်" : "Test mode is open") : (mm ? "ယနေ့ စမ်းသပ်အကြိမ်ပြည့်ပြီ" : "Today's test limit reached"))
                  : isSlotActive
                  ? (mm ? `${currentSlot?.label ?? ""} ဖွင့်နိုင်ပါပြီ` : "Open now")
                  : currentSlot
                    ? (mm ? "ဖွင့်ပြီးပါပြီ" : "Opened")
                    : (mm ? "ပိတ်ထားသည်" : "Closed")}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-[#555] font-myanmar">
                {isTestMode ? (mm ? "ယနေ့စမ်းသပ် ကျန်" : "Test openings left") : (mm ? "နောက်ဖွင့်ချိန်" : "Next Opening")}
              </p>
              <p className="text-sm font-bold text-[#B8860B] font-myanmar">
                {isTestMode ? `${timeSlots?.dailyOpeningsRemaining ?? 0} / 4` : (nextSlot ? (mm ? nextSlot.label : nextSlot.labelEn) : "--")}
              </p>
            </div>
          </div>
        </div>

        {/* Lucky Box — normal mode uses time slots; temporary test mode allows four immediate opens. */}
        {!isOpening && !showWinPopup ? (
          <div className="relative">
            {stats?.hasWonThisMonth && (
              <AlreadyWonMessage />
            )}
            <button
              onClick={handleOpenBox}
              disabled={!isSlotActive}
              className={`w-full py-8 rounded-2xl text-white shadow-xl transition-transform relative overflow-hidden group ${
                isSlotActive
                  ? "bg-gradient-to-r from-[#E8443A] to-[#C0392B] btn-press active:scale-[0.98]"
                  : "bg-gradient-to-r from-slate-500 to-slate-600 cursor-not-allowed"
              }`}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-transparent via-[#FFD700]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative flex flex-col items-center gap-3">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center animate-pulse">
                  <Gift size={36} className="text-white" />
                </div>
                <div>
                    <p className="text-xl font-bold font-myanmar-display">
                    {isSlotActive
                      ? (mm ? "ကံထူးဆုလက်ဆောင် ဖွင့်ပါ" : "Open Lucky Box")
                      : (isTestMode ? (mm ? "ယနေ့ စမ်းသပ်အကြိမ်ပြည့်ပြီ" : "Today's test limit reached") : (mm ? "နောက်ဖွင့်ချိန်ကို စောင့်ပါ" : "Wait for next opening"))}
                  </p>
                  <p className="text-sm text-white/70 font-myanmar mt-1">
                    {isTestMode
                      ? (isSlotActive
                        ? (mm ? `ချက်ချင်းဖွင့်နိုင်သည် · ${timeSlots?.dailyOpeningsRemaining ?? 0} ကြိမ်ကျန်` : `Open now · ${timeSlots?.dailyOpeningsRemaining ?? 0} remaining`)
                        : (mm ? "ပုံမှန်စနစ်သို့ပြန်ပြောင်းရန် admin ကိုပြောပါ" : "Ask the admin to restore normal mode"))
                      : isSlotActive
                      ? (mm ? "ယခုအချိန်တွင် တစ်ကြိမ်ဖွင့်နိုင်ပါသည်" : "One opening is available now")
                      : (mm ? `${formatCountdown(countdown)} တွင် ပြန်ဖွင့်ပါမည်` : `Opens in ${formatCountdown(countdown)}`)}
                  </p>
                </div>
              </div>
            </button>
          </div>
        ) : (
          <BoxAnimation isOpening={isOpening} onOpened={handleBoxOpened} />
        )}

        {/* Not a winner message — encouraging */}
        {lastResult && !lastResult.isWinner && !showWinPopup && (
          <div className="bg-gradient-to-b from-[#FFF8E1] to-white rounded-xl p-5 text-center shadow-md border border-[#FFD700]/30 animate-fade-in-up">
            <div className="w-12 h-12 rounded-full bg-[#FFD700]/20 flex items-center justify-center mx-auto mb-2">
              <span className="text-2xl">🍀</span>
            </div>
            <p className="text-base font-bold text-[#333] font-myanmar mb-1">
              {mm ? "ဒီတစ်ခါ မပေါက်သေးဘူး 😅" : "Not this time! 😅"}
            </p>
            <p className="text-sm text-[#555] font-myanmar">
              {mm ? "နောက်တစ်ကြိမ် ကံကောင်းပါစေ!" : "Better luck next time!"}
            </p>
            {openingsRemaining > 0 && (
              <p className="text-xs text-[#888] font-myanmar mt-2">
                {mm ? `${openingsRemaining} ကြိမ် ထပ်ဖွင့်နိုင်ပါသေးသည် — ထပ်ကြည့်ပါ!` : `${openingsRemaining} more openings left today — try again!`}
              </p>
            )}
          </div>
        )}

        {/* Each signed-in or guest user sees only their own saved winner records. */}
        <LuckyBoxHistory
          activePrizeId={historyPrize?.id ?? null}
          onViewWinner={setHistoryPrize}
          onActivePrizeRemoved={() => setHistoryPrize(null)}
          guestDeviceId={guestDeviceId}
          isGuest={!user}
        />

        {/* ─── Play Store Policy Compliance Disclaimer ──────────────────── */}
        <div className="bg-gray-50 rounded-xl p-3 border border-gray-200">
          <p className="text-[10px] text-gray-500 text-center font-myanmar leading-relaxed">
            {mm
              ? (
                  <>
                    ဤ Lucky Box သို့ ပိုက်ဆံဝင်ခြင်း၊ ပိုက်ဆံထုတ်ခြင်း မရှိပါ။ ဆုများသည် အခမဲ့ ပရိုမိုးရှင်း လက်ဆောင်များသာ ဖြစ်ပါသည်။ ထိုင်းလော့တာရော၊ ၂ဒီပေါင်းခြင်းမှ ထုတ်ယူသော အမြတ်ငွေများမှ ပံ့ပိုးထားပါသည်။ ပိုက်ဆံဖြင့် ဝယ်ယူရန်၊ အခကြေးငွေပေးသွင်းရန် မလိုအပ်ပါ။ ၁၈ နှစ်အထက်သာ အသုံးပြုရန်။ ဤအစီအစဉ်သည် လောင်းကစား မဟုတ်ပါ။
                  </>
                )
              : (
                  <>
                    This Lucky Box does not involve any monetary transaction, payment, or in-app purchase. Prizes are complimentary promotional gifts only. No purchase or payment is required to participate. 18+ only. This is NOT gambling. Prizes are funded from application revenue, not from user contributions.
                  </>
                )
            }
          </p>
          <p className="text-[9px] text-gray-400 text-center mt-1.5">
            {mm
              ? "အသေးစိတ်အတွက် မူဝါဒ စာမျက်နှာ ကြည့်ပါ"
              : "See Policy page for details"
            }
          </p>
        </div>
      </div>

      {/* Error Message */}
      {openError && !showWinPopup && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-center shadow-sm">
          <p className="text-sm text-[#E8443A] font-myanmar">{openError}</p>
          <button onClick={() => setOpenError(null)} className="text-xs text-gray-500 mt-2 underline">
            {mm ? "ပိတ်ရန်" : "Dismiss"}
          </button>
        </div>
      )}

      {/* Win Popup */}
      {showWinPopup && lastResult && (
        <CoinsWinPopup
          result={lastResult}
          onClose={() => {
            setShowWinPopup(false);
          }}
        />
      )}

      {/* Reopen the same Coins reward screen from a saved prize record. */}
      {historyPrize && (
        <CoinsWinPopup
          result={historyPrize}
          celebrate={false}
          onClose={() => setHistoryPrize(null)}
        />
      )}

      {/* Login Prompt — Only shown AFTER winning, for guests to claim prize */}
      {showLoginPrompt && !user && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center" style={{ paddingBottom: 'max(20px, env(safe-area-inset-bottom))' }}>
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowLoginPrompt(false)} />
          <div className="relative bg-white rounded-t-2xl p-6 w-full max-w-[480px] animate-fade-in-up shadow-2xl">
            <button
              onClick={() => setShowLoginPrompt(false)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
            >
              <X size={16} className="text-gray-500" />
            </button>
            <div className="text-center mb-5">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#FF6B35]/20 flex items-center justify-center mx-auto mb-3">
                <Star size={32} className="text-[#FFD700]" />
              </div>
              <h3 className="text-lg font-bold text-[#333] font-myanmar-display">
                {mm ? "ဆုလက်ဆောင် ရရှိပါပြီ!" : "You Won a Prize!"}
              </h3>
              <p className="text-sm text-gray-500 font-myanmar mt-2">
                {mm ? "ဆုကို အတည်ပြုရန် အကောင့်ဝင်ပါ" : "Sign in to verify your identity for prize claiming"}
              </p>
              <p className="text-xs text-gray-400 font-myanmar mt-1">
                {mm ? "အကောင့်ဝင်ပြီးနောက် Admin ကို Telegram မှ ဆက်သွယ်ပါ" : "After signing in, contact Admin via Telegram to claim your prize"}
              </p>
            </div>
            <button
              onClick={() => { setShowLoginPrompt(false); startLogin(); }}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FFD700] to-[#FFB300] text-[#333] font-bold text-base shadow-lg btn-press active:scale-[0.98] transition-transform"
            >
              {mm ? "အကောင့်ဝင်ရန်" : "Sign In"}
            </button>
            <div className="mt-4">
              <a
                href="https://t.me/Aung007t"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-[#0088CC] text-white text-sm font-bold shadow-md btn-press"
                style={{ textDecoration: 'none' }}
              >
                <Send size={16} />
                {mm ? "Admin ကို ချက်ချင်း ဆက်သွယ်ပါ" : "Contact Admin Immediately"}
              </a>
              <p className="text-[10px] text-gray-400 text-center mt-2 font-myanmar">
                {mm ? "Screenshot ရိုက်ပြီး Admin ကို ပို့ပါ" : "Take a screenshot and send to Admin"}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Lucky Box Prize History — Own winner records only ───────────────────
function LuckyBoxHistory({
  activePrizeId,
  onViewWinner,
  onActivePrizeRemoved,
  guestDeviceId,
  isGuest,
}: {
  activePrizeId: number | null;
  onViewWinner: (winner: any) => void;
  onActivePrizeRemoved: () => void;
  guestDeviceId: string;
  isGuest: boolean;
}) {
  const { lang } = useLang();
  const mm = lang === "mm";
  const historyOptions = {
    refetchInterval: 15_000,
    refetchOnWindowFocus: true,
  };
  const { data: signedInOpenings } = trpc.luckyBox.getHistory.useQuery(undefined, {
    ...historyOptions,
    enabled: !isGuest,
  });
  const { data: guestOpenings } = trpc.luckyBox.getGuestWinnerHistory.useQuery({ guestDeviceId }, {
    ...historyOptions,
    enabled: isGuest,
  });
  const openings = isGuest ? guestOpenings : signedInOpenings;
  const prizes = openings?.filter((opening) => opening.isWinner) ?? [];

  useEffect(() => {
    if (activePrizeId && openings && !openings.some((opening) => opening.id === activePrizeId)) {
      onActivePrizeRemoved();
    }
  }, [activePrizeId, openings, onActivePrizeRemoved]);

  if (prizes.length === 0) return null;

  return (
    <section className="overflow-hidden rounded-2xl border border-[#FFD700]/40 bg-white shadow-sm">
      <div className="border-b border-[#FFD700]/25 bg-gradient-to-r from-[#FFF8DF] to-[#FFFDF5] px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FFD700]/25">
            <Trophy size={18} className="text-[#B8860B]" />
          </div>
          <div>
            <h3 className="text-sm font-black text-[#3B3428] font-myanmar-display">
              {mm ? "ကျွန်ုပ်၏ Coins ဆုမှတ်တမ်း" : "My Coins Prize History"}
            </h3>
            <p className="text-[10px] text-[#8C7740] font-myanmar">
              {mm ? "ဆုကိုနှိပ်၍ ပေါက်ထားသော Coins နှင့်ဆု ID ကိုပြန်ကြည့်နိုင်သည်" : "Tap a prize to view the awarded Coins and prize ID"}
            </p>
          </div>
        </div>
      </div>
      <div className="max-h-72 space-y-2 overflow-y-auto p-3">
        {prizes.map((prize) => (
          <div key={prize.id} className="overflow-hidden rounded-xl border border-[#F4DE8A] bg-[#FFFDF7]">
            <button
              onClick={() => onViewWinner(prize)}
              className="flex w-full items-center gap-3 p-3 text-left transition-colors hover:bg-[#FFF8DF] btn-press"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#FFD700] to-[#FFB300] shadow-sm">
                <Trophy size={19} className="text-[#5A4100]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-black text-[#A86800]">{(prize.prizeAmount ?? 0).toLocaleString()} Coins</p>
                <p className="mt-0.5 truncate text-[10px] font-mono text-[#756C59]">{prize.referenceId || "--"}</p>
                <p className="mt-1 text-[10px] text-[#8C8778]">{new Date(prize.openedAt).toLocaleString(mm ? "my-MM" : "en-US", { dateStyle: "medium", timeStyle: "short" })}</p>
                <p className={`mt-1 text-[10px] font-black font-myanmar ${prize.paidAt ? "text-emerald-700" : "text-orange-700"}`}>{prize.paidAt ? (mm ? "✓ ဆုကြေးပေးပြီး" : "✓ Paid") : (mm ? "ဆုကြေးအတည်ပြုစောင့်နေသည်" : "Payment pending")}</p>
              </div>
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#E7C84D] bg-[#FFF5BE] text-[#A86800]">
                <Eye size={18} strokeWidth={2.4} />
              </div>
            </button>
            <a
              href="https://t.me/Aung007t"
              target="_blank"
              rel="noopener noreferrer"
              className="mx-3 mb-3 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#19A9E5] to-[#0088CC] px-3 py-2.5 text-xs font-black text-white shadow-sm btn-press"
              style={{ textDecoration: "none" }}
            >
              <Send size={16} />
              Telegram @Aung007t
              <span className="text-white/75 font-myanmar">{mm ? "သို့ ဆက်သွယ်ရန်" : "Contact Admin"}</span>
            </a>
          </div>
        ))}
      </div>
    </section>
  );
}
