import { useState, useEffect, useMemo } from "react";
import { useLang } from "@/contexts/LangContext";
import { useLocation } from "wouter";
import { ArrowLeft, Search, X, ChevronLeft, ChevronRight } from "lucide-react";
import { dreamData, dreamCategories, type DreamCategory } from "@/lib/dreamData";

// Color palette per category for the illustration background
const CategoryColors: Record<DreamCategory, { bg: string; border: string }> = {
  animals:      { bg: "bg-green-50", border: "border-green-200" },
  nature:       { bg: "bg-emerald-50", border: "border-emerald-200" },
  people:       { bg: "bg-purple-50", border: "border-purple-200" },
  objects:      { bg: "bg-amber-50", border: "border-amber-200" },
  supernatural: { bg: "bg-indigo-50", border: "border-indigo-200" },
};

// Icon component that renders the entry's own emoji icon in a styled circle
function DreamIcon({ icon, category, size = "sm" }: { icon: string; category: DreamCategory; size?: "sm" | "md" | "lg" }) {
  const colors = CategoryColors[category];
  const emojiSize = size === "sm" ? "text-3xl" : size === "md" ? "text-5xl" : "text-6xl";
  const boxSize = size === "sm" ? "w-12 h-12" : size === "md" ? "w-16 h-16" : "w-20 h-20";

  return (
    <div className={`${boxSize} flex items-center justify-center ${colors.bg} border ${colors.border} rounded-xl`}>
      <span className={`${emojiSize} leading-none`} role="img" aria-label={icon}>
        {icon}
      </span>
    </div>
  );
}

export default function DreamDictionary() {
  const { lang, t } = useLang();
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<DreamCategory | "all">("all");
  const [selected, setSelected] = useState<number | null>(null);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 30; // 10 rows x 3 cols = 30 per page

  const mm = lang === "mm";

  const catLabels: Record<string, { mm: string; en: string; th: string }> = {
    all:         { mm: "အားလုံး", en: "All", th: "ทั้งหมด" },
    animals:     { mm: "တိရစ္ဆာန်", en: "Animals", th: "สัตว์" },
    nature:      { mm: "သဘာဝ", en: "Nature", th: "ธรรมชาติ" },
    people:      { mm: "လူများ", en: "People", th: "คน" },
    objects:     { mm: "ပစ္စည်း", en: "Objects", th: "สิ่งของ" },
    supernatural:{ mm: "နတ်ဘုရား", en: "Super", th: "เหนือธรรมชาติ" },
  };

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return dreamData.filter((d) => {
      const matchCat = category === "all" || d.category === category;
      const matchSearch = !q || d.titleMm.includes(q) || d.titleEn.toLowerCase().includes(q)
        || d.numbers2D.some(n => n.includes(q)) || d.numbers3D.some(n => n.includes(q))
        || d.meaningMm.includes(q) || d.meaningEn.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [search, category]);

  // Reset page when filters change
  useEffect(() => { setPage(1); }, [search, category]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const selectedEntry = selected !== null ? dreamData.find(d => d.id === selected) : null;

  return (
    <div className="min-h-screen bg-[#f0f0f0]">
      {/* ─── Yellow Header ─────────────────────────────────────────────── */}
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/")} className="text-[#333] btn-press">
            <ArrowLeft size={20} />
          </button>
          <h1 className="font-display text-base font-bold text-[#333] flex-1">
            {t("dreamDict")}
          </h1>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-3 py-3 space-y-3">
        {/* ─── Search Bar ──────────────────────────────────────────────── */}
        <div className="bg-white rounded-xl px-4 py-2.5 flex items-center gap-2 shadow-sm">
          <Search size={16} className="text-purple-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t("searchDream")}
            className="flex-1 text-sm text-[#333] placeholder:text-muted-foreground font-myanmar bg-transparent focus:outline-none"
          />
          {search && (
            <button onClick={() => setSearch("")} className="text-muted-foreground btn-press">
              <X size={14} />
            </button>
          )}
        </div>

        {/* ─── Category Filter ─────────────────────────────────────────── */}
        <div className="flex gap-2 overflow-x-auto pb-1 scroll-x">
          {(["all", ...dreamCategories] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-semibold transition-all btn-press font-myanmar
                ${category === cat
                  ? "bg-[#FFD700] text-[#333] shadow-sm"
                  : "bg-white text-muted-foreground"}`}
            >
              {catLabels[cat][lang]}
            </button>
          ))}
        </div>

        {/* ─── Dream Count ─────────────────────────────────────────────── */}
        <p className="text-xs text-muted-foreground font-myanmar">
          {t("noSearchResult")} {filtered.length} {mm ? "ခု" : ""}
        </p>

        {/* ─── Grid Layout ─────────────────────────────────────────────── */}
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground font-myanmar">
            {t("noSearchResult")}
          </div>
        ) : (
          <>
          <div className="grid grid-cols-3 gap-2 stagger">
            {paginated.map((d) => (
              <button
                key={d.id}
                onClick={() => setSelected(d.id)}
                className="bg-white rounded-xl p-2 text-center shadow-sm border border-gray-100 hover:border-gray-300 transition-all btn-press"
              >
                {/* Dream illustration area — unique icon per entry */}
                <div className="w-full flex items-center justify-center mb-1">
                  <DreamIcon icon={d.icon} category={d.category} size="sm" />
                </div>
                {/* Dream name */}
                <p className="text-[11px] font-semibold text-[#333] font-myanmar leading-tight">
                  {lang === "mm" ? d.titleMm : lang === "th" ? d.titleEn : d.titleEn}
                </p>
                {/* Numbers row */}
                <div className="flex items-center justify-center gap-1 mt-1">
                  {d.numbers2D.slice(0, 1).map(n => (
                    <span key={n} className="text-[11px] font-bold text-[#333] font-mono">{n}</span>
                  ))}
                  {d.numbers3D && d.numbers3D.length > 0 && (
                    <span className="text-[11px] font-bold text-purple-500 font-mono">{d.numbers3D[0]}</span>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* ─── Pagination ────────────────────────────────────────────── */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-3 py-4">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="w-8 h-8 rounded-lg bg-white border border-gray-200 flex items-center justify-center disabled:opacity-30 btn-press"
              >
                <ChevronLeft size={14} />
              </button>
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  // Show current page centered among 5 pages
                  let pageNum: number;
                  if (totalPages <= 5) pageNum = i + 1;
                  else if (page <= 3) pageNum = i + 1;
                  else if (page >= totalPages - 2) pageNum = totalPages - 4 + i;
                  else pageNum = page - 2 + i;
                  return (
                    <button
                      key={pageNum}
                      onClick={() => setPage(pageNum)}
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all btn-press
                        ${page === pageNum ? "bg-[#FFD700] text-[#333]" : "bg-white text-gray-500 border border-gray-200"}`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="w-8 h-8 rounded-lg bg-white border border-gray-200 flex items-center justify-center disabled:opacity-30 btn-press"
              >
                <ChevronRight size={14} />
              </button>
            </div>
          )}
          </>
        )}
      </div>

      {/* ─── Bottom Category Tabs ──────────────────────────────────────── */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 safe-bottom">
        <div className="max-w-[480px] mx-auto px-2 py-2 flex gap-1 overflow-x-auto">
          {(["all", ...dreamCategories] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`flex-1 flex-shrink-0 py-2 rounded-lg text-[10px] font-bold transition-all btn-press font-myanmar
                ${category === cat
                  ? "bg-[#FFD700] text-[#333]"
                  : "text-muted-foreground"}`}
            >
              {catLabels[cat][lang]}
            </button>
          ))}
        </div>
      </div>

      {/* ─── Detail Modal ──────────────────────────────────────────────── */}
      {selectedEntry && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 animate-fade-in"
             onClick={() => setSelected(null)}>
          <div className="w-full max-w-[480px] bg-white rounded-t-2xl p-5 animate-scale-in"
               onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <DreamIcon icon={selectedEntry.icon} category={selectedEntry.category} size="md" />
                <div>
                  <h2 className="text-lg font-bold text-[#333] font-myanmar">
                    {lang === "mm" ? selectedEntry.titleMm : lang === "th" ? selectedEntry.titleEn : selectedEntry.titleEn}
                  </h2>
                  <p className="text-xs text-muted-foreground font-myanmar">
                    {lang === "mm" ? selectedEntry.titleEn : lang === "th" ? selectedEntry.titleMm : selectedEntry.titleMm}
                  </p>
                  <p className="text-[10px] text-muted-foreground font-myanmar mt-0.5 capitalize">
                    {catLabels[selectedEntry.category]?.[lang] || selectedEntry.category}
                  </p>
                </div>
              </div>
              <button onClick={() => setSelected(null)} className="text-muted-foreground btn-press">
                <X size={20} />
              </button>
            </div>

            <p className="text-sm text-[#555] font-myanmar mb-4 leading-relaxed">
              {lang === "mm" ? selectedEntry.meaningMm : lang === "th" ? selectedEntry.meaningEn : selectedEntry.meaningEn}
            </p>

            <div className="grid grid-cols-2 gap-3">
              {/* 2D Numbers */}
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                <p className="text-[10px] text-amber-700 font-bold mb-2 font-myanmar">
                  {t("numbers2D")}
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedEntry.numbers2D.map(n => (
                    <span key={n} className="prize-number text-lg font-black text-amber-600 bg-white border border-amber-200 rounded-lg px-2 py-0.5">{n}</span>
                  ))}
                </div>
              </div>
              {/* 3D Numbers */}
              <div className="bg-purple-50 border border-purple-200 rounded-xl p-3">
                <p className="text-[10px] text-purple-700 font-bold mb-2 font-myanmar">
                  {t("numbers3D")}
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedEntry.numbers3D.map(n => (
                    <span key={n} className="prize-number text-base font-black text-purple-600 bg-white border border-purple-200 rounded-lg px-2 py-0.5">{n}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
