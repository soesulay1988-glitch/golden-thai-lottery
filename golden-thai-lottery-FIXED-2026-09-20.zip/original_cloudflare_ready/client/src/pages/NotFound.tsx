import { useLang } from "@/contexts/LangContext";
import { useLocation } from "wouter";

export default function NotFound() {
  const [, navigate] = useLocation();
  const lang = "mm";
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 text-center">
      <div className="text-6xl mb-4">🔍</div>
      <h1 className="font-display text-2xl font-bold text-gold-gradient mb-2">404</h1>
      <p className="text-muted-foreground font-myanmar mb-6">
        {lang === "mm" ? "စာမျက်နှာ မတွေ့ပါ" : "Page not found"}
      </p>
      <button onClick={() => navigate("/")}
        className="bg-gradient-to-r from-amber-500 to-amber-400 text-white font-bold px-6 py-3 rounded-xl btn-press">
        {lang === "mm" ? "ပင်မစာမျက်နှာ" : "Go Home"}
      </button>
    </div>
  );
}

