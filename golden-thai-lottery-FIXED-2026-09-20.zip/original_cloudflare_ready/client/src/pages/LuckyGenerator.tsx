import { useState, useCallback, useEffect, useMemo, useRef } from "react";
import { useLocation } from "wouter";
import { useLang } from "@/contexts/LangContext";
import { toast } from "sonner";
import { ArrowLeft, Sparkles, Copy, Zap, RefreshCw, Clock } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import confetti from "canvas-confetti";
import {
  getLuckyContentPeriod,
  getLucky2DPeriod,
  getLucky2DSessionIndex,
  getLucky3DPeriodSeed,
  getMyanmarDate,
  getNextLucky3DDrawDay,
  isMyanmarMarketDay,
} from "@/lib/luckySchedule";

// ─── Seed-based deterministic random number generator (Mulberry32) ─────────
function seededRandom(seed: number) {
  let s = seed | 0;
  return () => {
    s = (s + 0x6D2B79F5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function generate3D(seed: number): string {
  const rng = seededRandom(seed);
  return String(100 + Math.floor(rng() * 900));
}

function generate2D(seed: number): string {
  const rng = seededRandom(seed);
  return String(Math.floor(rng() * 100)).padStart(2, "0");
}

function generate3Unique2D(seed: number): string[] {
  const rng = seededRandom(seed);
  const used = new Set<number>();
  const result: string[] = [];
  let attempts = 0;
  while (result.length < 3 && attempts < 500) {
    const num = Math.floor(rng() * 100);
    if (!used.has(num)) {
      used.add(num);
      result.push(String(num).padStart(2, "0"));
    }
    attempts++;
  }
  return result;
}

function getDailySeed(date: Date): number {
  const y = date.getUTCFullYear();
  const m = date.getUTCMonth();
  const d = date.getUTCDate();
  return y * 10000 + m * 100 + d;
}

function get3DDrawSeed(date: Date): number {
  return getLucky3DPeriodSeed(date);
}

// ─── Celebration Sound Effect (Multi-tone Fanfare) ─────────────────────────
function playCelebrationSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const sampleRate = ctx.sampleRate;
    const duration = 2;
    const length = Math.ceil(sampleRate * duration);
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);

    // Grand ascending fanfare
    const notes = [
      { freq: 523, start: 0, dur: 0.25 },
      { freq: 659, start: 0.12, dur: 0.25 },
      { freq: 784, start: 0.24, dur: 0.30 },
      { freq: 1047, start: 0.36, dur: 0.35 },
      { freq: 1319, start: 0.50, dur: 0.40 },
      { freq: 1568, start: 0.65, dur: 0.50 },
      { freq: 2093, start: 0.85, dur: 1.15 },
    ];

    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      let sample = 0;
      for (const note of notes) {
        if (t >= note.start && t < note.start + note.dur) {
          const decay = Math.exp(-(t - note.start) * 1.2);
          // Main tone
          sample += Math.sin(2 * Math.PI * note.freq * (t - note.start)) * decay * 0.12;
          // Harmonic (octave)
          sample += Math.sin(2 * Math.PI * note.freq * 2 * (t - note.start)) * decay * 0.04;
        }
      }
      // Sparkle noise at the end
      if (t > 0.5 && t < 2) {
        sample += (Math.random() - 0.5) * 0.02 * Math.exp(-(t - 0.5) * 1.5);
      }
      data[i] = Math.max(-1, Math.min(1, sample));
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start(0);
  } catch {
    // Silently fail
  }
}

// ─── Seen Cards (persisted in localStorage) ─────────────────────────────────
function getDailyPeriod(): string {
  return getLuckyContentPeriod(getMyanmarDate());
}

const SEEN_KEY = "lucky_seen_cards";
const REVEALED_KEY = "lucky_revealed_numbers";

function getSeenCards(): Set<string> {
  try {
    const period = getDailyPeriod();
    const raw = localStorage.getItem(`${SEEN_KEY}_${period}`);
    if (raw) return new Set(JSON.parse(raw));
  } catch { /* ignore */ }
  return new Set();
}

function markCardSeen(cardId: string) {
  const period = getDailyPeriod();
  const seen = getSeenCards();
  seen.add(cardId);
  try {
    localStorage.setItem(`${SEEN_KEY}_${period}`, JSON.stringify(Array.from(seen)));
  } catch { /* ignore */ }
}

// Persist revealed numbers for current session
function getRevealedNumbers(): { lucky3D: string; lucky2D: string[] } | null {
  try {
    const period = getDailyPeriod();
    const raw = localStorage.getItem(`${REVEALED_KEY}_${period}`);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

function saveRevealedNumbers(numbers: { lucky3D: string; lucky2D: string[] }) {
  try {
    const period = getDailyPeriod();
    localStorage.setItem(`${REVEALED_KEY}_${period}`, JSON.stringify(numbers));
  } catch { /* ignore */ }
}

function clearRevealedNumbers() {
  try {
    const period = getDailyPeriod();
    localStorage.removeItem(`${REVEALED_KEY}_${period}`);
  } catch { /* ignore */ }
}

// ─── Motivational Texts ────────────────────────────────────────────────────
const MOTIVATIONAL_MM = [
  "3D 2D များ ကံကောင်းပါစေ ✨",
  "သင့် ဂဏန်းများ ကံကောင်းပါစေ 🍀",
  "ယနေ့ ကံကောင်းပါစေ 🌟",
  "ဆုကြီး ရပါစေ 🎉",
  "ကံကြမ္မာ သင့်ဘက်ကပါ 😊",
  "ကံကောင်းဂဏန်းများ ရရှိပါစေ 💰",
];

const MOTIVATIONAL_EN = [
  "Good luck with your 3D & 2D numbers! ✨",
  "May your numbers be lucky today 🍀",
  "Lucky day for you! 🌟",
  "Win big prizes! 🎉",
  "Fortune is on your side 😊",
  "May you get lucky numbers! 💰",
];

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

// ─── Format date helpers ──────────────────────────────────────────────────
const WEEKDAYS_MM = ["တနင်္ဂနွေ", "တနင်္လာ", "အင်္ဂါ", "ဗုဒ္ဓဟူး", "ကြာသပတေး", "သောကြာ", "စနေ"];

function formatMyanmarDate(d: Date): string {
  return `${String(d.getUTCDate()).padStart(2, "0")}.${String(d.getUTCMonth() + 1).padStart(2, "0")}.${String(d.getUTCFullYear() % 100).padStart(2, "0")}`;
}

// ─── Generate numbers for a specific date + user ──────────────────────────
function getNumbersForDate(date: Date, userSeed: number, twoDSessionIndex = 0) {
  const dailySeed = getDailySeed(date);
  const lucky3D = generate3D(get3DDrawSeed(date) * 100 + userSeed);
  const lucky2D = generate3Unique2D(dailySeed * 100 + userSeed * 7 + twoDSessionIndex * 77777);
  return { lucky3D, lucky2D };
}

function getTodayNumbers(userSeed: number) {
  const date = getMyanmarDate();
  const sessionIdx = getLucky2DSessionIndex(date);
  const numbers = getNumbersForDate(date, userSeed, Math.max(sessionIdx, 0));
  return {
    lucky3D: numbers.lucky3D,
    lucky2D: sessionIdx < 0 ? [] : numbers.lucky2D,
  };
}

// ─── History item component ────────────────────────────────────────────────
function HistoryDayRow({ date, userSeed, mm, copyNumber }: {
  date: Date;
  userSeed: number;
  mm: boolean;
  copyNumber: (num: string) => void;
}) {
  const nums = getNumbersForDate(date, userSeed);
  const hasLucky2D = isMyanmarMarketDay(date);
  const dateStr = formatMyanmarDate(date);
  const weekday = WEEKDAYS_MM[date.getUTCDay()];

  return (
    <div className="bg-[#FFD700]/5 border border-[#FFD700]/15 rounded-xl p-3 space-y-2">
      <div className="flex items-center gap-2">
        <Clock size={12} className="text-[#FFD700]/60" />
        <span className="text-[#FFD700]/70 text-[11px] font-myanmar">
          {mm ? `${weekday} — ${dateStr}` : dateStr}
        </span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-[#FFD700]/60 text-[10px] font-myanmar">3D</span>
        <button onClick={() => copyNumber(nums.lucky3D)}
          className="bg-[#FFD700]/15 border border-[#FFD700]/25 rounded-lg px-4 py-1.5 btn-press">
          <span className="text-[#FFD700] text-[18px] font-black tracking-widest">{nums.lucky3D}</span>
        </button>
      </div>
      {hasLucky2D && (
        <div className="flex items-center justify-between">
          <span className="text-[#FFD700]/60 text-[10px] font-myanmar">2D</span>
          <div className="flex gap-2">
            {nums.lucky2D.map((n: string) => (
              <button key={n} onClick={() => copyNumber(n)}
                className="bg-[#FFD700]/10 border border-[#FFD700]/20 rounded-lg px-3 py-1 btn-press">
                <span className="text-[#FFD700] text-[14px] font-bold">{n}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Sparkle Particle Component ────────────────────────────────────────────
function SparkleParticles({ count = 24 }: { count?: number }) {
  const particles = useMemo(() => {
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      left: `${5 + Math.random() * 90}%`,
      top: `${5 + Math.random() * 90}%`,
      size: 2 + Math.random() * 4,
      delay: Math.random() * 0.8,
      color: ['#FFD700', '#FFB300', '#FFA500', '#FFF', '#FFE4B5', '#FF6B6B', '#4ECDC4'][Math.floor(Math.random() * 7)],
      duration: 0.8 + Math.random() * 1.2,
    }));
  }, [count]);

  return (
    <>
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full pointer-events-none"
          style={{
            left: p.left,
            top: p.top,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            animation: `sparkle-float ${p.duration}s ease-out ${p.delay}s both`,
            opacity: 0,
            boxShadow: `0 0 ${p.size * 2}px ${p.color}`,
          }}
        />
      ))}
    </>
  );
}

// ─── Slot Machine Rolling Digits ────────────────────────────────────────────
function RollingDigits({ targetDigits, isRolling, index }: {
  targetDigits: string;
  isRolling: boolean;
  index: number;
}) {
  const [displayedDigits, setDisplayedDigits] = useState(targetDigits.split(''));
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!isRolling) {
      setDisplayedDigits(targetDigits.split(''));
      if (intervalRef.current) clearInterval(intervalRef.current);
      return;
    }

    // Rolling animation: randomly cycle digits
    intervalRef.current = setInterval(() => {
      setDisplayedDigits(targetDigits.split('').map(() =>
        String(Math.floor(Math.random() * 10))
      ));
    }, 60);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRolling, targetDigits]);

  return (
    <div className="flex items-center justify-center gap-1.5">
      {displayedDigits.map((digit, dIdx) => (
        <span
          key={`${index}-${dIdx}`}
          className={`text-[#FFD700] font-black tracking-wider inline-block transition-all duration-100
            ${isRolling ? 'animate-pulse' : 'animate-number-pop'}
            ${targetDigits.length === 3 ? 'text-[42px] font-display' : 'text-[36px]'}
          `}
          style={{
            animationDelay: isRolling ? `${dIdx * 0.05}s` : `${index * 200 + dIdx * 80}ms`,
            textShadow: !isRolling ? '0 0 20px rgba(255,215,0,0.5), 0 0 40px rgba(255,215,0,0.2)' : 'none',
          }}
        >
          {digit}
        </span>
      ))}
    </div>
  );
}

// ─── Glowing Number Card ────────────────────────────────────────────────────
function GlowingNumberCard({ number, delay, onClick, isRevealing }: {
  number: string;
  delay: number;
  onClick: () => void;
  isRevealing: boolean;
}) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!isRevealing) {
      const timer = setTimeout(() => setVisible(true), delay);
      return () => clearTimeout(timer);
    } else {
      setVisible(false);
    }
  }, [isRevealing, delay]);

  return (
    <button
      onClick={onClick}
      className={`
        relative overflow-hidden rounded-xl py-4 flex items-center justify-center btn-press
        bg-[#FFD700]/15 border border-[#FFD700]/30
        hover:bg-[#FFD700]/25 hover:scale-[1.02]
        transition-all duration-500 ease-out
        ${visible ? 'scale-100 opacity-100 animate-glow-ring' : 'scale-50 opacity-0'}
      `}
    >
      {/* Inner glow effect */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#FFD700]/10 to-transparent" />
      <span className="text-[#FFD700] text-[36px] font-black tracking-wider relative z-10">
        {number}
      </span>
      {/* Shimmer overlay */}
      {visible && (
        <div
          className="absolute inset-0 opacity-30"
          style={{
            background: 'linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.3) 50%, transparent 60%)',
            animation: `shimmer 2s ease-in-out infinite`,
            animationDelay: `${delay}ms`,
          }}
        />
      )}
    </button>
  );
}

// ─── Main Page ──────────────────────────────────────────────────────────────
export default function LuckyGenerator() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const mm = lang === "mm";
  const { user } = useAuth();
  const [isRevealed, setIsRevealed] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isRolling, setIsRolling] = useState(false);
  const [revealStage, setRevealStage] = useState(0); // 0=hidden, 1=rolling, 2=3D revealed, 3=2D revealed
  const [showSparkles, setShowSparkles] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [revealCount, setRevealCount] = useState(0);
  const [persistedNumbers, setPersistedNumbers] = useState<{ lucky3D: string; lucky2D: string[] } | null>(null);
  const [scheduleTick, setScheduleTick] = useState(0);

  // User-specific seed
  const userSeed = useMemo(() => {
    if (user?.id) return hashString(String(user.id));
    let userId = localStorage.getItem("lucky_user_id");
    if (!userId) {
      userId = String(Math.floor(Math.random() * 1000000));
      localStorage.setItem("lucky_user_id", userId);
    }
    return hashString(userId);
  }, [user?.id]);

  useEffect(() => {
    markCardSeen("nekkun");
    // Load persisted numbers for current session
    const persisted = getRevealedNumbers();
    if (persisted) {
      setPersistedNumbers(persisted);
      setIsRevealed(true);
      setRevealStage(3);
    }
  }, []);

  // Check if session has changed and clear persisted numbers
  useEffect(() => {
    const checkSessionChange = () => {
      const currentPeriod = getDailyPeriod();
      const lastPeriod = localStorage.getItem("lucky_last_period");
      if (lastPeriod && lastPeriod !== currentPeriod) {
        // Session changed — clear persisted numbers and reset state
        clearRevealedNumbers();
        setPersistedNumbers(null);
        setIsRevealed(false);
        setRevealStage(0);
      }
      localStorage.setItem("lucky_last_period", currentPeriod);
      setScheduleTick((tick) => tick + 1);
    };
    checkSessionChange();
    // Update the app-side schedule promptly when a 10:00/15:00 session begins.
    const interval = setInterval(checkSessionChange, 15000);
    return () => clearInterval(interval);
  }, []);

  const todayNumbers = useMemo(() => getTodayNumbers(userSeed), [userSeed, scheduleTick]);
  const currentSessionIdx = getLucky2DSessionIndex(getMyanmarDate());
  const { lucky3D, lucky2D } = todayNumbers;

  const motivationalIdx = userSeed % MOTIVATIONAL_MM.length;
  const motivationalText = mm ? MOTIVATIONAL_MM[motivationalIdx] : MOTIVATIONAL_EN[motivationalIdx];

  const copyNumber = (num: string) => {
    navigator.clipboard.writeText(num).then(() =>
      toast.success(mm ? `${num} ကူးယူပြီး` : `Copied ${num}`)
    );
  };

  // ─── Confetti Celebration on Full Reveal ──────────────────────────────────
  const fireRevealConfetti = useCallback(() => {
    const colors = ['#FFD700', '#FF6B6B', '#FFB300', '#FFC0CB', '#FFF', '#C0C0C0', '#4ECDC4'];
    const duration = 3000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 4,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.9 },
        colors,
        shapes: ['circle', 'square'],
        scalar: 0.8 + Math.random() * 0.4,
        gravity: 0.8,
      });
      confetti({
        particleCount: 4,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.9 },
        colors,
        shapes: ['circle', 'square'],
        scalar: 0.8 + Math.random() * 0.4,
        gravity: 0.8,
      });
      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    // Big center burst
    setTimeout(() => {
      confetti({
        particleCount: 120,
        spread: 140,
        origin: { y: 0.5 },
        colors,
        shapes: ['circle', 'square', 'star'],
        scalar: 0.7 + Math.random() * 0.6,
        gravity: 0.7,
        ticks: 250,
      });
    }, 400);

    // Clear confetti state after animation
    setTimeout(() => setShowConfetti(false), 4000);
  }, []);

  const handleReveal = useCallback(() => {
    setIsAnimating(true);
    setIsRolling(true);
    setShowSparkles(true);
    setRevealCount(prev => prev + 1);
    playCelebrationSound();

    // Stage 1: Rolling animation
    setRevealStage(1);

    // Stage 2: Stop rolling, reveal 3D number
    setTimeout(() => {
      setIsRolling(false);
      setRevealStage(2);
    }, 1800);

    // Stage 3: Reveal 2D numbers + fire confetti celebration
    setTimeout(() => {
      setRevealStage(3);
      setIsRevealed(true);
      setIsAnimating(false);
      setShowSparkles(false);
      // Fire confetti celebration after all numbers are shown
      setShowConfetti(true);
      fireRevealConfetti();
      // Persist revealed numbers
      saveRevealedNumbers({ lucky3D, lucky2D });
    }, 3200);
  }, [fireRevealConfetti, lucky2D, lucky3D]);

  const now = new Date();
  const myanmarToday = getMyanmarDate(now);
  const todayStr = `${String(myanmarToday.getUTCDate()).padStart(2, "0")}.${String(myanmarToday.getUTCMonth() + 1).padStart(2, "0")}.${String(myanmarToday.getUTCFullYear() % 100).padStart(2, "0")}`;
  const weekdayMm = WEEKDAYS_MM[myanmarToday.getUTCDay()];

  // Check if today is a 3D draw day (1st, 5th, 16th, or 20th)
  const show3D = true;
  // On 2D market days, show three 2D numbers from 10:00 and refresh them at 15:00 MYT.
  // On weekends/closed periods, only the 3D number is shown.
  const show2D = isMyanmarMarketDay(myanmarToday) && currentSessionIdx >= 0;

  const historyDates = useMemo(() => {
    const dates: Date[] = [];
    const today = getMyanmarDate();
    for (let i = 1; i <= 30; i++) {
      const d = new Date(today);
      d.setUTCDate(today.getUTCDate() - i);
      dates.push(d);
    }
    return dates;
  }, [scheduleTick]);

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      {/* Header */}
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/")} className="p-2 rounded-xl hover:bg-white/30 transition-colors btn-press">
            <ArrowLeft size={18} className="text-[#333]" />
          </button>
          <div className="flex-1">
            <h1 className="text-[14px] font-bold text-[#333] font-display tracking-wider">
              LUCKY NUMBER
            </h1>
            <p className="text-[10px] text-[#555] font-myanmar">
              {mm ? weekdayMm + " — " + todayStr : todayStr}
            </p>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-[480px] mx-auto px-4 pt-4 pb-24">
        <div className={`relative rounded-2xl overflow-hidden flex flex-col transition-all duration-1000
          ${revealStage >= 3 ? 'ring-2 ring-[#FFD700]/40 shadow-[0_0_40px_rgba(255,215,0,0.2)]' : 'ring-0'}`}
             style={{
               background: revealStage >= 3
                 ? 'radial-gradient(ellipse at center, #5a0000 0%, #1a0000 50%, #0d0000 100%)'
                 : 'radial-gradient(ellipse at center, #8B0000 0%, #2a0000 100%)'
             }}>

          {/* Post-reveal golden ambient glow */}
          {revealStage >= 3 && (
            <div className="absolute inset-0 z-[1] pointer-events-none">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(255,215,0,0.08)_0%,transparent_70%)] animate-pulse" style={{ animationDuration: '3s' }} />
            </div>
          )}

          {/* Ornate Background */}
          <svg className="absolute inset-0 w-full h-full z-[2]" viewBox="0 0 400 700" preserveAspectRatio="none" fill="none">
            <g>
              <path d="M0 0 C 40 0, 60 20, 60 60 C 60 35, 40 15, 0 15 Z" fill="#FFD700" opacity="0.5"/>
              <path d="M0 0 C 25 0, 40 15, 40 40 C 40 22, 25 8, 0 8 Z" fill="#FFD700" opacity="0.7"/>
            </g>
            <g transform="translate(400, 0) scale(-1, 1)">
              <path d="M0 0 C 40 0, 60 20, 60 60 C 60 35, 40 15, 0 15 Z" fill="#FFD700" opacity="0.5"/>
              <path d="M0 0 C 25 0, 40 15, 40 40 C 40 22, 25 8, 0 8 Z" fill="#FFD700" opacity="0.7"/>
            </g>
            <g transform="translate(0, 700) scale(1, -1)">
              <path d="M0 0 C 40 0, 60 20, 60 60 C 60 35, 40 15, 0 15 Z" fill="#FFD700" opacity="0.5"/>
              <path d="M0 0 C 25 0, 40 15, 40 40 C 40 22, 25 8, 0 8 Z" fill="#FFD700" opacity="0.7"/>
            </g>
            <g transform="translate(400, 700) scale(-1, -1)">
              <path d="M0 0 C 40 0, 60 20, 60 60 C 60 35, 40 15, 0 15 Z" fill="#FFD700" opacity="0.5"/>
              <path d="M0 0 C 25 0, 40 15, 40 40 C 40 22, 25 8, 0 8 Z" fill="#FFD700" opacity="0.7"/>
            </g>
            <line x1="50" y1="680" x2="350" y2="680" stroke="#FFD700" strokeWidth="1" opacity="0.3"/>
          </svg>

          {/* Sparkle particles during reveal */}
          {showSparkles && (
            <div className="absolute inset-0 z-[25] overflow-hidden pointer-events-none">
              <SparkleParticles count={30} />
            </div>
          )}

          {/* Title */}
          <div className="relative z-10 text-center pt-6">
            <p className="text-[#FFD700] text-[22px] font-bold font-display tracking-[0.15em]">LUCKY NUMBER</p>
            <p className="text-[#FFD700]/80 text-[14px] font-myanmar mt-1">{todayStr}</p>
            <p className="text-[#FFD700]/60 text-[11px] font-myanmar mt-0.5">{weekdayMm}</p>
          </div>

          {!isRevealed && show2D ? (
            /* Pre-reveal: Tap to reveal */
            <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 mt-8">
              {/* Animated orb with pulse */}
              <div className="relative w-48 h-48">
                {/* Outer pulsing ring */}
                <div className="absolute inset-0 rounded-full border-2 border-[#FFD700]/20 animate-ping" style={{ animationDuration: '3s' }} />
                <div className="absolute inset-2 rounded-full border border-[#FFD700]/10 animate-ping" style={{ animationDuration: '2s', animationDelay: '0.5s' }} />
                {/* Main orb */}
                <div className="absolute inset-4 rounded-full border-4 border-[#FFD700]/40 flex items-center justify-center bg-[#4a0000]/50 shadow-[0_0_40px_rgba(255,215,0,0.2)]">
                  <Zap size={48} className="text-[#FFD700]/60 animate-pulse" />
                </div>
                {/* Floating sparkles around orb */}
                {Array.from({ length: 8 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-1.5 h-1.5 rounded-full bg-[#FFD700]"
                    style={{
                      left: `${50 + 45 * Math.cos((i / 8) * Math.PI * 2)}%`,
                      top: `${50 + 45 * Math.sin((i / 8) * Math.PI * 2)}%`,
                      animation: `sparkle-float 1.5s ease-in-out ${i * 0.15}s infinite alternate`,
                      opacity: 0,
                      boxShadow: '0 0 6px #FFD700',
                    }}
                  />
                ))}
              </div>

              <button onClick={handleReveal} disabled={isAnimating}
                className="mt-8 bg-[#FFD700] hover:bg-[#FFC700] text-[#333] font-bold py-3.5 px-10 rounded-xl flex items-center justify-center gap-2 btn-press text-[15px] font-myanmar shadow-[0_4px_20px_rgba(255,215,0,0.4)] disabled:opacity-70 relative overflow-hidden group">
                {/* Button shimmer */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                {isAnimating ? (
                  <>
                    <RefreshCw size={18} className="animate-spin" />
                    <span className="animate-pulse">{mm ? "ထုတ်ယူနေသည်..." : "Revealing..."}</span>
                  </>
                ) : revealCount > 0 ? (
                  <>
                    <Sparkles size={18} className="group-hover:rotate-12 transition-transform" />
                    {mm ? "ဂဏန်းသစ် ကြည့်ရန်" : "Reveal New Numbers"}
                  </>
                ) : (
                  <>
                    <Sparkles size={18} className="group-hover:rotate-12 transition-transform" />
                    {mm ? "ကံကောင်းဂဏန်း ကြည့်ပါ" : "Reveal Lucky Numbers"}
                  </>
                )}
              </button>
              <p className="text-[#FFD700]/40 text-[10px] font-myanmar mt-3">
                {mm ? "မနက် ၁၀:၀၀ နှင့် ညနေ ၃:၀၀ တွင် 2D ဂဏန်းသစ် ၃ ကွက်ရပါမည်" : "Three new 2D numbers at 10:00 AM and 3:00 PM"}
              </p>
            </div>
          ) : (
            /* Post-reveal: Show numbers with animations */
            <div className="relative z-10 px-6 mt-6 space-y-5">

              {/* 3D Lucky Number — only on draw days */}
              {show3D && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-[#FFD700] text-[13px] font-myanmar">
                    {mm ? "3D ကံကောင်းဂဏန်း" : "3D Lucky Number"}
                  </p>
                  <span className="text-[#FFD700]/50 text-[9px] font-myanmar bg-[#FFD700]/10 px-2 py-0.5 rounded-full">
                    {mm ? "၅၊ ၁၅၊ ၂၀ နှင့် လကုန်ရက်" : "Scheduled 3D"}
                  </span>
                </div>
                <div
                  className="relative overflow-hidden"
                  style={{
                    opacity: revealStage < 2 && show2D ? 0.3 : 1,
                    transition: 'opacity 500ms ease',
                  }}
                >
                  <button onClick={() => copyNumber(lucky3D)}
                    className="w-full bg-[#FFD700]/15 border border-[#FFD700]/30 rounded-xl py-4 flex items-center justify-center btn-press relative overflow-hidden">
                    {/* Golden glow background */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#FFD700]/5 to-transparent" />
                    {/* Shimmer effect */}
                    {(revealStage >= 2 || !show2D) && (
                      <div
                        className="absolute inset-0"
                        style={{
                          background: 'linear-gradient(105deg, transparent 30%, rgba(255,255,255,0.15) 50%, transparent 70%)',
                          animation: 'shimmer 2.5s ease-in-out infinite',
                        }}
                      />
                    )}
                    {/* Rolling or revealed digits */}
                    <RollingDigits
                      targetDigits={lucky3D}
                      isRolling={isRolling}
                      index={0}
                    />
                  </button>
                  {/* Glow ring on reveal */}
                  {(revealStage >= 2 || !show2D) && !isRolling && (
                    <div className="absolute inset-0 rounded-xl animate-glow-ring pointer-events-none" />
                  )}
                </div>
                {/* Next draw date info */}
                <p className="text-[#FFD700]/40 text-[10px] font-myanmar text-center mt-1">
                  {mm
                    ? `နောက်ထီထွက်ရက် — ${(() => {
                        const now = new Date();
                        const mmDate = new Date(now.getTime() + 6.5 * 60 * 60 * 1000);
                        const next = getNextLucky3DDrawDay(mmDate);
                        const y = next.getUTCFullYear() % 100;
                        const mo = next.getUTCMonth() + 1;
                        const d = next.getUTCDate();
                        return `${String(d).padStart(2, '0')}.${String(mo).padStart(2, '0')}.${String(y).padStart(2, '0')} (${WEEKDAYS_MM[next.getUTCDay()]})`;
                      })()}`
                    : (() => {
                        const now = new Date();
                        const mmDate = new Date(now.getTime() + 6.5 * 60 * 60 * 1000);
                        const next = getNextLucky3DDrawDay(mmDate);
                        return `Next draw: ${String(next.getUTCDate()).padStart(2, '0')}.${String(next.getUTCMonth() + 1).padStart(2, '0')}.${String(next.getUTCFullYear() % 100).padStart(2, '0')}`;
                      })()
                  }
                </p>
              </div>
              )}

              {/* 2D Lucky Numbers — 3 numbers with staggered reveal */}
              {show2D && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-[#FFD700] text-[13px] font-myanmar">
                    {mm ? "2D ကံကောင်းဂဏန်း" : "2D Lucky Numbers"}
                  </p>
                  <span className="text-[#FFD700]/50 text-[9px] font-myanmar bg-[#FFD700]/10 px-2 py-0.5 rounded-full">
                    {mm ? "တစ်ရက် ၂ ကြိမ်" : "2x Daily"}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  {lucky2D.map((num, idx) => (
                    <GlowingNumberCard
                      key={num}
                      number={num}
                      delay={revealStage >= 3 ? idx * 150 : 0}
                      onClick={() => copyNumber(num)}
                      isRevealing={revealStage < 3}
                    />
                  ))}
                </div>
              </div>
              )}

              {/* Motivational text with slide-up animation */}
              <div
                className="bg-[#FFD700]/10 border border-[#FFD700]/20 rounded-xl p-3 text-center"
                style={{
                  opacity: revealStage >= 3 ? 1 : 0,
                  transform: revealStage >= 3 ? 'translateY(0)' : 'translateY(12px)',
                  transition: 'all 500ms cubic-bezier(0.34, 1.56, 0.64, 1) 400ms',
                }}
              >
                <p className="text-[#FFD700] text-[14px] font-bold font-myanmar leading-relaxed">
                  {motivationalText}
                </p>
              </div>

              {/* History toggle button */}
              <button onClick={() => setShowHistory(!showHistory)}
                className="w-full bg-[#FFD700]/10 border border-[#FFD700]/20 rounded-xl py-3 flex items-center justify-center gap-2 btn-press">
                <Clock size={14} className="text-[#FFD700]" />
                <span className="text-[#FFD700] text-[12px] font-myanmar font-bold">
                  {showHistory
                    ? (mm ? "မှတ်တမ်း ပိတ်ရန်" : "Hide History")
                    : (mm ? "ယခင်ရက်မှတ်တမ်း ကြည့်ရန်" : "View Past History")}
                </span>
              </button>

              {/* History section */}
              {showHistory && (
                <div className="space-y-3 animate-section-up">
                  <div className="flex items-center gap-2">
                    <p className="text-[#FFD700] text-[13px] font-myanmar font-bold">
                      {mm ? "မှတ်တမ်း" : "History"}
                    </p>
                    <span className="text-[#FFD700]/40 text-[9px] font-myanmar">
                      {mm ? "ယခင်ရက် ၃၀" : "Past 30 days"}
                    </span>
                  </div>
                  <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1" style={{ scrollbarWidth: "thin" }}>
                    {historyDates.map((date, idx) => (
                      <HistoryDayRow
                        key={idx}
                        date={date}
                        userSeed={userSeed}
                        mm={mm}
                        copyNumber={copyNumber}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
