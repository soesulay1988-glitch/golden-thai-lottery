import { useState, useRef } from "react";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, Volume2, VolumeX, Star, Sparkles, Wand2, Calendar, Compass, Heart, BookOpen, Plane, Church } from "lucide-react";
import { toast } from "sonner";
import { getMyanmarYearInfo, getMyanmarBirthDisplay } from "@/lib/myanmarCalendar";

const MONTHS_MM = ["ဇန်နဝါရီ","ဖေဖော်ဝါရီ","မတ်","ဧပြီ","မေ","ဇွန်","ဇူလိုင်","သြဂုတ်","စက်တင်ဘာ","အောက်တိုဘာ","နိုဝင်ဘာ","ဒီဇင်ဘာ"];
const MONTHS_EN = ["January","February","March","April","May","June","July","August","September","October","November","December"];

// Myanmar calendar months (traditional names)
const MYANMAR_MONTHS = [
  "တန်ခူးလ", "ကဆုန်လ", "နယုန်လ", "ဝါဆိုလ",
  "ဝါခေါင်လ", "တော်သလင်းလ", "သီတင်းကျွတ်လ", "တန်ဆောင်မုန်းလ",
  "နတ်တော်လ", "ပြာသိုလ", "တပို့တွဲလ", "တပေါင်းလ"
];
const MYANMAR_MONTHS_EN = [
  "Tagu", "Kason", "Nayon", "Waso",
  "Wagaung", "Tawthalin", "Thadingyut", "Tazaungmon",
  "Nadaw", "Pyatho", "Tabodwe", "Tabaung"
];

const WEEKDAY_ICONS: Record<string, string> = {
  "တနင်္ဂနွေ": "🦅", "Sunday": "🦅",
  "တနင်္လာ": "🐯", "Monday": "🐯",
  "အင်္ဂါ": "🦁", "Tuesday": "🦁",
  "ဗုဒ္ဓဟူး": "🐘", "Wednesday": "🐘", "Wednesday (AM)": "🐘",
  "ကြာသပတေး": "🐀", "Thursday": "🐀",
  "သောကြာ": "🐹", "Friday": "🐹",
  "စနေ": "🐉", "Saturday": "🐉",
};

function getIcon(name: string) {
  for (const key of Object.keys(WEEKDAY_ICONS)) {
    if (name?.includes(key)) return WEEKDAY_ICONS[key];
  }
  return "⭐";
}

export default function Horoscope() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const [speaking, setSpeaking] = useState(false);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Birth date state
  const today = new Date();
  const [birthDay, setBirthDay] = useState<number>(1);
  const [birthMonth, setBirthMonth] = useState<number>(1);
  const [birthYear, setBirthYear] = useState<number>(1990);

  const [result, setResult] = useState<any>(null);

  // Myanmar year info
  const myanmarInfo = getMyanmarYearInfo(birthYear);

  const horoscopeMutation = trpc.horoscope.getPersonalized.useMutation({
    onSuccess: (data) => setResult(data),
    onError: (e) => toast.error(lang === "mm" ? "ဟောကိန်းရယူမရပါ — ထပ်ကြိုးစားပါ" : e.message),
  });

  // Days in selected month
  const daysInMonth = new Date(birthYear, birthMonth, 0).getDate();
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const years = Array.from({ length: today.getFullYear() - 1900 + 1 }, (_, i) => today.getFullYear() - i);

  // Gregorian year list (for dropdown) — use AD years internally
  const gregorianYears = Array.from({ length: 100 }, (_, i) => today.getFullYear() - i);

  // Day name in Myanmar
  const DAYS_MM = ["", "၁", "၂", "၃", "၄", "၅", "၆", "၇", "၈", "၉", "၁၀",
    "၁၁", "၁၂", "၁၃", "၁၄", "၁၅", "၁၆", "၁၇", "၁၈", "၁၉", "၂၀",
    "၂၁", "၂၂", "၂၃", "၂၄", "၂၅", "၂၆", "၂၇", "၂၈", "၂၉", "၃၀", "၃၁"];

  // Convert Myanmar month index to Gregorian month for submission
  function myanmarMonthToGregorian(mmMonthIdx: number): number {
    // Myanmar month 1 (တန်ခူး) ≈ April, Myanmar month 8 (တန်ဆောင်မုန်း) ≈ November
    // Approximate mapping: တန်ခူး(Apr)=4, ကဆုန်(May)=5, နယုန်(Jun)=6, ဝါဆို(Jul)=7,
    // ဝါခေါင်(Aug)=8, တော်သလင်း(Sep)=9, သီတင်းကျွတ်(Oct)=10, တန်ဆောင်မုန်း(Nov)=11,
    // နတ်တော်(Dec)=12, ပြာသို(Jan)=1, တပို့တွဲ(Feb)=2, တပေါင်း(Mar)=3
    const mapping = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
    return mapping[mmMonthIdx - 1] || 1;
  }

  function handleAsk() {
    if (birthDay > daysInMonth) setBirthDay(daysInMonth);
    horoscopeMutation.mutate({ birthDay, birthMonth, birthYear, language: lang as "mm" | "en" });
  }

  function speakResult() {
    if (!result) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const text = lang === "mm"
      ? `${result.birthWeekday}နေ့ဖွား။ ${result.personalityMm} ${result.weeklyMessageMm}`
      : `Born on ${result.birthWeekdayEn}. ${result.personalityEn} ${result.weeklyMessageEn}`;
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = lang === "mm" ? "my-MM" : "en-US";
    utt.rate = 0.9;
    utt.onend = () => setSpeaking(false);
    utt.onerror = () => setSpeaking(false);
    synthRef.current = utt;
    window.speechSynthesis.speak(utt);
    setSpeaking(true);
  }

  const selectClass = "bg-white border border-gray-200 rounded-xl px-3 py-2.5 text-sm font-myanmar text-[#333] focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-200 transition-all appearance-none cursor-pointer";

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/")} className="text-[#333] btn-press"><ArrowLeft size={20} /></button>
          <h1 className="font-display text-base font-bold text-[#333] flex-1">
            {lang === "mm" ? "မြန်မာ့ဗေဒင် ဟောကိန်း" : "Myanmar Astrology"}
          </h1>
          <div className="flex items-center gap-1 text-amber-600/60">
            <Sparkles size={14} />
            <span className="text-[10px] font-myanmar">AI</span>
          </div>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 py-4 space-y-4">

        {/* Birth date input card */}
        <div className="bg-white rounded-xl p-4 shadow-sm animate-fade-in-up">
          <div className="flex items-center gap-2 mb-3">
            <Calendar size={16} className="text-amber-600" />
            <p className="text-sm font-bold text-amber-600 font-myanmar">
              {lang === "mm" ? "မွေးနေ့ ထည့်ပါ" : "Enter Your Birth Date"}
            </p>
          </div>
          <p className="text-xs text-muted-foreground font-myanmar mb-4">
            {lang === "mm"
              ? "မွေးသက္ကရာဇ်ကို ထည့်သွင်းပြီး AI ဗေဒင်ဟောကိန်း ရယူပါ"
              : "Enter your birth date to get a personalized AI horoscope reading"}
          </p>

          {/* Day / Month / Year selectors */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            {/* Day */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-amber-600/70 font-myanmar">
                {lang === "mm" ? "ရက်" : "Day"}
              </label>
              <select
                value={birthDay}
                onChange={e => setBirthDay(Number(e.target.value))}
                className={selectClass}
              >
                {days.map(d => (
                  <option key={d} value={d}>
                    {lang === "mm" ? (DAYS_MM[d] || String(d)) : String(d)}
                  </option>
                ))}
              </select>
            </div>
            {/* Month — Myanmar month names */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-amber-600/70 font-myanmar">
                {lang === "mm" ? "လ" : "Month"}
              </label>
              <select
                value={birthMonth}
                onChange={e => setBirthMonth(Number(e.target.value))}
                className={selectClass}
              >
                {months.map(m => (
                  <option key={m} value={m}>
                    {lang === "mm" ? MYANMAR_MONTHS[m - 1] : MYANMAR_MONTHS_EN[m - 1]}
                  </option>
                ))}
              </select>
            </div>
            {/* Year — shows both AD and Myanmar year */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-amber-600/70 font-myanmar">
                {lang === "mm" ? "နှစ်" : "Year"}
              </label>
              <select
                value={birthYear}
                onChange={e => setBirthYear(Number(e.target.value))}
                className={selectClass}
              >
                {gregorianYears.map(y => (
                  <option key={y} value={y}>
                    {lang === "mm" ? `AD ${y} / မြန်မာ ${y - 638}` : `${y}`}  
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Myanmar Year Display */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl px-3 py-2.5 mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-base">🏛️</span>
              <div>
                <p className="text-[10px] text-amber-600/70 font-myanmar">
                  {lang === "mm" ? "မြန်မာ ခုနှစ်" : "Myanmar Year"}
                </p>
                <p className="text-sm font-bold text-amber-700 font-myanmar">
                  AD {birthYear} / မြန်မာ {birthYear - 638}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-amber-600/70 font-myanmar">
                {lang === "mm" ? "ရာသီခွင်" : "Zodiac"}
              </p>
              <p className="text-sm font-bold text-amber-700 font-myanmar">
                {lang === "mm" ? myanmarInfo.cycleMm : myanmarInfo.cycle}
              </p>
            </div>
          </div>

          <button
            onClick={handleAsk}
            disabled={horoscopeMutation.isPending}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-400 text-white font-bold py-3 rounded-xl text-sm font-myanmar disabled:opacity-50 transition-all btn-press flex items-center justify-center gap-2"
          >
            {horoscopeMutation.isPending ? (
              <>
                <span className="animate-spin">✨</span>
                {lang === "mm" ? "ဟောကိန်းရှာနေသည်..." : "Reading stars..."}
              </>
            ) : (
              <>
                <Wand2 size={16} />
                {lang === "mm" ? "ဟောကိန်းကြည့်ရန်" : "Get My Horoscope"}
              </>
            )}
          </button>
        </div>

        {/* Result */}
        {result && (
          <div className="space-y-3 animate-fade-in-up">

            {/* Header card */}
            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{getIcon(lang === "mm" ? result.birthWeekday : result.birthWeekdayEn)}</span>
                  <div>
                    <p className="text-base font-bold text-amber-600 font-myanmar">
                      {lang === "mm" ? result.birthWeekday : result.birthWeekdayEn}
                      {lang === "mm" ? "နေ့ဖွား" : " Born"}
                    </p>
                    <p className="text-xs text-muted-foreground font-myanmar">
                      {lang === "mm" ? result.rulingPlanet : result.rulingPlanetEn}
                    </p>
                    {/* Myanmar Year Badge */}
                    <p className="text-[10px] text-amber-600 font-myanmar mt-0.5">
                      {lang === "mm" ? `AD ${birthYear} / မြန်မာ ${birthYear - 638} · ${myanmarInfo.cycleMm}` : `${myanmarInfo.cycle} · AD ${birthYear} / Myanmar ${birthYear - 638}`}
                    </p>
                    <div className="flex mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} size={12} className={i < (result.overallFortune ?? 3) ? "text-yellow-400" : "text-muted-foreground/30"} fill="currentColor" />
                      ))}
                    </div>
                  </div>
                </div>
                <button
                  onClick={speakResult}
                  className={`p-2 rounded-xl transition-all btn-press ${speaking ? "bg-amber-100 text-amber-600" : "bg-white text-amber-600 border border-gray-200"}`}
                >
                  {speaking ? <VolumeX size={18} /> : <Volume2 size={18} />}
                </button>
              </div>
              <p className="text-sm text-foreground/90 font-myanmar leading-relaxed">
                {lang === "mm" ? result.personalityMm : result.personalityEn}
              </p>
            </div>

            {/* Weekly fortune — expanded categories */}
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <p className="text-xs text-amber-600/70 font-myanmar font-bold mb-3 uppercase tracking-widest">
                {lang === "mm" ? "ဤအပတ် ဟောကိန်း" : "This Week's Fortune"}
              </p>
              <div className="space-y-3">
                {[
                  { icon: "❤️", label: lang === "mm" ? "အချစ်ရေး" : "Love", text: lang === "mm" ? result.loveMm : result.loveEn },
                  { icon: "💼", label: lang === "mm" ? "အလုပ်ကိစ္စ" : "Career", text: lang === "mm" ? result.careerMm : result.careerEn },
                  { icon: "💚", label: lang === "mm" ? "ကျန်းမာရေး" : "Health", text: lang === "mm" ? result.healthMm : result.healthEn },
                  { icon: "💰", label: lang === "mm" ? "ငွေကြေး" : "Finance", text: lang === "mm" ? result.financeMm : result.financeEn },
                  { icon: "👨‍👩‍👧", label: lang === "mm" ? "မိသားစု" : "Family", text: lang === "mm" ? (result.familyMm || result.familyMm === "" ? result.familyMm : "") : (result.familyEn || ""), iconEl: "👨‍👩‍👧" },
                  { icon: "📚", label: lang === "mm" ? "ပညာရေး" : "Education", text: lang === "mm" ? (result.educationMm || "") : (result.educationEn || ""), iconEl: "📚" },
                  { icon: "✈️", label: lang === "mm" ? "ခရီးသွား" : "Travel", text: lang === "mm" ? (result.travelMm || "") : (result.travelEn || ""), iconEl: "✈️" },
                  { icon: "🙏", label: lang === "mm" ? "ဝိညာဉ်ရေး" : "Spiritual", text: lang === "mm" ? (result.spiritualMm || "") : (result.spiritualEn || ""), iconEl: "🙏" },
                ].filter(row => row.text).map((row, idx) => (
                  <div key={idx} className="flex gap-3 py-2 border-b border-amber-100 last:border-0">
                    <span className="text-lg mt-0.5">{row.icon}</span>
                    <div>
                      <p className="text-[10px] text-amber-600/70 font-myanmar font-bold mb-0.5">{row.label}</p>
                      <p className="text-sm text-foreground/85 font-myanmar leading-relaxed">{row.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Lucky info */}
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-white rounded-xl p-3 shadow-sm">
                <p className="text-[10px] text-muted-foreground font-myanmar mb-1">{lang === "mm" ? "ကံကောင်းရောင်" : "Lucky Color"}</p>
                <p className="text-sm font-bold text-amber-600 font-myanmar">{lang === "mm" ? result.luckyColorMm : result.luckyColor}</p>
              </div>
              <div className="bg-white rounded-xl p-3 shadow-sm">
                <p className="text-[10px] text-muted-foreground font-myanmar mb-1">{lang === "mm" ? "ကံကောင်းဦးတည်" : "Lucky Direction"}</p>
                <p className="text-sm font-bold text-amber-600 font-myanmar">{lang === "mm" ? result.luckyDirectionMm : result.luckyDirection}</p>
              </div>
              <div className="bg-white rounded-xl p-3 shadow-sm">
                <p className="text-[10px] text-muted-foreground font-myanmar mb-1">{lang === "mm" ? "ကံကောင်းနေ့" : "Lucky Day"}</p>
                <p className="text-sm font-bold text-amber-600 font-myanmar">{lang === "mm" ? result.luckyDayMm : result.luckyDay}</p>
              </div>
              <div className="bg-white rounded-xl p-3 shadow-sm">
                <p className="text-[10px] text-muted-foreground font-myanmar mb-1">{lang === "mm" ? "ကံကောင်းဂဏန်း (၂ဒီ)" : "Lucky 2D"}</p>
                <div className="flex gap-1 flex-wrap">
                  {result.lucky2dNumbers?.slice(0, 3).map((n: string) => (
                    <span key={n} className="prize-number text-sm font-bold text-emerald-400">{n}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Lottery numbers */}
            {result.luckyLotteryNumbers?.length > 0 && (
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
                <p className="text-[10px] text-amber-600/70 font-myanmar mb-2">{lang === "mm" ? "ကံကောင်းလော့တာဂဏန်း" : "Lucky Lottery Numbers"}</p>
                <div className="flex flex-wrap gap-2">
                  {result.luckyLotteryNumbers.map((n: string) => (
                    <span key={n} className="prize-number text-base font-bold text-amber-600 bg-amber-50 px-3 py-1.5 rounded-xl border border-gray-200">{n}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Weekly message */}
            <div className="bg-white rounded-xl p-4 shadow-sm border border-purple-500/20 bg-purple-500/5">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles size={14} className="text-purple-400" />
                <p className="text-[10px] text-purple-400/80 font-myanmar font-bold uppercase tracking-widest">
                  {lang === "mm" ? "ဤအပတ် အကြံပြုချက်" : "Weekly Advice"}
                </p>
              </div>
              <p className="text-sm text-foreground/90 font-myanmar leading-relaxed italic">
                {lang === "mm" ? result.weeklyMessageMm : result.weeklyMessageEn}
              </p>
            </div>

            {/* Ask again */}
            <button
              onClick={() => setResult(null)}
              className="w-full bg-white text-amber-600 font-myanmar text-sm py-2.5 rounded-xl btn-press"
            >
              {lang === "mm" ? "ထပ်မေးရန် (မွေးနေ့ ပြောင်းရန်)" : "Ask Again (Change Birth Date)"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
