import { useLang } from "@/contexts/LangContext";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { formatCalendar3DDrawTarget, getNextThaiLotteryDrawTarget } from "@/lib/calendar3DDrawSchedule";
import {
  Ticket, Grid3X3, BookOpen, Star,
  CalendarDays, Sparkles, ChevronRight, User, Globe, Crown, Zap, TicketCheck, MoreHorizontal, RefreshCw, Clock, Share2, Check, MessageCircle, X, ImagePlus, NotebookPen
} from "lucide-react";
import { useState, useEffect, useRef, useCallback } from "react";
import { canShowMyanmarMarketBoard, getCurrentDayLiveMarket, getCurrentDayVerifiedMarketResult, getMyanmarMarketSession } from "@/lib/twoDMarket";
import { getLuckyContentPeriod, getMyanmarDate } from "@/lib/luckySchedule";

// ─── Tap Sound Effect ───────────────────────────────────────────────────────
function playTapSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.setValueAtTime(800, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.08);
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.15);
  } catch { /* silent fail */ }
}

// ─── Notification Sound (plays when new lucky numbers are available) ───────
// Pre-generated bell chime as AudioBuffer to avoid autoplay issues
let cachedAudioBuffer: AudioBuffer | null = null;
async function getNotificationBuffer(): Promise<AudioBuffer | null> {
  try {
    if (cachedAudioBuffer) return cachedAudioBuffer;
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const sampleRate = ctx.sampleRate;
    const duration = 1.2; // seconds
    const length = Math.ceil(sampleRate * duration);
    const buffer = ctx.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    // Bell-like chime: 3 descending notes with decay
    const notes = [
      { freq: 880, start: 0, dur: 0.4 },
      { freq: 1100, start: 0.15, dur: 0.4 },
      { freq: 1320, start: 0.30, dur: 0.5 },
    ];
    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      let sample = 0;
      for (const note of notes) {
        if (t >= note.start && t < note.start + note.dur) {
          const nt = t - note.start;
          const envelope = Math.exp(-nt * 5); // fast decay
          sample += Math.sin(2 * Math.PI * note.freq * nt) * envelope * 0.3;
        }
      }
      data[i] = Math.max(-1, Math.min(1, sample));
    }
    cachedAudioBuffer = buffer;
    return buffer;
  } catch { return null; }
}

function playNewNumbersSound() {
  try {
    const AudioCtx = (window.AudioContext || (window as any).webkitAudioContext);
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    // Resume if suspended
    if (ctx.state === 'suspended') ctx.resume();
    getNotificationBuffer().then(buf => {
      if (!buf) return;
      const source = ctx.createBufferSource();
      source.buffer = buf;
      source.connect(ctx.destination);
      source.start(0);
    });
  } catch { /* silent fail */ }
}

// The Home badge and Lucky page use one shared period, so a viewed badge only
// returns after the next scheduled 2D or 3D content update.
function hasViewedLuckyCurrentPeriod(): boolean {
  try {
    const period = getLuckyContentPeriod(getMyanmarDate());
    const key = `lucky_seen_cards_${period}`;
    const raw = localStorage.getItem(key);
    if (!raw) return false;
    const seenIds: string[] = JSON.parse(raw);
    return seenIds.includes("nekkun");
  } catch { return false; }
}

// Myanmar 2D sessions: morning (12:00-14:00), evening (16:30-18:00) UTC+7
// Thai Lottery: 1st and 16th of each month, afternoon (14:30+) UTC+7
function getNextLotteryEvent() {
  const now = new Date();
  const utc7 = new Date(now.getTime() + 7 * 60 * 60 * 1000);
  const day = utc7.getUTCDate();
  const hour = utc7.getUTCHours();
  const minute = utc7.getUTCMinutes();
  const dayOfWeek = utc7.getUTCDay(); // 0=Sun

  // Thai lottery: 1st and 16th, draw at ~14:30
  const isThaiDrawDay = day === 1 || day === 16;
  const thaiDrawHour = 14, thaiDrawMin = 30;
  const thaiDrawPassed = isThaiDrawDay && (hour > thaiDrawHour || (hour === thaiDrawHour && minute >= thaiDrawMin));

  // Myanmar 2D: Mon-Sat (5 days), morning 12:00, evening 16:30
  const isMyanmarDrawDay = dayOfWeek !== 0 && dayOfWeek !== 6; // Mon-Fri
  // Actually Myanmar 2D runs Mon-Sat (not Sunday)
  const isMyanmar2DDay = dayOfWeek !== 0; // Mon-Sat
  const amHour = 12, amMin = 0;
  const pmHour = 16, pmMin = 30;
  const amPassed = isMyanmar2DDay && (hour > amHour || (hour === amHour && minute >= amMin));
  const pmPassed = isMyanmar2DDay && (hour > pmHour || (hour === pmHour && minute >= pmMin));

  // Calculate next events
  type Event = { type: string; labelMm: string; labelEn: string; time: Date };
  const events: Event[] = [];

  // Next Thai lottery draw
  let thaiNext = new Date(utc7);
  if (thaiDrawPassed) {
    // Next draw is 16th or 1st of next period
    if (day < 16) thaiNext.setUTCDate(16);
    else thaiNext.setUTCDate(1); // or 1st of next month
    thaiNext.setUTCHours(thaiDrawHour, thaiDrawMin, 0, 0);
  } else {
    thaiNext.setUTCHours(thaiDrawHour, thaiDrawMin, 0, 0);
  }
  events.push({ type: "thai", labelMm: "ထိုင်းထီ", labelEn: "Thai Lottery", time: thaiNext });

  // Next Myanmar 2D AM session
  if (amPassed) {
    const amNext = new Date(utc7);
    if (isMyanmar2DDay) {
      // Next session is PM today or AM tomorrow
      if (!pmPassed) {
        amNext.setUTCHours(pmHour, pmMin, 0, 0);
      } else {
        amNext.setUTCDate(amNext.getUTCDate() + 1);
        if (amNext.getUTCDay() === 0) amNext.setUTCDate(amNext.getUTCDate() + 1); // skip Sunday
        amNext.setUTCHours(amHour, amMin, 0, 0);
      }
    } else {
      amNext.setUTCDate(amNext.getUTCDate() + 1);
      if (amNext.getUTCDay() === 0) amNext.setUTCDate(amNext.getUTCDate() + 1);
      amNext.setUTCHours(amHour, amMin, 0, 0);
    }
    events.push({ type: "myanmar-am", labelMm: "၂ဒီ မနက်", labelEn: "2D AM", time: amNext });
  } else {
    const amToday = new Date(utc7);
    amToday.setUTCHours(amHour, amMin, 0, 0);
    events.push({ type: "myanmar-am", labelMm: "၂ဒီ မနက်", labelEn: "2D AM", time: amToday });
  }

  // Next Myanmar 2D PM session
  if (!pmPassed) {
    const pmToday = new Date(utc7);
    pmToday.setUTCHours(pmHour, pmMin, 0, 0);
    events.push({ type: "myanmar-pm", labelMm: "၂ဒီ ညနေ", labelEn: "2D PM", time: pmToday });
  } else {
    const pmNext = new Date(utc7);
    pmNext.setUTCDate(pmNext.getUTCDate() + 1);
    if (pmNext.getUTCDay() === 0) pmNext.setUTCDate(pmNext.getUTCDate() + 1); // skip Sunday
    pmNext.setUTCHours(pmHour, pmMin, 0, 0);
    events.push({ type: "myanmar-pm", labelMm: "၂ဒီ ညနေ", labelEn: "2D PM", time: pmNext });
  }

  events.sort((a, b) => a.time.getTime() - b.time.getTime());
  return events[0];
}

function useCountdown(target: Date | null): { hours: number; minutes: number; seconds: number } {
  const [now, setNow] = useState(() => new Date());
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!target) return;
    intervalRef.current = setInterval(() => setNow(new Date()), 1000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [target]);

  if (!target) return { hours: 0, minutes: 0, seconds: 0 };

  const diff = Math.max(0, target.getTime() - now.getTime() - 7 * 60 * 60 * 1000);
  const totalSec = Math.floor(diff / 1000);
  return {
    hours: Math.floor(totalSec / 3600),
    minutes: Math.floor((totalSec % 3600) / 60),
    seconds: totalSec % 60,
  };
}

// ─── Share to Messenger Button ─────────────────────────────────────────
function ShareToMessengerButton({ lang }: { lang: string }) {
  const [showPanel, setShowPanel] = useState(false);
  const [copied, setCopied] = useState(false);
  const mm = lang === "mm";
  const APP_URL = typeof window !== "undefined" ? window.location.origin : "https://golden-thai-lottery-web.pages.dev";
  const shareText = mm
    ? `ရွှေထိုင်းလော့တာ & ၂ဒီ app ကို ကြည့်ပါ\n${APP_URL}`
    : lang === "th"
    ? `ดูผลหวยไทยและ 2D พม่าในแอปนี้\n${APP_URL}`
    : `Check Thai Lottery & Myanmar 2D results on this app\n${APP_URL}`;

  const handleMessengerShare = () => {
    // Open Messenger share dialog with the app link
    window.open(`https://m.me/?text=${encodeURIComponent(shareText)}`, "_blank");
    setShowPanel(false);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(APP_URL).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <>
      <button
        onClick={() => setShowPanel(true)}
        className="bg-white/40 border border-white/50 p-2 rounded-lg text-[#333] btn-press relative"
        title={mm ? "မျှဝေရန်" : "Share"}
      >
        <Share2 size={16} />
      </button>

      {/* Share panel */}
      {showPanel && (
        <div className="fixed inset-0 z-[400] flex items-end justify-center px-4 pb-6" onClick={() => setShowPanel(false)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px] animate-fade-in" />
          <div
            className="relative w-full max-w-[380px] rounded-2xl shadow-[0_-4px_40px_rgba(0,0,0,0.3)] overflow-hidden animate-section-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="bg-gradient-to-br from-amber-500 via-amber-600 to-orange-600 px-5 pt-5 pb-6 relative overflow-hidden">
              <div className="absolute -top-8 -right-8 w-28 h-28 rounded-full bg-white/10" />
              <div className="absolute -bottom-10 -left-6 w-20 h-20 rounded-full bg-white/5" />
              <button
                onClick={() => setShowPanel(false)}
                className="absolute top-3 right-3 w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-all duration-200 active:scale-90"
              >
                <X size={14} className="text-white" />
              </button>
              <h3 className="text-white font-bold text-[16px] font-myanmar">
                {mm ? "သူငယ်ချင်းတွေဆီ မျှဝေရန်" : lang === "th" ? "แชร์ให้เพื่อน" : "Share with Friends"}
              </h3>
              <p className="text-amber-100 text-[12px] mt-1">
                {mm ? "ဒီ app ကို သူငယ်ချင်းတွေဆီ ပို့ပါ" : lang === "th" ? "ส่งแอปนี้ให้เพื่อนของคุณ" : "Send this app to your friends"}
              </p>
            </div>

            {/* Options */}
            <div className="bg-white px-5 py-4 space-y-3">
              {/* Messenger share */}
              <button
                onClick={handleMessengerShare}
                className="w-full flex items-center gap-3 p-3 rounded-xl bg-[#0084FF] text-white font-bold text-[14px] btn-press shadow-md transition-all duration-200 active:scale-[0.98]"
              >
                <MessageCircle size={20} />
                {mm ? "Messenger ဖြင့် မျှဝေရန်" : lang === "th" ? "แชร์ผ่าน Messenger" : "Share to Messenger"}
              </button>

              {/* Copy link */}
              <button
                onClick={handleCopyLink}
                className="w-full flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-200 text-[#333] font-medium text-[14px] btn-press transition-all duration-200 active:scale-[0.98]"
              >
                {copied ? <Check size={20} className="text-green-600" /> : <Share2 size={20} className="text-gray-500" />}
                {copied
                  ? (mm ? "✓ ကူးပြီးပါပြီ!" : lang === "th" ? "✓ คัดลอกแล้ว!" : "✓ Link copied!")
                  : (mm ? "Link ကူးယူရန်" : lang === "th" ? "คัดลอกลิงก์" : "Copy link")
                }
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}


const FALLBACK_THAI_DRAW_2026_09_01: any = {
  id: 20260901,
  drawDate: "2026-09-01T00:00:00.000Z",
  firstPrize: "417212",
  nearFirstPrize: ["417211", "417213"],
  firstThreeDigits: ["257", "346"],
  lastThreeDigits: ["136", "740"],
  lastTwoDigits: "04",
  secondPrize: ["082727", "713900", "806626", "936526", "989370"],
  thirdPrize: ["070925", "177649", "358935", "428320", "507383", "673807", "809293", "870961", "943127", "967840"],
  fourthPrize: [],
  fifthPrize: [],
};

export default function Home() {
  const { lang, t, toggle } = useLang();
  const [, navigate] = useLocation();
  const [homeClock, setHomeClock] = useState(() => new Date());
  const nextThreeDDrawLabel = formatCalendar3DDrawTarget(getNextThaiLotteryDrawTarget(homeClock));
  const mm = lang === "mm";

  useEffect(() => {
    const interval = window.setInterval(() => setHomeClock(new Date()), 60_000);
    return () => window.clearInterval(interval);
  }, []);

  // Auto-refetch lottery data every 30 seconds
  const { data: latestDraw, refetch: refetchLottery } = trpc.thaiLottery.getLatest.useQuery(undefined, {
    refetchInterval: 30000,
  });
  const homeLatestDraw: any = latestDraw ?? FALLBACK_THAI_DRAW_2026_09_01;
  const { data: latest2D, refetch: refetch2D } = trpc.myanmar2d.getLatest.useQuery(undefined, {
    refetchInterval: 15000,
  });
  const { data: live2DResponse } = trpc.myanmar2d.getLive.useQuery(undefined, {
    refetchInterval: 15000,
    refetchIntervalInBackground: true,
  });

  // Next draw countdown
  const nextEvent = getNextLotteryEvent();
  const countdown = useCountdown(nextEvent.time);

  const isThaiDrawTime = countdown.hours === 0 && countdown.minutes === 0 && countdown.seconds === 0;

  // Auto-refresh on draw day
  useEffect(() => {
    if (isThaiDrawTime) {
      const t = setTimeout(() => { refetchLottery(); refetch2D(); }, 60000);
      return () => clearTimeout(t);
    }
  }, [isThaiDrawTime, refetchLottery, refetch2D]);

  // Play notification sound when new lucky numbers are available
  // Use state so badge updates when localStorage changes (e.g., after visiting /lucky)
  const [hasSeenLuckyInSession, setHasSeenLuckyInSession] = useState(() => hasViewedLuckyCurrentPeriod());
  const notifiedRef = useRef(false);
  const audioUnlockedRef = useRef(false);

  // Listen for localStorage changes (when user visits /lucky and marks cards seen)
  useEffect(() => {
      const handler = (e: StorageEvent) => {
        if (e.key && e.key.startsWith('lucky_seen_cards_')) {
        setHasSeenLuckyInSession(hasViewedLuckyCurrentPeriod());
      }
    };
    window.addEventListener('storage', handler);
    // Also poll every 2 seconds in case same-tab changes happen
      const interval = setInterval(() => {
      setHasSeenLuckyInSession(hasViewedLuckyCurrentPeriod());
      }, 2000);
    return () => {
      window.removeEventListener('storage', handler);
      clearInterval(interval);
    };
  }, []);
  
  // Unlock AudioContext on first user interaction (browsers block autoplay)
  useEffect(() => {
    const unlock = () => {
      if (!audioUnlockedRef.current) {
        try {
          const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
          if (ctx.state === 'suspended') ctx.resume();
          audioUnlockedRef.current = true;
        } catch { /* ignore */ }
      }
      window.removeEventListener('touchstart', unlock);
      window.removeEventListener('click', unlock);
    };
    window.addEventListener('touchstart', unlock, { once: true });
    window.addEventListener('click', unlock, { once: true });
    return () => {
      window.removeEventListener('touchstart', unlock);
      window.removeEventListener('click', unlock);
    };
  }, []);

  // Play sound immediately on first render if badge is visible
  useEffect(() => {
    if (!hasSeenLuckyInSession && !notifiedRef.current) {
      notifiedRef.current = true;
      const timer = setTimeout(() => playNewNumbersSound(), 100);
      return () => clearTimeout(timer);
    }
  }, [hasSeenLuckyInSession]);

  const menuCards = [
    {
      icon: Ticket,
      titleMm: "ထိုင်းထီ စစ်ဆေးရန်",
      titleEn: "Thai Lottery",
      titleTh: "ตรวจหวยไทย",
      descMm: "ရလဒ်စစ်ဆေးရန်",
      descEn: "Check results",
      descTh: "ตรวจผลรางวัล",
      path: "/lottery",
      color: "#E8443A",
      badge: "HOT",
      badgeColor: "bg-red-500",
    },
    {
      icon: Grid3X3,
      titleMm: "မြန်မာ ၂ဒီ",
      titleEn: "Myanmar 2D",
      titleTh: "พม่า 2D",
      descMm: "တိုက်ရိုက် ရလဒ်",
      descEn: "Live results",
      descTh: "ผลสด",
      path: "/2d",
      color: "#FFD700",
      badge: "LIVE",
      badgeColor: "bg-green-500",
    },
    {
      icon: CalendarDays,
      titleMm: "၃ဒီ ပြက္ခဒိန်",
      titleEn: "3D Calendar",
      titleTh: "ปฏิทิน 3D",
      descMm: "၁၉၇၁–၂၀၂၆",
      descEn: "1971–2026",
      descTh: "1971–2026",
      path: "/3d",
      color: "#5B8DEF",
      badge: null,
      badgeColor: "",
    },
    {
      icon: BookOpen,
      titleMm: "အိမ်မက်တစ်ထောင်",
      titleEn: "Dream Dict",
      titleTh: "ทำนายฝัน",
      descMm: "ဂဏန်းရှာပါ",
      descEn: "Find lucky numbers",
      descTh: "ค้นหาเลขนำโชค",
      path: "/dreams",
      color: "#9B59B6",
      badge: null,
      badgeColor: "",
    },
    {
      icon: Sparkles,
      titleMm: "အိမ်မက်ဟောကိန်း",
      titleEn: "AI Dream",
      titleTh: "AI ทำนายฝัน",
      descMm: "အိပ်မက်မှ ကံကောင်းဂဏန်း",
      descEn: "Dream lucky numbers",
      descTh: "เลขนำโชคจากฝัน",
      path: "/dream-ai",
      color: "#E91E63",
      badge: "AI",
      badgeColor: "bg-pink-500",
    },
    {
      icon: Star,
      titleMm: "မဟာဘုတ် ဟောကိန်း",
      titleEn: "Mahaboke",
      titleTh: "มหาโบราณ",
      descMm: "တစ်ပတ်စာ ဟောကိန်း",
      descEn: "Weekly horoscope",
      descTh: "ดวงรายสัปดาห์",
      path: "/mahaboke",
      color: "#FF9800",
      badge: null,
      badgeColor: "",
    },
    {
      icon: Zap,
      titleMm: "LUCKY NUMBER",
      titleEn: "LUCKY NUMBER",
      titleTh: "เลขนำโชค",
      descMm: "3D ကံကောင်းဂဏန်း & 2D",
      descEn: "3D Lucky & Daily 2D",
      descTh: "3D นำโชค & 2D รายวัน",
      path: "/lucky",
      color: "#FFD700",
      badge: "AI",
      badgeColor: "bg-amber-500",
    },
    {
      icon: NotebookPen,
      titleMm: "ကံထူးမှတ်တမ်း",
      titleEn: "Lucky Notes",
      titleTh: "บันทึกเลข",
      descMm: "စာသားနှင့် ဂဏန်းများ မှတ်ရန်",
      descEn: "Save personal notes and numbers",
      descTh: "บันทึกข้อความและตัวเลข",
      path: "/lucky-notes",
      color: "#7C3AED",
      badge: null,
      badgeColor: "",
    },
    {
      icon: ImagePlus,
      titleMm: "3D အထောက်အထားပုံ",
      titleEn: "3D Evidence Image",
      titleTh: "รูปหลักฐาน 3D",
      descMm: "Golden Thai တင်ထားသောပုံ ကြည့်ရန်",
      descEn: "View image posted by Golden Thai",
      descTh: "ดูรูปที่ Golden Thai โพสต์",
      path: "/3d-analysis",
      color: "#F59E0B",
      badge: "3D",
      badgeColor: "bg-amber-500",
    },

  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF8E1] to-[#f5f5f5]">
      {/* ─── Yellow Header ─────────────────────────────────────────────── */}
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto px-3 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-white/30 border border-white/40 flex items-center justify-center">
              <Crown size={14} className="text-[#333]" />
            </div>
            <div>
              <h1 className="text-[18px] font-bold text-[#333] leading-tight font-myanmar-display">
                {t("appName")}
              </h1>
              <p className="text-[13px] text-[#555] font-myanmar leading-tight">
                {t("appTagline")}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <ShareToMessengerButton lang={lang} />
            <button
              onClick={toggle}
              className="flex items-center gap-0.5 bg-white/40 border border-white/50 px-2 py-1 rounded-lg text-[11px] font-bold text-[#333] btn-press"
            >
              <Globe size={10} />
              {lang === "mm" ? "EN" : lang === "en" ? "ไทย" : "မြန်မာ"}
            </button>
            <button
              onClick={() => navigate("/profile")}
              className="bg-white/40 border border-white/50 p-2 rounded-lg text-[#333] btn-press"
            >
              <User size={16} />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-3 pt-2 pb-24 space-y-2">

        {/* ─── Next Draw Countdown ──────────────────────────────────── */}
        {nextEvent && (
          <div className="bg-gradient-to-r from-[#FFF8E1] to-[#FFFDE7] rounded-xl px-3 py-2 flex items-center justify-between shadow-sm border border-[#FFD700]/20 animate-fade-in-up">
            <div className="flex items-center gap-2">
              <Clock size={14} className="text-[#FFD700]" />
              <div>
                <p className="text-[15px] font-bold text-[#333] font-myanmar-display">
                  {lang === "mm" ? nextEvent.labelMm : lang === "th" ? nextEvent.labelEn : nextEvent.labelEn}
                </p>
                <p className="text-[11px] text-gray-400 font-myanmar">
                  {t("nextDraw")}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-0.5">
              <span className="bg-[#333] text-white rounded-lg px-1.5 py-0.5 text-[11px] font-mono font-bold min-w-[24px] text-center">
                {String(countdown.hours).padStart(2, "0")}
              </span>
              <span className="text-gray-400 text-xs font-bold">:</span>
              <span className="bg-[#333] text-white rounded-lg px-1.5 py-0.5 text-[11px] font-mono font-bold min-w-[24px] text-center">
                {String(countdown.minutes).padStart(2, "0")}
              </span>
              <span className="text-gray-400 text-xs font-bold">:</span>
              <span className="bg-[#FFD700] text-[#333] rounded-lg px-1.5 py-0.5 text-[11px] font-mono font-bold min-w-[24px] text-center animate-pulse">
                {String(countdown.seconds).padStart(2, "0")}
              </span>
            </div>
          </div>
        )}

        {/* ─── Quick Chat Entry ─────────────────────────────────────── */}
        <button
          onClick={() => { playTapSound(); navigate("/2d?chat=1"); }}
          className="flex w-full items-center gap-2.5 rounded-xl border border-[#e4a820]/55 bg-[#fffdf2] px-3 py-2 text-left shadow-sm btn-press animate-fade-in-up"
          style={{ animationDelay: "20ms" }}
        >
          <span className="animate-chat-attention flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#fff0be] text-[#9a6500]">
            <MessageCircle size={17} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[13px] font-black text-[#4a3500] font-myanmar">ဆွေးနွေးခန်း</span>
            <span className="block truncate text-[10px] text-[#8a6a20] font-myanmar">၂ဒီသတင်းနှင့် ရလဒ်အကြောင်း ပြောရန်နှိပ်ပါ</span>
          </span>
          <span className="rounded-full bg-[#fff0be] px-2 py-1 text-[10px] font-black text-[#9a6500]">Chat</span>
          <ChevronRight size={16} className="shrink-0 text-[#9a6500]" />
        </button>

        {/* ─── Hero: Latest Thai Lottery — Red Card ──────────────────── */}
        {homeLatestDraw ? (
          <div
            onClick={() => navigate("/lottery")}
            className="bg-[#E8443A] rounded-xl p-3 cursor-pointer shadow-lg animate-fade-in-up"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-white/20 flex items-center justify-center">
                  <Crown size={12} className="text-white" />
                </div>
                <div>
                  <p className="text-[15px] font-bold text-white font-myanmar-display">
                    {t("latestDraw")}
                  </p>
                  <p className="text-[12px] text-white/70 font-myanmar">
                    {new Date(homeLatestDraw.drawDate).toLocaleDateString(lang === "mm" ? "my-MM" : lang === "th" ? "th-TH" : "en-US", {
                      day: "numeric", month: "short", year: "numeric"
                    })}
                  </p>
                </div>
              </div>
              <ChevronRight size={16} className="text-white/70" />
            </div>
            <div className="flex items-end justify-between">
              <div>
                <p className="text-[12px] text-white/60 font-myanmar mb-0.5">
                  {t("firstPrize")}
                </p>
                <div className="flex gap-1">
                  {(homeLatestDraw.firstPrize ?? "------").split("").map((digit: string, i: number) => (
                    <div key={i} className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm">
                      <span className="prize-number text-lg font-black text-[#333]">{digit}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="text-right">
                <p className="text-[12px] text-white/60 font-myanmar mb-0.5">
                  {t("last2Digits")}
                </p>
                <span className="prize-number text-3xl font-black text-[#FFD700]">
                  {homeLatestDraw.lastTwoDigits ?? "--"}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-[#E8443A]/10 rounded-xl p-3 border-2 border-dashed border-[#E8443A]/30 animate-fade-in-up">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-[#E8443A]/20 flex items-center justify-center">
                  <Crown size={12} className="text-[#E8443A]/50" />
                </div>
                <div>
                  <div className="h-3 w-28 bg-[#E8443A]/20 rounded mb-1" />
                  <div className="h-2.5 w-20 bg-[#E8443A]/15 rounded" />
                </div>
              </div>
            </div>
            <div className="flex items-end justify-between">
              <div>
                <div className="h-2.5 w-24 bg-[#E8443A]/15 rounded mb-2" />
                <div className="flex gap-1">
                  {[0,1,2,3,4,5].map(i => (
                    <div key={i} className="w-9 h-9 bg-white rounded-lg flex items-center justify-center shadow-sm border border-gray-200">
                      <span className="text-xl font-black text-gray-300">-</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="text-right">
                <div className="h-2.5 w-16 bg-[#E8443A]/15 rounded mb-2 ml-auto" />
                <div className="h-9 w-14 bg-[#E8443A]/20 rounded" />
              </div>
            </div>
          </div>
        )}

        {/* ─── Live 2D Banner — Yellow Card ──────────────────────────── */}
        {(() => {
          const myanmarNow = new Date(new Date().getTime() + 6.5 * 60 * 60 * 1000);
          const todayStr = myanmarNow.toISOString().split("T")[0];
          // Filter: only show today's results
          const today2D = (latest2D || []).filter((r: any) => {
            const rdStr = String(r.resultDate);
            const d = new Date(rdStr);
            const rDate = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
            return rDate === todayStr;
          });
          const day = myanmarNow.getUTCDate();
          const month = myanmarNow.getUTCMonth() + 1;
          const year = myanmarNow.getUTCFullYear();
          const morning = today2D.find((r: any) => r.session === "morning");
          const evening = today2D.find((r: any) => r.session === "evening");
          const marketSession = getMyanmarMarketSession();
          const marketBoardVisible = canShowMyanmarMarketBoard();
          const liveMarket = getCurrentDayLiveMarket(live2DResponse?.success ? live2DResponse.live : null);
          const providerResults = live2DResponse?.success ? live2DResponse.results : [];
          const providerMorning = getCurrentDayVerifiedMarketResult(providerResults, "morning");
          const providerEvening = getCurrentDayVerifiedMarketResult(providerResults, "evening");
          const displayMorning = morning || (providerMorning ? {
            winningNumber: providerMorning.twod,
            setNumber: providerMorning.set,
            valueNumber: providerMorning.value,
          } : undefined);
          const displayEvening = evening || (providerEvening ? {
            winningNumber: providerEvening.twod,
            setNumber: providerEvening.set,
            valueNumber: providerEvening.value,
          } : undefined);
          const marketFor = (session: "morning" | "evening", result?: any) => {
            if (marketBoardVisible && result?.setNumber && result?.valueNumber) {
              return { set: result.setNumber, value: result.valueNumber };
            }
            if (marketSession === session && liveMarket?.set && liveMarket?.value) {
              return { set: liveMarket.set, value: liveMarket.value };
            }
            return { set: "--", value: "--" };
          };
          const morningMarket = marketFor("morning", displayMorning);
          const eveningMarket = marketFor("evening", displayEvening);
          const liveTwoDRaw = String(liveMarket?.twod || "").trim();
          const currentSessionResult = marketSession === "morning" ? displayMorning : marketSession === "evening" ? displayEvening : undefined;
          const currentSessionTwoD = String(currentSessionResult?.winningNumber || "").trim();
          const latestSettledTwoD = String(displayEvening?.winningNumber || displayMorning?.winningNumber || "").trim();
          const liveTwoD = /^\d{1,2}$/.test(currentSessionTwoD)
            ? currentSessionTwoD.padStart(2, "0")
            : marketSession && /^\d{1,2}$/.test(liveTwoDRaw)
              ? liveTwoDRaw.padStart(2, "0")
              : marketBoardVisible && /^\d{1,2}$/.test(latestSettledTwoD)
                ? latestSettledTwoD.padStart(2, "0")
                : "--";
          const SessionResult = ({ label, result, session }: { label: string; result?: any; session: "morning" | "evening" }) => {
            const hasResult = Boolean(result?.winningNumber);
            const isMorning = session === "morning";
            const accent = isMorning ? "#075985" : "#b42318";
            const numberColor = hasResult ? accent : "#87792e";
            const sessionFontClass = lang === "mm" ? "font-myanmar" : "font-sans";
            return (
            <div className="flex h-[36px] items-center gap-2 whitespace-nowrap">
              <span className={`shrink-0 text-[14px] font-black ${sessionFontClass}`} style={{ color: accent }}>{label}</span>
              <span className="prize-number shrink-0 text-[25px] font-black leading-none tracking-tight" style={{ color: numberColor }}>
                {result?.winningNumber || "--"}
              </span>
            </div>
            );
          };
          const MarketPair = ({ market, session }: { market: { set: string; value: string }; session: "morning" | "evening" }) => {
            const hasMarket = market.set !== "--" && market.value !== "--";
            const valueClass = hasMarket ? (session === "morning" ? "text-[#075985]" : "text-[#b42318]") : "text-[#4b3c00]";
            const labelClass = session === "morning" ? "text-[#075985]" : "text-[#b42318]";
            return (
              <div className="h-[36px] leading-tight">
                <p className={`flex items-baseline justify-between gap-1 text-[11px] font-black ${labelClass}`}>
                  <span>SET</span><span className={`font-mono text-[15px] ${valueClass}`}>{market.set}</span>
                </p>
                <p className={`flex items-baseline justify-between gap-1 text-[11px] font-black ${labelClass}`}>
                  <span>VAL</span><span className={`font-mono text-[15px] ${valueClass}`}>{market.value}</span>
                </p>
              </div>
            );
          };
          return (
          <div
            onClick={() => navigate("/2d")}
            className="bg-[#FFD700] rounded-xl p-3 cursor-pointer shadow-md animate-fade-in-up"
            style={{ animationDelay: "40ms" }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                <span className="text-[15px] text-[#333] font-bold font-myanmar-display">
                  {t("live2D")}
                </span>
              </div>
              <ChevronRight size={14} className="text-[#555]" />
            </div>
            <div className="mt-1.5 -mx-1 rounded-[10px] border-2 border-[#876d00]/75 bg-white/25 px-2 py-2.5">
              <div className="grid grid-cols-[104px_minmax(0,1fr)_48px] items-center gap-1.5">
                <div className="divide-y-2 divide-[#8c7200]/75 border-r-2 border-[#8c7200]/55 pr-1.5">
                  <SessionResult label={t("morning")} result={displayMorning} session="morning" />
                  <SessionResult label={t("evening")} result={displayEvening} session="evening" />
                </div>
                <div className="divide-y-2 divide-[#8c7200]/75 border-r-2 border-[#8c7200]/55 pr-1.5">
                  <MarketPair market={morningMarket} session="morning" />
                  <MarketPair market={eveningMarket} session="evening" />
                </div>
                <div className="flex h-[76px] flex-col items-center justify-center rounded-md border-2 border-[#8c7200]/60 bg-[#fff7d0]/35">
                  <span className="text-[11px] font-black tracking-wide text-[#4b3c00]">2D</span>
                  <span className={`prize-number mt-0.5 text-[25px] font-black leading-none ${liveTwoD !== "--" ? "text-[#9a6500]" : "text-[#87792e]"}`}>{liveTwoD}</span>
                </div>
              </div>
            </div>
            <p className="text-[11px] text-[#555] font-myanmar mt-1">
              {day}/{month}/{year}
            </p>
          </div>
          );
        })()}

        {/* ─── Menu Grid ─────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-2">
          {menuCards.map((card, i) => {
            const Icon = card.icon;
            const isLucky = card.path === "/lucky";
            // Use the reactive state that polls every 2s and listens to storage events
            const cardLuckyViewed = isLucky ? hasSeenLuckyInSession : true;
            return (
              <button
                key={card.path}
                onClick={() => { playTapSound(); navigate(card.path); }}
                className="relative bg-white rounded-xl p-3.5 text-left shadow-sm border border-gray-100 hover:border-gray-300 transition-all card-lift animate-fade-in-up"
                style={{ animationDelay: `${i * 40}ms` }}
              >
                {card.badge && (
                  <span className={`absolute top-2 right-2 text-[8px] font-bold px-1.5 py-0.5 rounded-full text-white ${card.badgeColor}`}>
                    {card.badge}
                  </span>
                )}
                {/* "ဂဏန်းအသစ်" notification badge for Lucky Number - pulses to grab attention */}
                {isLucky && !cardLuckyViewed && (
                  <span className="absolute -top-2 left-1/2 -translate-x-1/2 z-10">
                    <span className="inline-flex items-center gap-0.5 bg-gradient-to-r from-red-500 to-orange-500 text-white text-[8px] font-bold px-2.5 py-1 rounded-full shadow-lg font-myanmar whitespace-nowrap"
                      style={{ animation: 'notifGlow 1.5s ease-in-out infinite, scaleBounce 0.6s ease-in-out' }}>
                      <Zap size={8} className="text-yellow-200" />
                      {lang === "mm" ? "ဂဏန်းအသစ်" : lang === "th" ? "เลขใหม่" : "New Numbers"}
                    </span>
                  </span>
                )}
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${isLucky && !cardLuckyViewed ? "animate-pulse" : ""}`}
                  style={{ backgroundColor: card.color + "18" }}
                >
                  <Icon size={18} style={{ color: card.color }} strokeWidth={1.8} />
                </div>
                <p className="text-[19px] font-bold text-[#333] leading-tight font-myanmar-display">
                  {lang === "mm" ? card.titleMm : lang === "th" ? card.titleTh : card.titleEn}
                </p>
                <p className="text-[15px] text-gray-400 mt-0.5 leading-tight font-myanmar">
                  {lang === "mm" ? card.descMm : lang === "th" ? card.descTh : card.descEn}
                </p>
              </button>
            );
          })}
        </div>


      </div>
    </div>
  );
}
