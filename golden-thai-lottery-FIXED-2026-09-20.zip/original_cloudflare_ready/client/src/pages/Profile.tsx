import { useLang } from "@/contexts/LangContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { startLogin } from "@/const";
import { ArrowLeft, LogIn, LogOut, User, Shield, Chrome, FileText, Bell, History, HelpCircle, Info, Download, Smartphone, ChevronDown as ChevronDownIcon, Settings, Users, Trophy, Gift, MessageCircle, Youtube, ExternalLink, Eye, Trash2, Percent, Plus, X, Copy, CheckCircle2, Clock3, Star } from "lucide-react";
import { toast } from "sonner";
import { useState, useEffect, useRef, type FormEvent } from "react";

// PWA Install hook for manual install button
function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Check if already installed
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone ||
      document.referrer.includes("android-app://");
    setIsInstalled(isStandalone);

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const install = async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setDeferredPrompt(null);
      setIsInstalled(true);
    }
    return outcome === "accepted";
  };

  return { install, canInstall: !!deferredPrompt && !isInstalled, isInstalled, deferredPrompt };
}

// ─── Install App Section Component ───────────────────────────────────────
function InstallAppSection() {
  const { lang, t } = useLang();
  const { install, canInstall, isInstalled, deferredPrompt } = usePWAInstall();
  const [isInstalling, setIsInstalling] = useState(false);

  // Detect iOS (can't use beforeinstallprompt, must use "Add to Home Screen")
  const isIOS = typeof navigator !== "undefined" && /iPhone|iPad|iPod/i.test(navigator.userAgent);
  const isStandalone = typeof window !== "undefined" && (
    window.matchMedia("(display-mode: standalone)").matches ||
    (window.navigator as any)?.standalone
  );

  if (isInstalled || isStandalone) {
    return (
      <div className="glass rounded-2xl p-4 border border-emerald-200 bg-emerald-50/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-emerald-200 flex items-center justify-center">
            <Smartphone size={18} className="text-emerald-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-bold text-foreground font-myanmar">
              {lang === "mm" ? "✓ အက်ပ် ထည့်သွင်းပြီးပါပြီ" : "✓ App Installed"}
            </h3>
            <p className="text-xs text-muted-foreground font-myanmar">
              {lang === "mm" ? "ဖုန်းတွင် အက်ပ် အဖြစ် ပြေးနေပါပြီ" : "Running as an app on your device"}
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Main install button — triggers PWA install prompt directly
  const handleInstallClick = async () => {
    if (isInstalling) return;
    
    if (canInstall && deferredPrompt) {
      // PWA deferred prompt is available — fire it directly
      setIsInstalling(true);
      try {
        await deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === "accepted") {
          toast.success(lang === "mm" ? "အက်ပ် ထည့်သွင်းပြီးပါပြီ!" : "App installed successfully!");
        }
      } catch {
        // Fallback: open Chrome
        openInChrome();
      }
      setIsInstalling(false);
    } else if (isIOS) {
      // iOS: show the share/Install instruction
      openInChrome();
    } else {
      // No deferred prompt available (e.g. in in-app browser or already dismissed)
      // Force open Chrome browser
      openInChrome();
    }
  };

  const openInChrome = () => {
    // Use intent:// to force Chrome browser on Android
    try {
      const currentUrl = window.location.href;
      const intentUrl = `intent://${currentUrl.replace(/^https?:\/\//, '')}#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=${encodeURIComponent(currentUrl)};end`;
      window.location.href = intentUrl;
    } catch {
      // Fallback: open in new tab
      window.open(window.location.href, '_blank');
    }
  };

  return (
    <button
      onClick={handleInstallClick}
      className="w-full glass rounded-2xl p-4 flex items-center gap-3 border border-amber-200 bg-gradient-to-br from-amber-50 to-yellow-50 hover:bg-amber-50 transition-all btn-press"
    >
      <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center">
        <Download size={18} className="text-amber-600" />
      </div>
      <div className="flex-1 text-left">
        <h3 className="text-sm font-bold text-foreground font-myanmar">{t("installApp")}</h3>
        <p className="text-xs text-muted-foreground font-myanmar">
          {lang === "mm" ? "Chrome browser တွင် install လုပ်ရန်" : "Install via Chrome browser"}
        </p>
      </div>
      {isInstalling ? (
        <div className="w-4 h-4 border-2 border-amber-600 border-t-transparent rounded-full animate-spin" />
      ) : (
        <Download size={16} className="text-amber-600" />
      )}
    </button>
  );
}



// ─── Admin Lucky Box Toggle Component ──────────────────────────────────────────
function AdminLuckyBoxToggle() {
  const { lang, t } = useLang();
  const mm = lang === "mm";
  const utils = trpc.useUtils();

  const { data: status } = trpc.adminLuckyBox.getLuckyBoxStatus.useQuery();
  const toggleMutation = trpc.adminLuckyBox.toggleLuckyBox.useMutation({
    onSuccess: () => {
      toast.success(t("luckyBoxSaved"));
    },
    onSettled: () => {
      utils.adminLuckyBox.getLuckyBoxStatus.invalidate();
    },
  });

  const isEnabled = status?.enabled ?? true;

  return (
    <div className="glass rounded-2xl p-4 border border-purple-200 bg-gradient-to-br from-purple-50 to-indigo-50">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-xl bg-purple-100 border border-purple-200 flex items-center justify-center">
          <Shield size={18} className="text-purple-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-bold text-foreground font-myanmar">{t("luckyBoxToggle")}</h3>
          <p className="text-xs text-muted-foreground font-myanmar">
            {isEnabled ? t("luckyBoxOnDesc") : t("luckyBoxOffDesc")}
          </p>
        </div>
      </div>

      <div className="flex items-center justify-between mt-3 pt-3 border-t border-purple-100">
        <div className="flex items-center gap-2">
          <div
            className={`w-2.5 h-2.5 rounded-full ${
              isEnabled ? "bg-green-500 shadow-sm shadow-green-200" : "bg-red-400 shadow-sm shadow-red-200"
            }`}
          />
          <span className={`text-sm font-bold font-myanmar ${isEnabled ? "text-green-700" : "text-red-600"}`}>
            {isEnabled ? t("luckyBoxOn") : t("luckyBoxOff")}
          </span>
        </div>
        <button
          onClick={() => toggleMutation.mutate({ enabled: !isEnabled })}
          disabled={toggleMutation.isPending}
          className={`relative w-12 h-6 rounded-full transition-all duration-300 btn-press ${
            isEnabled ? "bg-green-500" : "bg-gray-400"
          }`}
        >
          <div
            className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-all duration-300 ${
              isEnabled ? "left-6" : "left-0.5"
            }`}
          />
        </button>
      </div>
    </div>
  );
}

// ─── Admin Prize Amount Editor ──────────────────────────────────────────────
function AdminPrizeTiersEditor() {
  const { lang } = useLang();
  const mm = lang === "mm";
  const utils = trpc.useUtils();
  const [addAmount, setAddAmount] = useState("");
  const [isAdding, setIsAdding] = useState(false);

  const { data: tiersData } = trpc.adminLuckyBox.getPrizeTiers.useQuery();
  const { data: weightsData } = trpc.adminLuckyBox.getPrizeTierWeights.useQuery();
  const setMutation = trpc.adminLuckyBox.setPrizeTiers.useMutation({
    onSuccess: () => {
      toast.success(mm ? "Coins သိမ်းပြီးပါပြီ" : "Coins saved");
      setIsAdding(false);
      setAddAmount("");
    },
    onSettled: () => {
      utils.adminLuckyBox.getPrizeTiers.invalidate();
      utils.adminLuckyBox.getPrizeTierWeights.invalidate();
    },
  });

  const currentTiers = tiersData?.tiers ?? [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];

  const handleAdd = () => {
    const amount = parseInt(addAmount, 10);
    if (!amount || amount < 50 || amount > 9999999) {
      toast.error(mm ? "50 Coins အနည်းဆုံးထည့်ပါ" : "Amount must be at least 50 Coins");
      return;
    }
    if (currentTiers.includes(amount)) {
      toast.error(mm ? "ဒီ Coins ပမာဏ ရှိပြီးသားပါ" : "This tier already exists");
      return;
    }
    const newTiers = [...currentTiers, amount].sort((a, b) => a - b);
    setMutation.mutate({ tiers: newTiers });
  };

  const handleRemove = (amount: number) => {
    if (currentTiers.length <= 1) {
      toast.error(mm ? "အနည်းဆုံး တစ်ခုထားရမည်" : "At least one tier required");
      return;
    }
    const newTiers = currentTiers.filter(t => t !== amount);
    setMutation.mutate({ tiers: newTiers });
  };

  const getWeightLabel = (amount: number) => {
    const defaults: Record<number, number> = { 50: 25, 100: 20, 200: 15, 300: 12, 400: 9, 500: 7, 600: 4, 700: 3, 800: 2, 900: 2, 1000: 1 };
    return `${weightsData?.weights?.[amount] ?? defaults[amount] ?? 0}%`;
  };

  return (
    <div className="glass rounded-2xl p-4 border border-amber-200 bg-gradient-to-br from-amber-50 to-yellow-50">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center">
          <Gift size={18} className="text-amber-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-bold text-foreground font-myanmar">
            {mm ? "Coins ပမာဏများ" : "Coin Tiers"}
          </h3>
          <p className="text-xs text-muted-foreground font-myanmar">
            {mm ? "Coins လက်ဆောင်ပေါက်လျှင် ကျပန်းရွေးမည့် Coins များ" : "Random coins when Lucky Box is won"}
          </p>
        </div>
      </div>

      {/* Current Tiers List */}
      <div className="space-y-1.5 mt-3">
        {currentTiers.map((amount) => (
          <div key={amount} className="flex items-center justify-between bg-white/60 rounded-lg px-3 py-2 border border-amber-100">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-amber-700">{amount.toLocaleString()} Coins</span>
              {getWeightLabel(amount) && (
                <span className="text-[10px] text-amber-500 bg-amber-50 px-1.5 py-0.5 rounded-full">{getWeightLabel(amount)}</span>
              )}
            </div>
            <button
              onClick={() => handleRemove(amount)}
              className="w-6 h-6 rounded-full bg-red-100 text-red-500 text-xs font-bold hover:bg-red-200 transition-colors btn-press flex items-center justify-center"
            >
              ×
            </button>
          </div>
        ))}
      </div>

      {/* Add New Tier */}
      {isAdding ? (
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-amber-100">
          <input
            type="number"
            value={addAmount}
            onChange={(e) => setAddAmount(e.target.value)}
            placeholder={mm ? "Coins ထည့်ပါ" : "Add amount (Coins)"}
            min={50}
            max={9999999}
            className="flex-1 rounded-xl border-2 border-amber-300 bg-white px-3 py-2 text-sm font-bold text-foreground focus:outline-none focus:border-amber-500 transition-colors"
            style={{ fontFamily: "'Cinzel', serif" }}
          />
          <button
            onClick={handleAdd}
            disabled={setMutation.isPending}
            className="px-3 py-2 rounded-xl bg-amber-500 text-white text-sm font-bold hover:bg-amber-600 transition-colors btn-press disabled:opacity-50"
          >
            {setMutation.isPending ? "..." : (mm ? "ထည့်ရန်" : "Add")}
          </button>
          <button
            onClick={() => { setIsAdding(false); setAddAmount(""); }}
            className="px-3 py-2 rounded-xl bg-gray-200 text-gray-600 text-sm font-bold hover:bg-gray-300 transition-colors btn-press"
          >
            {mm ? "ပယ်ဖျက်" : "Cancel"}
          </button>
        </div>
      ) : (
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-amber-100">
          <p className="text-xs text-amber-600 font-myanmar">{currentTiers.length} {mm ? "ပမာဏ" : "tiers"}</p>
          <button
            onClick={() => setIsAdding(true)}
            className="px-3 py-1.5 rounded-lg bg-amber-100 text-amber-700 text-xs font-bold hover:bg-amber-200 transition-colors btn-press"
          >
            {mm ? "+ ထည့်ရန်" : "+ Add Tier"}
          </button>
        </div>
      )}
    </div>
  );
}

function AdminLuckyBoxTierPercentageEditor() {
  const { lang } = useLang();
  const mm = lang === "mm";
  const utils = trpc.useUtils();
  const [draft, setDraft] = useState<Record<string, string>>({});
  const { data: tiersData } = trpc.adminLuckyBox.getPrizeTiers.useQuery();
  const { data: weightsData } = trpc.adminLuckyBox.getPrizeTierWeights.useQuery();
  const tiers = tiersData?.tiers ?? [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
  const defaultWeights: Record<number, number> = { 50: 25, 100: 20, 200: 15, 300: 12, 400: 9, 500: 7, 600: 4, 700: 3, 800: 2, 900: 2, 1000: 1 };
  const weightFor = (amount: number) => {
    const edited = draft[String(amount)];
    if (edited !== undefined) return Number(edited) || 0;
    return weightsData?.weights?.[amount] ?? defaultWeights[amount] ?? 0;
  };
  const total = tiers.reduce((sum, amount) => sum + weightFor(amount), 0);
  const mutation = trpc.adminLuckyBox.setPrizeTierWeights.useMutation({
    onSuccess: () => {
      setDraft({});
      toast.success(mm ? "Coins တစ်ခုချင်း % သိမ်းပြီးပါပြီ" : "Coin percentages saved");
    },
    onSettled: () => {
      utils.adminLuckyBox.getPrizeTierWeights.invalidate();
      utils.adminLuckyBox.getPrizeTiers.invalidate();
    },
  });

  const save = () => {
    if (Math.abs(total - 100) > 0.001) {
      toast.error(mm ? `စုစုပေါင်း ${total}% ဖြစ်နေသည် — 100% ပြည့်အောင်ပြင်ပါ` : `Total is ${total}%; it must equal 100%`);
      return;
    }
    mutation.mutate({ weights: Object.fromEntries(tiers.map((amount) => [String(amount), weightFor(amount)])) });
  };

  return (
    <div className="glass rounded-2xl p-4 border border-orange-200 bg-gradient-to-br from-orange-50 to-amber-50">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-xl bg-orange-100 border border-orange-200 flex items-center justify-center"><Percent size={18} className="text-orange-700" /></div>
        <div className="flex-1"><h3 className="text-sm font-bold text-foreground font-myanmar">{mm ? "Coins ပေါက်နိုင်ချေ %" : "Coins tier percentages"}</h3><p className="text-xs text-muted-foreground font-myanmar">{mm ? "ကံထူးပြီးလျှင် မည်သည့် Coins ပမာဏပေါက်မည်ကိုသတ်မှတ်ပါ" : "Choose which Coin amount is awarded after a win"}</p></div>
      </div>
      <div className="max-h-64 space-y-1.5 overflow-y-auto border-t border-orange-100 pt-3">
        {tiers.map((amount) => (
          <div key={amount} className="flex items-center justify-between rounded-lg border border-orange-100 bg-white/75 px-3 py-2">
            <span className="text-sm font-bold text-orange-800">{amount.toLocaleString()} Coins</span>
            <div className="flex items-center rounded-lg border border-orange-200 bg-white px-2 py-1"><input type="number" min={0} max={100} step={0.1} value={draft[String(amount)] ?? String(weightFor(amount))} onChange={(event) => setDraft((current) => ({ ...current, [String(amount)]: event.target.value }))} className="w-14 bg-transparent text-right text-sm font-black text-orange-800 focus:outline-none" /><span className="ml-1 text-xs font-bold text-orange-700">%</span></div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center justify-between rounded-xl border border-orange-200 bg-orange-50 px-3 py-2"><span className="text-xs font-bold text-orange-800 font-myanmar">{mm ? "စုစုပေါင်း" : "Total"}</span><span className={`text-sm font-black ${Math.abs(total - 100) < 0.001 ? "text-green-700" : "text-red-600"}`}>{total}%</span></div>
      <button onClick={save} disabled={mutation.isPending || Math.abs(total - 100) > 0.001} className="mt-2 w-full rounded-xl bg-orange-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-orange-700 btn-press disabled:opacity-40">{mutation.isPending ? "..." : (mm ? "Coins % များသိမ်းရန်" : "Save percentages")}</button>
    </div>
  );
}

function AdminLuckyBoxMonthlyBudgetEditor() {
  const { lang } = useLang();
  const mm = lang === "mm";
  const utils = trpc.useUtils();
  const [budgetDraft, setBudgetDraft] = useState("");
  const { data } = trpc.adminLuckyBox.getMonthlyBudget.useQuery();
  const budgetCoins = budgetDraft === "" ? (data?.budgetCoins ?? 0) : Number(budgetDraft);
  const mutation = trpc.adminLuckyBox.setMonthlyBudget.useMutation({
    onSuccess: ({ budgetCoins: savedBudgetCoins }) => {
      setBudgetDraft("");
      toast.success(mm ? `ဒီလ Coins budget ${savedBudgetCoins.toLocaleString()} သိမ်းပြီးပါပြီ` : `Monthly budget saved: ${savedBudgetCoins.toLocaleString()} Coins`);
    },
    onSettled: () => utils.adminLuckyBox.getMonthlyBudget.invalidate(),
  });
  const save = () => {
    if (!Number.isFinite(budgetCoins) || !Number.isInteger(budgetCoins) || budgetCoins < 0) {
      toast.error(mm ? "Coins စုစုပေါင်းကို 0 သို့မဟုတ် အပြည့်ကိန်းဖြင့်ထည့်ပါ" : "Enter a whole Coin amount of 0 or more");
      return;
    }
    mutation.mutate({ budgetCoins });
  };

  const shownBudget = Number.isFinite(budgetCoins) ? Math.max(0, budgetCoins) : 0;
  return (
    <div className="glass rounded-2xl p-4 border border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50">
      <div className="border-t border-emerald-100 pt-3"><label className="text-xs font-myanmar text-emerald-800">{mm ? "ဒီလပေါက်ခွင့်ပြု Coins စုစုပေါင်း" : "Total Coins allowed this month"}<input type="number" min={0} step={1} value={budgetDraft === "" ? String(data?.budgetCoins ?? 0) : budgetDraft} onChange={(event) => setBudgetDraft(event.target.value)} className="mt-1 w-full rounded-xl border-2 border-emerald-200 bg-white px-3 py-2 text-lg font-black text-emerald-800 focus:outline-none focus:border-emerald-500" /></label></div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center"><div className="rounded-xl bg-white/80 p-2"><p className="text-[10px] text-muted-foreground font-myanmar">{mm ? "ခွင့်ပြု" : "Budget"}</p><p className="text-sm font-black text-emerald-700">{shownBudget.toLocaleString()}</p></div><div className="rounded-xl bg-white/80 p-2"><p className="text-[10px] text-muted-foreground font-myanmar">{mm ? "ပေါက်ပြီး" : "Won"}</p><p className="text-sm font-black text-amber-700">{(data?.spentCoins ?? 0).toLocaleString()}</p></div><div className="rounded-xl bg-white/80 p-2"><p className="text-[10px] text-muted-foreground font-myanmar">{mm ? "ကျန်" : "Remaining"}</p><p className="text-sm font-black text-sky-700">{Math.max(0, shownBudget - (data?.spentCoins ?? 0)).toLocaleString()}</p></div></div>
      <p className="mt-2 text-[11px] text-emerald-800 font-myanmar">{mm ? "Coins budget ပြည့်သွားလျှင် နောက်ထပ် Coins ပေါက်မည်မဟုတ်ပါ။" : "No further Coin rewards are issued once this budget is used."}</p>
      <button onClick={save} disabled={mutation.isPending} className="mt-3 w-full rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-emerald-700 btn-press disabled:opacity-50">{mutation.isPending ? "..." : (mm ? "ဒီလ budget သိမ်းရန်" : "Save monthly budget")}</button>
    </div>
  );
}

function AdminBroadcastComposer() {
  const { lang } = useLang();
  const mm = lang === "mm";
  const utils = trpc.useUtils();
  const [title, setTitle] = useState("Golden Thai");
  const [message, setMessage] = useState("");
  const [lastResult, setLastResult] = useState<string | null>(null);
  const { data: status } = trpc.adminLuckyBox.getBroadcastStatus.useQuery();
  const mutation = trpc.adminLuckyBox.sendBroadcast.useMutation({
    onSuccess: (result) => {
      setLastResult(mm ? "အသစ်ထည့်ထားသောစာကို app ဖွင့်သူများမြင်ပါမည်" : "The announcement is now shown in the app");
      setMessage("");
      utils.adminLuckyBox.getBroadcastStatus.invalidate();
      utils.inAppBroadcast.current.invalidate();
    },
  });

  const send = () => {
    const cleanTitle = title.trim();
    const cleanMessage = message.trim();
    if (!cleanTitle || !cleanMessage) {
      toast.error(mm ? "Title နှင့် message နှစ်ခုလုံးရေးပါ" : "Write both a title and message");
      return;
    }
    if (!window.confirm(mm ? "ဒီစာကို app ဖွင့်ထားသူများထံပြမလား?" : "Show this message to app users?")) return;
    setLastResult(null);
    mutation.mutate({ title: cleanTitle, message: cleanMessage });
  };

  return (
    <div className="glass rounded-2xl p-4 border border-indigo-200 bg-gradient-to-br from-indigo-50 to-violet-50">
      <div className="flex items-center gap-3 mb-3"><div className="w-10 h-10 rounded-xl bg-indigo-100 border border-indigo-200 flex items-center justify-center"><Bell size={18} className="text-indigo-700" /></div><div className="flex-1"><h3 className="text-sm font-bold text-foreground font-myanmar">{mm ? "App အသိပေးစာ" : "In-app announcement"}</h3><p className="text-xs text-muted-foreground font-myanmar">{mm ? "App ဖွင့်ထားသူများအားလုံးထံ စာတစ်ခုတည်းပြရန်" : "Show one message to users while they use the app"}</p></div></div>
      <div className="rounded-xl border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs text-indigo-800 font-myanmar">
        {status?.current ? (mm ? `လက်ရှိစာ: ${new Date(status.current.publishedAt).toLocaleString("my-MM")}` : `Current message: ${new Date(status.current.publishedAt).toLocaleString()}`) : (mm ? "လက်ရှိပြသနေသောစာမရှိသေးပါ" : "No current announcement")}
      </div>
      <div className="mt-3 space-y-2">
        <input value={title} maxLength={80} onChange={(event) => setTitle(event.target.value)} placeholder={mm ? "Notification ခေါင်းစဉ်" : "Notification title"} className="w-full rounded-xl border-2 border-indigo-200 bg-white px-3 py-2 text-sm font-bold text-foreground focus:outline-none focus:border-indigo-500" />
        <textarea value={message} maxLength={300} onChange={(event) => setMessage(event.target.value)} placeholder={mm ? "အသုံးပြုသူများထံပို့မည့် စာသားရေးပါ" : "Write the message to send"} rows={3} className="w-full resize-none rounded-xl border-2 border-indigo-200 bg-white px-3 py-2 text-sm text-foreground focus:outline-none focus:border-indigo-500" />
        <div className="flex items-center justify-between text-[10px] text-muted-foreground"><span>{message.length}/300</span><span>{mm ? "တစ်ဦးချင်းတစ်ကြိမ်သာပြမည်" : "Shown once per user"}</span></div>
      </div>
      <button onClick={send} disabled={mutation.isPending} className="mt-3 w-full rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-indigo-700 btn-press disabled:opacity-40">{mutation.isPending ? "..." : (mm ? "App စာထုတ်ရန်" : "Publish in-app message")}</button>
      {lastResult && <p className="mt-2 rounded-lg bg-white/80 px-3 py-2 text-xs font-myanmar text-indigo-800">{lastResult}</p>}
    </div>
  );
}

function AdminLuckyBoxChanceEditor() {
  const { lang } = useLang();
  const mm = lang === "mm";
  const utils = trpc.useUtils();
  const { data } = trpc.adminLuckyBox.getWinChance.useQuery();
  const [value, setValue] = useState("");
  const chance = data?.percentage ?? 2;
  const displayValue = value === "" ? String(chance) : value;

  const mutation = trpc.adminLuckyBox.setWinChance.useMutation({
    onSuccess: ({ percentage }) => {
      setValue("");
      toast.success(mm ? `ပေါက်နိုင်ချေ ${percentage}% သိမ်းပြီးပါပြီ` : `Win chance saved: ${percentage}%`);
    },
    onSettled: () => utils.adminLuckyBox.getWinChance.invalidate(),
  });

  const save = () => {
    const percentage = Number(displayValue);
    if (!Number.isFinite(percentage) || percentage < 0 || percentage > 100) {
      toast.error(mm ? "0 မှ 100% အတွင်းထည့်ပါ" : "Enter a value from 0 to 100");
      return;
    }
    mutation.mutate({ percentage });
  };

  return (
    <div className="glass rounded-2xl p-4 border border-sky-200 bg-gradient-to-br from-sky-50 to-cyan-50">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-xl bg-sky-100 border border-sky-200 flex items-center justify-center">
          <Percent size={18} className="text-sky-700" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-bold text-foreground font-myanmar">{mm ? "ကံထူးနိုင်ချေ" : "Win Chance"}</h3>
          <p className="text-xs text-muted-foreground font-myanmar">
            {mm ? "ဖွင့်မှုတစ်ကြိမ်လျှင် Coins ပေါက်နိုင်သည့် ရာခိုင်နှုန်း" : "Coins-winning percentage per opening"}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2 pt-3 border-t border-sky-100">
        <input
          type="number"
          min={0}
          max={100}
          step={0.1}
          value={displayValue}
          onChange={(event) => setValue(event.target.value)}
          className="w-28 rounded-xl border-2 border-sky-200 bg-white px-3 py-2 text-center text-lg font-black text-sky-800 focus:outline-none focus:border-sky-500"
        />
        <span className="text-lg font-black text-sky-700">%</span>
        <button
          onClick={save}
          disabled={mutation.isPending}
          className="ml-auto rounded-xl bg-sky-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-sky-700 btn-press disabled:opacity-50"
        >
          {mutation.isPending ? "..." : (mm ? "သိမ်းရန်" : "Save")}
        </button>
      </div>
    </div>
  );
}

function AdminLuckyBoxWinnerManager() {
  const { lang } = useLang();
  const mm = lang === "mm";
  const utils = trpc.useUtils();
  const [expandedWinnerId, setExpandedWinnerId] = useState<number | null>(null);
  const [lookupInput, setLookupInput] = useState("");
  const [lookupReferenceId, setLookupReferenceId] = useState("");
  const [selectedWinner, setSelectedWinner] = useState<any>(null);
  const { data: winners, isLoading } = trpc.adminLuckyBox.getAllWinners.useQuery();
  const { data: lookupWinner, isFetching: isLookingUp } = trpc.adminLuckyBox.getWinnerByRefId.useQuery(
    { referenceId: lookupReferenceId || "not-searched" },
    { enabled: Boolean(lookupReferenceId), retry: false },
  );

  useEffect(() => {
    if (lookupReferenceId && lookupWinner?.isWinner) {
      setSelectedWinner(lookupWinner);
    }
  }, [lookupReferenceId, lookupWinner]);

  const invalidate = () => {
    utils.adminLuckyBox.getAllWinners.invalidate();
    utils.luckyBoxWinners.getWinners.invalidate();
  };
  const deleteOneMutation = trpc.adminLuckyBox.deleteWinner.useMutation({
    onSuccess: () => {
      toast.success(mm ? "ကံထူးသူ record ကိုဖျက်ပြီးပါပြီ" : "Winner record deleted");
      setSelectedWinner(null);
      invalidate();
    },
  });
  const deleteAllMutation = trpc.adminLuckyBox.deleteAllWinners.useMutation({
    onSuccess: ({ deletedCount }) => {
      toast.success(mm ? `ကံထူးသူ ${deletedCount} ဦးကိုဖျက်ပြီးပါပြီ` : `Deleted ${deletedCount} winner records`);
      setExpandedWinnerId(null);
      invalidate();
    },
  });
  const paidStatusMutation = trpc.adminLuckyBox.setWinnerPaidStatus.useMutation({
    onSuccess: ({ paid }) => {
      toast.success(paid ? (mm ? "ဆုကြေးပေးပြီးအဖြစ် မှတ်သားပြီးပါပြီ" : "Marked as paid") : (mm ? "ဆုကြေးမပေးရသေးအဖြစ် ပြန်ထားပြီးပါပြီ" : "Marked as unpaid"));
      invalidate();
    },
  });

  const deleteOne = (id: number) => {
    if (window.confirm(mm ? "ဒီကံထူးသူ record ကိုဖျက်မလား?" : "Delete this winner record?")) {
      deleteOneMutation.mutate({ id });
    }
  };

  const deleteAll = () => {
    if (window.confirm(mm ? "ကံထူးသူအားလုံးကိုဖျက်မလား? ဒီလုပ်ဆောင်ချက်ကိုပြန်မရနိုင်ပါ။" : "Delete ALL winner records? This cannot be undone.")) {
      deleteAllMutation.mutate();
    }
  };

  const togglePaid = (winner: { id: number; paidAt?: Date | string | null }) => {
    const paid = !winner.paidAt;
    const confirmation = paid
      ? (mm ? "ဒီ user ကို Coins ဆုကြေးပေးပြီးအဖြစ် ON လုပ်မလား?" : "Mark this user as paid?")
      : (mm ? "ဒီ user ကို Coins ဆုကြေးမပေးရသေးအဖြစ် OFF ပြန်လုပ်မလား?" : "Mark this user as unpaid?");
    if (window.confirm(confirmation)) {
      paidStatusMutation.mutate({ id: winner.id, paid });
    }
  };

  const copyPrizeId = async (referenceId: string | null) => {
    if (!referenceId) return;
    try {
      await navigator.clipboard?.writeText(referenceId);
      toast.success(mm ? "ဆု ID ကိုကူးပြီးပါပြီ" : "Prize ID copied");
    } catch {
      toast.error(mm ? "ဆု ID ကိုကူး၍မရပါ" : "Could not copy prize ID");
    }
  };

  const findWinnerByReferenceId = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const cleanedId = lookupInput.trim().toUpperCase();
    if (!cleanedId) {
      toast.error(mm ? "User ပို့လာသော ဆု ID ကိုထည့်ပါ" : "Enter the Prize ID sent by the user");
      return;
    }
    setSelectedWinner(null);
    setLookupReferenceId(cleanedId);
  };

  return (
    <div className="glass rounded-2xl p-4 border border-rose-200 bg-gradient-to-br from-rose-50 to-orange-50">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-rose-100 border border-rose-200 flex items-center justify-center">
          <Users size={18} className="text-rose-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-bold text-foreground font-myanmar">{mm ? "ကံထူးသူ စီမံခန့်ခွဲမှု" : "Winner Management"}</h3>
          <p className="text-xs text-muted-foreground font-myanmar">{mm ? "မျက်လုံးပုံကိုနှိပ်လျှင် ပေါက်ထားသော Coins နှင့်ဆုအသေးစိတ်ကိုပြမည်" : "Tap the eye to see the awarded Coins and prize details"}</p>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between border-t border-rose-100 pt-3">
        <span className="text-xs font-myanmar text-rose-700">{winners?.length ?? 0} {mm ? "ဦး ကံထူးထားသည်" : "winner records"}</span>
        <button
          onClick={deleteAll}
          disabled={!winners?.length || deleteAllMutation.isPending}
          className="rounded-lg bg-red-600 px-3 py-2 text-xs font-bold text-white hover:bg-red-700 btn-press disabled:opacity-40"
        >
          {deleteAllMutation.isPending ? "..." : (mm ? "အားလုံးဖျက်ရန်" : "Delete all")}
        </button>
      </div>

      <form onSubmit={findWinnerByReferenceId} className="mt-3 rounded-2xl border border-amber-200 bg-amber-50/70 p-3">
        <p className="text-xs font-bold text-amber-900 font-myanmar">{mm ? "User ပို့လာသော ဆု ID စစ်ရန်" : "Check a Prize ID from a user"}</p>
        <p className="mt-1 text-[10px] text-amber-800/80 font-myanmar">{mm ? "Telegram မှပို့လာသော LB… ID ကိုကူးထည့်ပြီး ဆုအတိုင်းပြန်ကြည့်ပါ" : "Paste the LB… ID sent through Telegram to view the exact reward."}</p>
        <div className="mt-2 flex gap-2">
          <input
            value={lookupInput}
            onChange={(event) => setLookupInput(event.target.value.toUpperCase())}
            placeholder="LB20260904-…"
            autoCapitalize="characters"
            className="min-w-0 flex-1 rounded-xl border-2 border-amber-200 bg-white px-3 py-2 text-xs font-bold text-slate-800 uppercase focus:outline-none focus:border-amber-500"
          />
          <button type="submit" disabled={isLookingUp} className="shrink-0 rounded-xl bg-amber-500 px-3 py-2 text-xs font-bold text-white shadow-sm hover:bg-amber-600 btn-press disabled:opacity-50">
            {isLookingUp ? "..." : (mm ? "စစ်ရန်" : "Check")}
          </button>
        </div>
        {lookupReferenceId && !isLookingUp && !lookupWinner && (
          <p className="mt-2 text-[11px] font-bold text-rose-700 font-myanmar">{mm ? "ဒီဆု ID ဖြင့်ပေါက်ထားသော record မတွေ့ပါ" : "No winning record was found for this Prize ID."}</p>
        )}
      </form>

      {isLoading ? (
        <div className="py-6 text-center text-xs text-muted-foreground">...</div>
      ) : !winners?.length ? (
        <p className="py-5 text-center text-xs text-muted-foreground font-myanmar">{mm ? "ကံထူးသူမရှိသေးပါ" : "No winner records yet"}</p>
      ) : (
        <div className="mt-3 max-h-[420px] space-y-2 overflow-y-auto pr-0.5">
          {winners.map((winner) => {
            const expanded = expandedWinnerId === winner.id;
            return (
              <div key={winner.id} className={`rounded-2xl border bg-white/90 p-3 shadow-[0_3px_10px_rgba(120,53,15,0.04)] transition-colors ${expanded ? "border-amber-300" : "border-rose-100"}`}>
                <div className="flex items-center gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-black text-foreground">{winner.userName || winner.userEmail || (mm ? "ဧည့်သည်" : "Guest")}</p>
                    <p className="mt-1 text-[10px] text-muted-foreground font-myanmar">
                      {new Date(winner.openedAt).toLocaleString(mm ? "my-MM" : "en-US", { dateStyle: "medium", timeStyle: "short" })}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-base font-black leading-none text-amber-600">{(winner.prizeAmount ?? 0).toLocaleString()} <span className="text-xs">Coins</span></p>
                    <button
                      onClick={() => togglePaid(winner)}
                      disabled={paidStatusMutation.isPending}
                      className={`mt-1 inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[10px] font-black shadow-sm btn-press disabled:opacity-50 ${winner.paidAt ? "bg-emerald-600 text-white" : "border border-orange-300 bg-orange-100 text-orange-800"}`}
                      aria-label={winner.paidAt ? (mm ? "ဆုကြေးပေးပြီး ON" : "Paid ON") : (mm ? "ဆုကြေးမပေးရသေး OFF" : "Unpaid OFF")}
                    >
                      <CheckCircle2 size={12} /> {winner.paidAt ? "ON" : "OFF"}
                    </button>
                  </div>
                  <button
                    onClick={() => {
                      setExpandedWinnerId(expanded ? null : winner.id);
                      setSelectedWinner(winner);
                    }}
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border-2 border-amber-200 bg-amber-50 text-amber-700 transition-colors hover:bg-amber-100 btn-press"
                    aria-label={mm ? "ဆုအသေးစိတ်ကြည့်ရန်" : "View awarded prize details"}
                  >
                    <Eye size={19} strokeWidth={2.4} />
                  </button>
                  <button
                    onClick={() => deleteOne(winner.id)}
                    disabled={deleteOneMutation.isPending}
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-rose-200 bg-rose-50 text-rose-600 hover:bg-rose-100 btn-press disabled:opacity-40"
                    aria-label={mm ? "ဖျက်ရန်" : "Delete"}
                  >
                    <Trash2 size={17} />
                  </button>
                </div>
                {expanded && (
                  <div className="mt-3 space-y-2 border-t-2 border-amber-100 pt-3 text-xs animate-fade-in">
                    <div className="rounded-xl border border-amber-200 bg-gradient-to-r from-amber-50 to-yellow-50 p-3">
                      <div className="flex items-center justify-between gap-3">
                        <span className="font-bold text-amber-900 font-myanmar">{mm ? "ပေါက်ထားသော Coins" : "Awarded Coins"}</span>
                        <span className="text-xl font-black text-amber-700">{(winner.prizeAmount ?? 0).toLocaleString()} <span className="text-sm">Coins</span></span>
                      </div>
                      <p className="mt-1 text-[10px] text-amber-800/80 font-myanmar">{mm ? "Lucky Box ဖွင့်ချိန်တွင်အတည်ပြုပေါက်ထားသောဆု" : "The prize confirmed when Lucky Box was opened"}</p>
                    </div>
                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-bold text-slate-600 font-myanmar">{mm ? "ဆု ID" : "Prize ID"}</p>
                        {winner.referenceId && (
                          <button onClick={() => copyPrizeId(winner.referenceId)} className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-[10px] font-bold text-slate-600 hover:bg-slate-100 btn-press">
                            <Copy size={12} /> {mm ? "ကူးရန်" : "Copy"}
                          </button>
                        )}
                      </div>
                      <code className="mt-1 block break-all text-[11px] font-bold text-slate-800">{winner.referenceId || "--"}</code>
                    </div>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <div className="rounded-xl border border-sky-100 bg-sky-50 px-3 py-2">
                        <p className="flex items-center gap-1 text-[10px] font-bold text-sky-700 font-myanmar"><Clock3 size={12} /> {mm ? "ဖွင့်ခဲ့သည့်အချိန်" : "Opened at"}</p>
                        <p className="mt-1 text-[11px] font-semibold text-sky-900">{new Date(winner.openedAt).toLocaleString(mm ? "my-MM" : "en-US", { dateStyle: "medium", timeStyle: "short" })}</p>
                      </div>
                      <div className={`rounded-xl border px-3 py-2 ${winner.claimedAt ? "border-emerald-200 bg-emerald-50" : "border-orange-200 bg-orange-50"}`}>
                        <p className={`flex items-center gap-1 text-[10px] font-bold font-myanmar ${winner.claimedAt ? "text-emerald-700" : "text-orange-700"}`}><CheckCircle2 size={12} /> {mm ? "ဆုယူအခြေအနေ" : "Claim status"}</p>
                        <p className={`mt-1 text-[11px] font-black font-myanmar ${winner.claimedAt ? "text-emerald-800" : "text-orange-800"}`}>{winner.claimedAt ? (mm ? "ဆုယူပြီး" : "Claimed") : (mm ? "ဆုယူရန်စောင့်နေသည်" : "Awaiting claim")}</p>
                      </div>
                    </div>
                    <div className={`rounded-xl border px-3 py-2 ${winner.paidAt ? "border-emerald-300 bg-emerald-50" : "border-orange-200 bg-orange-50"}`}>
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <p className={`text-[10px] font-bold font-myanmar ${winner.paidAt ? "text-emerald-700" : "text-orange-700"}`}>{mm ? "ဆုကြေးပေးချေမှု" : "Prize payment"}</p>
                          <p className={`mt-1 text-xs font-black font-myanmar ${winner.paidAt ? "text-emerald-800" : "text-orange-800"}`}>{winner.paidAt ? (mm ? "ဆုကြေးပေးပြီး" : "Paid") : (mm ? "ဆုကြေးမပေးရသေး" : "Unpaid")}</p>
                        </div>
                        <button onClick={() => togglePaid(winner)} disabled={paidStatusMutation.isPending} className={`rounded-lg px-3 py-1.5 text-xs font-black btn-press disabled:opacity-50 ${winner.paidAt ? "bg-emerald-600 text-white" : "bg-orange-500 text-white"}`}>{winner.paidAt ? "ON" : "OFF"}</button>
                      </div>
                      {winner.paidAt && <p className="mt-1 text-[10px] text-emerald-700">{new Date(winner.paidAt).toLocaleString(mm ? "my-MM" : "en-US", { dateStyle: "medium", timeStyle: "short" })}</p>}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
      {selectedWinner && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">
          <div className="max-h-[92vh] w-full max-w-[430px] overflow-y-auto rounded-[28px] bg-[#FFFDF7] shadow-2xl animate-fade-in">
            <div className="sticky top-0 z-10 flex items-center justify-between bg-gradient-to-r from-[#FFD700] to-[#FFB300] px-5 py-4 text-[#4A3500]">
              <div>
                <p className="text-[10px] font-black tracking-[0.16em]">GOLDEN THAI</p>
                <h4 className="mt-0.5 text-lg font-black font-myanmar-display">{mm ? "ကံထူးဆု အတည်ပြုချက်" : "Lucky Prize Confirmation"}</h4>
              </div>
              <button onClick={() => setSelectedWinner(null)} className="flex h-9 w-9 items-center justify-center rounded-full bg-white/80 text-[#6C4A00] btn-press" aria-label={mm ? "ပိတ်ရန်" : "Close"}><X size={20} /></button>
            </div>
            <div className="space-y-4 p-5">
              <div className="rounded-3xl border border-[#F2D66B] bg-gradient-to-b from-[#FFFDF0] to-[#FFF9DF] px-5 py-4 text-center shadow-sm">
                <p className="text-xl font-black text-[#6D5A21] font-myanmar-display">{mm ? "ကံကောင်းကြယ်" : "Lucky Star"}</p>
                <div className="mt-2 flex justify-center gap-2 text-[#FFD700]"><Star size={31} fill="currentColor" /><Star size={31} fill="currentColor" /><Star size={31} fill="currentColor" /><Star size={31} fill="currentColor" /><Star size={31} fill="currentColor" /></div>
              </div>
              <div className="rounded-3xl bg-gradient-to-br from-[#FFD700] via-[#FFC400] to-[#FF9F00] px-5 py-6 text-center text-white shadow-[0_12px_28px_rgba(245,158,11,0.25)]">
                <p className="text-sm font-bold font-myanmar">🏆 {mm ? "Coins ပမာဏ" : "Coins awarded"}</p>
                <p className="mt-1 text-5xl font-black tracking-tight" style={{ fontFamily: "'Cinzel', serif" }}>{(selectedWinner.prizeAmount ?? 0).toLocaleString()} <span className="text-2xl">Coins</span></p>
                <p className="mt-2 text-xs font-myanmar text-white/90">{mm ? "Lucky Box ဖွင့်ချိန်တွင် အတည်ပြုပေါက်ထားသောဆု" : "Prize confirmed at the time of opening"}</p>
              </div>
              <div className="rounded-3xl border-[3px] border-[#F59E0B] bg-[#FFFDF8] p-4">
                <p className="text-lg font-black text-[#B45309] font-myanmar-display">💰 {mm ? "Coins ဆုယူရန်" : "Coin prize claim"}</p>
                <p className="mt-2 text-sm leading-7 text-[#3F3A32] font-myanmar">{mm ? "User ပို့လာသော ဆု ID ကိုစစ်ပြီးပါပြီ။ အောက်ပါ ID နှင့် Coins ပမာဏအတိုင်းသာ အတည်ပြုပါ။" : "This Prize ID has been checked. Confirm only the Coin amount shown below."}</p>
              </div>
              <div>
                <p className="mb-2 text-xs font-bold text-slate-500 font-myanmar">{mm ? "ဆု ID" : "Prize ID"}</p>
                <div className="flex items-center gap-2 rounded-2xl border-2 border-[#F4D96A] bg-white p-3 shadow-sm">
                  <code className="min-w-0 flex-1 break-all text-sm font-black text-slate-800">{selectedWinner.referenceId || "--"}</code>
                  {selectedWinner.referenceId && <button onClick={() => copyPrizeId(selectedWinner.referenceId)} className="shrink-0 rounded-xl bg-[#FFD700] p-2.5 text-[#4A3500] btn-press" aria-label={mm ? "ဆု ID ကူးရန်" : "Copy Prize ID"}><Copy size={15} /></button>}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-sky-200 bg-sky-50 p-3"><p className="text-[10px] font-bold text-sky-700 font-myanmar">{mm ? "ဖွင့်ခဲ့သည့်အချိန်" : "Opened at"}</p><p className="mt-1 text-xs font-black text-sky-900">{new Date(selectedWinner.openedAt).toLocaleString(mm ? "my-MM" : "en-US", { dateStyle: "medium", timeStyle: "short" })}</p></div>
                <div className={`rounded-2xl border p-3 ${selectedWinner.claimedAt ? "border-emerald-200 bg-emerald-50" : "border-orange-200 bg-orange-50"}`}><p className={`text-[10px] font-bold font-myanmar ${selectedWinner.claimedAt ? "text-emerald-700" : "text-orange-700"}`}>{mm ? "ဆုယူအခြေအနေ" : "Claim status"}</p><p className={`mt-1 text-xs font-black font-myanmar ${selectedWinner.claimedAt ? "text-emerald-800" : "text-orange-800"}`}>{selectedWinner.claimedAt ? (mm ? "ဆုယူပြီး" : "Claimed") : (mm ? "ဆုယူရန်စောင့်နေသည်" : "Awaiting claim")}</p></div>
              </div>
              <div className={`rounded-2xl border p-3 ${selectedWinner.paidAt ? "border-emerald-300 bg-emerald-50" : "border-orange-200 bg-orange-50"}`}>
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className={`text-[10px] font-bold font-myanmar ${selectedWinner.paidAt ? "text-emerald-700" : "text-orange-700"}`}>{mm ? "ဆုကြေးပေးချေမှု" : "Prize payment"}</p>
                    <p className={`mt-1 text-sm font-black font-myanmar ${selectedWinner.paidAt ? "text-emerald-800" : "text-orange-800"}`}>{selectedWinner.paidAt ? (mm ? "ဆုကြေးပေးပြီး" : "Paid") : (mm ? "ဆုကြေးမပေးရသေး" : "Unpaid")}</p>
                  </div>
                  <button onClick={() => togglePaid(selectedWinner)} disabled={paidStatusMutation.isPending} className={`rounded-xl px-4 py-2 text-sm font-black btn-press disabled:opacity-50 ${selectedWinner.paidAt ? "bg-emerald-600 text-white" : "bg-orange-500 text-white"}`}>{selectedWinner.paidAt ? "ON" : "OFF"}</button>
                </div>
                {selectedWinner.paidAt && <p className="mt-1 text-[10px] text-emerald-700">{new Date(selectedWinner.paidAt).toLocaleString(mm ? "my-MM" : "en-US", { dateStyle: "medium", timeStyle: "short" })}</p>}
              </div>
              <button onClick={() => setSelectedWinner(null)} className="w-full rounded-2xl bg-slate-800 px-4 py-3 text-sm font-bold text-white btn-press">{mm ? "ပိတ်ရန်" : "Close"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Profile() {
  const { lang, t } = useLang();
  const [, navigate] = useLocation();
  const { user, isAuthenticated, loading } = useAuth();
  const [showHistory, setShowHistory] = useState(false);

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => { toast.success(lang === "mm" ? "ထွက်ပြီးပါပြီ" : "Logged out"); navigate("/"); },
  });

  // Weekly lucky preference
  const { data: weeklyPref } = trpc.weeklyLucky.getPreference.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const utils = trpc.useUtils();
  const setPref = trpc.weeklyLucky.setPreference.useMutation({
    onMutate: (vars) => {
      const prev = utils.weeklyLucky.getPreference.getData(undefined);
      utils.weeklyLucky.getPreference.setData(undefined, { enabled: vars.enabled });
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prev) {
        utils.weeklyLucky.getPreference.setData(undefined, ctx.prev);
      }
    },
    onSettled: () => {
      utils.weeklyLucky.getPreference.invalidate();
    },
    onSuccess: () => {
      toast.success(t("weeklyLuckySaved"));
    },
  });

  // User notification history
  const { data: notifications } = trpc.notifications.list.useQuery(undefined, {
    enabled: isAuthenticated && showHistory,
  });

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/")} className="text-[#333] btn-press"><ArrowLeft size={20} /></button>
          <h1 className="font-display text-base font-bold text-[#333] flex-1">
            {lang === "mm" ? "အကောင့်" : "Account"}
          </h1>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 py-8 space-y-4">
        {loading ? (
          <div className="text-center py-12">
            <div className="w-8 h-8 rounded-full border-2 border-gold-400 border-t-transparent animate-spin mx-auto" />
          </div>
        ) : isAuthenticated && user ? (
          <>
            {/* User card */}
            <div className="bg-white rounded-xl p-5 shadow-sm text-center animate-fade-in-up">
              <div className="w-16 h-16 rounded-full bg-amber-100 border-2 border-amber-300 flex items-center justify-center mx-auto mb-3">
                <User size={28} className="text-amber-600" />
              </div>
              <h2 className="text-lg font-bold text-foreground">{user.name ?? "User"}</h2>
              {user.email && <p className="text-sm text-muted-foreground mt-1">{user.email}</p>}
              <div className="flex items-center justify-center gap-1 mt-2">
                <Shield size={12} className={user.role === "admin" ? "text-amber-600" : "text-muted-foreground"} />
                <span className="text-xs text-muted-foreground capitalize">{user.role}</span>
              </div>
            </div>

            {/* ─── Weekly Lucky Number Settings ─────────────────────────── */}
            <div className="glass rounded-2xl p-4 border border-amber-200 bg-gradient-to-br from-amber-50 to-yellow-50">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center">
                  <Bell size={18} className="text-amber-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-foreground font-myanmar">{t("weeklyLuckyPrefTitle")}</h3>
                  <p className="text-xs text-muted-foreground font-myanmar">{t("weeklyLuckyDesc")}</p>
                </div>
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-amber-100">
                <span className="text-sm text-foreground font-myanmar">
                  {weeklyPref?.enabled ? t("weeklyLuckyEnabled") : t("weeklyLuckyDisabled")}
                </span>
                <button
                  onClick={() => {
                    setPref.mutate({ enabled: !weeklyPref?.enabled });
                  }}
                  disabled={setPref.isPending}
                  className={`relative w-12 h-6 rounded-full transition-all duration-300 btn-press ${
                    weeklyPref?.enabled ? "bg-amber-500" : "bg-gray-300"
                  }`}
                >
                  <div
                    className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-all duration-300 ${
                      weeklyPref?.enabled ? "left-6" : "left-0.5"
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* ─── Lucky Number History Toggle ──────────────────────────── */}
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="w-full glass rounded-2xl p-4 flex items-center gap-3 border border-amber-200 bg-amber-50/50 hover:bg-amber-50 transition-all btn-press"
            >
              <History size={18} className="text-amber-600" />
              <span className="text-sm font-bold text-foreground font-myanmar flex-1 text-left">
                {t("myLuckyHistory")}
              </span>
              <span className="text-xs text-muted-foreground">
                {showHistory ? "▲" : "▼"}
              </span>
            </button>

            {/* ─── Lucky Number History List ────────────────────────────── */}
            {showHistory && (
              <div className="glass rounded-2xl p-4 border border-amber-200 max-h-80 overflow-y-auto">
                {!notifications || notifications.filter(n => n.type === "weekly_3d" || n.type === "lucky_number_7d" || n.type === "lucky_number_draw_day").length === 0 ? (
                  <div className="text-center py-6">
                    <Bell size={24} className="text-muted-foreground/30 mx-auto mb-2" />
                    <p className="text-xs text-muted-foreground font-myanmar">{t("noLuckyHistory")}</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {notifications
                      .filter(n => n.type === "weekly_3d" || n.type === "lucky_number_7d" || n.type === "lucky_number_draw_day")
                      .map((n) => (
                        <div key={n.id} className="flex items-center gap-3 p-2.5 rounded-xl bg-white/60 border border-amber-100">
                          <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0">
                            <span className="text-lg">🎯</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold text-foreground font-myanmar leading-tight">{n.title}</p>
                            <p className="text-[11px] text-muted-foreground font-myanmar leading-tight mt-0.5">{n.body}</p>
                          </div>
                          {n.luckyNumber && (
                            <span className="text-lg font-black text-amber-600 tracking-widest">{n.luckyNumber}</span>
                          )}
                        </div>
                      ))}
                  </div>
                )}
              </div>
            )}

            {/* Logout */}
            <button
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
              className="w-full glass rounded-2xl p-4 flex items-center gap-3 border border-red-500/20 hover:border-red-500/40 transition-all btn-press"
            >
              <LogOut size={18} className="text-red-400" />
              <span className="text-sm font-myanmar text-red-300">
                {logoutMutation.isPending ? "..." : (lang === "mm" ? "ထွက်ရန်" : "Log Out")}
              </span>
            </button>
          </>
        ) : (
          <>
            {/* Guest welcome — no login wall */}
            <div className="bg-white rounded-xl p-6 text-center shadow-sm animate-fade-in-up">
              <div className="w-16 h-16 rounded-full bg-amber-100 border border-amber-300 flex items-center justify-center mx-auto mb-4">
                <Info size={28} className="text-amber-600" />
              </div>
              <h2 className="text-base font-bold text-foreground font-myanmar mb-1">
                {lang === "mm" ? "ရွှေထိုင်းလော့တာ & ၂ဒီ သို့ ကြိုဆိုပါတယ်" : "Welcome to Golden Thai Lottery"}
              </h2>
              <p className="text-xs text-muted-foreground font-myanmar mb-4">
                {lang === "mm"
                  ? "လော့တာရလဒ်များ၊ ၂ဒီ၊ ၃ဒီ၊ ဟောကိန်းများကို အကောင့်မလိုဘဲ ကြည့်နိုင်ပါသည်"
                  : "View lottery results, 2D, 3D, horoscopes without an account"}
              </p>

              {/* Optional login */}
              <button
                onClick={() => startLogin()}
                className="w-full flex items-center justify-center gap-3 bg-amber-500 text-white font-bold py-3 rounded-xl mb-3 btn-press shadow-lg"
              >
                <LogIn size={16} />
                <span className="text-sm font-myanmar">
                  {lang === "mm" ? "အကောင့်ဝင်ရန် (ရွေးချယ်ခွင့်)" : "Sign In (Optional)"}
                </span>
              </button>

              <p className="text-[10px] text-muted-foreground font-myanmar">
                {lang === "mm"
                  ? "အကောင့်ဝင်ရင် — ကံဂဏန်း notification နှင့် လက်မှတ်သိမ်းဆည်းခြင်း သုံးနိုင်ပါတယ်"
                  : "Sign in to save tickets & receive weekly lucky number notifications"}
              </p>
            </div>

            {/* Help section removed - not needed */}
          </>
        )}

        {/* ─── Install App Button ──────────────────────────────────────── */}
        <InstallAppSection />

        {/* ─── Social Links: Telegram & YouTube ───────────────────────── */}
        <div className="glass rounded-2xl p-4 border border-blue-200 bg-gradient-to-br from-blue-50 to-sky-50">
          <h3 className="text-sm font-bold text-foreground font-myanmar mb-3 text-center">
            {lang === "mm" ? "ဆက်သွယ်ရန်" : "Connect With Us"}
          </h3>
          <div className="space-y-2">
            {/* Telegram */}
            <a
              href="https://t.me/Aung007t"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 rounded-xl bg-white/80 border border-blue-100 hover:bg-white transition-all btn-press"
              style={{ textDecoration: 'none' }}
            >
              <div className="w-10 h-10 rounded-xl bg-[#0088CC] flex items-center justify-center flex-shrink-0">
                <MessageCircle size={18} className="text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-bold text-foreground">Telegram</h4>
                <p className="text-xs text-muted-foreground">@Aung007t</p>
              </div>
              <ExternalLink size={14} className="text-muted-foreground" />
            </a>

            {/* YouTube */}
            <a
              href="https://youtube.com/@yourchannel"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 rounded-xl bg-white/80 border border-red-100 hover:bg-white transition-all btn-press"
              style={{ textDecoration: 'none' }}
            >
              <div className="w-10 h-10 rounded-xl bg-[#FF0000] flex items-center justify-center flex-shrink-0">
                <Youtube size={18} className="text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-bold text-foreground">YouTube</h4>
                <p className="text-xs text-muted-foreground">{lang === "mm" ? "YouTube Channel" : "YouTube Channel"}</p>
              </div>
              <ExternalLink size={14} className="text-muted-foreground" />
            </a>
          </div>
        </div>

        {/* Privacy Policy + Play Store Guide links */}
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={() => navigate("/privacy")}
              className="flex items-center gap-1.5 text-muted-foreground hover:text-amber-600 transition-colors"
            >
              <FileText size={14} />
              <span className="text-xs">{lang === "mm" ? "ကိုယ်ရေးကိုယ်တာ မူဝါဒ" : "Privacy Policy"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
