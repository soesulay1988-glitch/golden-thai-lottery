import { useState, useRef, useEffect, useCallback } from "react";
import { useLang } from "@/contexts/LangContext";
import { Play, ChevronLeft, Maximize, Minimize, Volume2, VolumeX, SkipBack, SkipForward, TrendingUp } from "lucide-react";
import { trpc } from "@/lib/trpc";

// Thai Lottery Live Draw YouTube channel ID (GLO Official)
const DRAW_LIVE_VIDEO_ID = "UCijJDSRBMjvmxx71qqYhIsg"; // ThaiLotteryResultToday channel

// Playlist — add your YouTube video IDs and titles here
const PLAYLIST = [
  {
    id: "jNQXAC9IVRw",
    title_mm: "Me at the zoo",
    title_en: "Me at the zoo",
    title_th: "ฉันที่สวนสัตว์",
  },
  {
    id: "9bZkp7q19f0",
    title_mm: "PSY - GANGNAM STYLE",
    title_en: "PSY - GANGNAM STYLE",
    title_th: "PSY - กังนัมสไตล์",
  },
  {
    id: "kJQP7kiw5Fk",
    title_mm: "Luis Fonsi - Despacito",
    title_en: "Luis Fonsi - Despacito",
    title_th: "Luis Fonsi - Despacito",
  },
  {
    id: "RgKAFK5djSk",
    title_mm: "Wiz Khalifa - See You Again",
    title_en: "Wiz Khalifa - See You Again",
    title_th: "Wiz Khalifa - See You Again",
  },
];

// Compact live 2D ticker bar showing SET, VALUE, and 2D number
function Live2DTicker({ lang }: { lang: "mm" | "en" | "th" }) {
  const { data: liveData } = trpc.myanmar2d.getLive.useQuery(undefined, {
    refetchInterval: 5000,
    staleTime: 0,
  });

  const liveCurrent = liveData?.success ? (liveData.live || null) : null;
  const liveResults = liveData?.success ? (liveData.results || []) : [];
  const liveMorning = liveResults.find((r) => r.session === "morning");
  const liveEvening = liveResults.find((r) => r.session === "evening");

  const now = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Yangon" }));
  const totalMin = now.getHours() * 60 + now.getMinutes();
  const activeSession = totalMin < 12 * 60 + 30 ? "morning" : "evening";

  const sessionData = activeSession === "morning" ? liveMorning : liveEvening;
  const set = (sessionData?.set && sessionData.set !== "--") ? sessionData.set : (liveCurrent?.set !== "--" ? liveCurrent?.set : "--");
  const value = (sessionData?.value && sessionData.value !== "--") ? sessionData.value : (liveCurrent?.value !== "--" ? liveCurrent?.value : "--");
  const twod = (sessionData?.twod && sessionData.twod !== "--") ? sessionData.twod : (liveCurrent?.twod !== "--" ? liveCurrent?.twod : "--");

  const sessionLabel = activeSession === "morning"
    ? (lang === "mm" ? "မနက်ပိုင်း" : lang === "th" ? "รอบเช้า" : "Morning")
    : (lang === "mm" ? "ညနေပိုင်း" : lang === "th" ? "รอบบ่าย" : "Evening");

  return (
    <div className="mx-3 mt-2">
      <div className="rounded-xl bg-gradient-to-r from-[#FF5722] to-[#E64A19] p-3 shadow-md">
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp size={14} className="text-yellow-200" />
          <span className="text-xs font-bold text-yellow-100">{sessionLabel}</span>
          <span className="text-[10px] text-yellow-200/70 ml-auto">LIVE</span>
          <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
        </div>
        <div className="flex items-center justify-between">
          <div className="text-center flex-1">
            <div className="text-[10px] text-yellow-200/80">SET</div>
            <div className="text-sm font-bold text-white">{set}</div>
          </div>
          <div className="w-px h-8 bg-white/20" />
          <div className="text-center flex-1">
            <div className="text-[10px] text-yellow-200/80">VALUE</div>
            <div className="text-sm font-bold text-white">{value}</div>
          </div>
          <div className="w-px h-8 bg-white/20" />
          <div className="text-center flex-1">
            <div className="text-[10px] text-yellow-200/80">2D</div>
            <div className="text-base font-black text-yellow-300">{twod}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function VideoPage() {
  const { lang, t } = useLang();
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(80);
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const playerRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Detect if today is a Thai lottery draw day (1st or 16th of the month)
  const myanmarNow = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Yangon" }));
  const drawDay = myanmarNow.getDate() === 1 || myanmarNow.getDate() === 16;
  const isDrawMonthDay = drawDay && myanmarNow.getHours() >= 14; // After 2 PM on draw day

  // Build the effective playlist — prepend live draw video on draw days
  const effectivePlaylist = isDrawMonthDay
    ? [
        {
          id: DRAW_LIVE_VIDEO_ID,
          title_mm: "ထီထွက်သည့်နေ့ — တိုက်ရိုက် ထီဆွဲခြင်း",
          title_en: "Draw Day — Live Lottery Draw",
          title_th: "วันหวยออก — ถ่ายทอดสดการออกรางวัล",
          isLive: true,
        },
        ...PLAYLIST,
      ]
    : PLAYLIST;

  const currentVideo = effectivePlaylist[currentIdx];

  // Handle fullscreen toggle
  const toggleFullscreen = useCallback(() => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(() => {
        setIsFullscreen(prev => !prev);
      });
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
      });
    }
  }, []);

  // Listen for fullscreen change events
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFsChange);
    return () => document.removeEventListener("fullscreenchange", handleFsChange);
  }, []);

  // Listen for YouTube IFrame API + getCurrentTime response
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!playerRef.current) return;
      if (event.data && typeof event.data === "string") {
        try {
          const data = JSON.parse(event.data);
          if (data.event === "infoDelivery" && data.info?.currentTime !== undefined) {
            const offset = Number(playerRef.current.dataset.seekOffset);
            if (offset !== 0) {
              const newTime = Math.max(0, data.info.currentTime + offset);
              const seekMsg = JSON.stringify({
                event: "command",
                func: "seekTo",
                args: [newTime, true],
              });
              playerRef.current.contentWindow?.postMessage(seekMsg, "*");
              playerRef.current.dataset.seekOffset = "0";
            }
          }
        } catch {
          // Not JSON or not our message — ignore
        }
      }
    };
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, []);

  // Send commands to YouTube iframe via postMessage
  const sendYouTubeCommand = useCallback((command: string) => {
    if (!playerRef.current?.contentWindow) return;
    const jsonMessage = JSON.stringify({
      event: "command",
      func: command,
      args: [],
    });
    playerRef.current.contentWindow.postMessage(jsonMessage, "*");
  }, []);

  // Initialize YouTube iframe API when playing
  useEffect(() => {
    if (isPlaying && iframeLoaded) {
      const timer = setTimeout(() => {
        sendYouTubeCommand("playVideo");
        sendYouTubeCommand("setVolume");
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [isPlaying, iframeLoaded, currentVideo.id, sendYouTubeCommand]);

  // Volume change handler
  const handleVolumeChange = useCallback((val: number) => {
    setVolume(val);
    if (!playerRef.current?.contentWindow) return;
    playerRef.current.contentWindow.postMessage(
      JSON.stringify({ event: "command", func: "setVolume", args: [val] }),
      "*"
    );
    if (val === 0) setIsMuted(true);
    else if (isMuted) setIsMuted(false);
  }, [isMuted]);

  // Mute toggle
  const toggleMute = useCallback(() => {
    if (!playerRef.current?.contentWindow) return;
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    playerRef.current.contentWindow.postMessage(
      JSON.stringify({ event: "command", func: newMuted ? "mute" : "unMute", args: [] }),
      "*"
    );
  }, [isMuted]);

  // Skip forward 10 seconds
  const skipForward = useCallback(() => {
    if (!playerRef.current?.contentWindow) return;
    playerRef.current.dataset.seekOffset = "10";
    playerRef.current.contentWindow.postMessage(
      JSON.stringify({ event: "command", func: "getCurrentTime", args: [] }),
      "*"
    );
  }, []);

  // Skip backward 10 seconds
  const skipBackward = useCallback(() => {
    if (!playerRef.current?.contentWindow) return;
    playerRef.current.dataset.seekOffset = "-10";
    playerRef.current.contentWindow.postMessage(
      JSON.stringify({ event: "command", func: "getCurrentTime", args: [] }),
      "*"
    );
  }, []);

  // Play a specific video from playlist
  const playVideo = (idx: number) => {
    setCurrentIdx(idx);
    setIsPlaying(true);
    setIframeLoaded(false);
  };

  // Next video in playlist
  const nextVideo = useCallback(() => {
    if (currentIdx < effectivePlaylist.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setIframeLoaded(false);
    }
  }, [currentIdx]);

  // Previous video in playlist
  const prevVideo = useCallback(() => {
    if (currentIdx > 0) {
      setCurrentIdx(currentIdx - 1);
      setIframeLoaded(false);
    }
  }, [currentIdx]);

  return (
    <div className={`bg-[#FFF8E1] ${isPlaying && isFullscreen ? "h-screen" : "min-h-screen"} pb-24`}>
      {/* Header — hidden in fullscreen */}
      {!isPlaying || !isFullscreen ? (
        <div className="sticky top-0 z-40 bg-[#FFD700] px-4 py-3 shadow-md">
          <h1 className="text-lg font-bold text-[#7B2D00] font-myanmar">
            {t("navVideo")}
          </h1>
        </div>
      ) : null}

      {/* Live 2D Market Ticker — always visible above video */}
      {!isFullscreen && <Live2DTicker lang={lang} />}

      <div className="px-3 pt-3 space-y-3">
        {!isPlaying ? (
          /* ===== Playlist Home View ===== */
          <>
            {/* Google Ads Banner Placeholder — Top */}
            <div className="w-full h-[60px] rounded-xl bg-gradient-to-r from-amber-100 to-yellow-50 border-2 border-dashed border-amber-300 flex items-center justify-center">
              <span className="text-xs text-amber-400 font-myanmar">
                {lang === "mm" ? "ကြော်ငြာ နေရာ" : lang === "th" ? "พื้นที่โฆษณา" : "Ad Space"}
              </span>
            </div>

            {/* Playlist Title */}
            <div className="flex items-center gap-2 px-1">
              <Play size={18} className="text-red-500" />
              <h2 className="text-base font-bold text-foreground font-myanmar">
                {t("navVideo")}
              </h2>
              <span className="text-xs text-muted-foreground ml-auto">
                {effectivePlaylist.length} {lang === "mm" ? "ပုဒ်" : lang === "th" ? "วิดีโอ" : "videos"}
              </span>
            </div>

            {/* Video List */}
            <div className="space-y-2">
              {effectivePlaylist.map((video, idx) => {
                const isLive = 'isLive' in video && video.isLive;
                return (
                  <button
                    key={video.id + (isLive ? '-live' : '')}
                    onClick={() => playVideo(idx)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border shadow-sm hover:shadow-md transition-all btn-press text-left ${
                      isLive
                        ? "bg-gradient-to-r from-red-500 to-red-600 border-red-400"
                        : "bg-white border border-amber-100"
                    }`}
                  >
                    {/* Thumbnail */}
                    <div className="w-28 h-20 rounded-lg overflow-hidden flex-shrink-0 bg-gray-900 relative">
                      <img
                        src={`https://img.youtube.com/vi/${video.id}/mqdefault.jpg`}
                        alt={video.title_en}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                        <div className="w-8 h-8 rounded-full bg-white/90 flex items-center justify-center">
                          <Play size={16} className="text-red-500 ml-0.5" />
                        </div>
                      </div>
                      {isLive && (
                        <div className="absolute top-1 left-1 bg-red-600 text-white text-[8px] font-bold px-1.5 py-0.5 rounded">
                          LIVE
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <h3 className={`text-sm font-bold truncate font-myanmar ${isLive ? "text-white" : "text-foreground"}`}>
                        {isLive
                          ? (lang === "mm" ? "🔴 " : "🔴 ") + (lang === "mm" ? video.title_mm : lang === "th" ? video.title_th : video.title_en)
                          : `${idx + 1}. ${lang === "mm" ? video.title_mm : lang === "th" ? video.title_th : video.title_en}`
                        }
                      </h3>
                      <p className={`text-xs mt-1 ${isLive ? "text-white/70" : "text-muted-foreground"}`}>
                        {isLive
                          ? (lang === "mm" ? "ထီထွက်သည့်နေ့ တိုက်ရိုက်" : lang === "th" ? "ถ่ายทอดสดวันหวยออก" : "Draw day live")
                          : (lang === "mm" ? "နှိပ်၍ ကြည့်ပါ" : lang === "th" ? "แตะเพื่อเล่น" : "Tap to play")
                        }
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Google Ads Banner Placeholder — Bottom */}
            <div className="w-full h-[60px] rounded-xl bg-gradient-to-r from-amber-100 to-yellow-50 border-2 border-dashed border-amber-300 flex items-center justify-center">
              <span className="text-xs text-amber-400 font-myanmar">
                {lang === "mm" ? "ကြော်ငြာ နေရာ" : lang === "th" ? "พื้นที่โฆษณา" : "Ad Space"}
              </span>
            </div>
          </>
        ) : (
          /* ===== Video Player View ===== */
          <div
            ref={containerRef}
            className={`space-y-2 ${isFullscreen ? "h-screen flex flex-col" : ""}`}
          >
            {/* Back button — hidden in fullscreen */}
            {!isFullscreen && (
              <button
                onClick={() => setIsPlaying(false)}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors py-1"
              >
                <ChevronLeft size={16} />
                {t("back")}
              </button>
            )}

            {/* Video Player */}
            <div className={`relative ${isFullscreen ? "flex-1" : ""} rounded-2xl overflow-hidden shadow-lg border border-red-100 bg-black`}>
              <div
                className="w-full"
                style={{
                  paddingBottom: isFullscreen ? "0" : "56.25%",
                  position: "relative",
                  ...(isFullscreen ? { height: "100%" } : {}),
                }}
              >
                <iframe
                  ref={playerRef}
                  key={currentVideo.id}
                  src={`https://www.youtube.com/embed/${currentVideo.id}?autoplay=1&enablejsapi=1&rel=0&modestbranding=1&playsinline=1&origin=${window.location.origin}`}
                  className="absolute inset-0 w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                  allowFullScreen
                  style={{ border: "none" }}
                  onLoad={() => setIframeLoaded(true)}
                />
              </div>

              {/* Custom Controls Overlay — bottom of player */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent px-3 pb-3 pt-6">
                <div className="flex items-center gap-2">
                  {/* Skip backward 10s */}
                  <button
                    onClick={skipBackward}
                    className="flex flex-col items-center justify-center w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 transition-all"
                    title={lang === "mm" ? "၁၀ စက္ကန့် နောက်သို့" : lang === "th" ? "ย้อนกลับ 10 วินาที" : "Back 10s"}
                  >
                    <SkipBack size={14} className="text-white" />
                    <span className="text-[9px] text-white leading-none mt-0.5">10</span>
                  </button>

                  {/* Previous video */}
                  <button
                    onClick={prevVideo}
                    disabled={currentIdx === 0}
                    className="flex items-center justify-center w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 transition-all disabled:opacity-30"
                    title={lang === "mm" ? "ဗီဒီယို အရင်ပုဒ်" : lang === "th" ? "วิดีโอก่อนหน้า" : "Previous video"}
                  >
                    <ChevronLeft size={16} className="text-white" />
                  </button>

                  {/* Mute/Unmute button */}
                  <button
                    onClick={toggleMute}
                    className="flex items-center justify-center w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 transition-all"
                    title={isMuted ? (lang === "mm" ? "အသံဖွင့်" : lang === "th" ? "เปิดเสียง" : "Unmute") : (lang === "mm" ? "အသံပိတ်" : lang === "th" ? "ปิดเสียง" : "Mute")}
                  >
                    {isMuted ? (
                      <VolumeX size={18} className="text-white" />
                    ) : (
                      <Volume2 size={18} className="text-white" />
                    )}
                  </button>

                  {/* Volume slider */}
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={isMuted ? 0 : volume}
                    onChange={(e) => handleVolumeChange(Number(e.target.value))}
                    className="flex-1 h-1.5 accent-red-500 cursor-pointer"
                    style={{
                      appearance: "none",
                      WebkitAppearance: "none",
                      height: "6px",
                      borderRadius: "3px",
                      background: `linear-gradient(to right, #fff 0%, #fff ${isMuted ? 0 : volume}%, rgba(255,255,255,0.3) ${isMuted ? 0 : volume}%, rgba(255,255,255,0.3) 100%)`,
                      outline: "none",
                    }}
                  />

                  {/* Volume percentage */}
                  <span className="text-xs text-white/80 w-8 text-center">
                    {isMuted ? 0 : volume}
                  </span>

                  {/* Skip forward 10s */}
                  <button
                    onClick={skipForward}
                    className="flex flex-col items-center justify-center w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 transition-all"
                    title={lang === "mm" ? "၁၀ စက္ကန့် ရှေ့သို့" : lang === "th" ? "ไปข้างหน้า 10 วินาที" : "Forward 10s"}
                  >
                    <SkipForward size={14} className="text-white" />
                    <span className="text-[9px] text-white leading-none mt-0.5">10</span>
                  </button>

                  {/* Next video */}
                  <button
                    onClick={nextVideo}
                    disabled={currentIdx === effectivePlaylist.length - 1}
                    className="flex items-center justify-center w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 transition-all disabled:opacity-30"
                    title={lang === "mm" ? "ဗီဒီယို နောက်ပုဒ်" : lang === "th" ? "วิดีโอถัดไป" : "Next video"}
                  >
                    <ChevronLeft size={16} className="text-white rotate-180" />
                  </button>

                  {/* Fullscreen button */}
                  <button
                    onClick={toggleFullscreen}
                    className="flex items-center justify-center w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 transition-all"
                    title={isFullscreen ? (lang === "mm" ? "ပုံမှန်ပြန်လာ" : lang === "th" ? "ออกจากเต็มจอ" : "Exit Fullscreen") : (lang === "mm" ? "မျက်နှြင်အပြည့်" : lang === "th" ? "เต็มจอ" : "Fullscreen")}
                  >
                    {isFullscreen ? (
                      <Minimize size={18} className="text-white" />
                    ) : (
                      <Maximize size={18} className="text-white" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Now Playing info — hidden in fullscreen */}
            {!isFullscreen && (
              <div className={`rounded-xl border p-3 ${('isLive' in currentVideo && currentVideo.isLive) ? "bg-red-50 border-red-200" : "bg-white border-amber-100"}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-muted-foreground">
                      {lang === "mm" ? "ပြနေသော" : lang === "th" ? "กำลังเล่น" : "Now Playing"}
                    </span>
                    <h3 className={`text-sm font-bold font-myanmar truncate ${('isLive' in currentVideo && currentVideo.isLive) ? "text-red-600" : "text-foreground"}`}>
                      {currentIdx + 1}. {lang === "mm" ? currentVideo.title_mm : lang === "th" ? currentVideo.title_th : currentVideo.title_en}
                      {'isLive' in currentVideo && currentVideo.isLive && (
                        <span className="ml-2 text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded">LIVE</span>
                      )}
                    </h3>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {currentIdx + 1} / {effectivePlaylist.length}
                  </span>
                </div>
              </div>
            )}

            {/* Playlist mini list — hidden in fullscreen */}
            {!isFullscreen && (
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-muted-foreground px-1 mb-1">
                  {t("navVideo")}
                </h4>
                {effectivePlaylist.map((video, idx) => {
                  const isLive = 'isLive' in video && video.isLive;
                  return (
                    <button
                      key={video.id + (isLive ? '-live' : '')}
                      onClick={() => {
                        setCurrentIdx(idx);
                        setIframeLoaded(false);
                      }}
                      className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left transition-all btn-press ${
                        idx === currentIdx
                          ? "bg-red-50 border border-red-200"
                          : isLive ? "bg-red-50 border border-red-100" : "bg-white/60 border border-transparent hover:bg-white"
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                        idx === currentIdx ? "bg-red-500 text-white" : isLive ? "bg-red-400 text-white" : "bg-gray-200 text-gray-500"
                      }`}>
                        {idx === currentIdx ? (
                          <span className="animate-pulse">▶</span>
                        ) : isLive ? (
                          <span className="text-[8px]">L</span>
                        ) : (
                          idx + 1
                        )}
                      </div>
                      <span className={`text-xs truncate font-myanmar ${
                        idx === currentIdx ? "text-red-600 font-bold" : isLive ? "text-red-500 font-bold" : "text-muted-foreground"
                      }`}>
                        {lang === "mm" ? video.title_mm : lang === "th" ? video.title_th : video.title_en}
                      </span>
                      {isLive && <span className="text-[8px] bg-red-500 text-white px-1 py-0.5 rounded ml-auto">LIVE</span>}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
