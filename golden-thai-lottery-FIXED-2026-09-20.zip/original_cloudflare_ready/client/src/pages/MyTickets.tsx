import { useState } from "react";
import { useLocation } from "wouter";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { toast } from "sonner";
import { ArrowLeft, Ticket, Plus, Trash2, RefreshCw, CheckCircle, XCircle, Clock, LogIn } from "lucide-react";

export default function MyTickets() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const mm = lang === "mm";

  const [ticketInput, setTicketInput] = useState("");
  const [drawDateInput, setDrawDateInput] = useState(() => {
    const today = new Date();
    return today.toISOString().split("T")[0];
  });
  const [noteInput, setNoteInput] = useState("");

  const utils = trpc.useUtils();

  const { data: tickets, isLoading } = trpc.savedTickets.list.useQuery(undefined, {
    enabled: !!user,
  });

  const { data: drawDates } = trpc.thaiLottery.listDrawDates.useQuery();

  const addTicket = trpc.savedTickets.add.useMutation({
    onSuccess: () => {
      utils.savedTickets.list.invalidate();
      setTicketInput("");
      setNoteInput("");
      toast.success(mm ? "လက်မှတ် သိမ်းဆည်းပြီး" : "Ticket saved");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteTicket = trpc.savedTickets.delete.useMutation({
    onSuccess: () => {
      utils.savedTickets.list.invalidate();
      toast.success(mm ? "ဖျက်ပြီး" : "Deleted");
    },
  });

  const checkAll = trpc.savedTickets.checkAll.useMutation({
    onSuccess: (data) => {
      utils.savedTickets.list.invalidate();
      toast.success(
        mm
          ? `${data.checkedCount} ရွက် စစ်ဆေးပြီး`
          : `Checked ${data.checkedCount} ticket(s)`
      );
    },
    onError: (e) => toast.error(e.message),
  });

  const handleAdd = () => {
    if (ticketInput.length !== 6 || !/^\d{6}$/.test(ticketInput)) {
      toast.error(mm ? "ဂဏန်း ၆ လုံး ထည့်ပါ" : "Enter a valid 6-digit number");
      return;
    }
    addTicket.mutate({
      ticketNumber: ticketInput,
      drawDate: drawDateInput,
      note: noteInput || undefined,
    });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#f5f5f5]">
        <header className="page-header bg-[#FFD700]">
          <div className="max-w-[480px] mx-auto px-4 py-3 flex items-center gap-3">
            <button onClick={() => navigate("/")} className="p-2 rounded-xl hover:bg-white/30 transition-colors btn-press">
              <ArrowLeft size={18} className="text-[#333]" />
            </button>
            <h1 className="text-[14px] font-bold text-foreground font-myanmar">
              {mm ? "ကျွန်ုပ်၏ လက်မှတ်များ" : "My Tickets"}
            </h1>
          </div>
        </header>
        <div className="max-w-[480px] mx-auto px-4 pt-16 pb-24 flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-amber-100 border border-amber-200 flex items-center justify-center">
            <Ticket size={28} className="text-amber-600" />
          </div>
          <p className="text-[14px] font-bold text-foreground font-myanmar text-center">
            {mm ? "အကောင့်ဝင်ရောက်ပါ" : "Sign In Required"}
          </p>
          <p className="text-[12px] text-muted-foreground font-myanmar text-center">
            {mm
              ? "လက်မှတ်သိမ်းဆည်းရန် အကောင့်ဝင်ရောက်ရပါမည်"
              : "Please sign in to save and check your tickets"}
          </p>
          <button
            onClick={() => startLogin()}
            className="flex items-center gap-2 bg-amber-500 text-white font-bold px-6 py-3 rounded-xl btn-press font-myanmar"
          >
            <LogIn size={16} />
            {mm ? "အကောင့်ဝင်ရောက်ရန်" : "Sign In"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      {/* Header */}
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/")} className="p-2 rounded-xl hover:bg-white/30 transition-colors btn-press">
              <ArrowLeft size={18} className="text-[#333]" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center">
                <Ticket size={16} className="text-amber-600" />
              </div>
              <div>
                <h1 className="text-[14px] font-bold text-foreground font-myanmar leading-tight">
                  {mm ? "ကျွန်ုပ်၏ လက်မှတ်များ" : "My Tickets"}
                </h1>
                <p className="text-[10px] text-muted-foreground font-myanmar">
                  {mm ? "သိမ်းဆည်းပြီး အလိုအလျောက် စစ်ဆေးပါ" : "Save & auto-check tickets"}
                </p>
              </div>
            </div>
          </div>
          {tickets && tickets.length > 0 && (
            <button
              onClick={() => checkAll.mutate()}
              disabled={checkAll.isPending}
              className="flex items-center gap-1.5 bg-amber-100 border border-amber-300 text-amber-700 text-[11px] font-bold px-3 py-2 rounded-xl btn-press font-myanmar"
            >
              <RefreshCw size={12} className={checkAll.isPending ? "animate-spin" : ""} />
              {mm ? "အားလုံးစစ်ဆေး" : "Check All"}
            </button>
          )}
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 pt-4 pb-24 space-y-4">

        {/* Add Ticket Form */}
        <div className="glass rounded-2xl p-4 border border-amber-200 bg-gradient-to-br from-amber-50 to-white">
          <p className="text-[12px] font-bold text-foreground font-myanmar mb-3">
            <Plus size={13} className="inline mr-1" />
            {mm ? "လက်မှတ် ထည့်ရန်" : "Add Ticket"}
          </p>
          <div className="space-y-2">
            <input
              type="text"
              inputMode="numeric"
              maxLength={6}
              value={ticketInput}
              onChange={(e) => setTicketInput(e.target.value.replace(/\D/g, ""))}
              placeholder={mm ? "ဂဏန်း ၆ လုံး ထည့်ပါ" : "6-digit ticket number"}
              className="w-full bg-white border border-border rounded-xl px-4 py-3 text-[18px] font-bold tracking-[0.2em] text-center text-foreground focus:outline-none focus:border-amber-400 font-myanmar"
            />
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-muted-foreground font-myanmar block mb-1">
                  {mm ? "ဆွဲချက်ရက်" : "Draw Date"}
                </label>
                <select
                  value={drawDateInput}
                  onChange={(e) => setDrawDateInput(e.target.value)}
                  className="w-full bg-white border border-border rounded-xl px-2 py-2 text-[12px] font-myanmar text-foreground focus:outline-none focus:border-amber-400"
                >
                  {drawDates?.map((d) => {
                    const dateStr = typeof d.drawDate === "string" ? d.drawDate : new Date(d.drawDate as unknown as string).toISOString().split("T")[0];
                    return (
                      <option key={d.id} value={dateStr}>
                        {new Date(dateStr).toLocaleDateString(lang === "mm" ? "my-MM" : "en-US", {
                          day: "numeric", month: "short", year: "numeric"
                        })}
                      </option>
                    );
                  })}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-muted-foreground font-myanmar block mb-1">
                  {mm ? "မှတ်ချက် (ရွေးချယ်မှု)" : "Note (optional)"}
                </label>
                <input
                  type="text"
                  value={noteInput}
                  onChange={(e) => setNoteInput(e.target.value)}
                  placeholder={mm ? "မှတ်ချက်" : "Note"}
                  className="w-full bg-white border border-border rounded-xl px-2 py-2 text-[12px] font-myanmar text-foreground focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
            <button
              onClick={handleAdd}
              disabled={addTicket.isPending}
              className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-2.5 rounded-xl flex items-center justify-center gap-2 btn-press transition-colors font-myanmar disabled:opacity-60"
            >
              {addTicket.isPending ? (
                <RefreshCw size={14} className="animate-spin" />
              ) : (
                <Plus size={14} />
              )}
              {mm ? "သိမ်းဆည်းရန်" : "Save Ticket"}
            </button>
          </div>
        </div>

        {/* Ticket List */}
        {isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="glass rounded-2xl p-4 border border-border animate-pulse">
                <div className="h-4 w-32 skeleton mb-2" />
                <div className="h-8 w-24 skeleton" />
              </div>
            ))}
          </div>
        ) : tickets && tickets.length > 0 ? (
          <div className="space-y-2">
            {tickets.map((ticket) => {
              const isWinner = ticket.prizeResult && ticket.prizeResult.length > 0;
              const isLoser = ticket.isChecked && (!ticket.prizeResult || ticket.prizeResult.length === 0);
              return (
                <div
                  key={ticket.id}
                  className={`glass rounded-2xl p-4 border transition-all ${
                    isWinner
                      ? "border-amber-300 bg-amber-50"
                      : isLoser
                      ? "border-gray-200 bg-gray-50"
                      : "border-border"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="prize-number text-2xl font-black text-foreground tracking-wider">
                          {ticket.ticketNumber}
                        </span>
                        {ticket.isChecked ? (
                          isWinner ? (
                            <CheckCircle size={16} className="text-amber-500" />
                          ) : (
                            <XCircle size={16} className="text-gray-400" />
                          )
                        ) : (
                          <Clock size={14} className="text-muted-foreground" />
                        )}
                      </div>
                      <p className="text-[10px] text-muted-foreground font-myanmar">
                        {mm ? "ဆွဲချက်ရက်" : "Draw"}: {new Date(ticket.drawDate).toLocaleDateString(lang === "mm" ? "my-MM" : "en-US", {
                          day: "numeric", month: "short", year: "numeric"
                        })}
                      </p>
                      {ticket.note && (
                        <p className="text-[10px] text-muted-foreground font-myanmar mt-0.5">{ticket.note}</p>
                      )}
                      {isWinner && ticket.prizeResult && (
                        <div className="mt-2 space-y-1">
                          {ticket.prizeResult.map((p, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <span className="text-[11px] font-bold text-amber-700 font-myanmar">
                                🏆 {mm ? p.prizeMm : p.prizeEn}
                              </span>
                              <span className="text-[11px] text-amber-600 font-myanmar">
                                {p.amount} {mm ? "ဘတ်" : "Baht"}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                      {isLoser && (
                        <p className="text-[11px] text-muted-foreground font-myanmar mt-1">
                          {mm ? "ဆုမပေါ်ပါ" : "Not a winning ticket"}
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => deleteTicket.mutate({ id: ticket.id })}
                      className="p-2 rounded-xl hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors btn-press"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3 py-12">
            <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center">
              <Ticket size={24} className="text-muted-foreground" />
            </div>
            <p className="text-[13px] text-muted-foreground font-myanmar text-center">
              {mm ? "လက်မှတ် မရှိသေးပါ" : "No tickets saved yet"}
            </p>
            <p className="text-[11px] text-muted-foreground font-myanmar text-center">
              {mm ? "အထက်မှ လက်မှတ်နံပါတ် ထည့်ပါ" : "Add a ticket number above"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
