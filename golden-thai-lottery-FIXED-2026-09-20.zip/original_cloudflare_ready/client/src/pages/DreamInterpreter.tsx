import { useState } from "react";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, Sparkles, Star } from "lucide-react";
import { toast } from "sonner";

export default function DreamInterpreter() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const [dreamText, setDreamText] = useState("");
  const [result, setResult] = useState<any>(null);

  const interpretMutation = trpc.dream.interpret.useMutation({
    onSuccess: (data) => setResult(data),
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <header className="page-header bg-[#FFD700]">
        <div className="max-w-[480px] mx-auto flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/")} className="text-[#333] btn-press"><ArrowLeft size={20} /></button>
          <h1 className="font-display text-base font-bold text-[#333] flex-1">
            {lang === "mm" ? "AI အိမ်မက်ဟောကိန်း" : "AI Dream Interpreter"}
          </h1>
          <Sparkles size={18} className="text-amber-600 animate-gold-pulse" />
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 py-4 space-y-4">
        <div className="bg-white rounded-xl p-4 shadow-sm animate-fade-in-up">
          <p className="text-xs text-amber-600 font-myanmar mb-2">
            {lang === "mm" ? "မနေ့ညမက်သောအိမ်မက်ကို ဖော်ပြပါ" : "Describe your dream below"}
          </p>
          <textarea
            value={dreamText}
            onChange={(e) => setDreamText(e.target.value)}
            placeholder={lang === "mm"
              ? "ဥပမာ - ရေမြောင်းထဲ ငါးကြီးတွေ တွေ့သည်။ ရွှေတွေ ကောက်သည်..."
              : "e.g. I saw big fish in a river. I was picking up gold coins..."}
            rows={4}
            className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-[#333] placeholder:text-gray-400 focus:outline-none focus:border-amber-400 resize-none font-myanmar leading-relaxed"
          />
          <button
            onClick={() => interpretMutation.mutate({ dreamText, language: lang })}
            disabled={dreamText.length < 5 || interpretMutation.isPending}
            className="mt-3 w-full bg-gradient-to-r from-purple-600 to-pink-500 text-white font-bold py-3 rounded-xl text-sm font-myanmar disabled:opacity-40 transition-all btn-press flex items-center justify-center gap-2"
          >
            <Sparkles size={16} />
            {interpretMutation.isPending
              ? (lang === "mm" ? "ဟောကိန်းကြည့်နေသည်..." : "Interpreting...")
              : (lang === "mm" ? "ဟောကိန်းကြည့်ရန်" : "Interpret Dream")}
          </button>
        </div>

        {result && (
          <div className="space-y-3 animate-fade-in-up">
            {/* Fortune rating */}
            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-amber-600 font-semibold font-myanmar">
                  {lang === "mm" ? "ကံကြမ္မာ အဆင့်" : "Fortune Rating"}
                </span>
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={14} className={i < result.overallFortune ? "star-filled" : "star-empty"} fill="currentColor" />
                  ))}
                </div>
              </div>
              <p className="text-sm text-foreground/90 font-myanmar leading-relaxed">
                {lang === "mm" ? result.interpretationMm : result.interpretationEn}
              </p>
            </div>

            {/* Lucky numbers */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-xl p-4 shadow-sm">
                <p className="text-[10px] text-amber-600 font-semibold mb-2 font-myanmar">
                  {lang === "mm" ? "ကံကောင်း ၂ဒီ ဂဏန်း" : "Lucky 2D Numbers"}
                </p>
                <div className="flex flex-wrap gap-2">
                  {result.lucky2dNumbers?.map((n: string) => (
                    <span key={n} className="prize-number text-2xl font-bold text-amber-600 bg-amber-100 rounded-xl px-3 py-1">{n}</span>
                  ))}
                </div>
              </div>
              <div className="glass rounded-2xl p-4 border border-gray-200">
                <p className="text-[10px] text-amber-600 font-semibold mb-2 font-myanmar">
                  {lang === "mm" ? "ကံကောင်း လော့တာ ဂဏန်း" : "Lucky Lottery Numbers"}
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {result.luckyLotteryNumbers?.map((n: string) => (
                    <span key={n} className="prize-number text-sm font-bold text-amber-600 bg-amber-50 rounded-lg px-2 py-1">{n}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Lucky color & direction */}
            <div className="grid grid-cols-2 gap-3">
              <div className="glass rounded-xl p-3">
                <p className="text-[10px] text-muted-foreground font-myanmar">{lang === "mm" ? "ကံကောင်းရောင်" : "Lucky Color"}</p>
                <p className="text-sm font-bold text-amber-600 font-myanmar mt-1">
                  {lang === "mm" ? result.luckyColorMm : result.luckyColor}
                </p>
              </div>
              <div className="glass rounded-xl p-3">
                <p className="text-[10px] text-muted-foreground font-myanmar">{lang === "mm" ? "ကံကောင်းဦးတည်ချက်" : "Lucky Direction"}</p>
                <p className="text-sm font-bold text-amber-600 font-myanmar mt-1">
                  {lang === "mm" ? result.luckyDirectionMm : result.luckyDirection}
                </p>
              </div>
            </div>

            {/* Fortune message */}
            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200 text-center">
              <p className="text-sm text-amber-600 font-myanmar leading-relaxed italic">
                ✨ {lang === "mm" ? result.fortuneMessageMm : result.fortuneMessageEn} ✨
              </p>
            </div>

            {/* Symbols */}
            {result.symbols?.length > 0 && (
              <div className="glass rounded-2xl p-4">
                <p className="text-xs text-amber-600 font-semibold mb-2 font-myanmar">
                  {lang === "mm" ? "သင်္ကေတ အဓိပ္ပာယ်" : "Dream Symbols"}
                </p>
                <div className="space-y-2">
                  {result.symbols.map((s: any, i: number) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="text-gold-500 text-xs mt-0.5">▸</span>
                      <div>
                        <span className="text-xs font-semibold text-foreground">{s.symbol}: </span>
                        <span className="text-xs text-muted-foreground font-myanmar">
                          {lang === "mm" ? s.meaningMm : s.meaningEn}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
