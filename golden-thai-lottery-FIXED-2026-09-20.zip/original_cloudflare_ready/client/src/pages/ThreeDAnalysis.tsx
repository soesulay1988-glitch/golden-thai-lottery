import { ChangeEvent, useRef, useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, Download, ImagePlus, LoaderCircle, Maximize2, RefreshCw, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { useLang } from "@/contexts/LangContext";
import { trpc } from "@/lib/trpc";

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];

function label(lang: "mm" | "en" | "th", value: { mm: string; en: string; th: string }) {
  return lang === "mm" ? value.mm : lang === "th" ? value.th : value.en;
}

export default function ThreeDAnalysis() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const [viewerImageUrl, setViewerImageUrl] = useState<string | null>(null);
  const imageQuery = trpc.threeDImage.get.useQuery(undefined, { staleTime: 30_000 });
  const upload = trpc.threeDImage.upload.useMutation({
    onError: (error) => toast(error.message || label(lang, { mm: "ပုံတင်မရသေးပါ", th: "ยังอัปโหลดรูปไม่ได้", en: "Unable to upload image" })),
  });
  const remove = trpc.threeDImage.remove.useMutation({
    onSuccess: () => {
      setViewerImageUrl(null);
      imageQuery.refetch();
      toast(label(lang, { mm: "ပုံဖယ်ရှားပြီးပါပြီ", th: "ลบรูปแล้ว", en: "Image removed" }));
    },
    onError: (error) => toast(error.message || label(lang, { mm: "ပုံဖယ်ရှားမရသေးပါ", th: "ยังลบรูปไม่ได้", en: "Unable to remove image" })),
  });

  const saveImage = async (imageUrl: string) => {
    try {
      const response = await fetch(imageUrl);
      if (!response.ok) throw new Error("download failed");
      const blobUrl = URL.createObjectURL(await response.blob());
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = `golden-thai-3d-${Date.now()}.jpg`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(blobUrl);
      toast(label(lang, { mm: "ပုံ Save လုပ်ပြီးပါပြီ", th: "บันทึกรูปแล้ว", en: "Image saved" }));
    } catch {
      window.open(imageUrl, "_blank", "noopener,noreferrer");
      toast(label(lang, { mm: "ပုံကိုဖွင့်ပေးထားပါသည်။ ပုံကိုဖိထားပြီး Save လုပ်ပါ", th: "เปิดรูปแล้ว กดค้างเพื่อบันทึก", en: "Image opened. Press and hold it to save." }));
    }
  };

  const handleImageSelect = async (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []);
    event.target.value = "";
    if (!files.length) return;
    if (files.length > 5) {
      toast(label(lang, { mm: "တစ်ကြိမ်လျှင် အများဆုံး ၅ ပုံသာ ရွေးပါ", th: "เลือกได้สูงสุด 5 รูปต่อครั้ง", en: "Select up to 5 images at a time" }));
      return;
    }
    if (files.some((file) => !ACCEPTED_IMAGE_TYPES.includes(file.type))) {
      toast(label(lang, { mm: "JPG၊ PNG သို့မဟုတ် WEBP ပုံသာတင်နိုင်သည်", th: "อัปโหลดได้เฉพาะ JPG, PNG หรือ WEBP", en: "Only JPG, PNG, or WEBP images are allowed" }));
      return;
    }
    if (files.some((file) => file.size > MAX_IMAGE_BYTES)) {
      toast(label(lang, { mm: "ပုံတစ်ပုံစီ 3 MB အောက်ဖြစ်ရမည်", th: "แต่ละรูปต้องมีขนาดไม่เกิน 3 MB", en: "Each image must be 3 MB or smaller" }));
      return;
    }
    try {
      for (const file of files) {
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("read failed"));
          reader.onerror = () => reject(reader.error);
          reader.readAsDataURL(file);
        });
        await upload.mutateAsync({ dataUrl });
      }
      await imageQuery.refetch();
      toast(label(lang, { mm: `ပုံ ${files.length} ပုံ တင်ပြီးပါပြီ`, th: `อัปโหลด ${files.length} รูปแล้ว`, en: `${files.length} image(s) uploaded` }));
    } catch {
      toast(label(lang, { mm: "ပုံအချို့တင်မရပါ။ ပြန်စမ်းပါ", th: "อัปโหลดบางรูปไม่สำเร็จ", en: "Some images could not be uploaded" }));
    }
  };

  const text = {
    title: label(lang, { mm: "3D အထောက်အထားပုံ", th: "รูปหลักฐาน 3D", en: "3D Evidence Image" }),
    subtitle: label(lang, { mm: "Golden Thai တင်ထားသောပုံများကိုကြည့်ရန်", th: "ดูรูปที่ Golden Thai โพสต์", en: "View images posted by Golden Thai" }),
    emptyTitle: label(lang, { mm: "ပုံမတင်ရသေးပါ", th: "ยังไม่มีรูปที่โพสต์", en: "No image posted yet" }),
    emptyBody: label(lang, { mm: "ပုံအသစ်တင်ပြီးပါက ဤနေရာတွင်အလိုအလျောက်ပေါ်လာပါမည်", th: "รูปใหม่จะปรากฏที่นี่เมื่อโพสต์แล้ว", en: "A new image will appear here after it is posted." }),
  };
  const images = imageQuery.data?.images ?? [];
  const isBusy = upload.isPending || remove.isPending;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF8E1] to-[#f7f7f7] pb-24">
      <header className="page-header bg-[#FFD700] shadow-sm">
        <div className="mx-auto flex max-w-[480px] items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/")} className="rounded-xl p-1.5 text-[#3b3200] hover:bg-white/35 btn-press" aria-label="Back"><ArrowLeft size={21} /></button>
          <div className="min-w-0 flex-1"><h1 className="font-myanmar-display text-[17px] font-black leading-tight text-[#312a00]">{text.title}</h1><p className="mt-0.5 font-myanmar text-[10px] text-[#5d5100]">{text.subtitle}</p></div>
          <ImagePlus size={20} className="text-[#926500]" />
        </div>
      </header>

      <main className="mx-auto max-w-[480px] space-y-3 px-3 pt-3">
        {imageQuery.data?.canManage && <section className="rounded-2xl border border-amber-300 bg-white p-3 shadow-sm">
          <p className="font-myanmar text-[11px] font-black text-amber-800">{label(lang, { mm: "Admin ပုံတင်ရန်", th: "สำหรับแอดมิน: อัปโหลดรูป", en: "Admin: upload image" })}</p>
          <p className="mt-1 font-myanmar text-[10px] leading-4 text-slate-600">{label(lang, { mm: "တစ်ကြိမ်လျှင် JPG၊ PNG သို့မဟုတ် WEBP အများဆုံး ၅ ပုံတင်နိုင်သည်။ တင်ပြီးသားပုံများ မပျောက်ပါ။", th: "อัปโหลด JPG, PNG หรือ WEBP ได้สูงสุด 5 รูปต่อครั้ง", en: "Upload up to 5 JPG, PNG, or WEBP images at a time. Existing images are kept." })}</p>
          <input ref={inputRef} onChange={handleImageSelect} type="file" accept="image/jpeg,image/png,image/webp" multiple className="hidden" />
          <div className="mt-3 flex gap-2">
            <button disabled={isBusy} onClick={() => inputRef.current?.click()} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-3 py-2.5 font-myanmar text-[11px] font-black text-white shadow-sm disabled:opacity-60 btn-press">{upload.isPending ? <LoaderCircle size={15} className="animate-spin" /> : <ImagePlus size={15} />}{label(lang, { mm: "ပုံရွေးရန် (အများဆုံး ၅ ပုံ)", th: "เลือกรูป (สูงสุด 5)", en: "Choose images (max 5)" })}</button>
          </div>
        </section>}

        <section className="overflow-hidden rounded-2xl border-2 border-amber-300 bg-white shadow-md">
          <div className="flex items-center justify-between border-b border-amber-100 bg-[#fff8df] px-3 py-2.5"><p className="font-myanmar text-[12px] font-black text-amber-900">{label(lang, { mm: "3D အထောက်အထားပုံ", th: "รูปหลักฐาน 3D", en: "3D evidence image" })}</p><button onClick={() => imageQuery.refetch()} disabled={imageQuery.isFetching} className="rounded-lg bg-white p-1.5 text-amber-700 shadow-sm ring-1 ring-amber-200 disabled:opacity-60 btn-press" aria-label="Refresh image"><RefreshCw size={14} className={imageQuery.isFetching ? "animate-spin" : ""} /></button></div>
          {imageQuery.isLoading ? <div className="flex min-h-64 items-center justify-center"><LoaderCircle className="animate-spin text-amber-500" size={26} /></div> : images.length ? <div className="space-y-3 p-3">{images.map((image) => <article key={image.id} className="overflow-hidden rounded-xl border border-slate-200 bg-slate-50"><button onClick={() => setViewerImageUrl(image.imageUrl)} className="group relative block w-full text-left"><img src={image.imageUrl} alt={text.title} className="block max-h-[70vh] w-full object-contain" /><span className="absolute bottom-2 right-2 flex items-center gap-1 rounded-full bg-black/70 px-2.5 py-1 font-myanmar text-[10px] font-bold text-white"><Maximize2 size={12} />{label(lang, { mm: "ကြီးကြည့်ရန်", th: "ดูขนาดใหญ่", en: "View" })}</span></button><div className="flex gap-2 border-t border-slate-200 bg-white p-2"><button onClick={() => saveImage(image.imageUrl)} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 font-myanmar text-[11px] font-bold text-white btn-press"><Download size={14} />{label(lang, { mm: "ပုံ Save လုပ်ရန်", th: "บันทึกรูป", en: "Save image" })}</button>{imageQuery.data?.canManage && <button disabled={isBusy} onClick={() => window.confirm(label(lang, { mm: "ဤပုံတစ်ပုံကို ဖျက်မလား?", th: "ลบรูปนี้หรือไม่?", en: "Delete this image?" })) && remove.mutate({ id: image.id })} className="flex items-center justify-center gap-1 rounded-lg border border-red-200 bg-red-50 px-3 font-myanmar text-[11px] font-bold text-red-600 disabled:opacity-60 btn-press"><Trash2 size={14} />{label(lang, { mm: "ဖျက်ရန်", th: "ลบ", en: "Delete" })}</button>}</div></article>)}</div> : <div className="flex min-h-64 flex-col items-center justify-center px-6 text-center"><ImagePlus size={34} className="text-amber-300" /><p className="mt-3 font-myanmar text-[14px] font-black text-slate-700">{text.emptyTitle}</p><p className="mt-1 font-myanmar text-[11px] leading-5 text-slate-500">{text.emptyBody}</p></div>}
        </section>
      </main>

      {viewerImageUrl && <div className="fixed inset-0 z-[500] flex items-center justify-center bg-black/95 p-3" onClick={() => setViewerImageUrl(null)}><button onClick={() => setViewerImageUrl(null)} className="absolute right-4 top-4 rounded-full bg-white/15 p-2 text-white btn-press" aria-label="Close full screen image"><X size={22} /></button><button onClick={(event) => { event.stopPropagation(); saveImage(viewerImageUrl); }} className="absolute bottom-5 right-4 flex items-center gap-1.5 rounded-full bg-emerald-600 px-4 py-2 font-myanmar text-xs font-bold text-white"><Download size={15} />Save</button><img src={viewerImageUrl} alt={text.title} className="max-h-full max-w-full rounded-lg object-contain" onClick={(event) => event.stopPropagation()} /></div>}
    </div>
  );
}
