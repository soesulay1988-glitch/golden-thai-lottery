import { useState, useMemo, useCallback, useRef, useEffect } from "react";
import { useLang } from "@/contexts/LangContext";
import { ArrowLeft, Check, Search, Hash, Calendar, Copy, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { calendar3DMatrix, CALENDAR_YEARS, CALENDAR_ROWS } from "@/lib/calendar3DData";

type Tab = "grid" | "calendar3d";

export default function NumberGrid() {
  const { lang } = useLang();
  const mm = lang === "mm";
  const [tab, setTab] = useState<Tab>("grid");
  const [search, setSearch] = useState("");
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  // 3D Calendar state
  const [yearRange, setYearRange] = useState({ start: 1971, end: 2027 });
  const [yearStartDropdown, setYearStartDropdown] = useState(false);
  const [yearEndDropdown, setYearEndDropdown] = useState(false);
  const startDropdownRef = useRef<HTMLDivElement>(null);
  const endDropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (startDropdownRef.current && !startDropdownRef.current.contains(e.target as Node)) {
        setYearStartDropdown(false);
      }
      if (endDropdownRef.current && !endDropdownRef.current.contains(e.target as Node)) {
        setYearEndDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  // Generate all years 1971-2027
  const allYears = useMemo(() => {
    const years: number[] = [];
    for (let y = 1971; y <= 2027; y++) years.push(y);
    return years;
  }, []);

  // ─── 000-999 Grid ──────────────────────────────────────────────────
  const allNumbers = useMemo(() => {
    const nums: string[] = [];
    for (let i = 0; i < 1000; i++) {
      nums.push(String(i).padStart(3, "0"));
    }
    return nums;
  }, []);

  const filteredNumbers = useMemo(() => {
    if (!search.trim()) return allNumbers;
    const q = search.trim().replace(/\D/g, "");
    if (!q) return allNumbers;
    return allNumbers.filter(n => n.includes(q));
  }, [allNumbers, search]);

  const copyNumber = useCallback(async (num: string) => {
    try {
      await navigator.clipboard.writeText(num);
      setCopiedNumber(num);
      toast.success(mm ? `${num} ကော်ပီလုပ်ပြီးပါပြီ!` : `${num} copied!`);
      setTimeout(() => setCopiedNumber(null), 1500);
    } catch {
      toast.error(mm ? "ကော်ပီလုပ်၍မရပါ" : "Failed to copy");
    }
  }, [mm]);

  // Convert year to SE format (1971→69, 1972→70, ... 2025→25, 2026→26)
  const toSE = useCallback((year: number) => {
    return String(year % 100);
  }, []);

  // Copy entire 3D table — Lion Special format
  const copy3DTable = useCallback(async (startYear: number, endYear: number) => {
    try {
      const selectedYears = allYears.filter(y => y >= startYear && y <= endYear);
      let text = "";
      // Title line
      text += `LON SPECIAL THAI LOTTERY\n`;
      // SE header row with 2-digit years
      const seHeaders = selectedYears.map(y => toSE(y));
      text += `SE:\t${seHeaders.join("\t")}\n`;
      // Data rows
      for (const row of CALENDAR_ROWS) {
        const rowNums = selectedYears.map(y => {
          const raw = calendar3DMatrix[row]?.[y];
          return raw ? String(raw).padStart(3, "0") : "---";
        });
        text += `${row}\t${rowNums.join("\t")}\n`;
      }
      await navigator.clipboard.writeText(text);
      toast.success(mm ? `ဇယားကွက် ကော်ပီလုပ်ပြီးပါပြီ!` : `Table copied!`);
    } catch {
      toast.error(mm ? "ကော်ပီလုပ်၍မရပါ" : "Failed to copy");
    }
  }, [allYears, mm, toSE]);

  // ─── 3D Calendar Grid ──────────────────────────────────────────────
  const selectedYears = useMemo(() => {
    return allYears.filter(y => y >= yearRange.start && y <= yearRange.end);
  }, [allYears, yearRange]);

  return (
    <div className="min-h-screen bg-[#FFF8E1] pb-20">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#FFD700] shadow-md" style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}>
        <div className="flex items-center gap-3 px-4 py-3 max-w-[480px] mx-auto">
          <button onClick={() => window.history.back()} className="btn-press">
            <ArrowLeft size={20} className="text-[#333]" />
          </button>
          <div className="flex-1">
            <h1 className="text-base font-bold text-[#333] font-myanmar font-myanmar-display">
              {mm ? "ဂဏန်းဇယား" : "Number Grid"}
            </h1>
            <p className="text-[10px] text-[#555] font-myanmar">
              {mm ? "ဂဏန်းကို နှိပ်ပြီး ကော်ပီယူပါ" : "Tap a number to copy it"}
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-t border-amber-600/20">
          <button
            onClick={() => setTab("grid")}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-bold font-myanmar transition-all
              ${tab === "grid"
                ? "text-[#333] bg-white/30 border-b-2 border-[#333]"
                : "text-[#555] hover:bg-white/15"
              }`}
          >
            <Hash size={14} />
            {mm ? "၀၀၀-၉၉၉" : "000-999"}
          </button>
          <button
            onClick={() => setTab("calendar3d")}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-bold font-myanmar transition-all
              ${tab === "calendar3d"
                ? "text-[#333] bg-white/30 border-b-2 border-[#333]"
                : "text-[#555] hover:bg-white/15"
              }`}
          >
            <Calendar size={14} />
            {mm ? "၃ဒီ ပြကွက်" : "3D Calendar"}
          </button>
        </div>
      </header>

      <div className="max-w-[480px] mx-auto px-4 pt-4 space-y-3">

        {/* ─── TAB 1: 000-999 Grid ─────────────────────────────────── */}
        {tab === "grid" && (
          <>
            {/* Search Bar */}
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                inputMode="numeric"
                placeholder={mm ? "ဂဏန်း ရှာပါ (ဥပမာ: 123)" : "Search numbers (e.g., 123)"}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-gray-200 bg-white text-sm font-myanmar
                  focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all"
              />
            </div>

            {/* Results count */}
            <div className="flex items-center justify-between text-[10px] text-muted-foreground font-myanmar">
              <span>
                {mm ? `ပြနေသည်: ${filteredNumbers.length} ခု` : `Showing: ${filteredNumbers.length}`}
              </span>
              <span className="text-[9px]">
                {mm ? "ဂဏန်းကို နှိပ် → ကော်ပီ" : "Tap number → Copy to clipboard"}
              </span>
            </div>

            {/* Number Grid */}
            <div className="bg-white rounded-xl border border-amber-200 shadow-sm overflow-hidden">
              <div className="grid grid-cols-10 gap-[2px] p-1">
                {filteredNumbers.map((num) => {
                  const isCopied = copiedNumber === num;
                  return (
                    <button
                      key={num}
                      onClick={() => copyNumber(num)}
                      className={`relative flex items-center justify-center py-1.5 rounded-md text-[11px] font-mono font-bold
                        transition-all duration-200 btn-press
                        ${isCopied
                          ? "bg-green-500 text-white scale-110 z-10"
                          : num.startsWith(search.trim())
                            ? "bg-amber-100 text-amber-800 hover:bg-amber-200"
                            : "bg-gray-50 text-gray-700 hover:bg-amber-50 hover:text-amber-700"
                        }`}
                    >
                      {num}
                      {isCopied && (
                        <span className="absolute -top-1 -right-1 bg-green-500 rounded-full w-3 h-3 flex items-center justify-center">
                          <Check size={8} className="text-white" />
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quick copy buttons */}
            <div className="bg-white rounded-xl border border-amber-200 shadow-sm p-3 space-y-2">
              <p className="text-[11px] font-bold text-foreground font-myanmar font-myanmar-display">
                {mm ? "အမြန် ကော်ပီ" : "Quick Copy"}
              </p>
              <div className="flex flex-wrap gap-2">
                {["00", "11", "22", "33", "44", "55", "66", "77", "88", "99"].map(d => (
                  <button
                    key={d}
                    onClick={() => copyNumber(d + d)}
                    className="px-3 py-1.5 rounded-lg bg-amber-50 text-amber-700 text-xs font-mono font-bold
                      hover:bg-amber-100 transition-colors btn-press border border-amber-200"
                  >
                    {d}{d}{d}
                  </button>
                ))}
              </div>
              <p className="text-[9px] text-muted-foreground font-myanmar">
                {mm ? "ဥပမာ: 000, 111, 222, ..." : "e.g., 000, 111, 222, ..."}
              </p>
            </div>
          </>
        )}

        {/* ─── TAB 2: 3D Calendar Grid ─────────────────────────────── */}
        {tab === "calendar3d" && (
          <>
            {/* Year range selector */}
            <div className="flex gap-2">
              {/* Start year */}
              <div className="flex-1 relative" ref={startDropdownRef}>
                <button
                  onClick={() => { setYearStartDropdown(!yearStartDropdown); setYearEndDropdown(false); }}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-xl border border-amber-300 bg-white
                    text-sm font-mono font-bold text-amber-800 hover:bg-amber-50 transition-colors btn-press"
                >
                  <span className="flex items-center gap-1.5">
                    <Calendar size={12} />
                    {yearRange.start}
                  </span>
                  <ChevronDown size={14} className={`transition-transform ${yearStartDropdown ? "rotate-180" : ""}`} />
                </button>
                {yearStartDropdown && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl border border-amber-200 shadow-lg
                    max-h-[180px] overflow-y-auto z-30">
                    {allYears.map(year => (
                      <button
                        key={year}
                        onClick={() => {
                          if (year <= yearRange.end) {
                            setYearRange(prev => ({ ...prev, start: year }));
                          }
                          setYearStartDropdown(false);
                        }}
                        className={`w-full px-3 py-1.5 text-left text-sm font-mono hover:bg-amber-50 transition-colors
                          ${year === yearRange.start ? "bg-amber-100 text-amber-800 font-bold" : "text-gray-700"}`}
                      >
                        {year}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* To label */}
              <div className="flex items-center text-sm font-bold text-gray-500 px-1">—</div>

              {/* End year */}
              <div className="flex-1 relative" ref={endDropdownRef}>
                <button
                  onClick={() => { setYearEndDropdown(!yearEndDropdown); setYearStartDropdown(false); }}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-xl border border-amber-300 bg-white
                    text-sm font-mono font-bold text-amber-800 hover:bg-amber-50 transition-colors btn-press"
                >
                  <span className="flex items-center gap-1.5">
                    {yearRange.end}
                    <Calendar size={12} />
                  </span>
                  <ChevronDown size={14} className={`transition-transform ${yearEndDropdown ? "rotate-180" : ""}`} />
                </button>
                {yearEndDropdown && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl border border-amber-200 shadow-lg
                    max-h-[180px] overflow-y-auto z-30">
                    {allYears.map(year => (
                      <button
                        key={year}
                        onClick={() => {
                          if (year >= yearRange.start) {
                            setYearRange(prev => ({ ...prev, end: year }));
                          }
                          setYearEndDropdown(false);
                        }}
                        className={`w-full px-3 py-1.5 text-left text-sm font-mono hover:bg-amber-50 transition-colors
                          ${year === yearRange.end ? "bg-amber-100 text-amber-800 font-bold" : "text-gray-700"}`}
                      >
                        {year}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Copy all button */}
            <button
              onClick={() => copy3DTable(yearRange.start, yearRange.end)}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl
                bg-gradient-to-r from-amber-500 to-amber-600 text-white text-sm font-bold font-myanmar
                hover:from-amber-600 hover:to-amber-700 transition-all btn-press shadow-sm"
            >
              <Copy size={14} />
              {mm ? "ဇယားကွက် တစ်ခုလုံး ကော်ပီယူပါ" : "Copy Entire Table"}
            </button>

            {/* Info */}
            <div className="flex items-center justify-between text-[10px] text-muted-foreground font-myanmar">
              <span>
                {mm ? `${selectedYears.length} နှစ် • ${CALENDAR_ROWS.length} အတန်း` : `${selectedYears.length} years • ${CALENDAR_ROWS.length} rows`}
              </span>
              <span className="text-[9px]">
                {mm ? "ဂဏန်းကို နှိပ် → ကော်ပီ" : "Tap number → Copy"}
              </span>
            </div>

            {/* 3D Calendar Table — horizontal scrollable */}
            <div className="bg-white rounded-xl border border-amber-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto" style={{ WebkitOverflowScrolling: "touch" }}>
                <table className="w-full border-collapse" style={{ minWidth: `${56 + selectedYears.length * 56}px` }}>
                  <thead>
                    <tr className="bg-[#FFD700]">
                      <th
                        className="sticky left-0 z-10 bg-[#FFD700] px-2 py-2 text-center text-[10px] font-bold text-[#333] border-b-2 border-[#333] font-myanmar"
                        style={{ width: 40, minWidth: 40 }}
                      >
                        {mm ? "SE" : "SE"}
                      </th>
                      {selectedYears.map(year => (
                        <th
                          key={year}
                          className={`px-1 py-2 text-center text-[10px] font-bold border-b-2 border-[#333]
                            ${year === new Date().getFullYear()
                              ? "bg-amber-200 text-amber-700"
                              : "bg-[#FFD700] text-[#333]"
                            }`}
                          style={{ width: 52 }}
                        >
                          {toSE(year)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {CALENDAR_ROWS.map((row, rowIdx) => (
                      <tr
                        key={row}
                        className={rowIdx % 2 === 0 ? "bg-white" : "bg-gray-50"}
                      >
                        <td
                          className="sticky left-0 z-10 px-2 py-2 text-center text-[11px] font-bold text-[#333] border-b border-gray-200 font-mono"
                          style={{
                            backgroundColor: rowIdx % 2 === 0 ? "#fff" : "#f9f9f9",
                            width: 40,
                            minWidth: 40,
                          }}
                        >
                          {row}
                        </td>
                        {selectedYears.map(year => {
                          const raw = calendar3DMatrix[row]?.[year];
                          const num = raw ? String(raw).padStart(3, "0") : "---";
                          const isCurrentYear = year === new Date().getFullYear();
                          const isCopied = copiedNumber === `${row}-${year}`;
                          return (
                            <td
                              key={year}
                              className="border-b border-gray-200 text-center"
                              style={{ width: 52 }}
                            >
                              <button
                                onClick={() => {
                                  if (num !== "---") copyNumber(num);
                                }}
                                className={`w-full py-1.5 text-center text-[11px] font-mono font-bold
                                  transition-all duration-200 btn-press
                                  ${num === "---"
                                    ? "text-gray-300 cursor-default"
                                    : isCopied
                                      ? "bg-green-500 text-white rounded"
                                      : isCurrentYear
                                        ? "text-amber-700 hover:bg-amber-50"
                                        : "text-[#333] hover:bg-amber-50"
                                  }`}
                              >
                                {isCopied ? (
                                  <Check size={10} className="mx-auto" />
                                ) : (
                                  num
                                )}
                              </button>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Copy all button bottom */}
            <button
              onClick={() => copy3DTable(yearRange.start, yearRange.end)}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl
                bg-gradient-to-r from-amber-500 to-amber-600 text-white text-sm font-bold font-myanmar
                hover:from-amber-600 hover:to-amber-700 transition-all btn-press shadow-sm"
            >
              <Copy size={14} />
              {mm ? `ဇယားကွက် (${yearRange.start}-${yearRange.end}) ကော်ပီယူပါ` : `Copy Table (${yearRange.start}-${yearRange.end})`}
            </button>

            {/* Legend */}
            <div className="flex items-center justify-center gap-4 text-[9px] text-gray-500 font-myanmar">
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded bg-amber-200 border border-amber-400" />
                <span>{mm ? "ယခုနှစ်" : "Current Year"}</span>
              </div>
              <span>{mm ? "ဘယ်ညာ ပွတ်ဆွဲ၍ ကြည့်ပါ" : "Swipe left/right to browse"}</span>
            </div>
          </>
        )}

        {/* Info footer */}
        <div className="text-center py-4">
          <p className="text-[10px] text-muted-foreground font-myanmar">
            {mm ? "ဂဏန်းတိုင်းကို နှိပ်ရင် ကော်ပီယူလို့ ရပါတယ်" : "Tap any number to copy to clipboard"}
          </p>
        </div>
      </div>
    </div>
  );
}
