import { useRef, useEffect, useState, useMemo } from "react";
import { useLang } from "@/contexts/LangContext";
import { useLocation } from "wouter";
import { ArrowLeft, Info, Copy, Check } from "lucide-react";
import { toast } from "sonner";
import { calendar3DMatrix, CALENDAR_YEARS, CALENDAR_ROWS } from "@/lib/calendar3DData";
import { trpc } from "@/lib/trpc";
import { CALENDAR_2026_REFERENCE } from "@shared/calendar3dReference";

export default function Calendar3D() {
  const { lang } = useLang();
  const [, navigate] = useLocation();
  const scrollRef = useRef<HTMLDivElement>(null);

  // Fetch 2026 data from API. The static column is the verified reference
  // through the 15th draw, so a stale/old-format API response must not replace it.
  const { data: apiData2026 } = trpc.calendar3d.getYear.useQuery({ year: 2026 });

  const mergedMatrix = useMemo(() => {
    const apiHasVerifiedReferencePrefix = Object.entries(CALENDAR_2026_REFERENCE).every(
      ([row, value]) => apiData2026?.[row] === value,
    );

    if (apiData2026 && Object.keys(apiData2026).length > 0 && apiHasVerifiedReferencePrefix) {
      return {
        ...calendar3DMatrix,
        // Override the 2026 column only when the persisted sequence is aligned.
        ...Object.entries(apiData2026).reduce((acc, [row, value]) => {
          const existing = calendar3DMatrix[row] || {};
          return { ...acc, [row]: { ...existing, 2026: value } };
        }, {} as Record<string, Record<number, string>>),
      };
    }

    return calendar3DMatrix;
  }, [apiData2026]);


  // Copy individual cell
  const [copiedCell, setCopiedCell] = useState<string | null>(null);
  const handleCopyCell = (num: string) => {
    if (num === "---") return;
    navigator.clipboard.writeText(num);
    setCopiedCell(num);
    toast(lang === "mm" ? `${num} ကော်ပီပြီးပါပြီ` : `${num} copied!`, { duration: 1000 });
    setTimeout(() => setCopiedCell(null), 1500);
  };

  // Copy entire table in Lion Special format
  const [copying, setCopying] = useState(false);
  const handleCopyTable = () => {
    const seYears = CALENDAR_YEARS.map(y => {
      const val = (y + 2) % 100;
      return val < 10 ? `0${val}` : String(val);
    });
    
    let text = "LON SPECIAL THAI LOTTERY\n";
    text += "SE: " + seYears.join("\t") + "\n";
    
    for (const row of CALENDAR_ROWS) {
      let line = `${row}\t`;
      for (const year of CALENDAR_YEARS) {
        const rawNum = mergedMatrix[row]?.[year];
        line += (rawNum ? String(rawNum).padStart(3, "0") : "---") + "\t";
      }
      text += line.trim() + "\n";
    }
    
    navigator.clipboard.writeText(text);
    setCopying(true);
    toast(lang === "mm" ? "ဇယားကွက် ကော်ပီပြီးပါပြီ! Excel ကို Paste လုပ်ပါ။" : "Table copied! Paste into Excel.", { duration: 2500 });
    setTimeout(() => setCopying(false), 2000);
  };

  // Scroll to current year column on mount
  const currentYear = new Date().getFullYear();
  const currentYearIdx = CALENDAR_YEARS.indexOf(currentYear as any);

  useEffect(() => {
    if (scrollRef.current && currentYearIdx >= 0) {
      const cellWidth = 56;
      const rowHeaderWidth = 48;
      const targetScrollLeft = rowHeaderWidth + currentYearIdx * cellWidth - (scrollRef.current.clientWidth / 2) + cellWidth / 2;
      scrollRef.current.scrollLeft = Math.max(0, targetScrollLeft);
    }
  }, [currentYearIdx]);

  return (
    <div className="min-h-screen bg-[#f5f5f5] flex flex-col">
      {/* Yellow Header */}
      <header className="page-header bg-[#FFD700] flex-shrink-0">
        <div className="max-w-[480px] mx-auto flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate("/")} className="text-[#333] btn-press">
            <ArrowLeft size={20} />
          </button>
          <div className="flex-1">
            <h1 className="font-display text-sm font-bold text-[#333]">
              {lang === "mm" ? "၃ဒီ ပြက္ခဒိန် (၁၉၇၁-၂၀၂၆)" : "3D Calendar (1971-2026)"}
            </h1>
            <p className="text-[10px] text-[#666] font-myanmar flex items-center gap-1">
              <Info size={10} />
              {lang === "mm" ? "ဂဏန်းကိုနှိပ်ရင် ကော်ပီရမယ်။ ဘယ်ညာ ပွတ်ဆွဲ၍ ကြည့်ပါ" : "Tap number to copy. Swipe left/right to browse"}
            </p>
          </div>
          <button
            onClick={handleCopyTable}
            className="flex-shrink-0 flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-lg shadow-md text-xs font-bold transition-colors btn-press"
          >
            {copying ? <Check size={14} /> : <Copy size={14} />}
            <span className="font-myanmar text-[11px]">
              {lang === "mm" ? "ဇယားကော်ပီ" : "Copy Table"}
            </span>
          </button>
        </div>
      </header>

      {/* Table Container */}
      <div className="flex-1 overflow-hidden">
        <div
          ref={scrollRef}
          className="h-full overflow-auto"
          style={{ WebkitOverflowScrolling: "touch" }}
        >
          <table
            className="w-full border-collapse"
            style={{ minWidth: `${48 + CALENDAR_YEARS.length * 56}px` }}
          >
            <thead>
              <tr className="bg-[#FFD700]">
                <th
                  className="sticky top-0 left-0 z-20 bg-[#FFD700] px-2 py-2.5 text-center text-[11px] font-bold text-[#333] border-b-2 border-[#333] font-myanmar"
                  style={{ width: 48 }}
                >
                  {lang === "mm" ? "အစဉ်" : "No."}
                </th>
                {CALENDAR_YEARS.map((year) => {
                  const val = (year + 2) % 100;
                  const se = val < 10 ? `0${val}` : String(val);
                  return (
                    <th
                      key={year}
                      className={`px-1 py-1.5 text-center text-[9px] font-bold border-b-2 border-[#333] ${
                        year === currentYear
                          ? "bg-amber-200 text-amber-700"
                          : "bg-[#FFD700] text-[#333]"
                      }`}
                      style={{ width: 56 }}
                      title={lang === "mm" ? `SE: ${se}` : `SE: ${se}`}
                    >
                      <div>SE {se}</div>
                      <div className="text-[8px] opacity-70">{year}</div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {CALENDAR_ROWS.map((row, idx) => (
                <tr
                  key={row}
                  className={idx % 2 === 0 ? "bg-white" : "bg-gray-50"}
                >
                  <td
                    className="sticky left-0 z-10 px-2 py-2 text-center text-[11px] font-bold text-[#333] border-b border-gray-200 font-myanmar"
                    style={{
                      width: 48,
                      backgroundColor: idx % 2 === 0 ? "#fff" : "#f9f9f9",
                    }}
                  >
                    {row}
                  </td>
                  {CALENDAR_YEARS.map((year) => {
                    const rawNum = mergedMatrix[row]?.[year];
                    const num = rawNum ? String(rawNum).padStart(3, "0") : "---";
                    const isCurrent = year === currentYear;
                    return (
                      <td
                        key={year}
                        className={`px-1 py-2 text-center text-[12px] border-b border-gray-200 font-mono cursor-pointer select-none ${
                          isCurrent
                            ? "bg-amber-50 text-amber-700 font-bold"
                            : num === "---"
                            ? "text-gray-300"
                            : "text-[#333] hover:bg-amber-100"
                        }`}
                        style={{ width: 56 }}
                        onClick={() => handleCopyCell(num)}
                      >
                        {copiedCell === num ? <Check size={12} className="mx-auto text-green-600" /> : num}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Legend */}
      <div className="flex-shrink-0 bg-white border-t border-gray-200 px-4 py-2">
        <div className="max-w-[480px] mx-auto flex items-center justify-between text-[10px] text-gray-500">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-amber-200 border border-amber-400" />
              <span>{lang === "mm" ? "ယခုနှစ်" : "Current Year"}</span>
            </div>
            <span className="font-myanmar">
              {lang === "mm" ? "စုစုပေါင်း ၅၆ နှစ် × ၂၄ အတန်း" : "56 years × 24 rows"}
            </span>
          </div>
          <span className="text-[9px] text-gray-400 font-myanmar">
            {lang === "mm" ? "ဂဏန်းကိုနှိပ် → ကော်ပီ" : "Tap number → copy"}
          </span>
        </div>
      </div>
    </div>
  );
}
