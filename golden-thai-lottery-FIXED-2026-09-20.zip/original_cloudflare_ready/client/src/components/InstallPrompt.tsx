import { useState, useEffect, useRef } from "react";
import { useLang } from "@/contexts/LangContext";
import { Download, Smartphone, Bell, Zap, X } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export default function InstallPrompt() {
  const { t } = useLang();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showBanner, setShowBanner] = useState(false);
  const [visible, setVisible] = useState(false);
  const [shakeBtn, setShakeBtn] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const [dismissed, setDismissed] = useState(() => {
    return sessionStorage.getItem("install-prompt-dismissed") === "true";
  });

  useEffect(() => {
    if (dismissed) return;

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setTimeout(() => {
        setShowBanner(true);
        // Trigger entrance animation after render
        requestAnimationFrame(() => {
          setVisible(true);
          // Shake the install button after entrance
          setTimeout(() => setShakeBtn(true), 1500);
        });
      }, 2500);
    };

    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, [dismissed]);

  // Check if already installed
  useEffect(() => {
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone ||
      document.referrer.includes("android-app://");

    if (isStandalone) {
      setShowBanner(false);
      return;
    }
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;

    if (outcome === "accepted") {
      setVisible(false);
      setTimeout(() => {
        setShowBanner(false);
        setDeferredPrompt(null);
      }, 300);
    } else {
      setVisible(false);
      setTimeout(() => setShowBanner(false), 300);
    }
  };

  const handleDismiss = () => {
    setVisible(false);
    setTimeout(() => {
      setShowBanner(false);
      setDismissed(true);
      sessionStorage.setItem("install-prompt-dismissed", "true");
    }, 300);
  };

  if (!showBanner || !deferredPrompt) return null;

  return (
    <div className="fixed inset-0 z-[300] flex items-end justify-center px-3 pb-4">
      {/* Animated backdrop */}
      <div
        className={`absolute inset-0 bg-black/50 backdrop-blur-[2px] transition-opacity duration-300 ${
          visible ? "opacity-100" : "opacity-0"
        }`}
        onClick={handleDismiss}
      />

      {/* Main Card */}
      <div
        ref={cardRef}
        className={`relative w-full max-w-[380px] rounded-[20px] shadow-[0_-4px_40px_rgba(0,0,0,0.3)] overflow-hidden transition-all duration-400 ease-[cubic-bezier(0.23,1,0.32,1)] ${
          visible
            ? "translate-y-0 opacity-100"
            : "translate-y-[120%] opacity-0"
        }`}
      >
        {/* Gradient header */}
        <div className="bg-gradient-to-br from-amber-500 via-amber-600 to-orange-600 px-5 pt-6 pb-8 relative overflow-hidden">
          {/* Decorative circles */}
          <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white/10" />
          <div className="absolute -bottom-12 -left-6 w-24 h-24 rounded-full bg-white/5" />
          <div className="absolute top-4 right-12 w-16 h-16 rounded-full bg-yellow-300/20" />

          {/* Close button */}
          <button
            onClick={handleDismiss}
            className="absolute top-3 right-3 w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-all duration-200 active:scale-90"
          >
            <X size={14} className="text-white" />
          </button>

          {/* App icon + title */}
          <div className="relative flex items-start gap-4">
            {/* Animated icon container */}
            <div className="relative shrink-0">
              <div className="w-[62px] h-[62px] rounded-[16px] bg-white/20 backdrop-blur-sm flex items-center justify-center shadow-lg border border-white/20">
                <svg viewBox="0 0 64 64" className="w-10 h-10 drop-shadow-md">
                  <path
                    d="M32 6 L39 24 L58 24 L43 35 L48 54 L32 43 L16 54 L21 35 L6 24 L25 24 Z"
                    fill="#FFD700"
                    stroke="#FFA000"
                    strokeWidth="0.5"
                  />
                </svg>
              </div>
              {/* Badge */}
              <div className="absolute -top-1.5 -right-1.5 bg-emerald-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-md border border-white/40">
                {t("installBadge")}
              </div>
            </div>

            <div className="flex-1 pt-0.5">
              <h3 className="text-white font-bold text-[17px] leading-tight tracking-wide">
                {t("installApp")}
              </h3>
              <p className="text-amber-100 text-[12px] mt-1 leading-relaxed">
                {t("installDesc")}
              </p>
            </div>
          </div>
        </div>

        {/* Features section */}
        <div className="bg-white px-5 py-4">
          <div className="space-y-2.5">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center shrink-0">
                <Zap size={15} className="text-amber-600" />
              </div>
              <span className="text-[13px] text-gray-700 font-medium">{t("installFeature1")}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center shrink-0">
                <Bell size={15} className="text-amber-600" />
              </div>
              <span className="text-[13px] text-gray-700 font-medium">{t("installFeature2")}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center shrink-0">
                <Smartphone size={15} className="text-amber-600" />
              </div>
              <span className="text-[13px] text-gray-700 font-medium">{t("installFeature3")}</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3 mt-5">
            <button
              onClick={handleInstall}
              className={`flex-1 flex items-center justify-center gap-2.5 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-bold text-[15px] py-3.5 rounded-[14px] shadow-[0_4px_15px_rgba(217,119,6,0.4)] hover:from-amber-600 hover:to-amber-700 hover:shadow-[0_6px_20px_rgba(217,119,6,0.5)] active:scale-[0.97] transition-all duration-200 ${
                shakeBtn ? "animate-[bounce_0.6s_ease-in-out_2]" : ""
              }`}
            >
              <Download size={18} strokeWidth={2.5} />
              {t("installApp")}
            </button>
            <button
              onClick={handleDismiss}
              className="px-4 py-3.5 text-[13px] text-gray-400 font-medium hover:text-gray-600 hover:bg-gray-50 rounded-[14px] transition-all duration-200 active:scale-95"
            >
              {t("installLater")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
