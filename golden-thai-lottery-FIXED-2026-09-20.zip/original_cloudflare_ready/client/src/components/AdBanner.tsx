import { useEffect, useRef } from "react";

// Google AdSense configuration
// Replace with your actual AdSense publisher ID when approved
const ADSENSE_PUBLISHER_ID = "pub-XXXXXXXXXXXXXXXX"; // Replace when approved
const ADSENSE_ENABLED = false; // Set to true when AdSense account is approved

interface AdBannerProps {
  format?: "horizontal" | "vertical" | "rectangle";
  className?: string;
}

declare global {
  interface Window {
    adsbygoogle?: any[];
  }
}

export default function AdBanner({ format = "horizontal", className = "" }: AdBannerProps) {
  const adRef = useRef<HTMLDivElement>(null);
  const initializedRef = useRef(false);

  useEffect(() => {
    if (!ADSENSE_ENABLED || initializedRef.current) return;

    try {
      if (window.adsbygoogle) {
        window.adsbygoogle.push({});
        initializedRef.current = true;
      }
    } catch (e) {
      console.warn("[AdSense] Push failed:", e);
    }
  }, []);

  const slotSizes: Record<string, { w: string; h: string; style: React.CSSProperties }> = {
    horizontal: {
      w: "728px",
      h: "90px",
      style: { minHeight: 90 },
    },
    rectangle: {
      w: "336px",
      h: "280px",
      style: { minHeight: 280 },
    },
    vertical: {
      w: "160px",
      h: "600px",
      style: { minHeight: 600 },
    },
  };

  const { w, h, style: slotStyle } = slotSizes[format];

  if (!ADSENSE_ENABLED) {
    // Show a subtle placeholder when AdSense is not enabled
    return (
      <div className={`my-2 px-2 ${className}`}>
        <div
          className="w-full rounded-xl border border-dashed border-gray-200 bg-gray-50/50 flex items-center justify-center"
          style={slotStyle}
        >
          <span className="text-xs text-gray-300 font-myanmar">
            ကြော်ငြာ နေရာ
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className={`my-2 px-2 ${className}`}>
      <div ref={adRef} className="w-full overflow-hidden">
        <ins
          className="adsbygoogle"
          style={{ display: "block", ...slotStyle }}
          data-ad-client={`ca-${ADSENSE_PUBLISHER_ID}`}
          data-ad-slot=""
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
      </div>
    </div>
  );
}
