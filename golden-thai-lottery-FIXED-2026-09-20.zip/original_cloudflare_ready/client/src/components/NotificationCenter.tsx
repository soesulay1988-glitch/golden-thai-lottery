import { useState, useEffect } from "react";
import { Bell, X, CheckCheck, Gift, BellRing, BellOff } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { subscribeToPush, unsubscribeFromPush, isSubscribed } from "@/lib/pushNotifications";

export default function NotificationCenter() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [pushSubscribed, setPushSubscribed] = useState(false);

  // Check push subscription status when user is logged in
  useEffect(() => {
    if (user) {
      isSubscribed().then(setPushSubscribed).catch(() => {});
    }
  }, [user, open]);

  const utils = trpc.useUtils();
  const { data: unreadData } = trpc.notifications.unreadCount.useQuery(undefined, {
    enabled: !!user,
    refetchInterval: 60_000,
  });
  const { data: notifications, isLoading } = trpc.notifications.list.useQuery(undefined, {
    enabled: !!user && open,
  });

  const markRead = trpc.notifications.markRead.useMutation({
    onSuccess: () => {
      utils.notifications.unreadCount.invalidate();
      utils.notifications.list.invalidate();
    },
  });
  const markAllRead = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => {
      utils.notifications.unreadCount.invalidate();
      utils.notifications.list.invalidate();
      toast.success("အားလုံး ဖတ်ပြီးသတ်မှတ်ပြီးပါပြီ");
    },
  });

  if (!user) return null;

  const unread = unreadData ?? 0;

  return (
    <>
      {/* Bell button */}
      <button
        onClick={() => setOpen(true)}
        className="relative p-2 rounded-full hover:bg-amber-50 transition-colors"
        aria-label="Notifications"
      >
        <Bell size={22} className="text-amber-700" strokeWidth={1.8} />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1 animate-pulse">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {/* Overlay */}
      {open && (
        <div className="fixed inset-0 z-[300] flex flex-col" style={{ background: "rgba(0,0,0,0.4)" }}>
          {/* Panel */}
          <div
            className="absolute top-0 right-0 bottom-0 w-full max-w-sm bg-white flex flex-col shadow-2xl"
            style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-amber-100 bg-gradient-to-r from-amber-50 to-yellow-50">
              <div className="flex items-center gap-2">
                <Bell size={18} className="text-amber-600" />
                <span className="font-bold text-amber-800 font-myanmar text-base">Notifications</span>
                {unread > 0 && (
                  <span className="bg-red-500 text-white text-[10px] font-bold rounded-full px-1.5 py-0.5">
                    {unread}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                  {unread > 0 && (
                  <button
                    onClick={() => markAllRead.mutate()}
                    className="text-xs text-amber-600 hover:text-amber-800 flex items-center gap-1 font-myanmar"
                  >
                    <CheckCheck size={14} />
                    အားလုံးဖတ်မည်
                  </button>
                )}
                {/* Push notification toggle */}
                {"serviceWorker" in navigator && "PushManager" in window && (
                  <button
                    onClick={async () => {
                      if (pushSubscribed) {
                        const res = await unsubscribeFromPush();
                        if (res.success) {
                          setPushSubscribed(false);
                          toast.success("Push notification ဖျက်ပြီးပါပြီ");
                        }
                      } else {
                        const res = await subscribeToPush();
                        if (res.success) {
                          setPushSubscribed(true);
                          toast.success("Push notification enable လုပ်ပြီးပါပြီ!");
                        } else {
                          toast.error("Push notification enable လုပ်၍ မရပါ");
                        }
                      }
                    }}
                    className="p-1 rounded-full hover:bg-amber-100"
                    title={pushSubscribed ? "Disable push notifications" : "Enable push notifications"}
                  >
                    {pushSubscribed ? (
                      <BellRing size={18} className="text-green-600" />
                    ) : (
                      <BellOff size={18} className="text-gray-400" />
                    )}
                  </button>
                )}
                <button onClick={() => setOpen(false)} className="p-1 rounded-full hover:bg-amber-100">
                  <X size={18} className="text-amber-700" />
                </button>
              </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto">
              {isLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="w-6 h-6 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                </div>
              ) : !notifications || notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-40 gap-3 text-muted-foreground">
                  <Bell size={32} strokeWidth={1.2} className="opacity-30" />
                  <p className="text-sm font-myanmar">Notification မရှိသေးပါ</p>
                </div>
              ) : (
                <ul className="divide-y divide-amber-50">
                  {notifications.map((n) => (
                    <li
                      key={n.id}
                      className={`px-4 py-3 flex gap-3 cursor-pointer transition-colors hover:bg-amber-50 ${
                        !n.isRead ? "bg-amber-50/60" : ""
                      }`}
                      onClick={() => {
                        if (!n.isRead) markRead.mutate({ id: n.id });
                      }}
                    >
                      <div className="flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center shadow-sm">
                        <Gift size={16} className="text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-myanmar leading-snug ${!n.isRead ? "font-semibold text-amber-900" : "text-foreground"}`}>
                          {n.title}
                        </p>
                        <p className="text-xs text-muted-foreground font-myanmar mt-0.5 leading-relaxed">
                          {n.body}
                        </p>
                        {n.luckyNumber && (
                          <div className="mt-1.5 inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-100 to-yellow-100 border border-amber-200 rounded-lg px-2.5 py-1">
                            <span className="text-amber-600 text-xs font-myanmar">Lucky 3D:</span>
                            <span className="text-amber-800 font-bold text-base tracking-widest">{n.luckyNumber}</span>
                          </div>
                        )}
                        <p className="text-[10px] text-muted-foreground/60 mt-1">
                          {new Date(n.createdAt).toLocaleString("my-MM", { dateStyle: "medium", timeStyle: "short" })}
                        </p>
                      </div>
                      {!n.isRead && (
                        <div className="flex-shrink-0 w-2 h-2 rounded-full bg-amber-500 mt-1.5" />
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
          {/* Tap outside to close */}
          <div className="flex-1" onClick={() => setOpen(false)} />
        </div>
      )}
    </>
  );
}
