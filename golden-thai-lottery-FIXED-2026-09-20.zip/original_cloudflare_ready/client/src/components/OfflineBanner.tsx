import { useLang } from "@/contexts/LangContext";
import { WifiOff, RefreshCw } from "lucide-react";
import { useNetworkStatus } from "@/hooks/useNetworkStatus";

export default function OfflineBanner() {
  const { isOnline } = useNetworkStatus();
  const { lang } = useLang();
  const mm = lang === "mm";

  if (isOnline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[300] bg-red-500 text-white px-4 py-2.5 flex items-center justify-center gap-2 shadow-lg">
      <WifiOff size={16} />
      <span className="text-xs font-semibold font-myanmar">
        {mm ? "အင်တာနက် ချိတ်ဆက်မှု မရှိပါ — ပြန်ကြိုးစားပါ" : "No internet connection — Tap to retry"}
      </span>
      <button
        onClick={() => window.location.reload()}
        className="ml-2 bg-white/20 rounded-lg px-2.5 py-1 text-[10px] font-bold flex items-center gap-1 transition-all btn-press"
      >
        <RefreshCw size={10} />
        {mm ? "ပြန်ကြိုးစား" : "Retry"}
      </button>
    </div>
  );
}
