import { describe, expect, it } from "vitest";

import { CALENDAR_2026_REFERENCE } from "@shared/calendar3dReference";
import { calendar3DMatrix } from "./calendar3DData";

describe("2026 3D calendar reference", () => {
  it("matches the screenshot-verified rows 01-15", () => {
    for (const [row, value] of Object.entries(CALENDAR_2026_REFERENCE)) {
      expect(calendar3DMatrix[row]?.[2026], `row ${row}`).toBe(value);
    }
  });

  it("keeps every reference result as a three-character string", () => {
    for (const value of Object.values(CALENDAR_2026_REFERENCE)) {
      expect(value).toMatch(/^\d{3}$/);
    }
  });
});
