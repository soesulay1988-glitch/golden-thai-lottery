export type Calendar3DDrawTarget = {
  isoDate: string;
  day: 1 | 16;
  month: number;
  year: number;
};

function thailandDateParts(now: Date): { year: number; month: number; day: number } {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Bangkok",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);

  const valueOf = (type: Intl.DateTimeFormatPartTypes) => Number(parts.find((part) => part.type === type)?.value ?? "0");
  return { year: valueOf("year"), month: valueOf("month"), day: valueOf("day") };
}

/**
 * Thai Government Lottery follows the regular 1st/16th draw cadence.  This
 * returns the next scheduled draw date in Thailand time so the analysis card
 * does not keep a fixed month or year.
 */
export function getNextThaiLotteryDrawTarget(now = new Date()): Calendar3DDrawTarget {
  const { year, month, day } = thailandDateParts(now);

  if (day < 16) {
    return { isoDate: `${year}-${String(month).padStart(2, "0")}-16`, day: 16, month, year };
  }

  const nextMonth = month === 12 ? 1 : month + 1;
  const nextYear = month === 12 ? year + 1 : year;
  return { isoDate: `${nextYear}-${String(nextMonth).padStart(2, "0")}-01`, day: 1, month: nextMonth, year: nextYear };
}

export function formatCalendar3DDrawTarget(target: Calendar3DDrawTarget): string {
  return `${String(target.day).padStart(2, "0")}-${String(target.month).padStart(2, "0")}-${target.year}`;
}
