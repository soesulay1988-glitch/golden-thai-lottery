import { describe, expect, it } from "vitest";
import { canShowMyanmarMarketBoard, getCurrentDayLiveMarket, getCurrentDayVerifiedMarketResult, getMyanmarDateKey, getMyanmarMarketSession, getThaiLotteryThreeDigit } from "./twoDMarket";

describe("Myanmar 2D market display rules", () => {
  it("shows live market data in the Myanmar morning trading window", () => {
    const now = new Date("2026-09-07T03:00:00.000Z"); // 09:30 Myanmar, Monday
    expect(getMyanmarMarketSession(now)).toBe("morning");
    expect(getMyanmarDateKey(now)).toBe("2026-09-07");
  });

  it("clears the market display at Myanmar midnight and throughout weekends", () => {
    const midnight = new Date("2026-09-07T17:30:00.000Z"); // 00:00 Myanmar, Monday
    const weekend = new Date("2026-09-05T03:00:00.000Z"); // 09:30 Myanmar, Saturday
    expect(getMyanmarMarketSession(midnight)).toBeNull();
    expect(getMyanmarMarketSession(weekend)).toBeNull();
    expect(getCurrentDayLiveMarket({ time: "2026-09-07 09:30:00", set: "1,580.67" }, midnight)).toBeNull();
  });

  it("accepts only current-day live values and uses the final three first-prize digits for 3D", () => {
    const now = new Date("2026-09-07T03:00:00.000Z");
    expect(getCurrentDayLiveMarket({ time: "2026-09-07 09:30:00", set: "1,580.67" }, now)?.set).toBe("1,580.67");
    expect(getCurrentDayLiveMarket({ time: "2026-09-06 09:30:00", set: "1,579.00" }, now)).toBeNull();
    expect(getThaiLotteryThreeDigit("004615")).toBe("615");
    expect(getThaiLotteryThreeDigit("615")).toBe("---");
  });

  it("keeps the verified 12:01 provider result visible during the afternoon break", () => {
    const providerRows = [
      { session: "morning" as const, stockDate: "2026-09-04", time: "12:01:00", set: "1,588.82", value: "35,776.44", twod: "26" },
      { session: "evening" as const, stockDate: "2026-09-04", time: "16:30:00", set: "--", value: "--", twod: "--" },
    ];
    const afternoonBreak = new Date("2026-09-04T06:33:00.000Z"); // 13:03 Myanmar, Friday

    expect(getMyanmarMarketSession(afternoonBreak)).toBeNull();
    expect(getCurrentDayVerifiedMarketResult(providerRows, "morning", afternoonBreak)?.twod).toBe("26");
    expect(getCurrentDayVerifiedMarketResult(providerRows, "evening", afternoonBreak)).toBeNull();
  });

  it("keeps settled provider market values through Myanmar midnight, then clears them", () => {
    const providerRows = [
      { session: "morning" as const, stock_date: "2026-09-04", set: "1,588.82", value: "35,776.44", twod: "26" },
    ];
    const afterClose = new Date("2026-09-04T10:30:00.000Z"); // 17:00 Myanmar, Friday
    const midnightSaturday = new Date("2026-09-04T17:30:00.000Z"); // 00:00 Myanmar, Saturday

    expect(canShowMyanmarMarketBoard(afterClose)).toBe(true);
    expect(getCurrentDayVerifiedMarketResult(providerRows, "morning", afterClose)?.twod).toBe("26");
    expect(canShowMyanmarMarketBoard(midnightSaturday)).toBe(false);
    expect(getCurrentDayVerifiedMarketResult(providerRows, "morning", midnightSaturday)).toBeNull();
  });
});
