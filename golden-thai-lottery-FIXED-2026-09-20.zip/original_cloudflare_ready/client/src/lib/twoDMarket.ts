export type MarketSession = "morning" | "evening" | null;

export type ProviderMarketResult = {
  session?: MarketSession;
  stockDate?: string;
  stock_date?: string;
  date?: string;
  time?: string;
  open_time?: string;
  set?: string;
  value?: string;
  twod?: string;
};

function getMyanmarClock(now: Date): Date {
  return new Date(now.getTime() + 6.5 * 60 * 60 * 1000);
}

export function getMyanmarDateKey(now = new Date()): string {
  return getMyanmarClock(now).toISOString().slice(0, 10);
}

/** Shows live market values only during the Thai market windows on Myanmar weekdays. */
export function getMyanmarMarketSession(now = new Date()): MarketSession {
  const local = getMyanmarClock(now);
  const day = local.getUTCDay();
  const minutes = local.getUTCHours() * 60 + local.getUTCMinutes();
  if (day === 0 || day === 6) return null;
  if (minutes >= 9 * 60 && minutes < 12 * 60 + 30) return "morning";
  if (minutes >= 13 * 60 + 30 && minutes < 17 * 60) return "evening";
  return null;
}

/** Keeps same-day market figures visible until the next Myanmar date begins. */
export function canShowMyanmarMarketBoard(now = new Date()): boolean {
  const local = getMyanmarClock(now);
  const day = local.getUTCDay();
  return day !== 0 && day !== 6;
}

export function getCurrentDayLiveMarket<T extends { time?: string }>(live: T | null | undefined, now = new Date()): T | null {
  if (!live?.time || !canShowMyanmarMarketBoard(now)) return null;
  const liveDate = String(live.time).slice(0, 10);
  return liveDate === getMyanmarDateKey(now) ? live : null;
}

/**
 * Returns a verified provider result for its settled 12:01/16:30 session.
 * Unlike the active market session indicator, it remains visible until
 * Myanmar midnight so the same-day figures do not disappear after close.
 */
export function getCurrentDayVerifiedMarketResult<T extends ProviderMarketResult>(
  results: readonly T[] | null | undefined,
  session: Exclude<MarketSession, null>,
  now = new Date(),
): T | null {
  if (!canShowMyanmarMarketBoard(now)) return null;

  const local = getMyanmarClock(now);
  const minutes = local.getUTCHours() * 60 + local.getUTCMinutes();
  const settledAt = session === "morning" ? 12 * 60 + 1 : 16 * 60 + 30;
  if (minutes < settledAt) return null;

  const today = getMyanmarDateKey(now);
  return results?.find((result) => {
    const rowDate = String(result.stockDate || result.stock_date || result.date || "").slice(0, 10);
    const twoD = String(result.twod || "").trim();
    const set = String(result.set || "").trim();
    const value = String(result.value || "").trim();
    return result.session === session
      && rowDate === today
      && /^\d{1,2}$/.test(twoD)
      && set !== "--"
      && value !== "--";
  }) ?? null;
}

export function getThaiLotteryThreeDigit(firstPrize: string | null | undefined): string {
  const number = String(firstPrize || "").trim();
  return /^\d{6}$/.test(number) ? number.slice(-3) : "---";
}
