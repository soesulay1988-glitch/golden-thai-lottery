import { describe, expect, it } from "vitest";
import { FALLBACK_THAI_DRAW_2026_09_01, withThaiLotteryFallback } from "./thaiLotteryFallback";

describe("September 1 Thai lottery fallback", () => {
  it("contains every 4th and 5th prize number", () => {
    expect(FALLBACK_THAI_DRAW_2026_09_01.fourthPrize).toHaveLength(50);
    expect(FALLBACK_THAI_DRAW_2026_09_01.fifthPrize).toHaveLength(100);
  });

  it("repairs incomplete database rows without overwriting other draw data", () => {
    const draw = withThaiLotteryFallback({
      drawDate: "2026-09-01",
      firstPrize: "417212",
      fourthPrize: [],
      fifthPrize: null,
      source: "database",
    });

    expect(draw.fourthPrize).toHaveLength(50);
    expect(draw.fifthPrize).toHaveLength(100);
    expect(draw.source).toBe("database");
  });
});
