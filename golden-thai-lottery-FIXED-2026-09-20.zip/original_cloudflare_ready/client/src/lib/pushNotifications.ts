/**
 * Client-side Web Push Notification utilities
 * Uses fetch API directly for mutations (trpc hooks require React context)
 */

const VAPID_PUBLIC_KEY_STORAGE = "vapid_public_key";
const PUSH_VISITOR_ID_STORAGE = "golden_thai_push_visitor_id";

function getPushVisitorId(): string {
  try {
    const existing = localStorage.getItem(PUSH_VISITOR_ID_STORAGE);
    if (existing) return existing;
    const created = typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `device-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    localStorage.setItem(PUSH_VISITOR_ID_STORAGE, created);
    return created;
  } catch {
    return `device-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

/**
 * Call a tRPC procedure via fetch
 */
async function callTrpcMutation(path: string, input: Record<string, unknown>) {
  const res = await fetch(`/api/trpc/${path}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      json: input,
      meta: { values: [path.split(".").pop(), 0, "undefined"] },
    }),
    credentials: "include",
  });
  if (!res.ok) {
    throw new Error(`tRPC call to ${path} failed: ${res.status}`);
  }
  return res.json();
}

async function callTrpcQuery(path: string) {
  const res = await fetch(`/api/trpc/${path}`, {
    method: "GET",
    credentials: "include",
  });
  if (!res.ok) {
    throw new Error(`tRPC call to ${path} failed: ${res.status}`);
  }
  return res.json();
}

/**
 * Get VAPID public key from server
 */
async function getPublicKey(): Promise<string | null> {
  try {
    const data = await callTrpcQuery("push.getPublicKey");
    return data.result?.data?.publicKey ?? null;
  } catch (err) {
    console.error("[PushNotif] Failed to get public key:", err);
    return null;
  }
}

/**
 * Register service worker
 */
export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!("serviceWorker" in navigator)) {
    console.log("[PushNotif] Service workers not supported");
    return null;
  }

  if (!("PushManager" in window)) {
    console.log("[PushNotif] Push notifications not supported");
    return null;
  }

  try {
    const registration = await navigator.serviceWorker.register("/sw.js");
    console.log("[PushNotif] Service worker registered");
    return registration;
  } catch (err) {
    console.error("[PushNotif] Service worker registration failed:", err);
    return null;
  }
}

/**
 * Check if notifications are already subscribed
 */
export async function isSubscribed(): Promise<boolean> {
  if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
    return false;
  }

  const registration = await navigator.serviceWorker.ready;
  const subscription = await registration.pushManager.getSubscription();
  return !!subscription;
}

/**
 * Subscribe to push notifications
 */
export async function subscribeToPush(): Promise<{ success: boolean }> {
  try {
    if (!("Notification" in window)) return { success: false };

    // Permission must be requested immediately inside a button press. Browsers
    // suppress it when it is delayed behind asynchronous work.
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      console.log("[PushNotif] Notification permission denied");
      return { success: false };
    }

    // Register SW
    const registration = await registerServiceWorker();
    if (!registration) return { success: false };

    // Get VAPID key
    const publicKey = await getPublicKey();
    if (!publicKey) return { success: false };

    // Subscribe
    const applicationServerKey = urlBase64ToUint8Array(publicKey) as unknown as ArrayBuffer;
    const subscription = (await registration.pushManager.getSubscription()) ??
      await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey,
      });

    // Send subscription to server
    const { endpoint, keys } = subscription.toJSON();
    if (endpoint && keys?.p256dh && keys?.auth) {
      await callTrpcMutation("push.subscribe", {
        endpoint,
        p256dh: keys.p256dh,
        auth: keys.auth,
        visitorId: getPushVisitorId(),
      });
      console.log("[PushNotif] Subscribed successfully");
      return { success: true };
    }

    return { success: false };
  } catch (err) {
    console.error("[PushNotif] Subscribe failed:", err);
    return { success: false };
  }
}

/**
 * Unsubscribe from push notifications
 */
export async function unsubscribeFromPush(): Promise<{ success: boolean }> {
  try {
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();

    if (subscription) {
      await subscription.unsubscribe();
      const endpoint = subscription.endpoint;
      await callTrpcMutation("push.unsubscribe", { endpoint });
      console.log("[PushNotif] Unsubscribed successfully");
    }
    return { success: true };
  } catch (err) {
    console.error("[PushNotif] Unsubscribe failed:", err);
    return { success: false };
  }
}

/**
 * Initialize push notifications on app load
 */
export async function initializePushNotifications(): Promise<void> {
  await registerServiceWorker();
}
