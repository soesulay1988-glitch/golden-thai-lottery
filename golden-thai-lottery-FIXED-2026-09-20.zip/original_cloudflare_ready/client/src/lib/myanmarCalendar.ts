/**
 * Myanmar Calendar Conversion
 * Converts Gregorian dates to Myanmar Calendar dates
 * Myanmar Calendar year = Gregorian year + 544
 * Myanmar months: တော်သလင်း, ဝါခေါင်, တန်ဆောင်မုန်း, နတ်တော်, ပြာသို, တပို့တွဲ, တပေါင်း, တန်ခူး, ကဆုန်, နယုန်, ဝဆို, ဝါတွင်း
 */

const MYANMAR_MONTHS = [
  "တော်သလင်း", "ဝါခေါင်", "တန်ဆောင်မုန်း", "နတ်တော်",
  "ပြာသို", "တပို့တွဲ", "တပေါင်း", "တန်ခူး",
  "ကဆုန်", "နယုန်", "ဝဆို", "ဝါတွင်း"
];

const MYANMAR_MONTHS_EN = [
  "Tagu", "Kason", "Nayon", "Waso",
  "Wagaung", "Tawthalin", "Thadingyut", "Tazaungmon",
  "Nadaw", "Pyatho", "Tabodwe", "Tabaung"
];

// Myanmar year calculation
// Myanmar Era started in 638 AD (April 22, 638)
// Myanmar Year = Gregorian Year - 638 (if after Thingyan in April, it's the new Myanmar year)
// Myanmar New Year ~ mid-April (Thingyan)
export function gregorianToMyanmarYear(gregorianYear: number, gregorianMonth: number): number {
  // Myanmar New Year ~ April 17 (Thingyan)
  // If month >= May, it's the new Myanmar year
  // If month === April, we check if after April 17
  if (gregorianMonth >= 5) {
    return gregorianYear - 638;
  } else if (gregorianMonth === 4) {
    // April: after Thingyan (April 17) it's the new year
    return gregorianYear - 638;
  }
  return gregorianYear - 639;
}

export function getMyanmarYearInfo(year: number): {
  myanmarYear: number;
  myanmarYearDisplay: string;
  cycle: string;
  cycleMm: string;
} {
  // 12-year zodiac cycle (similar to Chinese zodiac but with Myanmar animals)
  const ZODIAC_CYCLE_MM = [
    "ကြွက်", "နွား", "ကျား", "ယုန်", "နဂါး", "မြွေ",
    "မြင်း", "ဆိတ်", "မျောက်", "ကြက်", "ခွေး", "ဝက်"
  ];
  const ZODIAC_CYCLE_EN = [
    "Rat", "Ox", "Tiger", "Rabbit", "Dragon", "Snake",
    "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig"
  ];

  // year here is Gregorian year, compute zodiac from Myanmar year
  const myanmarYear = gregorianToMyanmarYear(year, new Date().getMonth() + 1);
  const cycleIndex = (myanmarYear - 1) % 12;

  return {
    myanmarYear,
    myanmarYearDisplay: `မြန်မာ ခုနှစ် ${myanmarYear}`,
    cycle: ZODIAC_CYCLE_EN[cycleIndex],
    cycleMm: ZODIAC_CYCLE_MM[cycleIndex],
  };
}

export function getMyanmarYearList(): number[] {
  const currentYear = new Date().getFullYear();
  // Myanmar year list: from Myanmar year 1200 (~1738 AD) to current + 1
  const years: number[] = [];
  for (let y = 1200; y <= currentYear - 638; y++) {
    years.push(y);
  }
  return years;
}

// Convert Myanmar year to approximate Gregorian year
export function myanmarToGregorianYear(myanmarYear: number): number {
  return myanmarYear + 638;
}

// Get a display string for a birth date including Myanmar year
export function getMyanmarBirthDisplay(day: number, month: number, gregorianYear: number): string {
  const mmYear = gregorianToMyanmarYear(gregorianYear, month);
  const monthNames = ["ဇန်နဝါရီ","ဖေဖော်ဝါရီ","မတ်","ဧပြီ","မေ","ဇွန်","ဇူလိုင်","သြဂုတ်","စက်တင်ဘာ","အောက်တိုဘာ","နိုဝင်ဘာ","ဒီဇင်ဘာ"];
  return `${day} ${monthNames[month - 1]} ${gregorianYear} (မြန်မာ ခုနှစ် ${mmYear})`;
}
