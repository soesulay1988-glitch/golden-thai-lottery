export type Calendar3DHistoryMatrix = Record<string, Record<number, string>>;

export type Calendar3DPrediction = {
  targetRow: string;
  targetDate: string;
  primaryPrediction: string;
  completedCurrentYearDraws: number;
  evidence: Array<{
    key: "sameRow" | "recentSameRow" | "currentYear";
    candidate: string;
    sampleCount: number;
    hotDigits: string[];
  }>;
};

const DIGITS = Array.from({ length: 10 }, (_, index) => String(index));

function isThreeDigitNumber(value: string | undefined): value is string {
  return typeof value === "string" && /^\d{3}$/.test(value);
}

function countPositionDigits(values: string[]): number[][] {
  return Array.from({ length: 3 }, (_, position) => (
    DIGITS.map((digit) => values.reduce((count, value) => count + (value[position] === digit ? 1 : 0), 0))
  ));
}

function countAllDigits(values: string[]): number[] {
  return DIGITS.map((digit) => values.reduce(
    (count, value) => count + value.split("").filter((valueDigit) => valueDigit === digit).length,
    0,
  ));
}

function hammingDistance(left: string, right: string): number {
  return left.split("").reduce((distance, digit, index) => distance + (digit === right[index] ? 0 : 1), 0);
}

function bestCandidateFromPositionCounts(positionCounts: number[][]): string {
  return positionCounts
    .map((counts) => {
      const highest = Math.max(...counts);
      return String(counts.findIndex((count) => count === highest));
    })
    .join("");
}

function rankedHotDigits(values: string[]): string[] {
  const counts = countAllDigits(values);
  return DIGITS
    .map((digit, index) => ({ digit, count: counts[index] }))
    .sort((left, right) => right.count - left.count || left.digit.localeCompare(right.digit))
    .slice(0, 3)
    .map(({ digit }) => digit);
}

export function analyzeCalendar3DHistory(
  matrix: Calendar3DHistoryMatrix,
  years: readonly number[],
  rows: readonly string[],
  targetYear: number,
  targetDate: string,
): Calendar3DPrediction | null {
  const targetRow = rows.find((row) => !isThreeDigitNumber(matrix[row]?.[targetYear]));
  if (!targetRow) return null;

  const targetRowIndex = rows.indexOf(targetRow);
  const completedCurrentYearValues = rows
    .slice(0, targetRowIndex)
    .map((row) => matrix[row]?.[targetYear])
    .filter(isThreeDigitNumber);

  const historicalSameRowValues = years
    .filter((year) => year < targetYear)
    .map((year) => matrix[targetRow]?.[year])
    .filter(isThreeDigitNumber);

  const recentYears = years.filter((year) => year < targetYear && year >= targetYear - 10);
  const recentSameRowValues = recentYears
    .map((year) => matrix[targetRow]?.[year])
    .filter(isThreeDigitNumber);

  if (!historicalSameRowValues.length) return null;

  const sameRowPositionCounts = countPositionDigits(historicalSameRowValues);
  const currentYearPositionCounts = countPositionDigits(completedCurrentYearValues);
  const recentSameRowPositionCounts = countPositionDigits(recentSameRowValues);

  const rankedCandidates = Array.from({ length: 1000 }, (_, value) => String(value).padStart(3, "0"))
    .map((candidate) => {
      const score = candidate.split("").reduce((total, digit, position) => {
        const digitIndex = Number(digit);
        return total
          + sameRowPositionCounts[position][digitIndex] * 5
          + currentYearPositionCounts[position][digitIndex] * 3
          + recentSameRowPositionCounts[position][digitIndex] * 2;
      }, 0);
      return { candidate, score };
    })
    .sort((left, right) => right.score - left.score || left.candidate.localeCompare(right.candidate));

  return {
    targetRow,
    targetDate,
    primaryPrediction: rankedCandidates[0]?.candidate ?? bestCandidateFromPositionCounts(sameRowPositionCounts),
    completedCurrentYearDraws: completedCurrentYearValues.length,
    evidence: [
      {
        key: "sameRow",
        candidate: bestCandidateFromPositionCounts(sameRowPositionCounts),
        sampleCount: historicalSameRowValues.length,
        hotDigits: rankedHotDigits(historicalSameRowValues),
      },
      {
        key: "recentSameRow",
        candidate: bestCandidateFromPositionCounts(recentSameRowPositionCounts),
        sampleCount: recentSameRowValues.length,
        hotDigits: rankedHotDigits(recentSameRowValues),
      },
      {
        key: "currentYear",
        candidate: bestCandidateFromPositionCounts(currentYearPositionCounts),
        sampleCount: completedCurrentYearValues.length,
        hotDigits: rankedHotDigits(completedCurrentYearValues),
      },
    ],
  };
}
