import { describe, expect, it } from "vitest";
import { calendar3DMatrix, CALENDAR_ROWS, CALENDAR_YEARS } from "./calendar3DData";
import { analyzeCalendar3DHistory } from "./calendar3DPrediction";

describe("calendar 3D historical prediction", () => {
  it("finds row 17 as the 16 September 2026 target without changing existing 2026 values", () => {
    const before = JSON.stringify(calendar3DMatrix);
    const result = analyzeCalendar3DHistory(calendar3DMatrix, CALENDAR_YEARS, CALENDAR_ROWS, 2026, "2026-09-16");

    expect(result?.targetRow).toBe("17");
    expect(result?.targetDate).toBe("2026-09-16");
    expect(result?.primaryPrediction).toMatch(/^\d{3}$/);
    expect(result?.evidence).toHaveLength(3);
    expect(result?.evidence.every((item) => /^\d{3}$/.test(item.candidate))).toBe(true);
    expect(calendar3DMatrix["01"][2026]).toBe("972");
    expect(calendar3DMatrix["16"][2026]).toBe("212");
    expect(calendar3DMatrix["15"][2026]).toBe("615");
    expect(JSON.stringify(calendar3DMatrix)).toBe(before);
  });

  it("moves prediction to row 18 only after a verified row 17 value is appended", () => {
    const matrixWithRow17 = {
      ...calendar3DMatrix,
      "17": { ...calendar3DMatrix["17"], 2026: "740" },
    };

    const first = analyzeCalendar3DHistory(matrixWithRow17, CALENDAR_YEARS, CALENDAR_ROWS, 2026, "2026-10-01");
    const second = analyzeCalendar3DHistory(matrixWithRow17, CALENDAR_YEARS, CALENDAR_ROWS, 2026, "2026-10-01");

    expect(first?.targetRow).toBe("18");
    expect(first).toEqual(second);
    expect(matrixWithRow17["17"][2026]).toBe("740");
  });
});
