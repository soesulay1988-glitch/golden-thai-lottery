import { describe, expect, it } from "vitest";
import { formatCalendar3DDrawTarget, getNextThaiLotteryDrawTarget } from "./calendar3DDrawSchedule";

describe("getNextThaiLotteryDrawTarget", () => {
  it("uses the 16th as the next regular draw before the 16th", () => {
    const target = getNextThaiLotteryDrawTarget(new Date("2026-09-05T12:00:00+07:00"));
    expect(target).toEqual({ isoDate: "2026-09-16", day: 16, month: 9, year: 2026 });
    expect(formatCalendar3DDrawTarget(target)).toBe("16-09-2026");
  });

  it("rolls from the 16th to the next month first", () => {
    expect(getNextThaiLotteryDrawTarget(new Date("2026-09-16T12:00:00+07:00"))).toEqual({
      isoDate: "2026-10-01", day: 1, month: 10, year: 2026,
    });
  });

  it("rolls year correctly after the 16 December draw", () => {
    expect(getNextThaiLotteryDrawTarget(new Date("2026-12-17T12:00:00+07:00"))).toEqual({
      isoDate: "2027-01-01", day: 1, month: 1, year: 2027,
    });
  });
});
