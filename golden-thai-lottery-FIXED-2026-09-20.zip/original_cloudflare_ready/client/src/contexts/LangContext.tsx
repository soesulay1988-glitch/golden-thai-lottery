import React, { createContext, useContext, useState, useCallback } from "react";
export type Lang = "mm" | "en" | "th";

// ─── Full bilingual dictionary ────────────────────────────────────────────────
const dict = {
  // App
  appName:        { mm: "ရွှေထိုင်းလော့တာရီ & ၂ဒီ", en: "Golden Thai Lottery & 2D", th: "หวยไทยทอง & 2D" },
  appTagline:     { mm: "ထိုင်းလော့တာရီ • မြန်မာ ၂ဒီ • ၃ဒီ ပြက္ခဒိန်", en: "Thai Lottery • Myanmar 2D • 3D Calendar", th: "หวยไทย • พม่า 2D • ปฏิทิน 3D" },

  // Nav
  navHome:        { mm: "ပင်မ", en: "Home", th: "หน้าหลัก" },
  navLottery:     { mm: "လော့တာ", en: "Lottery", th: "หวย" },
  nav2D:          { mm: "၂ဒီ", en: "2D", th: "2D" },
  nav3D:          { mm: "၃ဒီ", en: "3D", th: "3D" },
  navDream:       { mm: "အိမ်မက်", en: "Dreams", th: "ความฝัน" },
  navMore:        { mm: "နောက်ထပ်", en: "More", th: "เพิ่มเติม" },
  navHoroscope:   { mm: "ဟောကိန်း", en: "Horoscope", th: "ดวงชะตา" },
  navMahaboke:    { mm: "မဟာဘုတ်", en: "Mahaboke", th: "มหาโบราณ" },
  navVideo:       { mm: "ဗီဒီယို", en: "Video", th: "วิดีโอ" },
  navHistory:     { mm: "မှတ်တမ်း", en: "History", th: "ประวัติ" },

  // Home dashboard
  latestDraw:     { mm: "နောက်ဆုံးဆွဲချက်", en: "Latest Draw", th: "งวดล่าสุด" },
  checkTicket:    { mm: "လက်မှတ်စစ်ရန်", en: "Check Ticket", th: "ตรวจสลาก" },
  drawHistory:    { mm: "ဆွဲချက်မှတ်တမ်း", en: "Draw History", th: "ประวัติการออกรางวัล" },
  live2D:         { mm: "တိုက်ရိုက် ၂ဒီ", en: "Live 2D", th: "2D สด" },
  calendar3D:     { mm: "၃ဒီ ပြက္ခဒိန်", en: "3D Calendar", th: "ปฏิทิน 3D" },
  dreamDict:      { mm: "အိမ်မက်တစ်ထောင်", en: "Dream Dictionary", th: "ทำนายฝัน" },
  horoscope:      { mm: "ဟောကိန်း", en: "Horoscope", th: "ดวงชะตา" },
  dreamInterp:    { mm: "အိမ်မက်ဟောကိန်း", en: "Dream Reading", th: "ทำนายฝัน" },

  // Lottery checker
  enterTicket:    { mm: "လက်မှတ်နံပါတ် ၆ လုံး ထည့်ပါ", en: "Enter 6-digit ticket number", th: "ใส่หมายเลขสลาก 6 หลัก" },
  checkBtn:       { mm: "စစ်ဆေးရန်", en: "Check", th: "ตรวจสอบ" },
  scanQR:         { mm: "QR ကုဒ် စကင်ဖတ်ရန်", en: "Scan QR Code", th: "สแกน QR Code" },
  stopScan:       { mm: "ရပ်ရန်", en: "Stop Scan", th: "หยุดสแกน" },
  drawDate:       { mm: "ဆွဲချက်ရက်", en: "Draw Date", th: "วันที่ออกรางวัล" },
  selectDate:     { mm: "ရက်ရွေးချယ်ပါ", en: "Select Date", th: "เลือกวันที่" },
  noResult:       { mm: "ရလဒ်မတွေ့ပါ", en: "No results found", th: "ไม่พบผลลัพธ์" },
  noDrawData:     { mm: "ဆွဲချက်ဒေတာ မရှိသေးပါ", en: "No draw data available", th: "ไม่มีข้อมูลการออกรางวัล" },
  loading:        { mm: "ခဏစောင့်ပါ...", en: "Loading...", th: "กำลังโหลด..." },

  // Prize tiers
  firstPrize:     { mm: "ပထမဆု (၆,၀၀၀,၀၀၀ ဘတ်)", en: "1st Prize (6,000,000 Baht)", th: "รางวัลที่ 1 (6,000,000 บาท)" },
  nearFirst:      { mm: "ပထမဆုနှင့်နီးသောဆု (၁၀၀,၀၀၀ ဘတ်)", en: "Near 1st Prize (100,000 Baht)", th: "รางวัลข้างเคียงรางวัลที่ 1 (100,000 บาท)" },
  first3Digits:   { mm: "ရှေ့ ၃ လုံး (၄,၀၀၀ ဘတ်)", en: "First 3 Digits (4,000 Baht)", th: "เลขหน้า 3 ตัว (4,000 บาท)" },
  last3Digits:    { mm: "နောက် ၃ လုံး (၄,၀၀၀ ဘတ်)", en: "Last 3 Digits (4,000 Baht)", th: "เลขท้าย 3 ตัว (4,000 บาท)" },
  last2Digits:    { mm: "နောက် ၂ လုံး (၂,၀၀၀ ဘတ်)", en: "Last 2 Digits (2,000 Baht)", th: "เลขท้าย 2 ตัว (2,000 บาท)" },
  secondPrize:    { mm: "ဒုတိယဆု (၂၀၀,၀၀၀ ဘတ်)", en: "2nd Prize (200,000 Baht)", th: "รางวัลที่ 2 (200,000 บาท)" },
  thirdPrize:     { mm: "တတိယဆု (၈၀,၀၀၀ ဘတ်)", en: "3rd Prize (80,000 Baht)", th: "รางวัลที่ 3 (80,000 บาท)" },
  fourthPrize:    { mm: "စတုတ္ထဆု (၄၀,၀၀၀ ဘတ်)", en: "4th Prize (40,000 Baht)", th: "รางวัลที่ 4 (40,000 บาท)" },
  fifthPrize:     { mm: "ပဉ္စမဆု (၂၀,၀၀၀ ဘတ်)", en: "5th Prize (20,000 Baht)", th: "รางวัลที่ 5 (20,000 บาท)" },

  // Winning
  congratulations: { mm: "ဂုဏ်ယူပါတယ်! 🎉", en: "Congratulations! 🎉", th: "ยินดีด้วย! 🎉" },
  youWon:          { mm: "သင်ဆုရသည်!", en: "You Won!", th: "คุณถูกรางวัล!" },
  noWin:           { mm: "ဆုမပေါ်ပါ", en: "Not a winning ticket", th: "ไม่ถูกรางวัล" },
  tryAgain:        { mm: "ထပ်မံကြိုးစားပါ", en: "Try Again", th: "ลองอีกครั้ง" },
  prize:           { mm: "ဆု", en: "Prize", th: "รางวัล" },
  amount:          { mm: "ငွေပမာဏ", en: "Amount", th: "จำนวนเงิน" },
  baht:            { mm: "ဘတ်", en: "Baht", th: "บาท" },

  // 2D
  morningSession:  { mm: "မနက်ပိုင်း (၁၁:၀၀)", en: "Morning (11:00)", th: "รอบเช้า (11:00)" },
  eveningSession:  { mm: "ညနေပိုင်း (၄:၃၀)", en: "Evening (4:30)", th: "รอบบ่าย (16:30)" },
  todayResult:     { mm: "ယနေ့ ၂ဒီ ရလဒ်", en: "Today's 2D Result", th: "ผล 2D วันนี้" },
  history:         { mm: "မှတ်တမ်း", en: "History", th: "ประวัติ" },
  date:            { mm: "ရက်စွဲ", en: "Date", th: "วันที่" },
  session:         { mm: "အချိန်", en: "Session", th: "รอบ" },
  number:          { mm: "နံပါတ်", en: "Number", th: "หมายเลข" },
  set:             { mm: "ဆက်", en: "Set", th: "เซ็ต" },
  value:           { mm: "တန်ဖိုး", en: "Value", th: "มูลค่า" },
  morning:         { mm: "မနက်", en: "Morning", th: "เช้า" },
  evening:         { mm: "ညနေ", en: "Evening", th: "บ่าย" },

  // 2D Live tracking
  liveTracking:    { mm: "တိုက်ရိုက် စျေးကွက်", en: "Live Market", th: "ตลาดสด" },
  liveUpdateTime:  { mm: "နောက်ဆုံးအပ်ဒိတ်", en: "Last Updated", th: "อัปเดตล่าสุด" },
  liveBadge:       { mm: "တိုက်ရိုက်", en: "LIVE", th: "สด" },
  waitingResult:   { mm: "အဖြေ မထွက်သေးပါ", en: "Waiting for result", th: "รอผล" },
  marketClosed:    { mm: "စျေးကွက် ပိတ်ထားသည်", en: "Market Closed", th: "ตลาดปิด" },
  myanmarTime:     { mm: "မြန်မာစံတော်ချိန်", en: "Myanmar Time", th: "เวลาพม่า" },

  // 2D Chat
  chatBox:         { mm: "ဆွေးနွေးခန်း", en: "Live Chat", th: "แชทสด" },
  chatPlaceholder: { mm: "မှတ်ချက် ရေးပါ...", en: "Message...", th: "พิมพ์ข้อความ..." },
  chatSend:        { mm: "ပို့ရန်", en: "Send", th: "ส่ง" },
  chatLogin:       { mm: "စကားပြောရန် Login လုပ်ပါ", en: "Login to chat", th: "เข้าสู่ระบบเพื่อแชท" },
  chatNow:         { mm: "ယခု", en: "Now", th: "ตอนนี้" },
  chatToday:       { mm: "ယနေ့", en: "Today", th: "วันนี้" },

  // 3D Calendar
  calendar3DTitle: { mm: "၃ဒီ ပြက္ခဒိန် (၁၉၇၁-၂၀၂၆)", en: "3D Calendar (1971-2026)", th: "ปฏิทิน 3D (1971-2026)" },
  year:            { mm: "နှစ်", en: "Year", th: "ปี" },
  month:           { mm: "လ", en: "Month", th: "เดือน" },
  day:             { mm: "ရက်", en: "Day", th: "วัน" },
  swipeHint:       { mm: "ဘယ်ညာ ပွတ်ဆွဲ၍ကြည့်ပါ", en: "Swipe left/right to browse", th: "ปัดซ้าย/ขวาเพื่อดู" },

  // Dream Dictionary
  dreamTitle:      { mm: "အိမ်မက်တစ်ထောင်", en: "Dream One Thousand", th: "ทำนายฝัน" },
  dreamSubtitle:   { mm: "အိမ်မက်ကြည့်၍ ကံကောင်းဂဏန်းရှာပါ", en: "Find your lucky numbers from dreams", th: "ค้นหาเลขนำโชคจากความฝัน" },
  searchDream:     { mm: "အိမ်မက်ကို ရှာဖွေပါ...", en: "Search dreams...", th: "ค้นหาความฝัน..." },
  gridView:        { mm: "ကတ်ပြားကြည့်", en: "Grid View", th: "มุมมองตาราง" },
  listView:        { mm: "စာရင်းကြည့်", en: "List View", th: "มุมมองรายการ" },
  luckyNumbers:    { mm: "ကံကောင်းဂဏန်း", en: "Lucky Numbers", th: "เลขนำโชค" },
  numbers2D:       { mm: "၂ဒီ ဂဏန်း", en: "2D Numbers", th: "เลข 2D" },
  numbers3D:       { mm: "၃ဒီ ဂဏန်း", en: "3D Numbers", th: "เลข 3D" },
  dreamMeaning:    { mm: "အဓိပ္ပာယ်", en: "Meaning", th: "ความหมาย" },
  noSearchResult:  { mm: "ရှာမတွေ့ပါ", en: "No dreams found", th: "ไม่พบความฝัน" },
  allDreams:       { mm: "အားလုံး", en: "All", th: "ทั้งหมด" },
  animals:         { mm: "တိရစ္ဆာန်", en: "Animals", th: "สัตว์" },
  nature:          { mm: "သဘာဝ", en: "Nature", th: "ธรรมชาติ" },
  people:          { mm: "လူများ", en: "People", th: "คน" },
  objects:         { mm: "ပစ္စည်းများ", en: "Objects", th: "สิ่งของ" },
  supernatural:    { mm: "နတ်ဘုရား", en: "Supernatural", th: "เหนือธรรมชาติ" },

  // Horoscope
  horoTitle:       { mm: "အပတ်စဉ် ဟောကိန်း", en: "Weekly Horoscope", th: "ดวงรายสัปดาห์" },
  birthDay:        { mm: "မွေးနေ့", en: "Birth Day", th: "วันเกิด" },
  selectBirthDay:  { mm: "မွေးနေ့ ရွေးချယ်ပါ", en: "Select your birth day", th: "เลือกวันเกิดของคุณ" },
  luckyColor:      { mm: "ကံကောင်းရောင်", en: "Lucky Color", th: "สีนำโชค" },
  luckyDirection:  { mm: "ကံကောင်းဦးတည်ချက်", en: "Lucky Direction", th: "ทิศนำโชค" },
  luckyDay:        { mm: "ကံကောင်းနေ့", en: "Lucky Day", th: "วันนำโชค" },
  auspiciousNums:  { mm: "မင်္ဂလာဂဏန်း", en: "Auspicious Numbers", th: "เลขมงคล" },
  lotteryNums:     { mm: "လော့တာဂဏန်း", en: "Lottery Numbers", th: "เลขหวย" },
  overallRating:   { mm: "ကံကြမ္မာ အဆင့်", en: "Fortune Rating", th: "ระดับดวง" },
  listenBtn:       { mm: "နားထောင်ရန်", en: "Listen", th: "ฟัง" },
  stopBtn:         { mm: "ရပ်ရန်", en: "Stop", th: "หยุด" },
  forecast:        { mm: "ဟောကိန်း", en: "Forecast", th: "คำทำนาย" },

  // Birth days (Burmese)
  sunday:          { mm: "တနင်္ဂနွေ (ဂဠုန်)", en: "Sunday (Garuda)", th: "วันอาทิตย์ (ครุฑ)" },
  monday:          { mm: "တနင်္လာ (ကျားသစ်)", en: "Monday (Tiger)", th: "วันจันทร์ (เสือ)" },
  tuesday:         { mm: "အင်္ဂါ (ခြင်္သေ့)", en: "Tuesday (Lion)", th: "วันอังคาร (สิงโต)" },
  wednesday_am:    { mm: "ဗုဒ္ဓဟူး မနက် (ဆင်)", en: "Wednesday AM (Elephant)", th: "วันพุธเช้า (ช้าง)" },
  wednesday_pm:    { mm: "ဗုဒ္ဓဟူး ညနေ (ကျား)", en: "Wednesday PM (Tiger)", th: "วันพุธบ่าย (เสือ)" },
  thursday:        { mm: "ကြာသပတေး (ကြွက်)", en: "Thursday (Rat)", th: "วันพฤหัสบดี (หนู)" },
  friday:          { mm: "သောကြာ (ကြိုး)", en: "Friday (Guinea Pig)", th: "วันศุกร์ (หนูตะเภา)" },
  saturday:        { mm: "စနေ (နဂါး)", en: "Saturday (Dragon)", th: "วันเสาร์ (มังกร)" },

  // Dream interpreter
  dreamInterpTitle: { mm: "AI အိမ်မက်ဟောကိန်း", en: "AI Dream Interpreter", th: "AI ทำนายฝัน" },
  dreamPlaceholder: { mm: "သင်မက်သောအိမ်မက်ကို ဖော်ပြပါ... (ဥပမာ - ရေမြောင်းထဲ ငါးကြီးတွေ့သည်)", en: "Describe your dream... (e.g. saw big fish in a river)", th: "อธิบายความฝันของคุณ... (เช่น เห็นปลาใหญ่ในแม่น้ำ)" },
  interpretBtn:    { mm: "ဟောကိန်းကြည့်ရန်", en: "Interpret Dream", th: "ทำนายฝัน" },
  interpreting:    { mm: "ဟောကိန်းကြည့်နေသည်...", en: "Interpreting...", th: "กำลังทำนาย..." },
  interpretation:  { mm: "အဓိပ္ပာယ်ဖွင့်ဆိုချက်", en: "Interpretation", th: "การตีความ" },
  symbols:         { mm: "သင်္ကေတများ", en: "Symbols", th: "สัญลักษณ์" },
  fortuneMsg:      { mm: "ကံကြမ္မာ မက်ဆေ့ဂျ်", en: "Fortune Message", th: "ข้อความโชคชะตา" },

  // Common
  viewAll:         { mm: "အားလုံးကြည့်ရန်", en: "View All", th: "ดูทั้งหมด" },
  back:            { mm: "နောက်သို့", en: "Back", th: "กลับ" },
  close:           { mm: "ပိတ်ရန်", en: "Close", th: "ปิด" },
  refresh:         { mm: "ပြန်လည်ဆွဲယူရန်", en: "Refresh", th: "รีเฟรช" },
  tapToExpand:     { mm: "ဖွင့်ကြည့်ရန် နှိပ်ပါ", en: "Tap to expand", th: "แตะเพื่อขยาย" },
  updated:         { mm: "မွမ်းမံပြီး", en: "Updated", th: "อัปเดตแล้ว" },
  nextDraw:        { mm: "နောက်ဆွဲချက်", en: "Next Draw", th: "งวดถัดไป" },
  language:        { mm: "ဘာသာစကား", en: "Language", th: "ภาษา" },
  switchLang:      { mm: "English", en: "မြန်မာ", th: "ไทย" },

  // Lucky Number Generator
  luckyGenTitle:   { mm: "AI ကံကောင်းဂဏန်း", en: "AI Lucky Numbers", th: "AI เลขนำโชค" },
  luckyGenSub:     { mm: "မွေးနေ့မှ ကံဂဏန်းရှာပါ", en: "Find lucky numbers from birth date", th: "ค้นหาเลขนำโชคจากวันเกิด" },
  generateBtn:     { mm: "ကံကောင်းဂဏန်း ထုတ်ယူပါ", en: "Generate Lucky Numbers", th: "สร้างเลขนำโชค" },
  generating:      { mm: "ထုတ်ယူနေသည်...", en: "Generating...", th: "กำลังสร้าง..." },
  regenerate:      { mm: "ထပ်မံ ထုတ်ယူပါ", en: "Regenerate", th: "สร้างใหม่" },
  lotteryLucky:    { mm: "ထိုင်းထီ ကံကောင်းဂဏန်း", en: "Thai Lottery Lucky Numbers", th: "เลขนำโชคหวยไทย" },
  twodLucky:       { mm: "မြန်မာ ၂ဒီ ကံကောင်းဂဏန်း", en: "Myanmar 2D Lucky Numbers", th: "เลขนำโชค 2D พม่า" },
  reasoning:       { mm: "ကံဂဏန်းတွက်နည်း", en: "How These Numbers Were Chosen", th: "วิธีเลือกเลขเหล่านี้" },

  // My Tickets
  myTicketsTitle:  { mm: "ကျွန်ုပ်၏ လက်မှတ်များ", en: "My Tickets", th: "สลากของฉัน" },
  myTicketsSub:    { mm: "သိမ်းဆည်းပြီး အလိုအလျောက် စစ်ဆေးပါ", en: "Save & auto-check tickets", th: "บันทึกและตรวจอัตโนมัติ" },
  addTicket:       { mm: "လက်မှတ် ထည့်ရန်", en: "Add Ticket", th: "เพิ่มสลาก" },
  saveTicket:      { mm: "သိမ်းဆည်းရန်", en: "Save Ticket", th: "บันทึกสลาก" },
  checkAllTickets: { mm: "အားလုံးစစ်ဆေး", en: "Check All", th: "ตรวจทั้งหมด" },
  noTickets:       { mm: "လက်မှတ် မရှိသေးပါ", en: "No tickets saved yet", th: "ยังไม่มีสลากที่บันทึก" },
  ticketWon:       { mm: "ဆုရသည်!", en: "Won!", th: "ถูกรางวัล!" },
  ticketLost:      { mm: "ဆုမပေါ်ပါ", en: "Not a winning ticket", th: "ไม่ถูกรางวัล" },
  signInRequired:  { mm: "အကောင့်ဝင်ရောက်ပါ", en: "Sign In Required", th: "ต้องเข้าสู่ระบบ" },
  signIn:          { mm: "အကောင့်ဝင်ရောက်ရန်", en: "Sign In", th: "เข้าสู่ระบบ" },

  // 2D AI Prediction
  aiPrediction:    { mm: "AI ၂ဒီ ကြိုတင်ခန့်မှန်း", en: "AI 2D Prediction", th: "AI ทำนาย 2D" },
  predictBtn:      { mm: "ခန့်မှန်းရန်", en: "Predict", th: "ทำนาย" },
  hotNumbers:      { mm: "ကြာခဏပေါ်", en: "Hot Numbers", th: "เลขเด่น" },
  coldNumbers:     { mm: "ကြာမပေါ်", en: "Cold Numbers", th: "เลขเย็น" },

  // Weekly Lucky
  weeklyLuckyTitle: { mm: "အပတ်စဉ် ၃ဒီ ကံကောင်းဂဏန်း", en: "Weekly 3D Lucky Number", th: "เลขนำโชค 3D รายสัปดาห์" },
  weeklyLuckyDesc: { mm: "တနင်္ဂနွေတိုင်း ၃ဒီ ကံကောင်းဂဏန်း ၁ ကွက် ပို့ပေးပါမည်", en: "Get a lucky 3D number every Sunday", th: "รับเลขนำโชค 3D ทุกวันอาทิตย์" },
  weeklyLuckyEnabled: { mm: "အပတ်စဉ် ကံကောင်းဂဏန်း ပို့ပေးမည်", en: "Enable weekly lucky number", th: "เปิดเลขนำโชครายสัปดาห์" },
  weeklyLuckyDisabled: { mm: "အပတ်စဉ် ကံကောင်းဂဏန်း ပိတ်ထားသည်", en: "Weekly lucky number is off", th: "ปิดเลขนำโชครายสัปดาห์" },
  weeklyLuckySave: { mm: "သိမ်းဆည်းရန်", en: "Save", th: "บันทึก" },
  weeklyLuckySaved: { mm: "သိမ်းဆည်းပြီးပါပြီ!", en: "Saved!", th: "บันทึกแล้ว!" },
  weeklyLuckyPrefTitle: { mm: "အပတ်စဉ် ကံကောင်းဂဏန်း ဆက်တင်", en: "Weekly Lucky Settings", th: "ตั้งค่าเลขนำโชครายสัปดาห์" },
  myLuckyHistory: { mm: "ကျွန်ုပ်၏ ကံကောင်းဂဏန်းမှတ်တမ်း", en: "My Lucky Number History", th: "ประวัติเลขนำโชคของฉัน" },
  noLuckyHistory: { mm: "ကံကောင်းဂဏန်းမှတ်တမ်း မရှိသေးပါ", en: "No lucky number history yet", th: "ยังไม่มีประวัติเลขนำโชค" },

  // PWA Install Prompt
  installApp:     { mm: "အက်ပ် ထည့်သွင်းရန်", en: "Install App", th: "ติดตั้งแอป" },
  installDesc:    { mm: "ဖုန်းတွင် အက်ပ် အဖြစ် ထည့်သွင်းထားပါ", en: "Install as an app on your device", th: "ติดตั้งเป็นแอปบนอุปกรณ์ของคุณ" },
  installLater:   { mm: "နောက်မှ", en: "Later", th: "ภายหลัง" },
  installBadge:   { mm: "အခမဲ့", en: "Free", th: "ฟรี" },
  installFeature1: { mm: "ရလဒ် အမြန်ကြည့်ရန်", en: "Fast result access", th: "เข้าถึงผลเร็ว" },
  installFeature2: { mm: "အသိပေးချက် ရယူရန်", en: "Get notifications", th: "รับการแจ้งเตือน" },
  installFeature3: { mm: "ဒေတာ သက်သာရန်", en: "Save mobile data", th: "ประหยัดข้อมูล" },

  // Draw History Filter
  filterBy:       { mm: "စစ်ထုတ်ရန်", en: "Filter by", th: "กรองตาม" },
  filterAll:      { mm: "အားလုံး", en: "All", th: "ทั้งหมด" },
  filterMonth:    { mm: "လအလိုက်", en: "Month", th: "เดือน" },
  filterYear:     { mm: "နှစ်အလိုက်", en: "Year", th: "ปี" },
  showingOf:      { mm: "ပြနေပါသည်", en: "showing", th: "แสดง" },
  noFilteredDraws: { mm: "စစ်ထုတ်မှုနှင့် ကိုက်ညီသော မှတ်တမ်းမရှိပါ", en: "No draws match the filter", th: "ไม่มีผลที่ตรงกับตัวกรอง" },
  jan:            { mm: "ဇန်နဝါရီ", en: "Jan", th: "ม.ค." },
  feb:            { mm: "ဖေဖော်ဝါရီ", en: "Feb", th: "ก.พ." },
  mar:            { mm: "မတ်", en: "Mar", th: "มี.ค." },
  apr:            { mm: "ဧပီြ", en: "Apr", th: "เม.ย." },
  may:            { mm: "မေ", en: "May", th: "พ.ค." },
  jun:            { mm: "ဇွန်", en: "Jun", th: "มิ.ย." },
  jul:            { mm: "ဇူလိုင်", en: "Jul", th: "ก.ค." },
  aug:            { mm: "ဩဂုတ်", en: "Aug", th: "ส.ค." },
  sep:            { mm: "စက်တင်ဘာ", en: "Sep", th: "ก.ย." },
  oct:            { mm: "အောက်တိုဘာ", en: "Oct", th: "ต.ค." },
  nov:            { mm: "နိုဝင်ဘာ", en: "Nov", th: "พ.ย." },
  dec:            { mm: "ဒီဇင်ဘာ", en: "Dec", th: "ธ.ค." },

  // Lucky Number History
  luckyHistoryTitle: { mm: "မှတ်တမ်း", en: "History", th: "ประวัติ" },
  luckyHistorySub: { mm: "ယခင်ရက်များ၏ ပေါက်ဂဏန်းများ", en: "Past winning numbers", th: "เลขที่ออกในอดีต" },
  luckyHistoryShow: { mm: "မှတ်တမ်း ကြည့်ရန်", en: "View History", th: "ดูประวัติ" },

  // 2D Hot/Cold Analysis
  analysisTitle:   { mm: "ဂဏန်း ခွဲခြမ်းစိတ်ဖြာချက်", en: "Number Analysis", th: "วิเคราะห์ตัวเลข" },
  analysisSub:     { mm: "ရက် ၃၀ အတွင်း ခွဲခြမ်းစိတ်ဖြာချက်", en: "Based on last 30 days", th: "จาก 30 วันที่ผ่านมา" },
  freqChart:       { mm: "အကြိမ်အရေအတွက်", en: "Frequency Chart", th: "แผนภูมิความถี่" },
  consecutivePairs: { mm: "တွဲထွက်ဂဏန်း", en: "Consecutive Pairs", th: "เลขคู่ติดกัน" },
  digitFreq:       { mm: "တစ်လုံးဂဏန်း ခွဲခြမ်းစိတ်ဖြာချက်", en: "Single Digit Analysis", th: "วิเคราะห์เลขหลักเดียว" },
  resultsAnalyzed: { mm: "ရလဒ် အရေအတွက်", en: "Results Analyzed", th: "ผลที่วิเคราะห์" },
  bellNewResult:   { mm: "ရလဒ်အသစ် ထွက်ပါပြီ!", en: "New result available!", th: "มีผลใหม่แล้ว!" },

  // Number Grid
  numberGridTitle: { mm: "၀၀၀-၉၉၉ ဂဏန်းဇယား", en: "000-999 Number Grid", th: "ตารางเลข 000-999" },
  numberGridSub:   { mm: "ဂဏန်းကို နှိပ်ပြီး ကော်ပီယူပါ", en: "Tap a number to copy it", th: "แตะเลขเพื่อคัดลอก" },
  numberGridSearch: { mm: "ဂဏန်း ရှာပါ", en: "Search numbers", th: "ค้นหาเลข" },
  numberGridQuickCopy: { mm: "အမြန် ကော်ပီ", en: "Quick Copy", th: "คัดลอกด่วน" },
  numberGridTapCopy: { mm: "ဂဏန်းတိုင်းကို နှိပ်ရင် ကော်ပီယူလို့ ရပါတယ်", en: "Tap any number to copy to clipboard", th: "แตะเลขใดก็ได้เพื่อคัดลอก" },
  numberGridNav:   { mm: "ဂဏန်းဇယား", en: "Number Grid", th: "ตารางเลข" },

  // Admin Lucky Box Toggle
  adminToggle:     { mm: "Admin ကိရိယာများ", en: "Admin Tools", th: "เครื่องมือผู้ดูแล" },
  luckyBoxToggle:  { mm: "Lucky Box အဖွင့်အပိတ်", en: "Lucky Box Toggle", th: "สลับกล่องนำโชค" },
  luckyBoxOn:      { mm: "ဖွင့်ထားပါသည်", en: "Enabled", th: "เปิดใช้งาน" },
  luckyBoxOff:     { mm: "ပိတ်ထားပါသည်", en: "Disabled", th: "ปิดใช้งาน" },
  luckyBoxOnDesc:  { mm: "အသုံးပြုသူများ Lucky Box ဖွင့်နိုင်ပါသည်", en: "Users can open the Lucky Box", th: "ผู้ใช้สามารถเปิดกล่องนำโชคได้" },
  luckyBoxOffDesc: { mm: "Lucky Box ယာယီ ရပ်နားထားပါသည်", en: "Lucky Box is temporarily paused", th: "กล่องนำโชคหยุดชั่วคราว" },
  luckyBoxSaved:   { mm: "သိမ်းပြီးပါပြီ", en: "Saved", th: "บันทึกแล้ว" },
} as const;

export type DictKey = keyof typeof dict;

interface LangContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: DictKey) => string;
  toggle: () => void;
}

const LangContext = createContext<LangContextValue | null>(null);

export function LangProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLang] = useState<Lang>(() => {
    try { return (localStorage.getItem("app_lang") as Lang) || "mm"; } catch { return "mm"; }
  });

  const handleSetLang = useCallback((l: Lang) => {
    setLang(l);
    try { localStorage.setItem("app_lang", l); } catch {}
  }, []);

  const toggle = useCallback(() => {
    handleSetLang(lang === "mm" ? "en" : lang === "en" ? "th" : "mm");
  }, [lang, handleSetLang]);

  const t = useCallback((key: DictKey): string => {
    const entry = dict[key] as Record<string, string>;
    return entry[lang] || entry.en || entry.mm || "";
  }, [lang]);

  return (
    <LangContext.Provider value={{ lang, setLang: handleSetLang, t, toggle }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LangContext);
  if (!ctx) throw new Error("useLang must be used within LangProvider");
  return ctx;
}
