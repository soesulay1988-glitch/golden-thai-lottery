import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LangProvider, useLang } from "./contexts/LangContext";
import { lazy, Suspense, useEffect, useState } from "react";
import { Home, Ticket, Grid3X3, MoreHorizontal, Calendar, Star, Clock, Bell, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
// NotificationCenter removed per request
import InstallPrompt from "./components/InstallPrompt";
import OfflineBanner from "./components/OfflineBanner";

// Lazy-loaded pages
const HomePage       = lazy(() => import("./pages/Home"));
const LotteryPage    = lazy(() => import("./pages/Lottery"));
const Myanmar2DPage  = lazy(() => import("./pages/Myanmar2D"));
const Calendar3DPage = lazy(() => import("./pages/Calendar3D"));
const ThreeDAnalysisPage = lazy(() => import("./pages/ThreeDAnalysis"));
const DreamPage      = lazy(() => import("./pages/DreamDictionary"));
const HoroscopePage  = lazy(() => import("./pages/Horoscope"));
const MahabokePage   = lazy(() => import("./pages/Mahaboke"));
const DreamAIPage    = lazy(() => import("./pages/DreamInterpreter"));
const HistoryPage    = lazy(() => import("./pages/DrawHistory"));
const ProfilePage    = lazy(() => import("./pages/Profile"));
const NotFound       = lazy(() => import("./pages/NotFound"));
const LuckyPage      = lazy(() => import("./pages/LuckyGenerator"));
const LuckyNotesPage = lazy(() => import("./pages/LuckyNotes"));
const MyTicketsPage  = lazy(() => import("./pages/MyTickets"));
const PrivacyPolicy  = lazy(() => import("./pages/PrivacyPolicy"));


function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f5f5f5]">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 rounded-full border-3 border-[#FFD700] border-t-transparent animate-spin" />
        <p className="text-[#FFD700] text-sm font-myanmar animate-gold-pulse">ခဏစောင့်ပါ...</p>
      </div>
    </div>
  );
}

function InAppBroadcastOverlay() {
  const { lang } = useLang();
  const [dismissedId, setDismissedId] = useState<string | null>(null);
  const { data: broadcast } = trpc.inAppBroadcast.current.useQuery(undefined, { refetchInterval: 20_000 });

  useEffect(() => {
    if (!broadcast) return;
    setDismissedId(window.localStorage.getItem("golden-thai-dismissed-broadcast"));
  }, [broadcast]);

  if (!broadcast || dismissedId === broadcast.id) return null;

  const dismiss = () => {
    window.localStorage.setItem("golden-thai-dismissed-broadcast", broadcast.id);
    setDismissedId(broadcast.id);
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-slate-950/55 p-5 backdrop-blur-sm" role="dialog" aria-modal="true">
      <div className="w-full max-w-sm overflow-hidden rounded-[28px] border border-amber-200 bg-white shadow-2xl">
        <div className="relative bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 px-5 py-5 text-center text-[#3e2d00]">
          <button onClick={dismiss} className="absolute right-3 top-3 rounded-full bg-white/45 p-1.5 text-[#5b4200] hover:bg-white/70 btn-press" aria-label="Close"><X size={17} /></button>
          <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-2xl bg-white/65"><Bell size={22} /></div>
          <p className="mt-2 text-xs font-bold uppercase tracking-[0.16em]">Golden Thai</p>
        </div>
        <div className="p-5 text-center">
          <h2 className="text-xl font-black text-slate-900 font-myanmar">{broadcast.title}</h2>
          <p className="mt-3 whitespace-pre-wrap text-sm leading-7 text-slate-700 font-myanmar">{broadcast.message}</p>
          <button onClick={dismiss} className="mt-5 w-full rounded-2xl bg-[#FFD700] px-4 py-3 text-sm font-black text-[#332800] shadow-sm hover:bg-[#ffc800] btn-press">{lang === "mm" ? "နားလည်ပါပြီ" : "Got it"}</button>
        </div>
      </div>
    </div>
  );
}

function BottomNav() {
  const [location, navigate] = useLocation();
  const { t, lang } = useLang();

  const tabs = [
    { path: "/",              icon: Home,        labelKey: "navHome"     as const },
    { path: "/lottery",       icon: Ticket,      labelKey: "navLottery"  as const },
    { path: "/2d",            icon: Grid3X3,     labelKey: "nav2D"       as const },
    { path: "/3d",            icon: Calendar,    labelKey: "nav3D"       as const },
    { path: "/lottery/history", icon: Clock,    labelKey: "navHistory"  as const },
    { path: "/mahaboke",      icon: Star,        labelKey: "navMahaboke"  as const },
    { path: "/profile",       icon: MoreHorizontal, labelKey: "navMore"  as const },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#FFD700]/95 backdrop-blur-sm border-t border-[#FFB300] shadow-[0_-2px_8px_rgba(0,0,0,0.06)]"
         style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}>
      <div className="flex items-stretch max-w-[480px] mx-auto">
        {tabs.map(({ path, icon: Icon, labelKey }) => {
          const isActive = location === path || (path !== "/" && location.startsWith(path));
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className={`flex-1 flex flex-col items-center justify-center py-2 gap-0.5 transition-all duration-200 btn-press
                ${isActive ? "text-[#FFD700]" : "text-[#1A237E] hover:text-[#283593]"}`}
            >
                <Icon size={22} strokeWidth={isActive ? 2.5 : 2} color={isActive ? "#FFD700" : "#1A237E"} />
              <span className={`text-[9px] font-medium font-myanmar leading-none
                ${isActive ? "text-[#FFD700] font-bold" : "text-[#1A237E] font-semibold"}`}>
                {t(labelKey)}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

function Router() {
  return (
    <div className="min-h-screen bg-[#FFF8E1] bottom-nav-safe">
      <OfflineBanner />
      <InAppBroadcastOverlay />

      <Suspense fallback={<PageLoader />}>
        <Switch>
          <Route path="/"             component={HomePage} />
          <Route path="/lottery"      component={LotteryPage} />
          <Route path="/lottery/history" component={HistoryPage} />
          <Route path="/2d"           component={Myanmar2DPage} />
          <Route path="/myanmar-2d"    component={Myanmar2DPage} />
          <Route path="/3d"           component={Calendar3DPage} />
          <Route path="/3d-analysis"  component={ThreeDAnalysisPage} />
          <Route path="/dreams"       component={DreamPage} />
          <Route path="/dream-ai"     component={DreamAIPage} />
          <Route path="/horoscope"    component={HoroscopePage} />
          <Route path="/mahaboke"     component={MahabokePage} />
          <Route path="/profile"      component={ProfilePage} />
          <Route path="/lucky"        component={LuckyPage} />
          <Route path="/lucky-notes"  component={LuckyNotesPage} />
          <Route path="/my-tickets"   component={MyTicketsPage} />
          <Route path="/privacy"      component={PrivacyPolicy} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
      <BottomNav />
      <InstallPrompt />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <LangProvider>
          <TooltipProvider>
            <Toaster
              theme="light"
              toastOptions={{
                style: {
                  background: "white",
                  border: "1px solid #e5e5e5",
                  color: "#333",
                },
              }}
            />
            <Router />
          </TooltipProvider>
        </LangProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
