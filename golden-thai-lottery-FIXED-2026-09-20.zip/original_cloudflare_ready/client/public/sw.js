// Golden Thai Lottery Service Worker v2.0 — force the latest 2D UI assets.
const CACHE_NAME = 'golden-lottery-v2';
const OFFLINE_URL = '/offline.html';

// Assets to cache on install
const PRECACHE_ASSETS = [
  '/',
  '/manifest.json',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests and API calls
  if (request.method !== 'GET') return;
  if (url.pathname.startsWith('/api/')) return;
  if (url.pathname.startsWith('/manus-storage/')) return;

  // Network-first strategy for HTML pages
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).catch(() => {
        return caches.match('/') || caches.match(OFFLINE_URL);
      })
    );
    return;
  }

  // Cache-first for static assets
  if (url.pathname.match(/\.(js|css|png|jpg|jpeg|svg|ico|woff|woff2)$/)) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((response) => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        });
      })
    );
    return;
  }

  // Network-first for everything else
  event.respondWith(
    fetch(request).catch(() => caches.match(request))
  );
});

// ─── Web Push Notification Handling ─────────────────────────────────────────
self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data?.json() ?? {};
  } catch {
    data = { title: "Golden Thai Lottery", body: "New notification" };
  }

  const options = {
    body: data.body || "",
    icon: data.icon || "/icons/golden-thai-2d-crown.png",
    badge: data.badge || "/icon-96x96.png",
    tag: data._options?.tag || data.tag || "lottery-notification",
    requireInteraction: data._options?.requireInteraction ?? data.requireInteraction ?? false,
    silent: data._options?.silent ?? data.silent ?? false,
    vibrate: data._options?.vibrate ?? data.vibrate ?? [250, 100, 250],
    data: { url: data.url || "/lottery" },
    actions: [
      { action: "view", title: "View Results" },
      { action: "dismiss", title: "Dismiss" },
    ],
  };

  event.waitUntil(
    self.registration.showNotification(data.title || "Golden Thai Lottery", options)
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  if (event.action === "dismiss") {
    return;
  }

  const url = event.notification.data?.url || "/lottery";
  event.waitUntil(
    clients.matchAll({ type: "window" }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && "focus" in client) {
          client.focus();
          if (client.url.endsWith(url) || client.url.endsWith("/")) {
            return;
          }
          return client.navigate(url);
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(url);
      }
    })
  );
});
