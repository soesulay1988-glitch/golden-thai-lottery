CREATE TABLE `saved_tickets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`ticket_number` varchar(6) NOT NULL,
	`draw_date` date NOT NULL,
	`note` varchar(128),
	`is_checked` boolean NOT NULL DEFAULT false,
	`prize_result` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `saved_tickets_id` PRIMARY KEY(`id`)
);
