CREATE TABLE `myanmar2d_notification_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`result_date` varchar(10) NOT NULL,
	`session` enum('morning','evening') NOT NULL,
	`sentAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `myanmar2d_notification_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `user_notifications` MODIFY COLUMN `type` enum('lucky_number_7d','lucky_number_draw_day','lottery_result','weekly_3d','myanmar_2d_result','hot_number_alert') NOT NULL;