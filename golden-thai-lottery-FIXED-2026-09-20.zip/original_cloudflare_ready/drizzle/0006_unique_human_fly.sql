CREATE TABLE `calendar3d` (
	`id` int AUTO_INCREMENT NOT NULL,
	`year` int NOT NULL,
	`row` int NOT NULL,
	`value` varchar(3) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `calendar3d_id` PRIMARY KEY(`id`)
);
