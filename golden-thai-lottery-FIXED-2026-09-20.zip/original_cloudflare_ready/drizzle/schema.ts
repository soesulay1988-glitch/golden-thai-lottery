import {
  boolean,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  json,
  date,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  // Notification preferences
  weeklyLuckyEnabled: boolean("weekly_lucky_enabled").default(true).notNull(),
  // Country (auto-detected from language preference)
  country: mysqlEnum("country", ["myanmar", "thailand", "other"]).default("myanmar"),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Thai Lottery Draws ───────────────────────────────────────────────────────
export const thaiLotteryDraws = mysqlTable("thai_lottery_draws", {
  id: int("id").autoincrement().primaryKey(),
  drawDate: date("draw_date").notNull(),
  firstPrize: varchar("first_prize", { length: 6 }),
  nearFirstPrize: json("near_first_prize").$type<string[]>(),
  firstThreeDigits: json("first_three_digits").$type<string[]>(),
  lastThreeDigits: json("last_three_digits").$type<string[]>(),
  lastTwoDigits: varchar("last_two_digits", { length: 2 }),
  secondPrize: json("second_prize").$type<string[]>(),
  thirdPrize: json("third_prize").$type<string[]>(),
  fourthPrize: json("fourth_prize").$type<string[]>(),
  fifthPrize: json("fifth_prize").$type<string[]>(),
  isPublished: boolean("is_published").default(false).notNull(),
  source: varchar("source", { length: 128 }).default("manual"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ThaiLotteryDraw = typeof thaiLotteryDraws.$inferSelect;
export type InsertThaiLotteryDraw = typeof thaiLotteryDraws.$inferInsert;

// ─── Myanmar 2D Results ───────────────────────────────────────────────────────
export const myanmar2dResults = mysqlTable("myanmar_2d_results", {
  id: int("id").autoincrement().primaryKey(),
  resultDate: date("result_date").notNull(),
  session: mysqlEnum("session", ["morning", "evening"]).notNull(),
  winningNumber: varchar("winning_number", { length: 2 }).notNull(),
  setNumber: varchar("set_number", { length: 16 }),
  valueNumber: varchar("value_number", { length: 16 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Myanmar2dResult = typeof myanmar2dResults.$inferSelect;
export type InsertMyanmar2dResult = typeof myanmar2dResults.$inferInsert;

// ─── Weekly Horoscope Readings (Burmese birth-day based) ──────────────────────
export const horoscopeReadings = mysqlTable("horoscope_readings", {
  id: int("id").autoincrement().primaryKey(),
  weekStart: date("week_start").notNull(),
  birthDay: mysqlEnum("birth_day", [
    "sunday",
    "monday",
    "tuesday",
    "wednesday_am",
    "wednesday_pm",
    "thursday",
    "friday",
    "saturday",
  ]).notNull(),
  forecastEn: text("forecast_en").notNull(),
  forecastMm: text("forecast_mm").notNull(),
  luckyColor: varchar("lucky_color", { length: 64 }),
  luckyColorMm: varchar("lucky_color_mm", { length: 64 }),
  luckyDirection: varchar("lucky_direction", { length: 64 }),
  luckyDirectionMm: varchar("lucky_direction_mm", { length: 64 }),
  auspiciousNumbers: json("auspicious_numbers").$type<string[]>(),
  lotteryNumbers: json("lottery_numbers").$type<string[]>(),
  overallRating: int("overall_rating").default(3),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HoroscopeReading = typeof horoscopeReadings.$inferSelect;
export type InsertHoroscopeReading = typeof horoscopeReadings.$inferInsert;

// ─── Saved Tickets ────────────────────────────────────────────────────────────
export const savedTickets = mysqlTable("saved_tickets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  ticketNumber: varchar("ticket_number", { length: 6 }).notNull(),
  drawDate: varchar("draw_date", { length: 10 }).notNull(),
  note: varchar("note", { length: 128 }),
  isChecked: boolean("is_checked").default(false).notNull(),
  prizeResult: json("prize_result").$type<{ prize: string; prizeEn: string; prizeMm: string; amount: string }[] | null>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SavedTicket = typeof savedTickets.$inferSelect;
export type InsertSavedTicket = typeof savedTickets.$inferInsert;

// ─── User Notifications (in-app) ─────────────────────────────────────────────
export const userNotifications = mysqlTable("user_notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  type: mysqlEnum("type", ["lucky_number_7d", "lucky_number_draw_day", "lottery_result", "weekly_3d", "myanmar_2d_result", "hot_number_alert", "thai_3d_morning"]).notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  body: text("body").notNull(),
  luckyNumber: varchar("lucky_number", { length: 3 }),   // 3-digit lucky number
  drawDate: varchar("draw_date", { length: 10 }),         // related draw date YYYY-MM-DD
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserNotification = typeof userNotifications.$inferSelect;
export type InsertUserNotification = typeof userNotifications.$inferInsert;

// ─── Lucky Number Send Log (idempotency guard) ────────────────────────────────
export const luckyNumberLog = mysqlTable("lucky_number_log", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  drawDate: varchar("draw_date", { length: 10 }).notNull(),
  type: mysqlEnum("type", ["lucky_number_7d", "lucky_number_draw_day", "weekly_3d", "thai_3d_morning", "lucky_2d_9am", "lucky_2d_1130am", "lucky_2d_2pm", "lucky_2d_4pm"]).notNull(),
  luckyNumber: varchar("lucky_number", { length: 3 }).notNull(),
  sentAt: timestamp("sentAt").defaultNow().notNull(),
});

export type LuckyNumberLog = typeof luckyNumberLog.$inferSelect;
export type InsertLuckyNumberLog = typeof luckyNumberLog.$inferInsert;

// ─── Lottery Result Notification Log (idempotency guard) ──────────────────────
export const lotteryResultNotificationLog = mysqlTable("lottery_result_notification_log", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  drawDate: varchar("draw_date", { length: 10 }).notNull(),
  sentAt: timestamp("sentAt").defaultNow().notNull(),
});

export type LotteryResultNotificationLog = typeof lotteryResultNotificationLog.$inferSelect;
export type InsertLotteryResultNotificationLog = typeof lotteryResultNotificationLog.$inferInsert;

// ─── Myanmar 2D Result Notification Log (idempotency guard) ──────────────────
export const myanmar2dNotificationLog = mysqlTable("myanmar2d_notification_log", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  resultDate: varchar("result_date", { length: 10 }).notNull(),
  session: mysqlEnum("session", ["morning", "evening", "session1", "session2", "session3", "session4", "morning-before", "evening-before", "morning-after", "evening-after"]).notNull(),
  sentAt: timestamp("sentAt").defaultNow().notNull(),
});

export type Myanmar2dNotificationLog = typeof myanmar2dNotificationLog.$inferSelect;
export type InsertMyanmar2dNotificationLog = typeof myanmar2dNotificationLog.$inferInsert;

// ─── 3D Calendar Data ─────────────────────────────────────────────────────────
// Stores last 3 digits of 1st Prize for each draw date (row 01-31)
export const calendar3d = mysqlTable("calendar3d", {
  id: int("id").autoincrement().primaryKey(),
  year: int("year").notNull(),
  row: int("row").notNull(), // 1-31 (draw date day)
  value: varchar("value", { length: 3 }).notNull(), // last 3 digits
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Calendar3d = typeof calendar3d.$inferSelect;
export type InsertCalendar3d = typeof calendar3d.$inferInsert;

// ─── Web Push Subscriptions ──────────────────────────────────────────────────
export const pushSubscriptions = mysqlTable("push_subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PushSubscription = typeof pushSubscriptions.$inferSelect;
export type InsertPushSubscription = typeof pushSubscriptions.$inferInsert;

// ─── Mahaboke Weekly Horoscope Cache ──────────────────────────────────────
// Stores per-user Mahaboke horoscope readings, keyed by userId + birthDay + weekStart
// Same answer for the entire week, only regenerates when new week starts
export const mahabokeReadings = mysqlTable("mahaboke_readings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  deviceId: varchar("device_id", { length: 64 }),
  weekStart: varchar("week_start", { length: 10 }).notNull(), // YYYY-MM-DD (Monday)
  birthDay: mysqlEnum("birth_day", [
    "sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "rahu",
  ]).notNull(),
  birthDayOfMonth: int("birth_day_of_month"),
  birthMonth: int("birth_month"),
  birthYear: int("birth_year"),
  // Personal traits
  personalityMm: text("personality_mm"),
  personalityEn: text("personality_en"),
  personalityTh: text("personality_th"),
  rulingPlanet: varchar("ruling_planet", { length: 64 }),
  rulingPlanetEn: varchar("ruling_planet_en", { length: 64 }),
  // Weekly fortune
  loveMm: text("love_mm"),
  loveEn: text("love_en"),
  loveTh: text("love_th"),
  careerMm: text("career_mm"),
  careerEn: text("career_en"),
  careerTh: text("career_th"),
  healthMm: text("health_mm"),
  healthEn: text("health_en"),
  healthTh: text("health_th"),
  financeMm: text("finance_mm"),
  financeEn: text("finance_en"),
  financeTh: text("finance_th"),
  // Additional categories
  familyMm: text("family_mm"),
  familyEn: text("family_en"),
  familyTh: text("family_th"),
  educationMm: text("education_mm"),
  educationEn: text("education_en"),
  educationTh: text("education_th"),
  travelMm: text("travel_mm"),
  travelEn: text("travel_en"),
  travelTh: text("travel_th"),
  spiritualMm: text("spiritual_mm"),
  spiritualEn: text("spiritual_en"),
  spiritualTh: text("spiritual_th"),
  // Lucky items
  luckyColor: varchar("lucky_color", { length: 64 }),
  luckyColorMm: varchar("lucky_color_mm", { length: 64 }),
  luckyColorTh: varchar("lucky_color_th", { length: 64 }),
  luckyDirection: varchar("lucky_direction", { length: 64 }),
  luckyDirectionMm: varchar("lucky_direction_mm", { length: 64 }),
  luckyDirectionTh: varchar("lucky_direction_th", { length: 64 }),
  luckyDay: varchar("lucky_day", { length: 64 }),
  luckyDayMm: varchar("lucky_day_mm", { length: 64 }),
  luckyDayTh: varchar("lucky_day_th", { length: 64 }),
  lucky2dNumbers: json("lucky_2d_numbers").$type<string[]>(),
  luckyLotteryNumbers: json("lucky_lottery_numbers").$type<string[]>(),
  overallFortune: int("overall_fortune").default(3),
  weeklyMessageMm: text("weekly_message_mm"),
  weeklyMessageEn: text("weekly_message_en"),
  weeklyMessageTh: text("weekly_message_th"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MahabokeReading = typeof mahabokeReadings.$inferSelect;
export type InsertMahabokeReading = typeof mahabokeReadings.$inferInsert;

// ─── 2D Live Chat Messages ────────────────────────────────────────────────────
export const twoDChatMessages = mysqlTable("2d_chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id"),
  userName: varchar("user_name", { length: 64 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TwoDChatMessage = typeof twoDChatMessages.$inferSelect;
export type InsertTwoDChatMessage = typeof twoDChatMessages.$inferInsert;

// ─── Lucky Box Openings ────────────────────────────────────────────────────────
export const luckyBoxOpenings = mysqlTable("lucky_box_openings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  guestDeviceId: varchar("guest_device_id", { length: 64 }),
  slotKey: varchar("slot_key", { length: 32 }),
  openedAt: timestamp("opened_at").defaultNow().notNull(),
  isWinner: boolean("is_winner").default(false).notNull(),
  prizeAmount: int("prize_amount").default(0),
  referenceId: varchar("reference_id", { length: 32 }),
  screenshotSent: boolean("screenshot_sent").default(false).notNull(),
  qrToken: varchar("qr_token", { length: 64 }),
  claimantPhone: varchar("claimant_phone", { length: 32 }),
  claimedAt: timestamp("claimed_at"),
  paidAt: timestamp("paid_at"),
  year: int("year").notNull(),
  month: int("month").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LuckyBoxOpening = typeof luckyBoxOpenings.$inferSelect;
export type InsertLuckyBoxOpening = typeof luckyBoxOpenings.$inferInsert;

// ─── Monthly Prize Pool ────────────────────────────────────────────────────────
export const monthlyPrizePool = mysqlTable("monthly_prize_pool", {
  id: int("id").autoincrement().primaryKey(),
  year: int("year").notNull(),
  month: int("month").notNull(),
  adRevenue: int("ad_revenue").default(0).notNull(),
  prizePercentage: int("prize_percentage").default(20).notNull(),
  totalPrizePool: int("total_prize_pool").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MonthlyPrizePool = typeof monthlyPrizePool.$inferSelect;
export type InsertMonthlyPrizePool = typeof monthlyPrizePool.$inferInsert;

// ─── Lucky Box Monthly Reset Log ───────────────────────────────────────────────
export const luckyBoxMonthlyReset = mysqlTable("lucky_box_monthly_reset", {
  id: int("id").autoincrement().primaryKey(),
  year: int("year").notNull(),
  month: int("month").notNull(),
  resetAt: timestamp("reset_at").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LuckyBoxMonthlyReset = typeof luckyBoxMonthlyReset.$inferSelect;
export type InsertLuckyBoxMonthlyReset = typeof luckyBoxMonthlyReset.$inferInsert;

// ─── App Settings (Admin Toggle) ───────────────────────────────────────────────
export const appSettings = mysqlTable("app_settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 64 }).notNull(),
  value: varchar("value", { length: 256 }).notNull().default("true"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AppSetting = typeof appSettings.$inferSelect;
export type InsertAppSetting = typeof appSettings.$inferInsert;
