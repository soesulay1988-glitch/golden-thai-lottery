ALTER TABLE `mahaboke_readings` ADD `personality_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `love_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `career_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `health_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `finance_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `family_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `education_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `travel_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `spiritual_th` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `lucky_color_th` varchar(64);--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `lucky_direction_th` varchar(64);--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `lucky_day_th` varchar(64);--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `weekly_message_th` text;