ALTER TABLE `mahaboke_readings` ADD `device_id` varchar(64);--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `birth_day_of_month` int;