CREATE TABLE `lottery_result_notification_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`draw_date` varchar(10) NOT NULL,
	`sentAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lottery_result_notification_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `user_notifications` MODIFY COLUMN `type` enum('lucky_number_7d','lucky_number_draw_day','lottery_result') NOT NULL;