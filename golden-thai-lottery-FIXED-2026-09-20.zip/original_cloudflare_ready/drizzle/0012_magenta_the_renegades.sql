CREATE TABLE `lucky_box_monthly_reset` (
	`id` int AUTO_INCREMENT NOT NULL,
	`year` int NOT NULL,
	`month` int NOT NULL,
	`reset_at` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lucky_box_monthly_reset_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lucky_box_openings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`opened_at` timestamp NOT NULL DEFAULT (now()),
	`is_winner` boolean NOT NULL DEFAULT false,
	`prize_amount` int DEFAULT 0,
	`reference_id` varchar(32),
	`screenshot_sent` boolean NOT NULL DEFAULT false,
	`year` int NOT NULL,
	`month` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lucky_box_openings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `monthly_prize_pool` (
	`id` int AUTO_INCREMENT NOT NULL,
	`year` int NOT NULL,
	`month` int NOT NULL,
	`ad_revenue` int NOT NULL DEFAULT 0,
	`prize_percentage` int NOT NULL DEFAULT 20,
	`total_prize_pool` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `monthly_prize_pool_id` PRIMARY KEY(`id`)
);
