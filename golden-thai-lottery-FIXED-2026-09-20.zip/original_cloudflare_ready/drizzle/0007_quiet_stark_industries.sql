ALTER TABLE `lucky_number_log` MODIFY COLUMN `type` enum('lucky_number_7d','lucky_number_draw_day','weekly_3d') NOT NULL;--> statement-breakpoint
ALTER TABLE `user_notifications` MODIFY COLUMN `type` enum('lucky_number_7d','lucky_number_draw_day','lottery_result','weekly_3d') NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `weekly_lucky_enabled` boolean DEFAULT true NOT NULL;