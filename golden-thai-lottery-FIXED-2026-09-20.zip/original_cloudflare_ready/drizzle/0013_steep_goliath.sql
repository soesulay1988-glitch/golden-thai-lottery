ALTER TABLE `mahaboke_readings` ADD `family_mm` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `family_en` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `education_mm` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `education_en` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `travel_mm` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `travel_en` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `spiritual_mm` text;--> statement-breakpoint
ALTER TABLE `mahaboke_readings` ADD `spiritual_en` text;