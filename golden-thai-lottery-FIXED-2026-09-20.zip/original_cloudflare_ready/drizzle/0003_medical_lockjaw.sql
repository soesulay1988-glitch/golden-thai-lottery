CREATE TABLE `lucky_number_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`draw_date` varchar(10) NOT NULL,
	`type` enum('lucky_number_7d','lucky_number_draw_day') NOT NULL,
	`lucky_number` varchar(3) NOT NULL,
	`sentAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lucky_number_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`type` enum('lucky_number_7d','lucky_number_draw_day') NOT NULL,
	`title` varchar(256) NOT NULL,
	`body` text NOT NULL,
	`lucky_number` varchar(3),
	`draw_date` varchar(10),
	`is_read` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `saved_tickets` MODIFY COLUMN `draw_date` varchar(10) NOT NULL;