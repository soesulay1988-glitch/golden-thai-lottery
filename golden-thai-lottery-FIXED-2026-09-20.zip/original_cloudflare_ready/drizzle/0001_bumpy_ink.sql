CREATE TABLE `horoscope_readings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`week_start` date NOT NULL,
	`birth_day` enum('sunday','monday','tuesday','wednesday_am','wednesday_pm','thursday','friday','saturday') NOT NULL,
	`forecast_en` text NOT NULL,
	`forecast_mm` text NOT NULL,
	`lucky_color` varchar(64),
	`lucky_color_mm` varchar(64),
	`lucky_direction` varchar(64),
	`lucky_direction_mm` varchar(64),
	`auspicious_numbers` json,
	`lottery_numbers` json,
	`overall_rating` int DEFAULT 3,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `horoscope_readings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `myanmar_2d_results` (
	`id` int AUTO_INCREMENT NOT NULL,
	`result_date` date NOT NULL,
	`session` enum('morning','evening') NOT NULL,
	`winning_number` varchar(2) NOT NULL,
	`set_number` varchar(16),
	`value_number` varchar(16),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `myanmar_2d_results_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `thai_lottery_draws` (
	`id` int AUTO_INCREMENT NOT NULL,
	`draw_date` date NOT NULL,
	`first_prize` varchar(6),
	`near_first_prize` json,
	`first_three_digits` json,
	`last_three_digits` json,
	`last_two_digits` varchar(2),
	`second_prize` json,
	`third_prize` json,
	`fourth_prize` json,
	`fifth_prize` json,
	`is_published` boolean NOT NULL DEFAULT false,
	`source` varchar(128) DEFAULT 'manual',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `thai_lottery_draws_id` PRIMARY KEY(`id`)
);
