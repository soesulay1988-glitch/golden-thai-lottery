ALTER TABLE `lucky_box_openings` ADD `qr_token` varchar(64);--> statement-breakpoint
ALTER TABLE `lucky_box_openings` ADD `claimant_phone` varchar(32);--> statement-breakpoint
ALTER TABLE `lucky_box_openings` ADD `claimed_at` timestamp;