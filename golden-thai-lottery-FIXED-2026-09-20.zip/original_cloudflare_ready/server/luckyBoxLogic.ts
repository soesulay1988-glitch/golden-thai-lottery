export const DEFAULT_LUCKY_BOX_WIN_CHANCE = 2;

export function normalizeLuckyBoxWinChance(value: unknown): number {
  const numeric = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(numeric)) return DEFAULT_LUCKY_BOX_WIN_CHANCE;
  return Math.min(100, Math.max(0, numeric));
}

export function isLuckyBoxWinner(winChance: number, roll = Math.random() * 100): boolean {
  return roll < normalizeLuckyBoxWinChance(winChance);
}

export function canAwardLuckyBoxCoins(monthlyBudget: number, spentCoins: number, prizeAmount: number): boolean {
  return prizeAmount > 0 && spentCoins + prizeAmount <= Math.max(0, monthlyBudget);
}
