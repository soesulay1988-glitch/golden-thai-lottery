import { describe, expect, it } from "vitest";
import { generateLocalMahabokeReading, getSevenDayPeriodStart } from "./mahabokeLocal";

const base = {
  birthDay: 15,
  birthMonth: 4,
  birthYear: 1990,
  age: 36,
  dayOfWeek: 0,
  birthNameMm: "တနင်္ဂနွေ (ဂဠုန်)",
  birthNameEn: "Sunday (Garuda)",
  rulingPlanetMm: "နေ (Sun)",
  rulingPlanetEn: "Sun",
};

describe("local Mahaboke", () => {
  it("returns the same complete reading for the same person and period", () => {
    const input = { ...base, periodStart: "2026-09-10" };
    const first = generateLocalMahabokeReading(input);
    const second = generateLocalMahabokeReading(input);
    expect(second).toEqual(first);
    expect(first.personalityMm.length).toBeGreaterThan(180);
    expect(first.careerMm.length).toBeGreaterThan(200);
    expect(first.financeMm.length).toBeGreaterThan(200);
    expect(first.weeklyMessageMm.length).toBeGreaterThan(400);
    expect(first.lucky2dNumbers).toHaveLength(3);
  });

  it("changes the reading after the seven-day period changes", () => {
    const first = generateLocalMahabokeReading({ ...base, periodStart: "2026-09-10" });
    const next = generateLocalMahabokeReading({ ...base, periodStart: "2026-09-17" });
    expect(next).not.toEqual(first);
  });

  it("changes the reading when age changes", () => {
    const first = generateLocalMahabokeReading({ ...base, periodStart: "2026-09-10" });
    const older = generateLocalMahabokeReading({ ...base, age: 37, periodStart: "2026-09-10" });
    expect(older).not.toEqual(first);
  });

  it("groups dates into stable seven-day periods", () => {
    const start = getSevenDayPeriodStart(new Date("2026-09-13T12:00:00Z"));
    expect(getSevenDayPeriodStart(new Date("2026-09-14T12:00:00Z"))).toBe(start);
    expect(getSevenDayPeriodStart(new Date("2026-09-20T12:00:00Z"))).not.toBe(start);
  });
});
