import { describe, it, expect } from "vitest";

// This mirrors the extractTicketNumber function from Lottery.tsx
// We test it here to ensure QR parsing correctness
function extractTicketNumber(rawText: string): string {
  const text = rawText.trim();

  // 1. If exactly 6 digits, return directly
  if (/^\d{6}$/.test(text)) return text;

  // 2. Try standard Data Matrix format: YY-RR-PP-NNNNNN
  const dmMatch = text.match(/^(\d{2})-(\d{1,2})-(\d{1,2})-(\d{6})$/);
  if (dmMatch) return dmMatch[4];

  // 3. Try Data Matrix without dashes: 10-12 digits, starts with valid year (60-69)
  const bareDigits = text.replace(/\D/g, "");
  if (bareDigits.length >= 10 && bareDigits.length <= 12) {
    const yearPrefix = parseInt(bareDigits.substring(0, 2));
    if (yearPrefix >= 60 && yearPrefix <= 69) {
      return bareDigits.slice(-6);
    }
  }

  // 4. If exactly 6 digits after removing non-digits, return as-is
  if (bareDigits.length === 6) return bareDigits;

  // 5. If too long (1D barcode serial) — DO NOT extract
  if (bareDigits.length > 12) {
    return "";
  }

  // 6. Try to find a 6-digit group
  const sixDigitMatch = text.match(/\d{6}/);
  if (sixDigitMatch) return sixDigitMatch[0];

  // 7. Last resort: return empty
  return "";
}

describe("extractTicketNumber", () => {
  // ─── Standard 6-digit input ─────────────────────────────
  it("returns the number when exactly 6 digits provided", () => {
    expect(extractTicketNumber("842054")).toBe("842054");
  });

  it("handles numbers starting with zeros", () => {
    expect(extractTicketNumber("008356")).toBe("008356");
  });

  // ─── Standard Data Matrix format: YY-RR-PP-NNNNNN ──────
  it("extracts lottery number from standard Data Matrix format", () => {
    // 69-15-09-842054 → lottery number 842054
    expect(extractTicketNumber("69-15-09-842054")).toBe("842054");
  });

  it("handles Data Matrix with single-digit round/pack", () => {
    expect(extractTicketNumber("69-1-3-842054")).toBe("842054");
  });

  it("extracts lottery number from older Data Matrix", () => {
    expect(extractTicketNumber("62-08-15-349781")).toBe("349781");
  });

  // ─── Data Matrix without dashes (concatenated) ──────────
  it("extracts from concatenated Data Matrix (10 digits, valid year)", () => {
    // 69-1-3-842054 without dashes = 6913842054 (10 digits)
    expect(extractTicketNumber("6913842054")).toBe("842054");
  });

  it("extracts from concatenated Data Matrix (12 digits, valid year)", () => {
    // 69-15-09-842054 without dashes = 691509842054 (12 digits)
    expect(extractTicketNumber("691509842054")).toBe("842054");
  });

  it("rejects concatenated string with invalid year prefix", () => {
    // 26-2931-666888-2806 → starts with 26, not 60-69 → rejected
    expect(extractTicketNumber("2629316668882806")).toBe("");
  });

  // ─── 1D Barcode (serial number) — should be REJECTED ───
  it("rejects 1D barcode serial numbers (too long)", () => {
    // "2629316668882806-2603" → bareDigits = "26293166688828062603" (18 digits)
    expect(extractTicketNumber("2629316668882806-2603")).toBe("");
  });

  it("rejects long numeric barcode without dashes", () => {
    expect(extractTicketNumber("26293166688828062603")).toBe("");
  });

  // ─── Edge cases ─────────────────────────────────────────
  it("handles empty string", () => {
    expect(extractTicketNumber("")).toBe("");
  });

  it("handles non-numeric text", () => {
    expect(extractTicketNumber("NO NUMBERS HERE")).toBe("");
  });

  it("returns 6 digits after stripping non-digits", () => {
    expect(extractTicketNumber("TGL842054")).toBe("842054");
  });

  it("handles Data Matrix with alphanumeric prefix (GS1-like)", () => {
    expect(extractTicketNumber("GLO69-15-09-842054")).toBe("842054");
  });
});
