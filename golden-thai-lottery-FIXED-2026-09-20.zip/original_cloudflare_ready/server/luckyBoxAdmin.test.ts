import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createNonOwnerContext(): TrpcContext {
  return {
    user: {
      id: 42,
      openId: "non-owner",
      email: "member@example.com",
      name: "Member",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createAnonymousContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Lucky Box owner-admin controls", () => {
  it("rejects a non-owner admin before a win chance change is saved", async () => {
    const caller = appRouter.createCaller(createNonOwnerContext());

    await expect(caller.adminLuckyBox.setWinChance({ percentage: 50 })).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("rejects a non-owner admin before a custom broadcast can be sent", async () => {
    const caller = appRouter.createCaller(createNonOwnerContext());

    await expect(caller.adminLuckyBox.sendBroadcast({
      title: "Golden Thai",
      message: "Announcement",
      url: "/",
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects a non-owner admin before winner Coins and prize details are read", async () => {
    const caller = appRouter.createCaller(createNonOwnerContext());

    await expect(caller.adminLuckyBox.getAllWinners()).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("rejects a non-owner admin before a user-supplied Prize ID is looked up", async () => {
    const caller = appRouter.createCaller(createNonOwnerContext());

    await expect(caller.adminLuckyBox.getWinnerByRefId({
      referenceId: "LB20260904-G-TEST-1234",
    })).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("rejects a non-owner admin before a winner payment status is changed", async () => {
    const caller = appRouter.createCaller(createNonOwnerContext());

    await expect(caller.adminLuckyBox.setWinnerPaidStatus({
      id: 1,
      paid: true,
    })).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
  });

  it("requires sign-in before a user can read their own Lucky Box prize history", async () => {
    const caller = appRouter.createCaller(createAnonymousContext());

    await expect(caller.luckyBox.getHistory()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });

  it("rejects malformed guest device IDs before guest winner history is queried", async () => {
    const caller = appRouter.createCaller(createAnonymousContext());

    await expect(caller.luckyBox.getGuestWinnerHistory({
      guestDeviceId: "short-id",
    })).rejects.toMatchObject({
      code: "BAD_REQUEST",
    });
  });
});
