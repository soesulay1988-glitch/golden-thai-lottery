import { describe, expect, it } from "vitest";
import { parseModelJsonObject } from "./routers";

describe("Mahaboke AI response parsing", () => {
  it("reads a JSON object wrapped in a markdown code fence", () => {
    expect(parseModelJsonObject("```json\n{\"personalityMm\":\"အဖြေ\"}\n```"))
      .toEqual({ personalityMm: "အဖြေ" });
  });

  it("joins structured text parts before parsing the JSON object", () => {
    expect(parseModelJsonObject([
      { type: "text", text: "{\"overallFortune\":" },
      { type: "text", text: "4}" },
    ])).toEqual({ overallFortune: 4 });
  });

  it("rejects malformed model output so Mahaboke can use its local fallback", () => {
    expect(() => parseModelJsonObject("အဖြေမရှိပါ")).toThrow("does not contain a JSON object");
  });
});
