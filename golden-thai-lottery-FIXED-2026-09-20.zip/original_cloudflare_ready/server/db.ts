import { eq, asc, desc, and, gt, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  thaiLotteryDraws,
  myanmar2dResults,
  horoscopeReadings,
  mahabokeReadings,
  InsertThaiLotteryDraw,
  ThaiLotteryDraw,
  InsertMyanmar2dResult,
  InsertHoroscopeReading,
  InsertMahabokeReading,
} from "../drizzle/schema";
import {
  savedTickets,
  InsertSavedTicket,
} from "../drizzle/schema";
import {
  userNotifications,
  InsertUserNotification,
  luckyNumberLog,
  InsertLuckyNumberLog,
  lotteryResultNotificationLog,
  InsertLotteryResultNotificationLog,
  pushSubscriptions,
  InsertPushSubscription,
  calendar3d,
  InsertCalendar3d,
  users as usersTable,
  twoDChatMessages,
  InsertTwoDChatMessage,
  TwoDChatMessage,
  myanmar2dNotificationLog,
  InsertMyanmar2dNotificationLog,
  luckyBoxOpenings,
  InsertLuckyBoxOpening,
  monthlyPrizePool,
  InsertMonthlyPrizePool,
  luckyBoxMonthlyReset,
  InsertLuckyBoxMonthlyReset,
  appSettings,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import {
  CALENDAR_2026_REFERENCE,
  CALENDAR_2026_REFERENCE_LAST_DRAW_DATE,
} from "../shared/calendar3dReference";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ─────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
    else if (user.email === "soesulay1988@gmail.com") { values.role = "admin"; updateSet.role = "admin"; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    try {
      await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
    } catch (error) {
      // If duplicate key error, try to update instead
      if (error instanceof Error && error.message.includes("Duplicate entry")) {
        console.log("[Database] Duplicate entry detected, updating existing user");
        await db.update(users).set(updateSet).where(eq(users.openId, user.openId));
      } else {
        throw error;
      }
    }
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Thai Lottery ───────────────────────────────────────────────────────────
// MySQL drivers can return JSON columns as serialized strings. The lottery
// page uses .map/.includes, so normalize every prize list before tRPC returns it.
function parsePrizeArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String);
  if (typeof value !== "string" || !value.trim()) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
}

function normalizeThaiLotteryDraw(draw: ThaiLotteryDraw): ThaiLotteryDraw {
  return {
    ...draw,
    nearFirstPrize: parsePrizeArray(draw.nearFirstPrize),
    firstThreeDigits: parsePrizeArray(draw.firstThreeDigits),
    lastThreeDigits: parsePrizeArray(draw.lastThreeDigits),
    secondPrize: parsePrizeArray(draw.secondPrize),
    thirdPrize: parsePrizeArray(draw.thirdPrize),
    fourthPrize: parsePrizeArray(draw.fourthPrize),
    fifthPrize: parsePrizeArray(draw.fifthPrize),
  };
}

export async function getLatestThaiLotteryDraw() {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(thaiLotteryDraws)
    .where(eq(thaiLotteryDraws.isPublished, true))
    .orderBy(desc(thaiLotteryDraws.drawDate))
    .limit(1);
  return result[0] ? normalizeThaiLotteryDraw(result[0]) : null;
}

export async function getThaiLotteryDrawByDate(drawDate: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(thaiLotteryDraws)
    .where(sql`${thaiLotteryDraws.drawDate} = ${drawDate}`)
    .limit(1);
  return result[0] ? normalizeThaiLotteryDraw(result[0]) : null;
}

export async function listThaiLotteryDrawDates() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: thaiLotteryDraws.id,
      drawDate: thaiLotteryDraws.drawDate,
      firstPrize: thaiLotteryDraws.firstPrize,
    })
    .from(thaiLotteryDraws)
    .orderBy(desc(thaiLotteryDraws.drawDate))
    .limit(24);
}

export async function upsertThaiLotteryDraw(data: InsertThaiLotteryDraw) {
  const db = await getDb();
  if (!db) return;
  await db.insert(thaiLotteryDraws).values(data).onDuplicateKeyUpdate({ set: { ...data } });
}

// ─── Myanmar 2D ─────────────────────────────────────────────────────────────
export async function getLatestMyanmar2dResults() {
  const db = await getDb();
  if (!db) return [];
  // Use Myanmar timezone (UTC+6:30) to get the correct "today" date
  const myanmarNow = new Date(new Date().getTime() + 6.5 * 60 * 60 * 1000);
  const todayStr = myanmarNow.toISOString().split("T")[0];
  const weekAgo = new Date(myanmarNow.getTime());
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoStr = weekAgo.toISOString().split("T")[0];
  return db
    .select()
    .from(myanmar2dResults)
    .where(and(
      sql`${myanmar2dResults.resultDate} >= ${weekAgoStr}`,
      sql`${myanmar2dResults.resultDate} <= ${todayStr}`
    ))
    .orderBy(desc(myanmar2dResults.resultDate), desc(myanmar2dResults.session))
    .limit(14);
}

export async function getMyanmar2dHistory(page = 1, pageSize = 20) {
  const db = await getDb();
  if (!db) return { results: [], total: 0 };
  const offset = (page - 1) * pageSize;
  const results = await db
    .select()
    .from(myanmar2dResults)
    .orderBy(desc(myanmar2dResults.resultDate), desc(myanmar2dResults.session))
    .limit(pageSize)
    .offset(offset);
  // Get real total count for proper pagination
  const countResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(myanmar2dResults);
  const total = Number(countResult[0]?.count ?? 0);
  return { results, total };
}

// ─── Myanmar 2D Hot/Cold Analysis ───────────────────────────────────────
export async function getMyanmar2dAnalysis() {
  const db = await getDb();
  if (!db) return null;

  // Fetch last 60 rows (~30 days) for analysis
  const rows = await db
    .select()
    .from(myanmar2dResults)
    .orderBy(desc(myanmar2dResults.resultDate), desc(myanmar2dResults.session))
    .limit(60);

  if (rows.length === 0) return null;

  // Count frequency of each 2D number
  const freqMap = new Map<string, number>();
  const singleDigitFreq = new Map<string, number>();
  // Track consecutive pairs (e.g., "42,16")
  const pairMap = new Map<string, number>();

  let prevNumber = "";
  for (const r of rows) {
    const num = String(r.winningNumber).padStart(2, "0");
    freqMap.set(num, (freqMap.get(num) ?? 0) + 1);

    // Single digit frequency (0-9)
    for (const d of num) {
      singleDigitFreq.set(d, (singleDigitFreq.get(d) ?? 0) + 1);
    }

    // Consecutive pairs
    if (prevNumber) {
      const pair = `${prevNumber}-${num}`;
      pairMap.set(pair, (pairMap.get(pair) ?? 0) + 1);
    }
    prevNumber = num;
  }

  // Sort by frequency
  const hotNumbers = Array.from(freqMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([num, count]) => ({ number: num, count }));

  const coldNumbers = Array.from(freqMap.entries())
    .sort((a, b) => a[1] - b[1])
    .slice(0, 6)
    .map(([num, count]) => ({ number: num, count }));

  // Top consecutive pairs
  const consecutivePairs = Array.from(pairMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([pair, count]) => ({ pair, count }));

  // All 00-99 frequency for frequency bars
  const allFrequencies: { number: string; count: number }[] = [];
  for (let i = 0; i < 100; i++) {
    const num = String(i).padStart(2, "0");
    allFrequencies.push({ number: num, count: freqMap.get(num) ?? 0 });
  }

  // Single digit analysis (0-9)
  const digitAnalysis = Array.from(singleDigitFreq.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([digit, count]) => ({ digit, count }));

  const totalResults = rows.length;
  const dateRange = {
    from: typeof rows[rows.length - 1].resultDate === "string"
      ? String(rows[rows.length - 1].resultDate)
      : (rows[rows.length - 1].resultDate as Date).toISOString().split("T")[0],
    to: typeof rows[0].resultDate === "string"
      ? String(rows[0].resultDate)
      : (rows[0].resultDate as Date).toISOString().split("T")[0],
  };

  return {
    hotNumbers,
    coldNumbers,
    consecutivePairs,
    allFrequencies,
    digitAnalysis,
    totalResults,
    dateRange,
  };
}

export async function insertMyanmar2dResult(data: InsertMyanmar2dResult) {
  const db = await getDb();
  if (!db) return;
  await db.insert(myanmar2dResults).values(data);
}

// ─── Horoscope ──────────────────────────────────────────────────────────────
export async function getWeeklyHoroscope(weekStart: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(horoscopeReadings)
    .where(sql`${horoscopeReadings.weekStart} = ${weekStart}`)
    .orderBy(horoscopeReadings.birthDay);
}

export async function getLatestHoroscope() {
  const db = await getDb();
  if (!db) return [];
  const latest = await db
    .select({ weekStart: horoscopeReadings.weekStart })
    .from(horoscopeReadings)
    .orderBy(sql`${horoscopeReadings.weekStart} DESC`)
    .limit(1);
  if (!latest[0]) return [];
  return db
    .select()
    .from(horoscopeReadings)
    .where(sql`${horoscopeReadings.weekStart} = ${latest[0].weekStart}`);
}

export async function upsertHoroscopeReading(data: InsertHoroscopeReading) {
  const db = await getDb();
  if (!db) return;
  await db.insert(horoscopeReadings).values(data).onDuplicateKeyUpdate({ set: { ...data } });
}

// ─── Mahaboke ───────────────────────────────────────────────────────────────
export async function getMahabokeReading(
  userId: number,
  deviceId: string | null,
  birthDay: string,
  birthDayOfMonth: number,
  birthMonth: number,
  birthYear: number,
  weekStart: string
) {
  const db = await getDb();
  if (!db) return null;
  // Use single owner key: userId for logged-in users, deviceId for guests
  const ownerCondition = userId > 0
    ? eq(mahabokeReadings.userId, userId)
    : deviceId
      ? eq(mahabokeReadings.deviceId, deviceId)
      : sql`1=0`; // no owner = no cache
  const rows = await db
    .select()
    .from(mahabokeReadings)
    .where(
      and(
        ownerCondition,
        eq(mahabokeReadings.birthDay, birthDay as any),
        eq(mahabokeReadings.birthDayOfMonth, birthDayOfMonth),
        eq(mahabokeReadings.birthMonth, birthMonth),
        eq(mahabokeReadings.birthYear, birthYear),
        eq(mahabokeReadings.weekStart, weekStart)
      )
    )
    .limit(1);
  return rows[0] || null;
}

export async function saveMahabokeReading(data: InsertMahabokeReading) {
  const db = await getDb();
  if (!db) return;
  const { id: _id, createdAt: _createdAt, updatedAt: _updatedAt, ...rest } = data as any;
  await db.insert(mahabokeReadings).values(rest).onDuplicateKeyUpdate({ set: rest });
}

// ─── Saved Tickets ──────────────────────────────────────────────────────────
export async function getSavedTicketsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(savedTickets)
    .where(eq(savedTickets.userId, userId))
    .orderBy(desc(savedTickets.createdAt));
}

export async function addSavedTicket(data: InsertSavedTicket) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(savedTickets).values(data);
  return result;
}

export async function deleteSavedTicket(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(savedTickets).where(and(eq(savedTickets.id, id), eq(savedTickets.userId, userId)));
}

export async function updateSavedTicketResult(
  id: number,
  userId: number,
  prizeResult: { prize: string; prizeEn: string; prizeMm: string; amount: string }[] | null
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(savedTickets)
    .set({ isChecked: true, prizeResult })
    .where(and(eq(savedTickets.id, id), eq(savedTickets.userId, userId)));
}

// ─── User Notifications ─────────────────────────────────────────────────────
export async function insertUserNotification(data: InsertUserNotification) {
  const db = await getDb();
  if (!db) return;
  await db.insert(userNotifications).values(data);
}

export async function getUserNotifications(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(userNotifications)
    .where(eq(userNotifications.userId, userId))
    .orderBy(desc(userNotifications.createdAt))
    .limit(limit);
}

export async function markNotificationRead(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(userNotifications)
    .set({ isRead: true })
    .where(and(eq(userNotifications.id, id), eq(userNotifications.userId, userId)));
}

export async function markAllNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(userNotifications)
    .set({ isRead: true })
    .where(eq(userNotifications.userId, userId));
}

export async function getUnreadNotificationCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(userNotifications)
    .where(and(eq(userNotifications.userId, userId), eq(userNotifications.isRead, false)));
  return Number(result[0]?.count ?? 0);
}

// ─── Lucky Number Log (idempotency) ─────────────────────────────────────────
export async function insertLuckyNumberLog(data: InsertLuckyNumberLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(luckyNumberLog).values(data);
}

export async function hasLuckyNumberBeenSent(
  userId: number,
  drawDate: string,
  type: "lucky_number_7d" | "lucky_number_draw_day" | "weekly_3d" | "thai_3d_morning"
) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select({ id: luckyNumberLog.id })
    .from(luckyNumberLog)
    .where(
      and(
        eq(luckyNumberLog.userId, userId),
        eq(luckyNumberLog.drawDate, drawDate),
        eq(luckyNumberLog.type, type)
      )
    )
    .limit(1);
  return result.length > 0;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: users.id, name: users.name, weeklyLuckyEnabled: users.weeklyLuckyEnabled }).from(users);
}

export async function getWeeklyLuckyEnabledUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: users.id, name: users.name })
    .from(users)
    .where(eq(users.weeklyLuckyEnabled, true));
}

export async function setWeeklyLuckyPreference(userId: number, enabled: boolean) {
  const db = await getDb();
  if (!db) return;
  await db.update(users)
    .set({ weeklyLuckyEnabled: enabled })
    .where(eq(users.id, userId));
}

export async function getWeeklyLuckyPreference(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return true; // default to enabled
  const result = await db.select({ weeklyLuckyEnabled: users.weeklyLuckyEnabled })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  return result[0]?.weeklyLuckyEnabled ?? true;
}

// ─── Lottery Result Notification Log ───────────────────────────────────────
export async function insertLotteryResultNotificationLog(data: InsertLotteryResultNotificationLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(lotteryResultNotificationLog).values(data);
}

export async function hasResultNotified(userId: number, drawDate: string) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select({ id: lotteryResultNotificationLog.id })
    .from(lotteryResultNotificationLog)
    .where(
      and(
        eq(lotteryResultNotificationLog.userId, userId),
        eq(lotteryResultNotificationLog.drawDate, drawDate)
      )
    )
    .limit(1);
  return result.length > 0;
}

// ─── Myanmar 2D Notification Log ──────────────────────────────────────────
export async function insertMyanmar2dNotificationLog(data: InsertMyanmar2dNotificationLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(myanmar2dNotificationLog).values(data);
}

export async function has2dResultNotified(userId: number, resultDate: string, session: "morning" | "evening" | "session1" | "session2" | "session3" | "session4") {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select({ id: myanmar2dNotificationLog.id })
    .from(myanmar2dNotificationLog)
    .where(
      and(
        eq(myanmar2dNotificationLog.userId, userId),
        eq(myanmar2dNotificationLog.resultDate, resultDate),
        eq(myanmar2dNotificationLog.session, session)
      )
    )
    .limit(1);
  return result.length > 0;
}

// ─── Web Push Subscriptions ────────────────────────────────────────────────
export async function savePushSubscription(data: InsertPushSubscription) {
  const db = await getDb();
  if (!db) return;
  // Upsert: delete old subscriptions with same endpoint, then insert new
  await db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, data.endpoint));
  await db.insert(pushSubscriptions).values(data);
}

export async function removePushSubscription(userId: number, endpoint: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(pushSubscriptions).where(
    and(eq(pushSubscriptions.userId, userId), eq(pushSubscriptions.endpoint, endpoint))
  );
}

export async function getAllPushSubscriptions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pushSubscriptions);
}

export async function getPushSubscriptionsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));
}

// ─── Calendar 3D ──────────────────────────────────────────────────────────────
type CalendarDrawSource = {
  drawDate: unknown;
  firstPrize: string | null;
};

type Calendar3dRow = {
  row: number;
  value: string;
};

function getCalendarDrawDateKey(drawDate: unknown): string {
  if (drawDate instanceof Date) return drawDate.toISOString().slice(0, 10);
  return String(drawDate).slice(0, 10);
}

function buildCalendar3dRows(year: number, draws: CalendarDrawSource[]): Calendar3dRow[] {
  // Keep one valid result per draw date, in chronological order. This avoids
  // duplicate source records consuming an extra calendar row.
  const entries: Array<{ value: string; drawDateKey: string }> = [];
  const seenDrawDates = new Set<string>();
  for (const draw of draws) {
    if (!/^\d{6}$/.test(draw.firstPrize ?? "")) continue;

    const drawDateKey = getCalendarDrawDateKey(draw.drawDate);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(drawDateKey) || seenDrawDates.has(drawDateKey)) continue;

    seenDrawDates.add(drawDateKey);
    entries.push({ value: draw.firstPrize!.slice(-3), drawDateKey });
  }

  // The 2026 table already has a screenshot-verified prefix. Keep it stable,
  // then append later chronological draws from the source data. This makes
  // both the API and the database rebuild repair old day-of-month rows.
  if (year === 2026) {
    return [
      ...Object.entries(CALENDAR_2026_REFERENCE).map(([row, value]) => ({
        row: Number(row),
        value,
      })),
      ...entries
        .filter((entry) => entry.drawDateKey > CALENDAR_2026_REFERENCE_LAST_DRAW_DATE)
        .map((entry, index) => ({
          row: Object.keys(CALENDAR_2026_REFERENCE).length + index + 1,
          value: entry.value,
        })),
    ];
  }

  return entries.map((entry, index) => ({ row: index + 1, value: entry.value }));
}

export async function getCalendar3dData(year: number) {
  const db = await getDb();
  if (!db) return [];

  if (year === 2026) {
    const draws = await db
      .select({ drawDate: thaiLotteryDraws.drawDate, firstPrize: thaiLotteryDraws.firstPrize })
      .from(thaiLotteryDraws)
      .where(sql`YEAR(${thaiLotteryDraws.drawDate}) = ${year}`)
      .orderBy(asc(thaiLotteryDraws.drawDate));
    return buildCalendar3dRows(year, draws);
  }

  return db
    .select({ row: calendar3d.row, value: calendar3d.value })
    .from(calendar3d)
    .where(eq(calendar3d.year, year))
    .orderBy(calendar3d.row);
}

export async function upsertCalendar3dEntry(year: number, row: number, value: string) {
  const db = await getDb();
  if (!db) return;
  const existing = await db
    .select()
    .from(calendar3d)
    .where(and(eq(calendar3d.year, year), eq(calendar3d.row, row)))
    .limit(1);

  if (existing.length > 0) {
    await db.update(calendar3d).set({ value }).where(eq(calendar3d.id, existing[0].id));
  } else {
    await db.insert(calendar3d).values({ year, row, value });
  }
}

export async function bulkUpsertCalendar3d(entries: InsertCalendar3d[]) {
  const db = await getDb();
  if (!db) return;
  for (const entry of entries) {
    const existing = await db
      .select()
      .from(calendar3d)
      .where(and(eq(calendar3d.year, entry.year), eq(calendar3d.row, entry.row)))
      .limit(1);

    if (existing.length > 0) {
      await db.update(calendar3d).set({ value: entry.value }).where(eq(calendar3d.id, existing[0].id));
    } else {
      await db.insert(calendar3d).values(entry);
    }
  }
}

export async function getAllCalendar3dYears() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.selectDistinct({ year: calendar3d.year }).from(calendar3d).orderBy(calendar3d.year);
  return rows.map(r => r.year);
}

// Rebuild all 3D calendar entries for a given year from lottery draw data.
// Rows 01-24 are the chronological draw sequence for that year, matching the
// established calendar table format. The row is not the day of month.
// Example: the 15th draw of 2026 (16 August, first prize 004615) writes 615
// to row 15, as shown in the reference 2026 table.
export async function rebuildCalendar3dForYear(year: number) {
  const db = await getDb();
  if (!db) return 0;

  const draws = await db
    .select({ drawDate: thaiLotteryDraws.drawDate, firstPrize: thaiLotteryDraws.firstPrize })
    .from(thaiLotteryDraws)
    .where(sql`YEAR(${thaiLotteryDraws.drawDate}) = ${year}`)
    .orderBy(asc(thaiLotteryDraws.drawDate));
  const normalizedEntries = buildCalendar3dRows(year, draws);

  // Rebuild the year from source-of-truth draw data so old day-of-month rows
  // cannot continue overriding the reference sequence-based calendar.
  await db.delete(calendar3d).where(eq(calendar3d.year, year));
  for (const entry of normalizedEntries) {
    await db.insert(calendar3d).values({ year, row: entry.row, value: entry.value });
  }

  return normalizedEntries.length;
}

// ─── 2D Chat Messages ───────────────────────────────────────────────────────
export async function getTwoDChatMessages(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(twoDChatMessages)
    .orderBy(desc(twoDChatMessages.createdAt))
    .limit(limit);
}

export async function insertTwoDChatMessage(data: InsertTwoDChatMessage) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(twoDChatMessages).values(data);
  return result;
}

export async function deleteTwoDChatMessage(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(twoDChatMessages).where(eq(twoDChatMessages.id, id));
}

// Auto-delete 2D chat messages older than 7 days
export async function deleteOldChatMessages(daysOld = 7) {
  const db = await getDb();
  if (!db) return 0;
  const cutoff = new Date(Date.now() - daysOld * 24 * 60 * 60 * 1000);
  const result = await db.delete(twoDChatMessages).where(sql`${twoDChatMessages.createdAt} < ${cutoff.toISOString()}`);
  return Number(result[0]?.affectedRows ?? 0);
}

// Retain 2D morning/evening history for 60 days before automatic cleanup.
export async function deleteOld2DResults(daysOld = 60) {
  const db = await getDb();
  if (!db) return 0;
  const cutoff = new Date(Date.now() - daysOld * 24 * 60 * 60 * 1000);
  const cutoffStr = cutoff.toISOString().split("T")[0];
  const result = await db.delete(myanmar2dResults).where(sql`${myanmar2dResults.resultDate} < ${cutoffStr}`);
  return Number(result[0]?.affectedRows ?? 0);
}

// ─── Lucky Box ──────────────────────────────────────────────────────────────
export async function countTodayOpenings(userId: number, year: number, month: number, day: number) {
  const db = await getDb();
  if (!db) return 0;
  const todayStart = new Date(year, month - 1, day, 0, 0, 0);
  const todayEnd = new Date(year, month - 1, day, 23, 59, 59, 999);
  const count = await db
    .select({ count: sql`count(*)` })
    .from(luckyBoxOpenings)
    .where(and(
      eq(luckyBoxOpenings.userId, userId),
      gte(luckyBoxOpenings.openedAt, todayStart),
      lte(luckyBoxOpenings.openedAt, todayEnd)
    ));
  return count[0]?.count as number ?? 0;
}


export async function countLuckyBoxOpeningsBySlot(userId: number, slotKey: string) {
  const db = await getDb();
  if (!db) return 0;
  const count = await db
    .select({ count: sql`count(*)` })
    .from(luckyBoxOpenings)
    .where(and(eq(luckyBoxOpenings.userId, userId), eq(luckyBoxOpenings.slotKey, slotKey)));
  return count[0]?.count as number ?? 0;
}

export async function countMonthWins(userId: number, year: number, month: number) {
  const db = await getDb();
  if (!db) return 0;
  const count = await db
    .select({ count: sql`count(*)` })
    .from(luckyBoxOpenings)
    .where(and(
      eq(luckyBoxOpenings.userId, userId),
      eq(luckyBoxOpenings.year, year),
      eq(luckyBoxOpenings.month, month),
      eq(luckyBoxOpenings.isWinner, true)
    ));
  return count[0]?.count as number ?? 0;
}

export async function insertLuckyBoxOpening(data: InsertLuckyBoxOpening) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(luckyBoxOpenings).values(data);
  return result;
}

export async function getLuckyBoxOpenings(userId: number, limit = 30) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(luckyBoxOpenings)
    .where(eq(luckyBoxOpenings.userId, userId))
    .orderBy(desc(luckyBoxOpenings.createdAt))
    .limit(limit);
}

export async function getGuestLuckyBoxWinnerHistory(guestDeviceId: string, limit = 30) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select({
      id: luckyBoxOpenings.id,
      guestDeviceId: luckyBoxOpenings.guestDeviceId,
      openedAt: luckyBoxOpenings.openedAt,
      isWinner: luckyBoxOpenings.isWinner,
      prizeAmount: luckyBoxOpenings.prizeAmount,
      referenceId: luckyBoxOpenings.referenceId,
      claimedAt: luckyBoxOpenings.claimedAt,
      paidAt: luckyBoxOpenings.paidAt,
    })
    .from(luckyBoxOpenings)
    .where(and(
      eq(luckyBoxOpenings.guestDeviceId, guestDeviceId),
      eq(luckyBoxOpenings.isWinner, true),
    ))
    .orderBy(desc(luckyBoxOpenings.createdAt))
    .limit(limit);
}

// Get recent guest openings (for rate limiting)
export async function getRecentGuestOpenings(guestDeviceId: string, limit = 1) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(luckyBoxOpenings)
    .where(eq(luckyBoxOpenings.guestDeviceId, guestDeviceId))
    .orderBy(desc(luckyBoxOpenings.openedAt))
    .limit(limit);
}

// Guest device-based counting — for users who haven't logged in
export async function countTodayOpeningsByDevice(guestDeviceId: string, year: number, month: number, day: number) {
  const db = await getDb();
  if (!db) return 0;
  const todayStart = new Date(year, month - 1, day, 0, 0, 0);
  const todayEnd = new Date(year, month - 1, day, 23, 59, 59, 999);
  try {
    const count = await db
      .select({ count: sql`count(*)` })
      .from(luckyBoxOpenings)
      .where(and(
        eq(luckyBoxOpenings.guestDeviceId, guestDeviceId),
        gte(luckyBoxOpenings.openedAt, todayStart),
        lte(luckyBoxOpenings.openedAt, todayEnd)
      ));
    return count[0]?.count as number ?? 0;
  } catch (error) {
    console.error("[Database] Failed to count today openings by device:", error);
    return 0;
  }
}


export async function countLuckyBoxOpeningsByDeviceAndSlot(guestDeviceId: string, slotKey: string) {
  const db = await getDb();
  if (!db) return 0;
  const count = await db
    .select({ count: sql`count(*)` })
    .from(luckyBoxOpenings)
    .where(and(eq(luckyBoxOpenings.guestDeviceId, guestDeviceId), eq(luckyBoxOpenings.slotKey, slotKey)));
  return count[0]?.count as number ?? 0;
}

export async function countMonthWinsByDevice(guestDeviceId: string, year: number, month: number) {
  const db = await getDb();
  if (!db) return 0;
  const count = await db
    .select({ count: sql`count(*)` })
    .from(luckyBoxOpenings)
    .where(and(
      eq(luckyBoxOpenings.guestDeviceId, guestDeviceId),
      eq(luckyBoxOpenings.year, year),
      eq(luckyBoxOpenings.month, month),
      eq(luckyBoxOpenings.isWinner, true)
    ));
  return count[0]?.count as number ?? 0;
}

// Get stats for a guest device (used by frontend to show daily limit)
export async function getGuestLuckyBoxStats(guestDeviceId: string, year: number, month: number, day: number) {
  const db = await getDb();
  if (!db) return { todayOpenings: 0, hasWonThisMonth: false };
  const todayStart = new Date(year, month - 1, day, 0, 0, 0);
  const todayEnd = new Date(year, month - 1, day, 23, 59, 59, 999);
  try {
    const todayCount = await db
      .select({ count: sql`count(*)` })
      .from(luckyBoxOpenings)
      .where(and(
        eq(luckyBoxOpenings.guestDeviceId, guestDeviceId),
        gte(luckyBoxOpenings.openedAt, todayStart),
        lte(luckyBoxOpenings.openedAt, todayEnd)
      ));
    const monthWinCount = await db
      .select({ count: sql`count(*)` })
      .from(luckyBoxOpenings)
      .where(and(
        eq(luckyBoxOpenings.guestDeviceId, guestDeviceId),
        eq(luckyBoxOpenings.year, year),
        eq(luckyBoxOpenings.month, month),
        eq(luckyBoxOpenings.isWinner, true)
      ));
    return {
      todayOpenings: todayCount[0]?.count as number ?? 0,
      hasWonThisMonth: (monthWinCount[0]?.count as number ?? 0) > 0,
    };
  } catch (error) {
    console.error("[Database] Failed to get guest lucky box stats:", error);
    return { todayOpenings: 0, hasWonThisMonth: false };
  }
}

export async function getMonthlyPrizePool(year: number, month: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select()
    .from(monthlyPrizePool)
    .where(and(eq(monthlyPrizePool.year, year), eq(monthlyPrizePool.month, month)))
    .limit(1);
  return rows[0] ?? null;
}

export async function upsertMonthlyPrizePool(data: InsertMonthlyPrizePool) {
  const db = await getDb();
  if (!db) return;
  const existing = await db
    .select()
    .from(monthlyPrizePool)
    .where(and(eq(monthlyPrizePool.year, data.year), eq(monthlyPrizePool.month, data.month)))
    .limit(1);

  if (existing.length > 0) {
    await db.update(monthlyPrizePool).set(data).where(eq(monthlyPrizePool.id, existing[0].id));
  } else {
    await db.insert(monthlyPrizePool).values(data);
  }
}

export async function isMonthlyResetDone(year: number, month: number) {
  const db = await getDb();
  if (!db) return false;
  const rows = await db
    .select()
    .from(luckyBoxMonthlyReset)
    .where(and(eq(luckyBoxMonthlyReset.year, year), eq(luckyBoxMonthlyReset.month, month)))
    .limit(1);
  return rows.length > 0;
}

export async function insertMonthlyReset(year: number, month: number) {
  const db = await getDb();
  if (!db) return;
  await db.insert(luckyBoxMonthlyReset).values({ year, month });
}

export async function getMonthlyWinners(year: number, month: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(luckyBoxOpenings)
    .where(and(
      eq(luckyBoxOpenings.year, year),
      eq(luckyBoxOpenings.month, month),
      eq(luckyBoxOpenings.isWinner, true)
    ));
}

export async function getMonthlyLuckyBoxCoinsSpent(year: number, month: number): Promise<number> {
  const winners = await getMonthlyWinners(year, month);
  return winners.reduce((total, winner) => total + (winner.prizeAmount ?? 0), 0);
}

// Get unique users who have push subscriptions
export async function getPushSubscriptionUserIds() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.selectDistinct({ userId: pushSubscriptions.userId }).from(pushSubscriptions);
  return rows.map(r => r.userId);
}

// Get all users with push subscriptions (for notification broadcast)
export async function getUsersWithPushSubscriptions() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({
      userId: pushSubscriptions.userId,
      endpoint: pushSubscriptions.endpoint,
      p256dh: pushSubscriptions.p256dh,
      auth: pushSubscriptions.auth,
    })
    .from(pushSubscriptions)
    .innerJoin(usersTable, eq(pushSubscriptions.userId, usersTable.id));
  return rows;
}

// Get all Lucky Box winners with user details for admin panel
export async function getAllLuckyBoxWinners() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: luckyBoxOpenings.id,
      userId: luckyBoxOpenings.userId,
      openedAt: luckyBoxOpenings.openedAt,
      isWinner: luckyBoxOpenings.isWinner,
      prizeAmount: luckyBoxOpenings.prizeAmount,
      referenceId: luckyBoxOpenings.referenceId,
      screenshotSent: luckyBoxOpenings.screenshotSent,
      year: luckyBoxOpenings.year,
      month: luckyBoxOpenings.month,
      qrToken: luckyBoxOpenings.qrToken,
      claimantPhone: luckyBoxOpenings.claimantPhone,
      claimedAt: luckyBoxOpenings.claimedAt,
      paidAt: luckyBoxOpenings.paidAt,
      guestDeviceId: luckyBoxOpenings.guestDeviceId,
      userName: usersTable.name,
      userEmail: usersTable.email,
      userOpenId: usersTable.openId,
    })
    .from(luckyBoxOpenings)
    .leftJoin(usersTable, eq(luckyBoxOpenings.userId, usersTable.id))
    .where(eq(luckyBoxOpenings.isWinner, true))
    .orderBy(desc(luckyBoxOpenings.createdAt))
    .limit(100);
}

export async function deleteLuckyBoxWinnerById(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .delete(luckyBoxOpenings)
    .where(and(eq(luckyBoxOpenings.id, id), eq(luckyBoxOpenings.isWinner, true)));

  return (result[0]?.affectedRows ?? 0) > 0;
}

export async function setLuckyBoxWinnerPaidStatus(id: number, paid: boolean): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .update(luckyBoxOpenings)
    .set({ paidAt: paid ? new Date() : null })
    .where(and(eq(luckyBoxOpenings.id, id), eq(luckyBoxOpenings.isWinner, true)));

  return (result[0]?.affectedRows ?? 0) > 0;
}

export async function deleteAllLuckyBoxWinnerRecords(): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .delete(luckyBoxOpenings)
    .where(eq(luckyBoxOpenings.isWinner, true));

  return result[0]?.affectedRows ?? 0;
}
// ─── Lucky Box Claim Functions ──────────────────────────────────────────────

export async function saveQrToken(openingId: number, qrToken: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(luckyBoxOpenings)
    .set({ qrToken })
    .where(eq(luckyBoxOpenings.id, openingId));
}

export async function claimPrizeByReferenceId(referenceId: string, phone: string) {
  const db = await getDb();
  if (!db) return null;

  // Find the winning opening
  const rows = await db
    .select()
    .from(luckyBoxOpenings)
    .where(eq(luckyBoxOpenings.referenceId, referenceId))
    .limit(1);

  if (!rows[0] || !rows[0].isWinner) return null;

  // Check if already claimed
  if (rows[0].claimedAt) {
    return { alreadyClaimed: true, message: "This prize has already been claimed" };
  }

  // Update with phone and claimed_at
  await db.update(luckyBoxOpenings)
    .set({
      claimantPhone: phone,
      claimedAt: new Date(),
    })
    .where(eq(luckyBoxOpenings.id, rows[0].id));

  return { alreadyClaimed: false, success: true };
}

export async function checkDuplicateClaim(phone: string) {
  const db = await getDb();
  if (!db) return false;

  const rows = await db
    .select({ count: sql`count(*)` })
    .from(luckyBoxOpenings)
    .where(and(
      eq(luckyBoxOpenings.claimantPhone, phone),
      eq(luckyBoxOpenings.isWinner, true),
    ));

  return (rows[0]?.count as number ?? 0) > 0;
}

export async function getWinnerDetailsByRefId(referenceId: string) {
  const db = await getDb();
  if (!db) return null;

  const rows = await db
    .select({
      id: luckyBoxOpenings.id,
      referenceId: luckyBoxOpenings.referenceId,
      isWinner: luckyBoxOpenings.isWinner,
      prizeAmount: luckyBoxOpenings.prizeAmount,
      openedAt: luckyBoxOpenings.openedAt,
      claimantPhone: luckyBoxOpenings.claimantPhone,
      claimedAt: luckyBoxOpenings.claimedAt,
      paidAt: luckyBoxOpenings.paidAt,
      qrToken: luckyBoxOpenings.qrToken,
      guestDeviceId: luckyBoxOpenings.guestDeviceId,
      userName: usersTable.name,
      userEmail: usersTable.email,
    })
    .from(luckyBoxOpenings)
    .leftJoin(usersTable, eq(luckyBoxOpenings.userId, usersTable.id))
    .where(eq(luckyBoxOpenings.referenceId, referenceId))
    .limit(1);

  return rows[0] ?? null;
}
// ─── App Settings Helpers ────────────────────────────────────────────────────────

export async function getAppSetting(key: string): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select()
    .from(appSettings)
    .where(eq(appSettings.key, key))
    .limit(1);
  return rows[0]?.value ?? null;
}

export async function setAppSetting(key: string, value: string) {
  const db = await getDb();
  if (!db) return;
  const rows = await db.select()
    .from(appSettings)
    .where(eq(appSettings.key, key))
    .limit(1);
  
  if (rows.length > 0) {
    await db.update(appSettings)
      .set({ value })
      .where(eq(appSettings.key, key));
  } else {
    await db.insert(appSettings).values({ key, value });
  }
}
// ─── Admin: Total User Count ─────────────────────────────────────────────────
export async function countAllUsers(): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(usersTable);
  return result.length;
}
