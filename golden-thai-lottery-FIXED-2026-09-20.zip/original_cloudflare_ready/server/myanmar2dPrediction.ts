import { getMyanmar2dHistory } from "./db";
import { invokeLLM } from "./_core/llm";

export type Myanmar2dPrediction = {
  morningPredictions: string[];
  eveningPredictions: string[];
  hotNumbers: string[];
  coldNumbers: string[];
  analysisMm: string;
  analysisEn: string;
  confidenceLevel: number;
  disclaimer: string;
};

const TWO_DIGIT_PATTERN = /^\d{2}$/;

export function getMyanmarPredictionDate(now = new Date()): string {
  return new Date(now.getTime() + 6.5 * 60 * 60 * 1000).toISOString().slice(0, 10);
}

export function makeMyanmarPredictionSettingKey(
  predictionDate: string,
  session: "morning" | "evening",
): string {
  return `myanmar2d_ai_prediction_${predictionDate}_${session}`;
}

export function normalizeTwoDigitCandidates(values: unknown): string[] {
  if (!Array.isArray(values)) return [];
  const unique = new Set<string>();
  for (const value of values) {
    const number = String(value).trim().padStart(2, "0");
    if (TWO_DIGIT_PATTERN.test(number)) unique.add(number);
    if (unique.size === 3) break;
  }
  return Array.from(unique);
}

function normalizeAnalysisCandidates(values: unknown, max = 6): string[] {
  if (!Array.isArray(values)) return [];
  const unique = new Set<string>();
  for (const value of values) {
    const number = String(value).trim().padStart(2, "0");
    if (TWO_DIGIT_PATTERN.test(number)) unique.add(number);
    if (unique.size === max) break;
  }
  return Array.from(unique);
}

export function parseMyanmar2dPrediction(value: unknown): Myanmar2dPrediction | null {
  if (!value || typeof value !== "object") return null;
  const data = value as Record<string, unknown>;
  const morningPredictions = normalizeTwoDigitCandidates(data.morningPredictions);
  const eveningPredictions = normalizeTwoDigitCandidates(data.eveningPredictions);
  if (morningPredictions.length !== 3 || eveningPredictions.length !== 3) return null;

  return {
    morningPredictions,
    eveningPredictions,
    hotNumbers: normalizeAnalysisCandidates(data.hotNumbers),
    coldNumbers: normalizeAnalysisCandidates(data.coldNumbers),
    analysisMm: typeof data.analysisMm === "string" ? data.analysisMm.slice(0, 500) : "",
    analysisEn: typeof data.analysisEn === "string" ? data.analysisEn.slice(0, 500) : "",
    confidenceLevel: Math.max(1, Math.min(5, Number(data.confidenceLevel) || 1)),
    disclaimer: typeof data.disclaimer === "string" && data.disclaimer.trim()
      ? data.disclaimer.slice(0, 300)
      : "ဟောဂဏန်းသည် ဖျော်ဖြေရေးအတွက်သာဖြစ်ပြီး အာမခံရလဒ်မဟုတ်ပါ။",
  };
}

export async function generateMyanmar2dPrediction(language: "mm" | "en" | "th" = "mm"): Promise<Myanmar2dPrediction> {
  const historyData = await getMyanmar2dHistory(1, 60);
  const recentRows = historyData.results.slice(0, 40).map((row) => {
    const resultDate = typeof row.resultDate === "string"
      ? row.resultDate
      : (row.resultDate as Date).toISOString().slice(0, 10);
    return [
      resultDate,
      row.session,
      `2D ${String(row.winningNumber).padStart(2, "0")}`,
      row.setNumber ? `SET ${row.setNumber}` : "",
      row.valueNumber ? `VAL ${row.valueNumber}` : "",
    ].filter(Boolean).join(" | ");
  });
  const predictionDate = getMyanmarPredictionDate();

  const response = await invokeLLM({
    model: "gpt-5-mini",
    messages: [
      {
        role: "system",
        content: "You are a careful Myanmar 2D pattern analyst. Analyze only the supplied verified result and SET/VAL history. Return candidate numbers for entertainment only; never claim that any candidate is guaranteed, stable, certain, or likely to win. Output valid JSON only.",
      },
      {
        role: "user",
        content: language === "mm"
          ? `ယနေ့ (မြန်မာစံတော်ချိန်): ${predictionDate}\nVerified 2D / SET / VAL history:\n${recentRows.join("\n") || "မှတ်တမ်းမလုံလောက်သေးပါ"}\n\nမှတ်တမ်း၏ထပ်လာပုံနှင့် SET/VAL ပြောင်းလဲမှုကို ဖျော်ဖြေရေးအတွက်သာခွဲခြမ်းပါ။ မနက်အတွက် ၂ လုံးဂဏန်း ၃ လုံး၊ ညနေအတွက် ၂ လုံးဂဏန်း ၃ လုံးကိုထပ်မနေအောင်ပေးပါ။ အာမခံမရှိကြောင်း disclaimer ကိုမြန်မာလိုရေးပါ။`
          : `Myanmar date: ${predictionDate}\nVerified 2D / SET / VAL history:\n${recentRows.join("\n") || "Insufficient history"}\n\nAnalyze recurrence patterns and SET/VAL movement for entertainment only. Return three unique two-digit morning candidates and three unique two-digit evening candidates. Include a no-guarantee disclaimer.`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "myanmar_2d_daily_prediction",
        strict: true,
        schema: {
          type: "object",
          properties: {
            morningPredictions: { type: "array", items: { type: "string" } },
            eveningPredictions: { type: "array", items: { type: "string" } },
            hotNumbers: { type: "array", items: { type: "string" } },
            coldNumbers: { type: "array", items: { type: "string" } },
            analysisMm: { type: "string" },
            analysisEn: { type: "string" },
            confidenceLevel: { type: "integer", minimum: 1, maximum: 5 },
            disclaimer: { type: "string" },
          },
          required: ["morningPredictions", "eveningPredictions", "hotNumbers", "coldNumbers", "analysisMm", "analysisEn", "confidenceLevel", "disclaimer"],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content;
  if (typeof content !== "string") throw new Error("No AI prediction response");
  const prediction = parseMyanmar2dPrediction(JSON.parse(content));
  if (!prediction) throw new Error("AI prediction did not contain six unique two-digit candidates");
  return prediction;
}
