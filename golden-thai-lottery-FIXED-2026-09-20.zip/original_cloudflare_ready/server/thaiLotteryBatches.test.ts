import { describe, expect, it } from "vitest";
import { getThaiLotteryCompletedBatches } from "./scheduledSync";

describe("Thai lottery result batches", () => {
  it("treats the first prize, front/back 3 digits and last 2 digits as one batch", () => {
    expect(getThaiLotteryCompletedBatches({
      firstPrize: "123456",
      firstThreeDigits: ["123", "456"],
      lastThreeDigits: ["789", "012"],
      lastTwoDigits: "34",
    }).first).toBe(true);
  });

  it("keeps near-first and lower prizes as separate batches", () => {
    const batches = getThaiLotteryCompletedBatches({
      nearFirstPrize: ["123455", "123457"],
      secondPrize: Array(5).fill("111111"),
      thirdPrize: Array(10).fill("222222"),
      fourthPrize: Array(50).fill("333333"),
      fifthPrize: Array(99).fill("444444"),
    });
    expect(batches.nearFirst).toBe(true);
    expect(batches.second).toBe(true);
    expect(batches.third).toBe(true);
    expect(batches.fourth).toBe(true);
    expect(batches.fifth).toBe(false);
  });
});
