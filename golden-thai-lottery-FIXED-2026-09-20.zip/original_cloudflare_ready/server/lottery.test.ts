import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the db module
vi.mock("./db", () => ({
  getLatestThaiLotteryDraw: vi.fn().mockResolvedValue({
    id: 1,
    drawDate: "2026-07-16",
    firstPrize: "847293",
    nearFirstPrize: ["847292", "847294"],
    firstThreeDigits: ["847", "293"],
    lastThreeDigits: ["293", "847"],
    lastTwoDigits: "93",
    secondPrize: ["123456", "234567", "345678", "456789", "567890"],
    thirdPrize: ["497784", "659804", "771930", "035383", "380525", "978165", "079524", "371610", "761407", "354653"],
    fourthPrize: ["672550", "094191", "478672", "626100", "509887", "479157", "979421", "256938", "829785", "082401", "443519", "438460", "742059", "468328", "932266", "348500", "844650", "103661", "717755", "319910", "357597", "879348", "497535", "456226", "430448", "558819", "867644", "909993", "718860", "891144", "061038", "860528", "094576", "119529", "153613", "438279", "498424", "845535", "167205", "131971", "599328", "892342", "372784", "548337", "094764", "969365", "181672", "093572", "089456", "453190"],
    fifthPrize: ["287685", "725186", "873368", "501179", "860747", "441239", "412068", "742438", "166352", "132431", "580336", "173327", "374365", "986255", "446216", "777440", "517022", "230615", "767596", "143090", "829888", "072283", "247336", "853268", "890990", "374072", "909462", "547440", "792357", "970135", "747650", "096161", "109471", "818769", "334661", "297974", "147786", "093818", "623654", "223277", "079141", "455264", "750721", "129882", "707899", "224730", "589314", "772578", "432005", "668261", "543413", "084924", "226273", "151630", "481684", "011907", "262193", "324446", "931512", "597708", "779077", "692076", "913074", "938624", "459192", "996865", "562301", "307998", "522407", "695727", "791175", "018615", "653548", "189460", "104707", "345151", "682426", "348193", "649490", "384590", "412701", "379705", "642164", "606900", "873413", "357443", "240462", "487677", "329838", "219739", "801441", "438719", "910346", "334334", "790572", "461278", "293563", "656819", "350190", "966738"],
    createdAt: new Date(),
    updatedAt: new Date(),
  }),
  getThaiLotteryDrawByDate: vi.fn().mockResolvedValue(null),
  listThaiLotteryDrawDates: vi.fn().mockResolvedValue([
    { drawDate: "2026-07-16" },
    { drawDate: "2026-07-01" },
  ]),
  getLatestMyanmar2dResults: vi.fn().mockResolvedValue([
    { id: 1, resultDate: "2026-07-31", session: "morning", winningNumber: "16", setNumber: "1,622.41", valueNumber: "49196.66", createdAt: new Date() },
    { id: 2, resultDate: "2026-07-31", session: "evening", winningNumber: "42", setNumber: "1,623.64", valueNumber: "89032.00", createdAt: new Date() },
  ]),
  getMyanmar2dHistory: vi.fn().mockResolvedValue({ results: [], total: 0 }),
  getLatestHoroscope: vi.fn().mockResolvedValue([]),
  getWeeklyHoroscope: vi.fn().mockResolvedValue([]),
  upsertUser: vi.fn(),
  getUserByOpenId: vi.fn(),
  upsertThaiLotteryDraw: vi.fn(),
  insertMyanmar2dResult: vi.fn(),
  upsertHoroscopeReading: vi.fn(),
}));

function createPublicCtx(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("thaiLottery.getLatest", () => {
  it("returns the latest Thai lottery draw", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.getLatest();
    expect(result).not.toBeNull();
    expect(result?.firstPrize).toBe("847293");
    expect(result?.lastTwoDigits).toBe("93");
  });
});

describe("thaiLottery.listDrawDates", () => {
  it("returns a list of draw dates", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.listDrawDates();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
  });
});

describe("thaiLottery.checkTicket", () => {
  it("returns no match for a non-winning ticket", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "000000" });
    expect(result.ticket).toBe("000000");
    expect(result.matches).toBeFalsy();
  });

  it("returns 1st prize match for the winning ticket", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "847293" });
    expect(result.matches).toBeTruthy();
    expect(result.matches?.[0]?.prize).toBe("1st");
  });

  it("returns last2 match for ticket ending in 93", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "123493" });
    expect(result.matches).toBeTruthy();
    const prizes = result.matches?.map((m: { prize: string }) => m.prize) ?? [];
    expect(prizes).toContain("last2");
  });

  it("returns near1st match for number next to winning number", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "847292" });
    expect(result.matches).toBeTruthy();
    const prizes = result.matches?.map((m: { prize: string }) => m.prize) ?? [];
    expect(prizes).toContain("near1st");
  });

  it("returns first3 match for ticket starting with 847", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "847000" });
    expect(result.matches).toBeTruthy();
    const prizes = result.matches?.map((m: { prize: string }) => m.prize) ?? [];
    expect(prizes).toContain("first3");
  });

  it("returns last3 match for ticket ending with 293", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "000293" });
    expect(result.matches).toBeTruthy();
    const prizes = result.matches?.map((m: { prize: string }) => m.prize) ?? [];
    expect(prizes).toContain("last3");
  });

  it("returns 2nd prize match for ticket in secondPrize array", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "123456" });
    expect(result.matches).toBeTruthy();
    const prizes = result.matches?.map((m: { prize: string }) => m.prize) ?? [];
    expect(prizes).toContain("2nd");
  });

  it("returns correct prize name and amount for 1st prize", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "847293" });
    expect(result.matches).toBeTruthy();
    expect(result.matches?.[0]?.prizeEn).toBe("1st Prize");
    expect(result.matches?.[0]?.amount).toBe("6,000,000");
  });

  it("returns 4th prize match for ticket in fourthPrize array", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "672550" });
    expect(result.matches).toBeTruthy();
    const prizes = result.matches?.map((m: { prize: string }) => m.prize) ?? [];
    expect(prizes).toContain("4th");
    expect(result.matches?.[prizes.indexOf("4th")]?.amount).toBe("40,000");
  });

  it("returns 5th prize match for ticket in fifthPrize array", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "287685" });
    expect(result.matches).toBeTruthy();
    const prizes = result.matches?.map((m: { prize: string }) => m.prize) ?? [];
    expect(prizes).toContain("5th");
    expect(result.matches?.[prizes.indexOf("5th")]?.amount).toBe("20,000");
  });

  it("returns 3rd prize match for ticket in thirdPrize array", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "497784" });
    expect(result.matches).toBeTruthy();
    const prizes = result.matches?.map((m: { prize: string }) => m.prize) ?? [];
    expect(prizes).toContain("3rd");
    expect(result.matches?.[prizes.indexOf("3rd")]?.amount).toBe("80,000");
  });

  it("returns no match for a ticket not in any prize array (842054)", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.thaiLottery.checkTicket({ ticket: "842054" });
    expect(result.matches).toBeFalsy();
  });
});

describe("thaiLottery.checkTicket with drawDate", () => {
  it("throws NOT_FOUND when specific drawDate has no data", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    await expect(
      caller.thaiLottery.checkTicket({ ticket: "847293", drawDate: "2026-08-01" })
    ).rejects.toThrow("No draw data found");
  });
});

describe("myanmar2d.getLatest", () => {
  it("returns today's 2D results", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.myanmar2d.getLatest();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBe(2);
    expect(result[0].winningNumber).toBe("16");
  });
});

describe("auth.me", () => {
  it("returns null for unauthenticated user", async () => {
    const caller = appRouter.createCaller(createPublicCtx());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });
});
