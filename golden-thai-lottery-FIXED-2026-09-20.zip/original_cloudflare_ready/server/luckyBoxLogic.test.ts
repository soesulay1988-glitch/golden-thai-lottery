import { describe, expect, it } from "vitest";
import { canAwardLuckyBoxCoins, isLuckyBoxWinner, normalizeLuckyBoxWinChance } from "./luckyBoxLogic";

describe("Lucky Box win percentage", () => {
  it("clamps invalid percentage values to the safe 0–100 range", () => {
    expect(normalizeLuckyBoxWinChance(-3)).toBe(0);
    expect(normalizeLuckyBoxWinChance(125)).toBe(100);
    expect(normalizeLuckyBoxWinChance("bad")).toBe(2);
  });

  it("uses the configured percentage without a testing bypass", () => {
    expect(isLuckyBoxWinner(0, 0)).toBe(false);
    expect(isLuckyBoxWinner(100, 99.999)).toBe(true);
    expect(isLuckyBoxWinner(25, 24.99)).toBe(true);
    expect(isLuckyBoxWinner(25, 25)).toBe(false);
  });

  it("never allows a Coins reward to exceed the remaining monthly budget", () => {
    expect(canAwardLuckyBoxCoins(1_000, 800, 200)).toBe(true);
    expect(canAwardLuckyBoxCoins(1_000, 800, 201)).toBe(false);
    expect(canAwardLuckyBoxCoins(0, 0, 50)).toBe(false);
  });
});
