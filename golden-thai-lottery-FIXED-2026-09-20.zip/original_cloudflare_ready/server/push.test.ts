import { describe, it, expect } from "vitest";
import webPush from "web-push";

describe("Push Notification Module", () => {
  it("should initialize VAPID keys without error", () => {
    const { publicKey, privateKey } = webPush.generateVAPIDKeys();

    expect(publicKey).toBeTruthy();
    expect(privateKey).toBeTruthy();

    expect(() => webPush.setVapidDetails(
      "mailto:admin@goldenthai.manus.space",
      publicKey,
      privateKey
    )).not.toThrow();
  });

  it("should have valid VAPID key pair", () => {
    const keys = webPush.generateVAPIDKeys();
    expect(keys.publicKey).toBeTruthy();
    expect(keys.privateKey).toBeTruthy();
    // Public key should be longer than private key
    expect(keys.publicKey.length).toBeGreaterThan(keys.privateKey.length);
  });
});
