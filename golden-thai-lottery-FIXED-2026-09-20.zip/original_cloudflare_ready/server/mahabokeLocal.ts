export type MahabokeLocalInput = {
  birthDay: number;
  birthMonth: number;
  birthYear: number;
  age: number;
  dayOfWeek: number;
  periodStart: string;
  birthNameMm: string;
  birthNameEn: string;
  rulingPlanetMm: string;
  rulingPlanetEn: string;
};

function hashSeed(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function pick<T>(items: readonly T[], seed: number, offset: number): T {
  return items[(seed + offset * 17) % items.length];
}

function pickPair(items: readonly string[], seed: number, offset: number): string {
  const firstIndex = (seed + offset * 17) % items.length;
  let secondIndex = (seed + offset * 31 + 1) % items.length;
  if (secondIndex === firstIndex) secondIndex = (secondIndex + 1) % items.length;
  return `${items[firstIndex]} ${items[secondIndex]}`;
}

const colors = [
  ["Gold", "ရွှေရောင်", "สีทอง"], ["White", "အဖြူရောင်", "สีขาว"],
  ["Green", "အစိမ်းရောင်", "สีเขียว"], ["Blue", "အပြာရောင်", "สีน้ำเงิน"],
  ["Red", "အနီရောင်", "สีแดง"], ["Purple", "ခရမ်းရောင်", "สีม่วง"],
  ["Yellow", "အဝါရောင်", "สีเหลือง"],
] as const;

const directions = [
  ["East", "အရှေ့ဘက်", "ทิศตะวันออก"], ["West", "အနောက်ဘက်", "ทิศตะวันตก"],
  ["North", "မြောက်ဘက်", "ทิศเหนือ"], ["South", "တောင်ဘက်", "ทิศใต้"],
  ["Northeast", "အရှေ့မြောက်ဘက်", "ทิศตะวันออกเฉียงเหนือ"],
  ["Southeast", "အရှေ့တောင်ဘက်", "ทิศตะวันออกเฉียงใต้"],
] as const;

const luckyDays = [
  ["Sunday", "တနင်္ဂနွေနေ့", "วันอาทิตย์"], ["Monday", "တနင်္လာနေ့", "วันจันทร์"],
  ["Tuesday", "အင်္ဂါနေ့", "วันอังคาร"], ["Wednesday", "ဗုဒ္ဓဟူးနေ့", "วันพุธ"],
  ["Thursday", "ကြာသပတေးနေ့", "วันพฤหัสบดี"], ["Friday", "သောကြာနေ့", "วันศุกร์"],
  ["Saturday", "စနေနေ့", "วันเสาร์"],
] as const;

const workMm = [
  "လုပ်ငန်းသစ်စတင်ရန်ထက် လက်ရှိတာဝန်များကို စနစ်တကျပြီးစီးအောင်လုပ်ခြင်းက အောင်မြင်မှုရစေမည်။ အကြီးအကဲနှင့်ပြောဆိုရာတွင် အချက်အလက်ပြည့်စုံစွာတင်ပြပါ။",
  "အလုပ်တွင် တာဝန်အသစ် သို့မဟုတ် ပူးပေါင်းဆောင်ရွက်ရန်အခွင့်အရေးပေါ်နိုင်သည်။ အလျင်စလိုကတိမပေးဘဲ အချိန်နှင့်အကျိုးအမြတ်ကို စစ်ဆေးပါ။",
  "ရပ်တန့်နေသောအလုပ်တစ်ခု ပြန်လည်လှုပ်ရှားလာမည်။ လုပ်ဖော်ကိုင်ဖက်၏အကြံကို နားထောင်သော်လည်း နောက်ဆုံးဆုံးဖြတ်ချက်ကို ကိုယ်တိုင်သေချာချပါ။",
  "ဖန်တီးမှုနှင့်ဆက်သွယ်ရေးလိုအပ်သောအလုပ်များတွင် အားသာချက်ရမည်။ စာရွက်စာတမ်းနှင့်ရက်ချိန်းများကို နှစ်ကြိမ်စစ်ဆေးပါ။",
];
const loveMm = [
  "ချစ်သူရှိသူများ စိတ်ထဲထားမည့်အစား ပွင့်ပွင့်လင်းလင်းပြောဆိုလျှင် နားလည်မှုတိုးမည်။ လူလွတ်များ မိတ်ဆွေဝိုင်းမှတစ်ဆင့် အကျွမ်းတဝင်အသစ်ရနိုင်သည်။",
  "အသေးအဖွဲသဘောမတူမှုကို အနိုင်ယူလိုစိတ်မထားဘဲ နားထောင်ပေးပါ။ အတိတ်ကိစ္စကို ပြန်မဖော်ခြင်းက ဆက်ဆံရေးကို ပိုနွေးထွေးစေမည်။",
  "အလုပ်များမှုကြောင့် ချစ်ခင်သူကို လျစ်လျူရှုမိနိုင်သည်။ အချိန်တိုလေးဖြစ်စေ အတူတကွစကားပြောခြင်းက ကောင်းသောပြောင်းလဲမှုဖြစ်စေမည်။",
  "မေတ္တာရေးတွင် အေးအေးဆေးဆေးတိုးတက်မည့်ကာလဖြစ်သည်။ ဆုံးဖြတ်ချက်ကြီးများကို နှစ်ဦးသဘောတူမှ ချမှတ်ပါ။",
];
const moneyMm = [
  "ဝင်ငွေထက် မမျှော်လင့်ထားသောအသုံးစရိတ်သေးသေးများ စုပေါင်းများလာနိုင်သည်။ နေ့စဉ်အသုံးစာရင်းထားပြီး အကြွေးအသစ်ရှောင်ပါ။",
  "ငွေကြေးအခွင့်အရေးတစ်ခု ကြားသိရနိုင်သော်လည်း အမြတ်မြန်မည်ဆိုသောကတိကို မယုံကြည်ပါနှင့်။ လိုအပ်သောပစ္စည်းကိုသာ ဦးစားပေးဝယ်ပါ။",
  "ပေးရန်ယူရန်အဟောင်းတစ်ခု ပြေလည်နိုင်သည်။ ရလာသောငွေအားလုံးမသုံးဘဲ အရေးပေါ်အတွက် တစ်စိတ်တစ်ပိုင်းသိမ်းပါ။",
  "မိသားစုနှင့်ဆိုင်သောအသုံးစရိတ်ရှိနိုင်သော်လည်း စီမံထားလျှင် မခက်ခဲပါ။ ငွေလွှဲခြင်းနှင့်စာချုပ်အချက်အလက်ကို သေချာစစ်ပါ။",
];
const healthMm = [
  "အိပ်ရေးပျက်ခြင်းနှင့်ပင်ပန်းနွမ်းနယ်မှုကို သတိထားပါ။ ရေမှန်မှန်သောက်ပြီး ညအိပ်ချိန်ကို တည်ငြိမ်စွာထားပါ။",
  "အစာအိမ်နှင့်အစာချေမှုကို ဂရုစိုက်ကာ အချိန်မှန်စားပါ။ နာတာရှည်လက္ခဏာရှိလျှင် ဟောကိန်းကိုမမှီခိုဘဲ ဆရာဝန်နှင့်တိုင်ပင်ပါ။",
  "လည်ပင်း၊ ပခုံးနှင့်ခါးတင်းကျပ်မှု ဖြစ်လွယ်သဖြင့် အကြာကြီးတစ်နေရာတည်းမထိုင်ပါနှင့်။ နေ့စဉ်လမ်းလျှောက်ခြင်းက အထောက်အကူဖြစ်မည်။",
  "စိတ်ဖိစီးမှုကို စုပုံမထားဘဲ အနားယူချိန်သတ်မှတ်ပါ။ ဆေးဝါးနှင့်ကျန်းမာရေးကိစ္စများတွင် ကျွမ်းကျင်သူ၏အကြံကိုသာလိုက်နာပါ။",
];
const familyMm = [
  "မိသားစုအတွင်း အမြင်မတူမှုရှိပါက အသက်ကြီးသူ၏စကားကို ဦးစွာနားထောင်ပါ။ အိမ်မှုကိစ္စတစ်ခုကို အတူတကွဖြေရှင်းရင်း သံယောဇဉ်ပိုကောင်းလာမည်။",
  "ဆွေမျိုးတစ်ဦးထံမှ သတင်းကောင်း သို့မဟုတ် အကူအညီတောင်းခံမှုရနိုင်သည်။ ကိုယ်တတ်နိုင်သည့်အတိုင်းအတာကို ရှင်းရှင်းလင်းလင်းပြောပါ။",
  "အိမ်တွင်းကိစ္စအသေးအဖွဲကို ကြီးမားအောင်မလုပ်ဘဲ ချက်ချင်းညှိနှိုင်းပါ။ မိသားစုနှင့်အတူစားသောက်ချိန်ထားခြင်းက စိတ်ချမ်းသာစေမည်။",
];
const educationMm = [
  "လေ့လာရာတွင် အကြောင်းအရာများကို အပိုင်းငယ်ခွဲပြီး နေ့စဉ်ပြန်လည်လေ့ကျင့်ပါ။ စာမေးပွဲ သို့မဟုတ် အင်တာဗျူးအတွက် မနက်ပိုင်းပြင်ဆင်ခြင်းက ပိုထိရောက်မည်။",
  "ဘာသာစကားနှင့်နည်းပညာအသစ်လေ့လာရန် ကောင်းသောကာလဖြစ်သည်။ မသိသည်ကို မေးမြန်းခြင်းက အချိန်ကုန်သက်သာစေမည်။",
  "အာရုံပျံ့လွယ်သဖြင့် ဖုန်းအသုံးပြုချိန်ကန့်သတ်ပြီး ရည်မှန်းချက်သေးသေးထားပါ။ ပြီးမြောက်မှုကို နေ့စဉ်မှတ်တမ်းတင်ပါ။",
];
const travelMm = [
  "ခရီးတိုများ အဆင်ပြေမည်ဖြစ်သော်လည်း အချိန်ဇယား၊ လက်မှတ်နှင့်လိုအပ်သောစာရွက်စာတမ်းကို ကြိုစစ်ပါ။ မိုးလေဝသနှင့်ယာဉ်ကြောကြောင့် အချိန်ပိုထားပါ။",
  "အလုပ်ကိစ္စခရီး သို့မဟုတ် မိသားစုထံသွားရောက်ရန် အကြောင်းပေါ်နိုင်သည်။ ညပိုင်းအလျင်စလိုခရီးထွက်ခြင်းကို ရှောင်ပါ။",
  "ခရီးစဉ်ပြောင်းလဲမှုအသေးစားရှိနိုင်သော်လည်း အကျိုးမပျက်ပါ။ တန်ဖိုးကြီးပစ္စည်းနှင့်ဖုန်းကို သတိထားထိန်းသိမ်းပါ။",
];
const spiritualMm = [
  "မနက်ပိုင်း မေတ္တာပို့ခြင်းနှင့် မိဘ၊ ဆရာသမားတို့အားကူညီခြင်းက စိတ်တည်ငြိမ်စေမည်။ ဒေါသဖြင့်ဆုံးဖြတ်ခြင်းကို ရှောင်ပါ။",
  "တတ်နိုင်သမျှ အစားအစာ သို့မဟုတ် ရေဒါနပြုပါ။ ကျေးဇူးတင်စိတ်ဖြင့်နေ့စတင်ခြင်းက အခက်အခဲကို အေးချမ်းစွာရင်ဆိုင်နိုင်စေမည်။",
  "ဘုရားရှိခိုး၊ တရားထိုင်ချိန်တိုတစ်ခုထားပြီး မကောင်းသောစကားကို ရှောင်ကြဉ်ပါ။ ကောင်းမှုသေးသေးကို စဉ်ဆက်မပြတ်လုပ်ခြင်းက ပိုအကျိုးရှိသည်။",
];

const opportunitiesMm = [
  "ယခုကာလတွင် အရင်ကဆက်သွယ်ခဲ့ဖူးသူတစ်ဦးမှ အသုံးဝင်သောသတင်း သို့မဟုတ် အခွင့်အရေးရလာနိုင်သည်။ စကားကိုသာမယုံဘဲ အချက်အလက်နှင့်အချိန်ကာလကို စစ်ဆေးပြီးမှ လက်ခံပါ။",
  "ကြာရှည်စောင့်ဆိုင်းခဲ့သောကိစ္စတစ်ခု ရွေ့လျားလာနိုင်သည်။ ကိုယ်တိုင်တစ်ဆင့်တိုး၍ မေးမြန်းခြင်း၊ စာရွက်စာတမ်းဖြည့်စွက်ခြင်းက လမ်းပွင့်စေမည်။",
  "ကျွမ်းကျင်မှုအဟောင်းကို ပြန်အသုံးချရာမှ အပိုဝင်ငွေ သို့မဟုတ် လူသိများမှုရနိုင်သည်။ သေးငယ်သောအခွင့်အရေးကို ပေါ့မထားဘဲ စနစ်တကျလုပ်ပါ။",
  "မိတ်ဆွေ၊ လုပ်ဖော်ကိုင်ဖက် သို့မဟုတ် မိသားစုမှတစ်ဆင့် ကောင်းသောအဆက်အသွယ်ရနိုင်သည်။ ကိုယ့်လိုအပ်ချက်ကို ရှင်းရှင်းလင်းလင်းပြောနိုင်ခြင်းက အကျိုးရှိမည်။",
];

const cautionsMm = [
  "အလျင်လို၍ ဆုံးဖြတ်ခြင်း၊ မဖတ်ဘဲ လက်မှတ်ထိုးခြင်းနှင့် မသေချာသောသူအား ငွေယုံအပ်ခြင်းကို ရှောင်ပါ။ အင်္ဂါနှင့်စနေညပိုင်းတွင် စကားအငြင်းပွားမှုကို အထူးလျှော့ချပါ။",
  "ကတိအလွန်အကျွံပေးခြင်းနှင့် ကိုယ်မနိုင်သောတာဝန်ကို လက်ခံခြင်းက ပင်ပန်းစေနိုင်သည်။ အရေးကြီးဖိုင်၊ ဖုန်းနှင့်ငွေလွှဲအချက်အလက်ကို နှစ်ကြိမ်စစ်ပါ။",
  "သူတစ်ပါးစကားကြောင့် စိတ်မြန်ခြင်းမပြုဘဲ တစ်ညအိပ်ပြီးမှ ဆုံးဖြတ်ပါ။ ခရီးနှင့်ချိန်းဆိုမှုတွင် အချိန်ပိုထားခြင်းက အမှားလျော့စေမည်။",
  "အတိတ်ပြဿနာကို ထပ်ခါပြန်ဖော်ခြင်းနှင့် လူမှုကွန်ရက်ပေါ်တွင် စိတ်ခံစားချက်ဖြင့်စာတင်ခြင်းကို ရှောင်ပါ။ ကိုယ်ရေးအချက်အလက်နှင့် OTP များကို မည်သူ့ကိုမျှမပေးပါနှင့်။",
];

const remediesMm = [
  "နံနက်ပိုင်း မေတ္တာသုတ် သို့မဟုတ် မိမိယုံကြည်ရာဆုတောင်းကို ရွတ်ဖတ်ပြီး သက်ကြီးရွယ်အိုတစ်ဦးအား အစားအစာကူညီပါ။ အရေးကြီးကိစ္စကို ကံကောင်းနေ့၏ နံနက်ပိုင်းတွင် စတင်ပါ။",
  "သန့်ရှင်းသောရေ သို့မဟုတ် သောက်ရေဒါနပြုပြီး မိဘဆရာသမားအား ရိုသေကန်တော့ပါ။ ဒေါသထွက်ချိန် ဆယ်ချက်အသက်ရှူပြီးမှ ပြောဆိုခြင်းကို ယတြာကဲ့သို့ ကျင့်ပါ။",
  "ဘုရားပန်း သို့မဟုတ် မိမိယုံကြည်ရာနေရာ၌ အလင်းတိုင်ပူဇော်ပြီး မကောင်းသောစကားတစ်ရက်ရှောင်ပါ။ အခက်အခဲရှိသူအား တတ်နိုင်သလောက် လက်တွေ့ကူညီပါ။",
  "ငှက်၊ တိရစ္ဆာန် သို့မဟုတ် လိုအပ်သူအား အစာဒါနပြုပြီး ယခုအပတ်ရည်မှန်းချက်သုံးချက်ကို စာရွက်ပေါ်ရေးပါ။ ကောင်းမှုနှင့်လက်တွေ့အစီအစဉ်ကို တွဲလုပ်ခြင်းက ပိုအကျိုးရှိသည်။",
];

const ageGuidanceMm = [
  "အတွေ့အကြုံသစ်များကို သေချာလေ့လာပြီး မိတ်ဆွေရွေးချယ်မှုကို ဂရုစိုက်ရမည့်",
  "အလုပ်အကိုင်တည်ဆောက်မှု၊ ငွေစုမှုနှင့်မိသားစုတာဝန်ကို မျှတစွာကိုင်တွယ်ရမည့်",
  "ရှိပြီးသားအတွေ့အကြုံကို အသုံးချကာ ကျန်းမာရေးနှင့်ငွေကြေးလုံခြုံမှုကို ဦးစားပေးရမည့်",
] as const;

function numberSet(seed: number) {
  const nums = new Set<string>();
  let n = seed || 1;
  while (nums.size < 3) {
    n = (Math.imul(n, 1664525) + 1013904223) >>> 0;
    nums.add(String(n % 100).padStart(2, "0"));
  }
  const twoD = Array.from(nums);
  return { twoD, lottery: [`${twoD[0]}${twoD[1]}${twoD[2]}`, `${twoD[2]}${twoD[0]}${twoD[1]}`] };
}

export function getSevenDayPeriodStart(now = new Date()): string {
  const day = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const bucket = Math.floor(day.getTime() / (7 * 86400000));
  return new Date(bucket * 7 * 86400000).toISOString().slice(0, 10);
}

export function generateLocalMahabokeReading(input: MahabokeLocalInput) {
  const seed = hashSeed(`${input.birthDay}-${input.birthMonth}-${input.birthYear}-${input.age}-${input.periodStart}`);
  const color = pick(colors, seed, 1);
  const direction = pick(directions, seed, 2);
  const luckyDay = pick(luckyDays, seed, 3);
  const numbers = numberSet(seed);
  const phase = input.age < 25 ? ageGuidanceMm[0] : input.age < 45 ? ageGuidanceMm[1] : ageGuidanceMm[2];
  const myanmarYear = input.birthYear - 638;
  const lifeRemainder = ((myanmarYear % 7) + 7) % 7;
  const strength = ["စိတ်ဓာတ်", "ဆက်သွယ်ရေး", "သင်ယူနိုင်စွမ်း", "တာဝန်ယူမှု", "ဖန်တီးနိုင်စွမ်း", "သည်းခံနိုင်စွမ်း", "ဦးဆောင်နိုင်စွမ်း"][lifeRemainder];
  const opportunity = pick(opportunitiesMm, seed, 12);
  const caution = pick(cautionsMm, seed, 13);
  const remedy = pick(remediesMm, seed, 14);
  return {
    personalityMm: `${input.birthNameMm}ဖွား၊ မြန်မာနှစ် ${myanmarYear} နှင့် အသက် ${input.age} နှစ်အတွက် ယခုကာလသည် ${phase} ၇ ရက်ဖြစ်သည်။ ${input.rulingPlanetMm} နေ့နံသက်ရောက်မှုကြောင့် ${strength}သည် အားသာချက်ဖြစ်သော်လည်း မိမိထင်မြင်ချက်ကို အလွန်အမင်းစွဲကိုင်လျှင် အခွင့်အရေးနှောင့်နှေးနိုင်သည်။ အရေးကြီးကိစ္စကို အချက်အလက်စုံပြီး ယုံကြည်ရသူတစ်ဦးနှင့်တိုင်ပင်ကာ ဆုံးဖြတ်ပါ။`,
    personalityEn: `For a ${input.birthNameEn} person aged ${input.age}, this seven-day period rewards patient, well-informed decisions under the influence of ${input.rulingPlanetEn}.`,
    personalityTh: `สำหรับผู้เกิด${input.birthNameEn} อายุ ${input.age} ปี ช่วงเจ็ดวันนี้ควรตัดสินใจอย่างรอบคอบภายใต้อิทธิพลของ ${input.rulingPlanetEn}`,
    loveMm: pickPair(loveMm, seed, 4), loveEn: "Clear and gentle communication will improve relationships this week. Avoid reviving old disagreements and make important decisions together.", loveTh: "การสื่อสารอย่างชัดเจนและอ่อนโยนจะช่วยให้ความสัมพันธ์ดีขึ้น หลีกเลี่ยงการรื้อฟื้นความขัดแย้งเก่า",
    careerMm: `${pickPair(workMm, seed, 5)} ${opportunity}`, careerEn: "Set priorities, verify details, and avoid rushed commitments at work. A delayed task or useful contact may create an opportunity.", careerTh: "จัดลำดับความสำคัญ ตรวจสอบรายละเอียด และหลีกเลี่ยงการรับปากอย่างเร่งรีบ งานที่ล่าช้าอาจกลับมาเดินหน้า",
    healthMm: pickPair(healthMm, seed, 6), healthEn: "Protect sleep, hydration, regular meals, and movement. Seek professional care for persistent or serious symptoms rather than relying on a horoscope.", healthTh: "ดูแลการนอน ดื่มน้ำ รับประทานอาหารตรงเวลา และเคลื่อนไหวสม่ำเสมอ หากมีอาการต่อเนื่องควรพบผู้เชี่ยวชาญ",
    financeMm: `${pickPair(moneyMm, seed, 7)} ${caution}`, financeEn: "Track expenses, avoid quick-profit promises, protect account information, and keep an emergency reserve. Review transfers and contracts twice.", financeTh: "ติดตามรายจ่าย หลีกเลี่ยงคำสัญญากำไรเร็ว ปกป้องข้อมูลบัญชี และเก็บเงินสำรองฉุกเฉิน",
    familyMm: pickPair(familyMm, seed, 8), familyEn: "Patient conversation and shared time will strengthen family trust. State clearly what help you can realistically provide.", familyTh: "การพูดคุยอย่างอดทนและใช้เวลาร่วมกันจะช่วยเพิ่มความไว้วางใจในครอบครัว",
    educationMm: pickPair(educationMm, seed, 9), educationEn: "Study in small daily sections, limit distractions, ask questions early, and review consistently.", educationTh: "แบ่งการเรียนเป็นส่วนเล็ก ๆ ลดสิ่งรบกวน ถามเมื่อไม่เข้าใจ และทบทวนอย่างสม่ำเสมอ",
    travelMm: pickPair(travelMm, seed, 10), travelEn: "Check schedules, documents, weather, valuables, and allow extra travel time. Avoid rushed late-night travel.", travelTh: "ตรวจสอบกำหนดการ เอกสาร สภาพอากาศ ของมีค่า และเผื่อเวลาเดินทาง",
    spiritualMm: `${pickPair(spiritualMm, seed, 11)} ${remedy}`, spiritualEn: "Begin each day with gratitude, calm reflection, and a practical act of kindness. Pair spiritual practice with a clear real-world plan.", spiritualTh: "เริ่มแต่ละวันด้วยความกตัญญู ทำจิตใจให้สงบ และทำความดีควบคู่กับแผนที่ปฏิบัติได้จริง",
    luckyColor: color[0], luckyColorMm: color[1], luckyColorTh: color[2],
    luckyDirection: direction[0], luckyDirectionMm: direction[1], luckyDirectionTh: direction[2],
    luckyDay: luckyDay[0], luckyDayMm: luckyDay[1], luckyDayTh: luckyDay[2],
    lucky2dNumbers: numbers.twoD, luckyLotteryNumbers: numbers.lottery,
    overallFortune: 2 + (seed % 4),
    weeklyMessageMm: `${input.birthNameMm}ဖွားအတွက် ယခု ၇ ရက်၏ အဓိကသော့ချက်မှာ “ဖြည်းဖြည်းမှန်မှန် လှမ်းသူ ပန်းတိုင်ရောက်သည်” ဟူသောသဘောဖြစ်သည်။ အခွင့်အရေး—${opportunity} သတိပြုရန်—${caution} ကံကောင်းနေ့ ${luckyDay[1]} တွင် ${color[1]}ကို အသုံးပြုပြီး ${direction[1]}မျက်နှာမူကာ အရေးကြီးအလုပ်စတင်နိုင်သည်။ ယတြာနှင့်လက်တွေ့အကြံ—${remedy} ဟောကိန်းသည် လမ်းညွှန်သဘောသာဖြစ်၍ ကျန်းမာရေး၊ ငွေကြေးနှင့်ဥပဒေဆိုင်ရာဆုံးဖြတ်ချက်များတွင် ကျွမ်းကျင်သူ၏အကြံကို ဦးစားပေးပါ။`,
    weeklyMessageEn: `For ${input.birthNameEn}, steady and orderly progress is the best guide for these seven days.`,
    weeklyMessageTh: `สำหรับผู้เกิด${input.birthNameEn} การก้าวไปอย่างมั่นคงและเป็นระบบคือแนวทางที่ดีที่สุดในเจ็ดวันนี้`,
  };
}
