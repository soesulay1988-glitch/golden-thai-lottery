import { describe, expect, it } from "vitest";
import { buildCalendar3DAiSource, makeCalendar3DAiCacheKey } from "./calendar3dAi";

describe("3D AI analysis source", () => {
  it("uses Golden Thai historical data and the next regular 1st/16th draw", () => {
    const source = buildCalendar3DAiSource(new Date("2026-09-05T12:00:00+07:00"));
    expect(source).not.toBeNull();
    expect(source).toMatchObject({
      targetDate: "2026-09-16",
      targetRow: "17",
      completedCurrentYearDraws: 16,
    });
    expect(source?.evidence).toHaveLength(3);
    expect(source?.evidence.map((item) => item.sampleCount)).toEqual([55, 10, 16]);
    expect(source?.evidence.map((item) => item.values.length)).toEqual([55, 10, 16]);
    expect(source?.visualMaps).toHaveLength(10);
    expect(new Set(source?.visualMaps.map((map) => map.candidate)).size).toBe(10);
    expect(source?.visualMaps.every((map) => map.visualEvidence.length === 3 && map.visualEvidence.every((group, index) => group.points.length === 3 && group.points.every((point) => source.evidence[index]?.values.includes(point.value))))).toBe(true);
    expect(source?.visualMaps.every((map) => new Set(map.visualEvidence.flatMap((group) => group.points.map((point) => `${point.row}-${point.year}`))).size === 9)).toBe(true);
    expect(source?.visualMaps.every((map) => map.visualEvidence[0]?.points.every((point) => point.year >= 2000 && point.year < 2016))).toBe(true);
    expect(source?.visualMaps.every((map) => map.visualEvidence[1]?.points.every((point) => point.year >= 2016 && point.year < 2026))).toBe(true);
    expect(source?.visualMaps.every((map) => map.visualEvidence[2]?.points.every((point) => point.year === 2026))).toBe(true);
  });

  it("changes the cache input when the regular target date rolls over", () => {
    const september = buildCalendar3DAiSource(new Date("2026-09-05T12:00:00+07:00"));
    const october = buildCalendar3DAiSource(new Date("2026-09-17T12:00:00+07:00"));
    expect(september).not.toBeNull();
    expect(october).not.toBeNull();
    expect(september?.targetDate).toBe("2026-09-16");
    expect(october?.targetDate).toBe("2026-10-01");
    expect(makeCalendar3DAiCacheKey(september!)).not.toBe(makeCalendar3DAiCacheKey(october!));
  });

  it("uses a later verified 2026 row to move the evidence target forward", () => {
    const source = buildCalendar3DAiSource(new Date("2026-09-17T12:00:00+07:00"), { "17": "555" });
    expect(source).toMatchObject({ targetDate: "2026-10-01", targetRow: "18", completedCurrentYearDraws: 17 });
  });
});
