import { describe, it, expect } from "vitest";
import webPush from "web-push";

describe("VAPID Keys", () => {
  it("should be able to initialize web-push with VAPID keys", () => {
    const { publicKey, privateKey } = webPush.generateVAPIDKeys();

    expect(publicKey).toBeTruthy();
    expect(privateKey).toBeTruthy();
    expect(publicKey.length).toBeGreaterThan(20);
    expect(privateKey.length).toBeGreaterThan(20);

    // Test that web-push can be configured without throwing
    webPush.setVapidDetails(
      "mailto:admin@goldenthai.manus.space",
      publicKey,
      privateKey
    );

    // Verify key format by generating a valid subscription test
    const result = webPush.generateVAPIDKeys();
    expect(result.publicKey).toBeTruthy();
    expect(result.privateKey).toBeTruthy();
  });

  it("should validate VAPID key pair compatibility", () => {
    const { publicKey, privateKey } = webPush.generateVAPIDKeys();

    // Verify the keys are valid base64url encoded strings
    expect(() => webPush.setVapidDetails(
      "mailto:admin@goldenthai.manus.space",
      publicKey,
      privateKey
    )).not.toThrow();
  });
});
