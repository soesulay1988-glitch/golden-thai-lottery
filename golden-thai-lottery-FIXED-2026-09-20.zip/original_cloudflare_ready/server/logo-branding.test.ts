import { describe, expect, it } from "vitest";

describe("Golden Thai public crown branding", () => {
  it("loads the supplied crown 2D icon from the public app", async () => {
    const response = await fetch("http://127.0.0.1:3000/icons/golden-thai-2d-crown.png");

    expect(response.ok).toBe(true);
    expect(response.headers.get("content-type")).toContain("image/png");
  });
});
