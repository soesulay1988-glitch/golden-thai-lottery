import { describe, expect, it } from "vitest";
import { getLuckyBoxSlotState } from "./luckyBoxSlots";

describe("Lucky Box time slots", () => {
  it("counts down to the 10:00 Myanmar opening", () => {
    const state = getLuckyBoxSlotState(new Date("2026-09-04T03:29:30.000Z"));
    expect(state.activeSlot).toBeNull();
    expect(state.nextSlot.labelEn).toBe("10:00 AM");
    expect(state.secondsUntilNext).toBe(30);
  });

  it("opens only during the 30-minute 13:00 Myanmar slot", () => {
    const state = getLuckyBoxSlotState(new Date("2026-09-04T06:45:00.000Z"));
    expect(state.activeSlot?.labelEn).toBe("1:00 PM");
    expect(state.slotKey).toBe("2026-09-04-2");
  });

  it("moves to the next day after the 20:30 Myanmar window closes", () => {
    const state = getLuckyBoxSlotState(new Date("2026-09-04T14:30:00.000Z"));
    expect(state.activeSlot).toBeNull();
    expect(state.nextSlot.labelEn).toBe("10:00 AM");
    expect(state.secondsUntilNext).toBe((13 * 60) * 60);
  });
});
