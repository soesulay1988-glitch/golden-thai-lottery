import { describe, expect, it } from "vitest";
import {
  getMyanmarPredictionDate,
  makeMyanmarPredictionSettingKey,
  normalizeTwoDigitCandidates,
  parseMyanmar2dPrediction,
} from "./myanmar2dPrediction";

describe("Myanmar 2D daily AI prediction helpers", () => {
  it("uses the Myanmar calendar date at a UTC day boundary", () => {
    expect(getMyanmarPredictionDate(new Date("2026-09-04T18:00:00.000Z"))).toBe("2026-09-05");
  });

  it("accepts three unique two-digit candidates only", () => {
    expect(normalizeTwoDigitCandidates(["7", "07", "26", "26", "84", "99"])).toEqual(["07", "26", "84"]);
  });

  it("validates a stored prediction before it can be displayed", () => {
    const prediction = parseMyanmar2dPrediction({
      morningPredictions: ["07", "26", "84"],
      eveningPredictions: ["14", "55", "90"],
      hotNumbers: ["26"],
      coldNumbers: ["01"],
      analysisMm: "test",
      analysisEn: "test",
      confidenceLevel: 3,
      disclaimer: "ဖျော်ဖြေရေးအတွက်သာ",
    });
    expect(prediction?.morningPredictions).toEqual(["07", "26", "84"]);
    expect(makeMyanmarPredictionSettingKey("2026-09-04", "evening")).toBe("myanmar2d_ai_prediction_2026-09-04_evening");
  });
});
