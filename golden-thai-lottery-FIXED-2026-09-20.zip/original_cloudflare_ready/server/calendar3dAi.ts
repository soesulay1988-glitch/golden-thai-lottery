import { CALENDAR_ROWS, CALENDAR_YEARS, calendar3DMatrix } from "../client/src/lib/calendar3DData";
import { getNextThaiLotteryDrawTarget, type Calendar3DDrawTarget } from "../client/src/lib/calendar3DDrawSchedule";
import { analyzeCalendar3DHistory } from "../client/src/lib/calendar3DPrediction";

export type Calendar3DAiSource = {
  targetDate: string;
  targetRow: string;
  deterministicEstimate: string;
  completedCurrentYearDraws: number;
  evidence: Array<{
    source: "sameRow" | "recentSameRow" | "currentYear";
    sampleCount: number;
    hotDigits: string[];
    candidate: string;
    values: string[];
  }>;
  visualMaps: Calendar3DVisualMap[];
};

export type Calendar3DVisualEvidenceGroup = {
  source: "sameRow" | "recentSameRow" | "currentYear";
  points: Array<{ row: string; year: number; value: string }>;
};

export type Calendar3DVisualMap = {
  index: number;
  candidate: string;
  visualEvidence: Calendar3DVisualEvidenceGroup[];
};

function digitMatchCount(value: string, candidate: string): number {
  return value.split("").reduce((total, digit, index) => total + (digit === candidate[index] ? 1 : 0), 0);
}

function selectVisualEvidencePoints(
  values: Array<{ row: string; year: number; value: string }>,
  candidate: string,
): Array<{ row: string; year: number; value: string }> {
  return [...values]
    .sort((left, right) => (
      digitMatchCount(right.value, candidate) - digitMatchCount(left.value, candidate)
      || right.year - left.year
      || left.row.localeCompare(right.row)
    ))
    .slice(0, 3)
    .sort((left, right) => left.year - right.year || left.row.localeCompare(right.row));
}

function selectDistinctEvidenceCandidates(
  evidence: Calendar3DAiSource["evidence"],
  anchorCandidate: string,
): string[] {
  const scores = new Map<string, number>();
  evidence.forEach((group, groupIndex) => {
    group.values.forEach((value, valueIndex) => {
      if (!/^\d{3}$/.test(value)) return;
      const proximity = digitMatchCount(value, anchorCandidate) * 100;
      const groupWeight = (3 - groupIndex) * 10;
      const recencyWeight = Math.max(0, 9 - Math.min(valueIndex, 9));
      scores.set(value, (scores.get(value) ?? 0) + proximity + groupWeight + recencyWeight);
    });
  });
  return Array.from(scores.entries())
    .sort(([leftValue, leftScore], [rightValue, rightScore]) => rightScore - leftScore || leftValue.localeCompare(rightValue))
    .map(([value]) => value)
    .slice(0, 10);
}

/** Builds a verified, compact input for AI; no client-provided numbers are trusted. */
export function buildCalendar3DAiSource(
  now = new Date(),
  currentYearRows: Record<string, string> = {},
): Calendar3DAiSource | null {
  const target: Calendar3DDrawTarget = getNextThaiLotteryDrawTarget(now);
  const matrix = Object.entries(currentYearRows).reduce((merged, [row, value]) => {
    if (!/^\d{2}$/.test(row) || !/^\d{3}$/.test(value)) return merged;
    return { ...merged, [row]: { ...(merged[row] ?? {}), 2026: value } };
  }, { ...calendar3DMatrix } as typeof calendar3DMatrix);
  const analysis = analyzeCalendar3DHistory(
    matrix,
    CALENDAR_YEARS,
    CALENDAR_ROWS,
    2026,
    target.isoDate,
  );

  if (!analysis) return null;
  const sourceEvidence = analysis.evidence.map((item) => ({
    source: item.key,
    candidate: item.candidate,
  }));
  const historicalSameRowCells = CALENDAR_YEARS
    .filter((year) => year >= 2000 && year < 2016)
    .map((year) => ({ row: analysis.targetRow, year, value: matrix[analysis.targetRow]?.[year] }))
    .filter((cell) => /^\d{3}$/.test(cell.value ?? ""))
    .map((cell) => ({ row: String(cell.row), year: Number(cell.year), value: cell.value! }));
  const recentSameRowCells = CALENDAR_YEARS
    .filter((year) => year >= 2016 && year < 2026)
    .map((year) => ({ row: analysis.targetRow, year, value: matrix[analysis.targetRow]?.[year] }))
    .filter((cell) => /^\d{3}$/.test(cell.value ?? ""))
    .map((cell) => ({ row: String(cell.row), year: Number(cell.year), value: cell.value! }));
  const currentYearCells = CALENDAR_ROWS
    .slice(0, Number(analysis.targetRow) - 1)
    .map((row) => ({ row, year: 2026, value: matrix[row]?.[2026] }))
    .filter((cell) => /^\d{3}$/.test(cell.value ?? ""))
    .map((cell) => ({ row: String(cell.row), year: Number(cell.year), value: cell.value! }));
  const sourceCells = [historicalSameRowCells, recentSameRowCells, currentYearCells];
  const evidence = analysis.evidence.map((item) => ({
    source: item.key,
    sampleCount: item.sampleCount,
    hotDigits: item.hotDigits,
    candidate: item.candidate,
    values: item.key === "sameRow"
      ? CALENDAR_YEARS.filter((year) => year < 2026).map((year) => matrix[analysis.targetRow]?.[year]).filter((value): value is string => /^\d{3}$/.test(value ?? ""))
      : item.key === "recentSameRow"
        ? CALENDAR_YEARS.filter((year) => year >= 2016 && year < 2026).map((year) => matrix[analysis.targetRow]?.[year]).filter((value): value is string => /^\d{3}$/.test(value ?? ""))
        : CALENDAR_ROWS.slice(0, Number(analysis.targetRow) - 1).map((row) => matrix[row]?.[2026]).filter((value): value is string => /^\d{3}$/.test(value ?? "")),
  }));
  const candidates = selectDistinctEvidenceCandidates(evidence, analysis.primaryPrediction);
  return {
    targetDate: analysis.targetDate,
    targetRow: analysis.targetRow,
    deterministicEstimate: analysis.primaryPrediction,
    completedCurrentYearDraws: analysis.completedCurrentYearDraws,
    evidence,
    visualMaps: candidates.map((candidate, index) => ({
      index: index + 1,
      candidate,
      visualEvidence: sourceEvidence.map((item, evidenceIndex) => ({
        source: item.source,
        points: selectVisualEvidencePoints(sourceCells[evidenceIndex] ?? [], candidate),
      })),
    })),
  };
}

export function makeCalendar3DAiCacheKey(source: Calendar3DAiSource): string {
  return JSON.stringify(source);
}
