export const LUCKY_BOX_TIME_SLOTS = [
  { id: 1, hour: 10, minute: 0, label: "မနက် ၁၀:၀၀", labelEn: "10:00 AM" },
  { id: 2, hour: 13, minute: 0, label: "နေ့လည် ၁:၀၀", labelEn: "1:00 PM" },
  { id: 3, hour: 16, minute: 0, label: "ညနေ ၄:၀၀", labelEn: "4:00 PM" },
  { id: 4, hour: 20, minute: 30, label: "ည ၈:၃၀", labelEn: "8:30 PM" },
] as const;

const MYANMAR_OFFSET_MS = 6.5 * 60 * 60 * 1000;
const SLOT_WINDOW_MINUTES = 30;

type Slot = (typeof LUCKY_BOX_TIME_SLOTS)[number];

function toMyanmarParts(now: Date) {
  const shifted = new Date(now.getTime() + MYANMAR_OFFSET_MS);
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate(),
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    second: shifted.getUTCSeconds(),
  };
}

function formatDateKey(year: number, month: number, day: number) {
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

export function getLuckyBoxSlotState(now = new Date()) {
  const parts = toMyanmarParts(now);
  const currentSeconds = (parts.hour * 60 * 60) + (parts.minute * 60) + parts.second;
  const currentMinutes = parts.hour * 60 + parts.minute;
  const activeSlot = LUCKY_BOX_TIME_SLOTS.find((slot) => {
    const openAt = slot.hour * 60 + slot.minute;
    return currentMinutes >= openAt && currentMinutes < openAt + SLOT_WINDOW_MINUTES;
  }) ?? null;
  const nextSlot = LUCKY_BOX_TIME_SLOTS.find((slot) => (slot.hour * 60 + slot.minute) * 60 > currentSeconds)
    ?? LUCKY_BOX_TIME_SLOTS[0];
  const nextSlotSeconds = (nextSlot.hour * 60 + nextSlot.minute) * 60;
  const secondsUntilNext = nextSlotSeconds > currentSeconds
    ? nextSlotSeconds - currentSeconds
    : (24 * 60 * 60) - currentSeconds + nextSlotSeconds;
  const dateKey = formatDateKey(parts.year, parts.month, parts.day);

  return {
    year: parts.year,
    month: parts.month,
    day: parts.day,
    activeSlot,
    nextSlot,
    secondsUntilNext,
    slotKey: activeSlot ? `${dateKey}-${activeSlot.id}` : null,
  };
}
