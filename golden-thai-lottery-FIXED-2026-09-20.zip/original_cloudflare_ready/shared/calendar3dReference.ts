/**
 * Screenshot-verified 2026 3D calendar prefix.
 *
 * Rows are chronological draw sequence numbers, not day-of-month values.
 * The reference currently covers draws 01-16 through 1 September 2026.
 */
export const CALENDAR_2026_REFERENCE = {
  "01": "972",
  "02": "629",
  "03": "563",
  "04": "866",
  "05": "009",
  "06": "514",
  "07": "612",
  "08": "077",
  "09": "387",
  "10": "770",
  "11": "184",
  "12": "495",
  "13": "214",
  "14": "479",
  "15": "615",
  "16": "212",
} as const;

export const CALENDAR_2026_REFERENCE_LAST_DRAW_DATE = "2026-09-01";
