# Gemini TTS Official Integration Notes

Sources checked on 2026-09-05:

- Gemini API speech generation: https://ai.google.dev/gemini-api/docs/speech-generation
- Google Cloud Gemini-TTS: https://docs.cloud.google.com/text-to-speech/docs/gemini-tts

## Confirmed facts

- Gemini TTS produces audio from exact text and is separate from the normal text-generating Gemini model and from browser `speechSynthesis`.
- The current Gemini API single-speaker example uses model `gemini-3.1-flash-tts-preview`, `response_format: { type: "audio" }`, and a selected voice such as `Kore`.
- The direct Gemini API requires a `GEMINI_API_KEY` sent through the `x-goog-api-key` header; this key must remain server-side.
- Burmese (`my` / `my-MM`) and Thai (`th` / `th-TH`) are listed as supported languages. Burmese is preview in the Cloud TTS language table; Thai is generally available there.
- Audio is returned as base64 PCM data at 24 kHz in the Gemini API example, so the application must add a WAV header or otherwise serve a browser-playable format.
- Gemini TTS is a preview capability, so the existing device/browser speech path should remain as a fallback if cloud generation is unavailable.
