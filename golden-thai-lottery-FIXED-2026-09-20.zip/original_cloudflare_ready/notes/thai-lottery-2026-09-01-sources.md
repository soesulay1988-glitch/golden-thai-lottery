# Thai Lottery 1 September 2026 Sources

Sources checked on 2026-09-05 while confirming that the next standard Thai Lottery draw is 16 September 2026:

| Source | URL | Confirmed point |
|---|---|---|
| The Thaiger | https://thethaiger.com/thai-lottery/01-09-2026 | The 1 September 2026 government lottery results page lists the draw date and its published first/last three-digit results. |
| Thairath | https://en.thairath.co.th/lottery/latest-result/2956583 | The page identifies the draw as 1 September 2026 and refers to the next 16 September 2026 draw. |

The Golden Thai **3D calendar sequence** is its own historical matrix of one three-digit value per chronological row. The user-supplied 2026 table shows row 16 as `212`; this was appended to the existing Golden Thai 2026 sequence without replacing rows 01–15. The historical analysis feature uses that matrix, not either of the general Thai government lottery's separate first/last-three-digit prize fields.
