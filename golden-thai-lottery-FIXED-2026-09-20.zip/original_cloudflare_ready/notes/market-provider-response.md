# Thai Stock 2D Provider Check

- Source: https://api.thaistock2d.com/live
- Checked: 2026-09-04 12:59:27 provider time.
- The `live` object returned a current market value: `set: "1,588.82"`, `value: "35,888.00"`, `time: "2026-09-04 12:59:25"`, `twod: "28"`, `date: "2026-09-04"`.
- The `result` array returned a verified 12:01 row: `set: "1,588.82"`, `value: "35,776.44"`, `twod: "26"`, `stock_date: "2026-09-04"`.
- The future 15:00 and 16:30 rows returned `--` for SET, VALUE, and 2D at the check time.
- Investigation focus: the provider supplies valid live and 12:01 values, so the client/server mapping or Myanmar-market time-window rule is preventing those values from rendering.

## Published UI Check

At the same market period, the public `/2d` page rendered `--` for both session rows and its current 2D display, despite the provider returning same-day live values and a verified 12:01 result. This confirms that the issue is reproducible in the public app and is not simply an inactive-session display at 13:27. The next diagnostic step is to inspect the browser's tRPC response and runtime errors, then correct the affected data path without displaying stale values outside active sessions.

## Confirmed Data Path and Time Mismatch

The public `myanmar2d.getLive` tRPC request returned HTTP 200 with the same provider data: a verified 12:01 row (`SET 1,588.82`, `VAL 35,776.44`, `2D 26`) and a current live value. The page used only the current `live` object for rendering and discarded the verified `results` rows, so the morning result disappeared during the 12:30–13:30 Myanmar break.

The scheduled database sync had also treated the provider timestamps as Thailand time. Its 12:05/12:15 and 16:35/16:45 jobs consequently ran 30 minutes early in Myanmar time, before the provider's 12:01 and 16:30 values were available. The repair changes the jobs to 12:05/12:15 and 16:35/16:45 Myanmar time, respectively, and renders the verified same-day provider row while the market board is open.

## Local Verification Follow-up

At 13:11 Myanmar time, the local backend returned HTTP 200 with a same-day verified morning result and current live value. The browser still showed the earlier blank UI after navigation, so the next check is a cache-bypassing reload of the development page. The source-level helper tests pass; this check separates a cached browser bundle from a remaining rendering issue.

After a cache-bypassing reload, the repaired local `/2d` board showed the verified 12:01 result `26`, `SET 1,588.82`, and `VAL 35,776.44`; the 16:30 row correctly remained `--`. The Home page navigation then initially showed its old cached bundle, so Home must be verified after the same cache-bypassing reload before the repair is checkpointed.

## Evening Market Check

At 13:32 Myanmar time, the provider returned a current evening live value: `SET 1,591.10`, `VAL 37,854.68`, and live `2D 04`; the 16:30 official result row was correctly still pending. The deployed public page was still loading its old blank data state during the initial capture, so a cache-bypassing reload and direct public tRPC response check are required to distinguish a loading/cache delay from a code-path fault.

## History and Schedule Follow-up

The history API initially returned an empty dataset because the previous incorrectly timed jobs had not saved the morning result. The verified 2026-09-04 12:01 provider row (`2D 26`, `SET 1,588.82`, `VAL 35,776.44`) has now been restored to the real history table with an idempotent database repair. The local history API returns that record.

The 2D schedule UI now has explicit Time, SET, VAL, and 2D columns and is wired to show each settled result or the active session's current live SET/VAL. The first local capture after code editing still used cached data; a cache-bypassing reload is the final visual check.

After cache-bypassing reload at the active evening session, the local 2D board showed the morning verified row (`SET 1,588.82`, `VAL 35,776.44`, `2D 26`) and the current evening row (`SET 1,591.20`, `VAL 38,526.35`, 16:30 result pending). The schedule table displayed the same Time, SET, VAL, and 2D columns. Opening “မှတ်တမ်းနှင့် အသေးစိတ်ကြည့်ရန်” showed the restored 60-day history row as `04/09/26`, Friday, morning `26`, evening `--`.

## Reference Schedule Behavior

The requested schedule behavior is now verified locally. At the active evening session, the table contains only Time, SET, and VAL columns. The 12:01 row displays `--` for both market values, while the 16:30 row shows the current provider SET and VAL. The separate result board retains the morning verified 2D result and the active live two-digit value, exactly separating official results from active market tracking.

## Current-week Daily Two-slot Display

The current-week panel now allocates two vertically stacked result slots for every weekday: morning first, evening second. During the active afternoon before 16:30, the Friday column renders the verified morning `26` in the first slot and `--` in the pending evening slot; all remaining weekdays correctly display two pending slots. This was verified after the live queries completed on the local 2D page.

## Prediction Card Separation

The cards previously labeled Hot now use the explicit Burmese label “ဟောဂဏန်း” for the morning and evening sessions. Before the visitor requests a prediction, all three slots remain pending; no official result is copied into either prediction card. The verified 12:01 result `26` continues to appear only in the official result board, history, and current-week result panel.

After the user selects “ခန့်မှန်းဂဏန်း ကြည့်ရန်”, the verified prediction procedure returns three distinct morning and three distinct evening numbers. The two “ဟောဂဏန်း” cards then display those predictions while the official 12:01 result remains confined to the result board, history, and current-week panel. The existing in-app statement that predictions are not guaranteed remains visible.

## Schedule Morning Result Persistence

The schedule now keeps the current-day verified morning SET `1,588.82` and VAL `35,776.44` visible after the morning session has settled. The evening row remains pending only while its live or verified session data is unavailable; once live values are received during the afternoon, that row independently renders the current SET and VAL. Both rows clear automatically when the Myanmar date changes or on the weekend because their sources are current-day guarded.

At the latest provider check, the upstream live endpoint returned a current-day live object containing SET `1,594.88`, VAL `48,823.99`, and 2D `83`, while retaining the verified 12:01 row. The local page's first render was still showing query placeholders, so visual verification must wait for tRPC queries to complete rather than evaluating the initial loading frame.

## Home Market Readability

The Home yellow 2D card now allocates more horizontal space to its center SET/VAL column and uses 15px monospace market figures with 11px labels. The local phone-width view confirms that both morning and live evening market pairs remain readable without overlapping the left result slots or the right live-2D box.

## Home Morning/Evening Divider

The yellow Home 2D card now uses a consistent gold horizontal divider between its morning and evening result rows and between their matching SET/VAL rows. The divider separates the two sessions without crossing the live 2D box, so the four market figures remain visibly grouped with their correct session.

## Home Morning/Evening Market Colors

The Home card now renders both the SET/VAL labels and figures in dark blue for the morning market and dark red for the evening market. The colors mirror the existing morning/evening result labels and remain legible against the yellow card, while the divider preserves visual separation between the two session pairs.

## Daily AI Prediction Preview — 04 Sep 2026

The local board refreshed after the official afternoon provider result and displayed verified morning `26` and evening `81` with their current-day SET/VAL values. Before the new production Heartbeat jobs are deployed, the persisted daily-prediction query deliberately returns no value and the two prediction cards remain pending rather than fabricating numbers.

The daily AI prediction procedure was directly validated with the selected `gpt-5-mini` model. It returned three valid two-digit morning candidates and three valid two-digit evening candidates from verified 2D/SET/VAL history, plus a Burmese no-guarantee disclaimer. Production persistence is intentionally not run during this after-result verification; the two idempotent weekday jobs will create the stored morning and evening values at 10:30 and 15:30 Myanmar time after deployment.

The two new scheduled callback paths were also verified to reject a direct anonymous POST with HTTP 403. Only a Heartbeat cron identity can trigger model usage and persistent daily prediction generation.

## Lucky Box Scheduled Opening

The local Lucky Box page was checked during a closed slot. It showed the next Myanmar opening as 8:30 PM, displayed a live 1:28:31 countdown, and rendered the box as locked rather than opening it early. The scheduled button state is sourced from the server slot query.

## Same-day Market Values Until Midnight

At 8:05 PM Myanmar time, after the market had closed, the local Myanmar 2D page still showed the verified same-day morning SET `1,588.82` / VAL `35,776.44` and evening SET `1,595.58` / VAL `63,421.60`, together with their official 2D results `26` and `81`. The shared date guard clears these figures on the next Myanmar date and during weekends.

## Home Lucky Box Closed-Slot Badge

At 8:07 PM Myanmar time, the Home Lucky Box card showed the next opening as 8:30 PM with a live countdown. The red Burmese `ဆုလက်ဆောင်` availability badge was absent while the slot was closed. The card's small static `GIFT` category tag remains unchanged.
