# Home Live 2D Language Layout Validation

Date: 2026-09-04

The Home Live 2D card was checked in Myanmar and English modes after the layout change. In English, the widened session column keeps `Morning` and `Evening` separate from their two-digit results. The SET and VAL labels remain on the left of the market column, while their numeric values are right-aligned. Both morning and evening market rows remain visually separated.

Thai and Myanmar modes were also checked. The localized session labels fit without crossing into the two-digit result slot, and each SET/VAL numeric value remains aligned to the right edge of its market row.

The Home card was rechecked after the inner-panel refinement. Its outer market panel border, the two vertical column separators, the morning/evening row dividers, and the 2D result box border are all visibly thicker while retaining the yellow card layout and readable spacing.
