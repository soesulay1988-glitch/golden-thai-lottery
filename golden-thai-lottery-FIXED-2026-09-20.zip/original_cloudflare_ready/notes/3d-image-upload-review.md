# 3D image upload review

The reference-style automatic 3D history sheets are no longer rendered in the public interface. On the phone-width anonymous review, the Home card now reads “3D အထောက်အထားပုံ” and leads to a simple empty-state image viewer. It does not expose upload controls to viewers. The route explains that the next image will automatically appear after it is posted.

The upload endpoint accepts JPG, PNG, and WEBP images up to 3 MB. Upload, replacement, and removal are server-enforced for the sole owner-admin address. Tapping a posted image opens a larger full-screen viewer; the regular image card remains sized for a phone screen.
